'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  image_emoji: string;
  verification_status: string;
  keccak_hash: string | null;
  category_name: string | null;
  cover_image_url: string | null;
  expiry?: { state: string; daysRemaining: number | null; textEn: string | null; textBn: string | null };
}

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => {
      fetch(`/api/products?search=${encodeURIComponent(query)}`)
        .then((r) => r.json())
        .then((res) => setProducts(res.data || []))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [query]);

  return (
    <div>
      <section className="bg-gradient-to-b from-ink to-[#142238] text-white px-6 py-20">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 bg-secondary/15 text-[#4ADE80] px-3 py-1.5 rounded-full text-xs font-bold mb-5 font-mono">
              ⛓ Polygon-anchored · Keccak-256
            </div>
            <h1 className="font-display text-5xl leading-tight mb-4">Buy genuine FMCG products with confidence</h1>
            <p className="text-slate-400 max-w-md mb-7 leading-relaxed">
              AI reads every label. A real cryptographic fingerprint gets generated for each product. You verify, we recompute and compare — deterministically.
            </p>
            <div className="flex gap-3">
              <a href="#products" className="btn btn-secondary px-6 py-3.5">Shop Now</a>
              <Link href="/seller" className="btn px-6 py-3.5 border border-white/25 text-white">Become a Seller</Link>
            </div>
          </div>
        </div>
      </section>

      <section id="products" className="max-w-6xl mx-auto px-6 -mt-10 relative pb-16">
        <div className="card p-4 shadow-xl">
          <input
            className="input"
            placeholder="Search products, brands or categories..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>

        <h2 className="font-display text-2xl my-8">Explore Verified Products</h2>

        {loading ? (
          <div className="text-muted text-sm">Loading products…</div>
        ) : products.length === 0 ? (
          <div className="text-muted text-sm">No matching products found.</div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {products.map((p) => (
              <Link key={p.id} href={`/product/${p.id}`} className="card p-4 hover:-translate-y-1 transition-transform block">
                <div className="h-28 flex items-center justify-center text-5xl bg-slate-100 rounded-xl mb-3 overflow-hidden">
                  {p.cover_image_url ? (
                    <img src={p.cover_image_url} alt={p.name} className="w-full h-full object-cover" />
                  ) : (
                    p.image_emoji
                  )}
                </div>
                <div className="flex justify-between items-start mb-1">
                  <span className="text-xs text-muted font-semibold">{p.brand}</span>
                  {p.verification_status === 'VERIFIED' ? (
                    <span className="text-[11px] font-semibold text-[#16803C] bg-secondary/10 rounded-full px-2 py-0.5">✓ Verified</span>
                  ) : (
                    <span className="text-[11px] font-semibold text-[#B45309] bg-warning/10 rounded-full px-2 py-0.5">Pending</span>
                  )}
                </div>
                <div className="font-bold text-sm mb-2 leading-snug">{p.name}</div>
                <div className="font-mono font-bold text-primary">৳{p.price}</div>
                {p.expiry && (p.expiry.state === 'NEAR_EXPIRY' || p.expiry.state === 'EXPIRES_TODAY') && (
                  <div className="text-[11px] font-semibold text-[#B45309] mt-1" lang="bn">{p.expiry.textBn}</div>
                )}
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
