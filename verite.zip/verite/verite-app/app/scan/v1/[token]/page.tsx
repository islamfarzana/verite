'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';

// Public page opened by scanning the QR code on a pack (no login needed).
// It states only what the system actually checked: the code's registration and status,
// plus a warning when the code has been scanned unusually often. It never says a product
// is "genuine" or "fake".

type ScanData = {
  status: 'VALID' | 'SUSPICIOUS_ACTIVITY' | 'REVOKED' | 'UNKNOWN_IDENTIFIER' | 'UNAVAILABLE' | 'RATE_LIMITED' | 'ERROR';
  scope?: 'UNIT' | 'BATCH';
  warning?: boolean;
  message: string;
  guidance?: string;
  product?: { name: string; brand: string | null; batchNumber: string | null; manufacturingDate: string | null; expiryDate: string | null; productPath: string };
  batchStatus?: { recalled: boolean; expired: boolean; expiryText: { en: string | null; bn: string | null }; notices: { code: string; en: string; bn: string }[] };
};

const LOOK: Record<string, { title: string; box: string }> = {
  VALID: { title: 'Registered code', box: 'border-[#16803C] bg-[#16803C]/5' },
  SUSPICIOUS_ACTIVITY: { title: 'Possible cloned code / unusual scan activity', box: 'border-[#B45309] bg-[#B45309]/10' },
  REVOKED: { title: 'Revoked code', box: 'border-[#B91C1C] bg-[#B91C1C]/5' },
  UNKNOWN_IDENTIFIER: { title: 'Code not recognised', box: 'border-slate-300 bg-slate-50' },
  UNAVAILABLE: { title: 'Could not check right now', box: 'border-slate-300 bg-slate-50' },
  RATE_LIMITED: { title: 'Too many requests', box: 'border-slate-300 bg-slate-50' },
  ERROR: { title: 'Could not check', box: 'border-slate-300 bg-slate-50' },
};

export default function ScanPage({ params }: { params: { token: string } }) {
  const [data, setData] = useState<ScanData | null>(null);
  // React StrictMode runs effects twice in development; the ref makes sure one page view = one scan event.
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    fetch('/api/scan', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: params.token }) })
      .then((r) => r.json())
      .then((json) => setData(json.data as ScanData))
      .catch(() => setData({ status: 'UNAVAILABLE', message: 'The code could not be checked right now. This says nothing about the product. Please try again later.' }));
  }, [params.token]);

  if (!data) return <div className="max-w-lg mx-auto px-6 py-16 text-muted">Checking code…</div>;
  const look = LOOK[data.status] || LOOK.ERROR;

  return (
    <div className="max-w-lg mx-auto px-6 py-12">
      <div className={`rounded-2xl border-2 p-6 ${look.box}`}>
        <div className="font-display text-xl mb-2">{look.title}</div>
        {data.scope && (
          <div className="text-xs font-semibold text-muted mb-2">{data.scope === 'UNIT' ? 'Unit code (one pack)' : 'Batch code (shared by a production batch)'}</div>
        )}
        <p className="text-sm">{data.message}</p>
        {data.guidance && <p className="text-sm mt-3 font-semibold">{data.guidance}</p>}
      </div>

      {data.batchStatus && data.batchStatus.notices.length > 0 && (
        <div className="rounded-2xl border-2 border-[#B91C1C] bg-[#B91C1C]/5 p-4 mt-5 text-sm">
          {data.batchStatus.notices.map((n) => (
            <div key={n.code}><b lang="bn">{n.bn}</b> <span className="text-muted">{n.en}</span></div>
          ))}
        </div>
      )}

      {data.product && (
        <div className="card p-5 mt-5 text-sm space-y-1.5">
          <div className="font-bold">{data.product.name}</div>
          {data.product.brand && <div className="text-muted">{data.product.brand}</div>}
          {data.product.batchNumber && <div><span className="text-muted">Batch: </span>{data.product.batchNumber}</div>}
          {data.product.manufacturingDate && <div><span className="text-muted">Manufactured: </span>{data.product.manufacturingDate}</div>}
          {data.product.expiryDate && <div><span className="text-muted">Expires: </span>{data.product.expiryDate}</div>}
          {data.batchStatus?.expiryText?.bn && !data.batchStatus.expired && <div className="text-[#B45309] font-semibold" lang="bn">{data.batchStatus.expiryText.bn}</div>}
          <Link href={data.product.productPath} className="inline-block mt-2 text-primary font-semibold">
            Open the product page and run the blockchain check →
          </Link>
          <Link href={`${data.product.productPath}/check`} className="block mt-1 text-primary font-semibold">
            📷 Compare the label on your pack (প্যাকেট যাচাই) →
          </Link>
        </div>
      )}

      <p className="text-xs text-muted mt-6 leading-relaxed">
        What this check means: it confirms the code is registered by the seller and has not been revoked. A QR code can be copied, so a
        registered code alone is not proof of authenticity. Repeated scans raise a warning, which is a signal, not a verdict.
      </p>
    </div>
  );
}
