import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { getSession } from '@/lib/session';
import { ProtectionError } from '@/lib/protection/errors';
import { protectionErrorResponse, readJson, requireRole } from '@/lib/protection/http';

// A buyer asks for a label check result to be reviewed (POST {action:'REQUEST_REVIEW'}), and an admin
// records the outcome (POST {action:'RESOLVE', note}). Anonymous checks can't request review: the
// requester must be signed in so the admin can see the request came from a real account.
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await readJson(req);
    const now = new Date().toISOString();
    if (body.action === 'REQUEST_REVIEW') {
      const s = await getSession(req);
      if (!s) throw new ProtectionError('UNAUTHENTICATED', 'Sign in to send this result for review.');
      const r = db.prepare('UPDATE label_checks SET review_requested_at = ? WHERE id = ? AND checker_user_id = ? AND review_requested_at IS NULL').run(now, params.id, s.id);
      if (!Number(r.changes)) {
        const own = db.prepare('SELECT review_requested_at FROM label_checks WHERE id = ? AND checker_user_id = ?').get(params.id, s.id) as any;
        if (!own) throw new ProtectionError('NOT_FOUND', 'Check not found.');
      }
      return NextResponse.json({ success: true, message: 'Sent for review.', messageBn: 'যাচাইয়ের জন্য পাঠানো হয়েছে।' });
    }
    if (body.action === 'RESOLVE') {
      const admin = await requireRole(req, ['ADMIN']);
      const note = typeof body.note === 'string' ? body.note.slice(0, 300) : null;
      const r = db.prepare('UPDATE label_checks SET reviewed_at = ?, reviewed_by = ?, review_note = ? WHERE id = ? AND review_requested_at IS NOT NULL AND reviewed_at IS NULL')
        .run(now, admin.id, note, params.id);
      if (!Number(r.changes)) throw new ProtectionError('NOT_FOUND', 'No open review request with this id.');
      return NextResponse.json({ success: true, message: 'Review recorded.' });
    }
    throw new ProtectionError('INVALID', 'Unknown action.');
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
