import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { loadProtectionConfig } from '@/lib/protection/config';
import { addToCart, getCart, mergeCart, removeFromCart, setCartQuantity } from '@/lib/protection/cart';
import { protectionErrorResponse, readJson, requireRole } from '@/lib/protection/http';

// The buyer's cart, stored in the database (cart_items) — it survives closing the browser, signing in on
// another device and restarting the server. Every change re-checks that the product can still be sold
// (recall, expiry, MRP, stock): see lib/protection/sellability.ts.
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const buyer = await requireRole(req, ['BUYER']);
    return NextResponse.json({ success: true, data: getCart(db as any, buyer.id, new Date(), loadProtectionConfig()) });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}

// { productId, quantity }            -> add to the line
// { items: [{productId, quantity}] } -> one-time import of an old browser cart
export async function POST(req: NextRequest) {
  try {
    const buyer = await requireRole(req, ['BUYER']);
    const body = await readJson(req);
    const now = new Date();
    const cfg = loadProtectionConfig();
    if (Array.isArray(body.items)) {
      const r = mergeCart(db as any, buyer.id, body.items, now, cfg);
      return NextResponse.json({ success: true, data: { ...r, cart: getCart(db as any, buyer.id, now, cfg) } });
    }
    if (typeof body.productId !== 'string') return NextResponse.json({ success: false, message: 'productId is required' }, { status: 422 });
    const quantity = addToCart(db as any, buyer.id, body.productId, body.quantity ?? 1, now, cfg);
    return NextResponse.json({ success: true, message: 'Added to cart', data: { quantity, cart: getCart(db as any, buyer.id, now, cfg) } }, { status: 201 });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}

// { productId, quantity } -> set the exact quantity
export async function PATCH(req: NextRequest) {
  try {
    const buyer = await requireRole(req, ['BUYER']);
    const body = await readJson(req);
    if (typeof body.productId !== 'string') return NextResponse.json({ success: false, message: 'productId is required' }, { status: 422 });
    const now = new Date();
    const cfg = loadProtectionConfig();
    setCartQuantity(db as any, buyer.id, body.productId, body.quantity, now, cfg);
    return NextResponse.json({ success: true, data: getCart(db as any, buyer.id, now, cfg) });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}

// ?productId=... removes one line; no parameter empties the cart.
export async function DELETE(req: NextRequest) {
  try {
    const buyer = await requireRole(req, ['BUYER']);
    const productId = req.nextUrl.searchParams.get('productId');
    removeFromCart(db as any, buyer.id, productId);
    return NextResponse.json({ success: true, data: getCart(db as any, buyer.id, new Date(), loadProtectionConfig()) });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
