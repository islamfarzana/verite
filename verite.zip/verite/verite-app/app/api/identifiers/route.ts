import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import db from '@/lib/db';
import { getSession } from '@/lib/session';
import { getPublicBaseUrl } from '@/lib/trace/config';
import { buildScanUrl } from '@/lib/trace/token';
import { issueIdentifiers, listIdentifiers } from '@/lib/trace/service';
import { traceErrorResponse } from '@/lib/trace/http';

export const dynamic = 'force-dynamic';

const issueSchema = z.object({
  productId: z.string().min(1),
  scope: z.enum(['UNIT', 'BATCH']),
  quantity: z.number().int().optional(),
  requestId: z.string(),
});

async function actorFrom(req: NextRequest) {
  const s = await getSession(req);
  if (!s || (s.role !== 'SELLER' && s.role !== 'ADMIN')) return null;
  return { id: s.id, role: s.role } as const;
}

const withScanUrl = (list: ReturnType<typeof listIdentifiers>) => {
  const base = getPublicBaseUrl();
  return list.map((i) => ({ ...i, scanUrl: buildScanUrl(base, i.token) }));
};

export async function GET(req: NextRequest) {
  const actor = await actorFrom(req);
  if (!actor) return NextResponse.json({ success: false, message: 'Seller or admin authentication required' }, { status: 401 });
  const productId = req.nextUrl.searchParams.get('productId');
  if (!productId) return NextResponse.json({ success: false, message: 'productId is required' }, { status: 422 });
  try {
    return NextResponse.json({ success: true, data: withScanUrl(listIdentifiers(db as any, productId, actor)) });
  } catch (err) {
    return traceErrorResponse(err);
  }
}

export async function POST(req: NextRequest) {
  const actor = await actorFrom(req);
  if (!actor) return NextResponse.json({ success: false, message: 'Seller or admin authentication required' }, { status: 401 });
  const parsed = issueSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ success: false, message: 'Validation error', errors: parsed.error.issues }, { status: 422 });
  try {
    const result = issueIdentifiers(db as any, { ...parsed.data, actor });
    const base = getPublicBaseUrl();
    return NextResponse.json(
      { success: true, created: result.created, data: result.identifiers.map((i) => ({ ...i, scanUrl: buildScanUrl(base, i.token) })) },
      { status: result.created ? 201 : 200 }
    );
  } catch (err) {
    return traceErrorResponse(err);
  }
}
