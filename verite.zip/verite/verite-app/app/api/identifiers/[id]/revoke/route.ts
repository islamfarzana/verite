import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import db from '@/lib/db';
import { getSession } from '@/lib/session';
import { revokeIdentifier } from '@/lib/trace/service';
import { traceErrorResponse } from '@/lib/trace/http';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const s = await getSession(req);
  if (!s || (s.role !== 'SELLER' && s.role !== 'ADMIN')) {
    return NextResponse.json({ success: false, message: 'Seller or admin authentication required' }, { status: 401 });
  }
  const parsed = z.object({ reason: z.string() }).safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ success: false, message: 'A revocation reason is required.' }, { status: 422 });
  try {
    const out = revokeIdentifier(db as any, { identifierId: params.id, reason: parsed.data.reason, actor: { id: s.id, role: s.role } });
    return NextResponse.json({ success: true, data: out });
  } catch (err) {
    return traceErrorResponse(err);
  }
}
