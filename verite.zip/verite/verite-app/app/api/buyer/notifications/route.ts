import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { protectionErrorResponse, readJson, requireRole } from '@/lib/protection/http';
import { buyerUnreadCount, listBuyerNotifications, markBuyerNotificationsRead } from '@/lib/protection/recall';

// The signed-in buyer's own in-app notices (batch recalls). In-app only: no email/SMS is sent.
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const buyer = await requireRole(req, ['BUYER']);
    return NextResponse.json({ success: true, data: { notifications: listBuyerNotifications(db as any, buyer.id), unread: buyerUnreadCount(db as any, buyer.id) } });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}

// { ids: [...] } or { all: true }
export async function POST(req: NextRequest) {
  try {
    const buyer = await requireRole(req, ['BUYER']);
    const body = await readJson(req);
    const ids = body.all === true ? 'all' : Array.isArray(body.ids) ? body.ids.filter((x: unknown) => typeof x === 'string') : [];
    const marked = markBuyerNotificationsRead(db as any, buyer.id, ids, new Date());
    return NextResponse.json({ success: true, data: { marked, unread: buyerUnreadCount(db as any, buyer.id) } });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
