import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { getSession } from '@/lib/session';
import { newId } from '@/lib/ids';
import { simulateChainWrite } from '@/lib/blockchain';
import { chainWriteConfigured, chainNetworkName, readFromChain, registerOnChain, explorerTxUrl } from '@/lib/chain';
import { identityErrorResponse, identityRuntime } from '@/lib/identity/http';
import { publicIdentityFor } from '@/lib/identity/public';
import { finalizeRegistration, prepareRegistration } from '@/lib/identity/registration';
import { tx } from '@/lib/identity/onboarding';
import { loadProtectionConfig } from '@/lib/protection/config';
import { audit, protectionFor } from '@/lib/protection/sellability';

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const row = db
    .prepare(
      `SELECT p.*, u.name as seller_name, bc.keccak_hash, bc.tx_hash, bc.block_number
       FROM products p
       LEFT JOIN users u ON u.id = p.seller_id
       LEFT JOIN blockchain_records bc ON bc.product_id = p.id
       WHERE p.id = ?`
    )
    .get(params.id);

  if (!row) return NextResponse.json({ success: false, message: 'Product not found' }, { status: 404 });

  // --- Product_Image_Gallery_Extension.md: attach the uploaded gallery.
  // Only extends the response of the existing endpoint — the query above
  // and everything else about this route is unchanged.
  const images = db
    .prepare('SELECT image_url FROM product_images WHERE product_id = ? ORDER BY sort_order')
    .all(params.id)
    .map((r: any) => r.image_url);

  // --- Seller onboarding & licence verification: public, minimised identity summary
  // (names and statuses only; no emails, internal IDs or licence numbers).
  const identity = publicIdentityFor(db as any, params.id);

  // --- v4: Bangla name and which images are enhanced versions of the seller's photo.
  const label = db.prepare('SELECT name_bn FROM product_label_extractions WHERE product_id = ?').get(params.id) as { name_bn: string | null } | undefined;
  const imageLabels = Object.fromEntries(
    (db.prepare('SELECT image_url, kind FROM product_image_meta WHERE product_id = ?').all(params.id) as { image_url: string; kind: string }[])
      .map((r) => [r.image_url, r.kind])
  );

  // --- v5 buyer protection: can it be bought now, and why not (recall > expiry > MRP > stock).
  const prot = protectionFor(db as any, params.id, new Date(), loadProtectionConfig());
  const protection = prot && {
    sellable: prot.sellable,
    blockers: prot.blockers,
    expiry: prot.expiry,
    mrp: prot.mrp,
    priceDecision: prot.pricing.decision,
    recall: prot.recall && { status: prot.recall.status, reasonCode: prot.recall.reasonCode, publicMessage: prot.recall.publicMessage, createdAt: prot.recall.createdAt },
  };

  return NextResponse.json({ success: true, data: { ...row, images, identity, nameBn: label?.name_bn ?? null, imageLabels, protection } });
}

// Publish: generates the real Keccak-256 fingerprint and anchors it (simulated write).
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const payload = await getSession(req);
  if (!payload || payload.role !== 'SELLER') {
    return NextResponse.json({ success: false, message: 'Seller authentication required' }, { status: 401 });
  }

  const product = db.prepare('SELECT * FROM products WHERE id = ? AND seller_id = ?').get(params.id, payload.id) as
    | Record<string, any>
    | undefined;
  if (!product) return NextResponse.json({ success: false, message: 'Product not found' }, { status: 404 });

  // v5 buyer protection: a recalled, expired, undated or above-MRP batch is never published.
  {
    const now = new Date();
    const prot = protectionFor(db as any, product.id, now, loadProtectionConfig());
    const blocking = (prot?.blockers || []).filter((b) => b.code !== 'NOT_PUBLISHED' && b.code !== 'OUT_OF_STOCK');
    if (blocking.length) {
      tx(db as any, () => audit(db as any, { actorId: payload.id, actorRole: 'SELLER', action: 'PUBLISH_BLOCKED', productId: product.id, after: { blockers: blocking.map((b) => b.code) } }, now));
      return NextResponse.json(
        { success: false, code: blocking[0].code, message: `${blocking[0].en} The product was saved as a draft and was not published.`, messageBn: blocking[0].bn, blockers: blocking },
        { status: 409 }
      );
    }
  }

  // Seller onboarding & licence verification: the centralised eligibility policy decides whether
  // this product may be registered, and the hash (schema v2) commits to stable seller/manufacturer
  // entity references instead of the seller's email. See docs/changes/seller-licence-verification/.
  let prepared: Awaited<ReturnType<typeof prepareRegistration>>;
  try {
    const rt = identityRuntime();
    prepared = await prepareRegistration(db as any, { id: payload.id, role: payload.role }, product.id, { adapter: rt.adapter, policy: rt.policy });
  } catch (err) {
    return identityErrorResponse(err);
  }
  if (!prepared.ok) {
    return NextResponse.json(
      { success: false, code: prepared.code, message: `${prepared.message} The product was saved as a draft and was not published.` },
      { status: 409 }
    );
  }
  const hash = prepared.hash;
  // Real chain when configured (CHAIN_* env vars), simulated ledger otherwise.
  let txHash = '';
  let blockNumber = 0;
  let network = 'polygon-amoy-simulated';
  if (chainWriteConfigured()) {
    try {
      const existing = await readFromChain(product.id);
      if (existing && existing.hash === hash.toLowerCase()) {
        // Already registered with this exact fingerprint (e.g. publish retried): reuse it.
        const prev = db.prepare('SELECT tx_hash, block_number FROM blockchain_records WHERE product_id = ?').get(product.id) as
          | Record<string, any>
          | undefined;
        txHash = prev?.tx_hash || '';
        blockNumber = prev?.block_number || 0;
      } else if (existing) {
        return NextResponse.json(
          { success: false, message: 'A different fingerprint is already registered on-chain for this product.' },
          { status: 409 }
        );
      } else {
        ({ txHash, blockNumber } = await registerOnChain(product.id, hash));
      }
      network = chainNetworkName();
    } catch (err) {
      console.error('Blockchain registration failed', err);
      return NextResponse.json(
        { success: false, message: 'Blockchain registration failed. The product was not published; please try again.' },
        { status: 502 }
      );
    }
  } else {
    ({ txHash, blockNumber } = simulateChainWrite(hash));
  }

  const registration = prepared;
  finalizeRegistration(db as any, product.id, registration, () => {
    db.prepare(
      `INSERT INTO blockchain_records (id, product_id, keccak_hash, tx_hash, block_number, network)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(product_id) DO UPDATE SET keccak_hash=excluded.keccak_hash, tx_hash=excluded.tx_hash, block_number=excluded.block_number, network=excluded.network`
    ).run(newId('bcr'), product.id, hash, txHash, blockNumber, network);

    db.prepare("UPDATE products SET status='PUBLISHED', verification_status='VERIFIED' WHERE id = ?").run(product.id);
  });

  return NextResponse.json({ success: true, message: 'Product published and anchored on-chain', data: { hash, txHash, blockNumber, network, explorerUrl: explorerTxUrl(txHash), hashSchemaVersion: 2, registrationBasis: registration.basis } });
}
