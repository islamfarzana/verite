import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { chainReadConfigured, explorerTxUrl, isRealNetwork, readFromChain } from '@/lib/chain';
import { newId } from '@/lib/ids';
import { getSession } from '@/lib/session';
import { publicIdentityFor } from '@/lib/identity/public';
import { verificationHash } from '@/lib/identity/registration';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const product = db
    .prepare(`SELECT p.*, u.email as seller_email FROM products p LEFT JOIN users u ON u.id = p.seller_id WHERE p.id = ?`)
    .get(params.id) as Record<string, any> | undefined;

  if (!product) return NextResponse.json({ success: false, message: 'Product not found' }, { status: 404 });

  const record = db.prepare('SELECT * FROM blockchain_records WHERE product_id = ?').get(params.id) as
    | Record<string, any>
    | undefined;

  if (!record) {
    return NextResponse.json({ success: true, data: { verified: false, reason: 'No blockchain record found for this product.' } });
  }

  // Recompute the fingerprint from the CURRENT database row. If anyone has
  // tampered with the product's data since publishing, this will not match
  // the fingerprint that was anchored at publish time.
  // Products registered with hash schema v2 are recomputed from the product row plus the frozen
  // seller/manufacturer identity snapshot; legacy records keep the original v1 rule (seller email).
  const { version: hashSchemaVersion, hash: recomputed } = verificationHash(db as any, product);
  const identity = publicIdentityFor(db as any, product.id);

  // Where does the trusted fingerprint come from?
  //  - Products registered on a real network: read straight from the smart
  //    contract, NOT from SQLite, so editing the database cannot hide tampering.
  //  - Demo products from the seed script (simulated ledger): the local record.
  let expectedHash: string = record.keccak_hash;
  let source: 'blockchain' | 'simulated-ledger' = 'simulated-ledger';
  let registrar: string | null = null;
  let anchoredAt: number | null = null;
  let verified: boolean;
  let reason: string | undefined;

  const buyer = await getSession(req);
  const log = (ok: boolean) =>
    db
      .prepare('INSERT INTO verification_logs (id, product_id, buyer_id, result) VALUES (?, ?, ?, ?)')
      .run(newId('vlog'), product.id, buyer?.id || null, ok ? 'VERIFIED' : 'FAILED');

  if (isRealNetwork(record.network) && chainReadConfigured()) {
    try {
      const onChain = await readFromChain(product.id);
      source = 'blockchain';
      if (!onChain) {
        log(false);
        return NextResponse.json({
          success: true,
          data: { verified: false, source, reason: 'No record for this product was found on the blockchain.' },
        });
      }
      expectedHash = onChain.hash;
      registrar = onChain.registrar;
      anchoredAt = onChain.timestamp;
    } catch (err) {
      // A network problem is not evidence of tampering: do not log a failure.
      console.error('Blockchain read failed', err);
      return NextResponse.json({
        success: true,
        data: {
          verified: false,
          networkError: true,
          reason: 'The blockchain network could not be reached, so this product could not be checked. Please try again.',
        },
      });
    }
  }

  verified = recomputed.toLowerCase() === String(expectedHash).toLowerCase();
  if (!verified) reason = 'The fingerprint of the current product data does not match the registered fingerprint.';
  log(verified);

  return NextResponse.json({
    success: true,
    data: {
      verified,
      reason,
      source,
      onChainHash: expectedHash,
      recomputedHash: recomputed,
      txHash: record.tx_hash,
      blockNumber: record.block_number,
      network: record.network,
      registrar,
      anchoredAt,
      explorerUrl: source === 'blockchain' ? explorerTxUrl(record.tx_hash) : null,
      hashSchemaVersion,
      // Separate claims, shown separately: hash integrity (above) is not seller approval,
      // and neither is licence validity or physical authenticity.
      identity,
    },
  });
}
