import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import db from '@/lib/db';
import { tx } from '@/lib/identity/onboarding';
import { loadProtectionConfig } from '@/lib/protection/config';
import { ProtectionError } from '@/lib/protection/errors';
import { protectionErrorResponse, readJson, requireRole } from '@/lib/protection/http';
import { dbTakaToPaisa, parseTakaToPaisa, paisaToTakaNumber } from '@/lib/protection/money';
import { evaluatePrice } from '@/lib/protection/pricing';
import { audit, loadProduct } from '@/lib/protection/sellability';

// Seller changes the selling price and/or stock of their OWN listing. The MRP, batch, dates and every
// verification/status field are NOT accepted here (strict schema: mass assignment is rejected).
// The price-above-MRP guard runs on the server for every change.
export const dynamic = 'force-dynamic';

const schema = z.object({
  price: z.union([z.number(), z.string()]).optional(),
  stock: z.number().int().min(0).max(100000).optional(),
}).strict();

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const seller = await requireRole(req, ['SELLER']);
    const parsed = schema.safeParse(await readJson(req));
    if (!parsed.success) {
      return NextResponse.json({ success: false, message: 'Only price and stock can be changed here.', errors: parsed.error.issues }, { status: 422 });
    }
    const p = loadProduct(db as any, params.id);
    if (!p || p.seller_id !== seller.id) throw new ProtectionError('NOT_FOUND', 'Product not found.');
    const now = new Date();
    const cfg = loadProtectionConfig();

    let newPricePaisa = dbTakaToPaisa(p.price)!;
    if (parsed.data.price !== undefined) {
      const pp = parseTakaToPaisa(parsed.data.price);
      if (pp === null || pp <= 0) throw new ProtectionError('INVALID', 'Enter a price in taka with at most 2 decimals, e.g. 120 or 120.50.');
      newPricePaisa = pp;
    }
    const decision = evaluatePrice(newPricePaisa, p.mrp_paisa === null ? null : Number(p.mrp_paisa), cfg);
    if (decision.decision === 'BLOCKED_ABOVE_MRP') {
      tx(db as any, () => audit(db as any, { actorId: seller.id, actorRole: 'SELLER', action: 'PRICE_BLOCKED_ABOVE_MRP', productId: p.id,
        before: { pricePaisa: dbTakaToPaisa(p.price) }, after: { pricePaisa: newPricePaisa, mrpPaisa: p.mrp_paisa } }, now));
      throw new ProtectionError('NOT_SELLABLE', decision.en, [{ code: 'ABOVE_MRP', en: decision.en, bn: decision.bn }], decision.bn);
    }

    const newStock = parsed.data.stock ?? p.stock;
    tx(db as any, () => {
      db.prepare('UPDATE products SET price = ?, stock = ? WHERE id = ? AND seller_id = ?').run(paisaToTakaNumber(newPricePaisa), newStock, p.id, seller.id);
      audit(db as any, { actorId: seller.id, actorRole: 'SELLER', action: 'LISTING_UPDATED', productId: p.id,
        before: { pricePaisa: dbTakaToPaisa(p.price), stock: p.stock }, after: { pricePaisa: newPricePaisa, stock: newStock, priceDecision: decision.decision } }, now);
    });
    return NextResponse.json({ success: true, message: 'Listing updated', data: { price: paisaToTakaNumber(newPricePaisa), stock: newStock, priceDecision: decision } });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
