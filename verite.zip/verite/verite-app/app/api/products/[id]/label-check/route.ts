import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { newId } from '@/lib/ids';
import { getSession } from '@/lib/session';
import { publicIdentityFor } from '@/lib/identity/public';
import { readLabelOcr, sniffImageType, validImage } from '@/lib/ocr/read-label';
import { loadProtectionConfig, POLICY_VERSION } from '@/lib/protection/config';
import { compareLabel, overallResult, type RegisteredRecord } from '@/lib/protection/label-check';
import { protectionFor } from '@/lib/protection/sellability';
import { FixedWindowLimiter } from '@/lib/trace/ratelimit';
import { clientIpFromHeaders, sourceHash } from '@/lib/trace/source';

// Buyer physical-label check: the buyer photographs the pack (front, optional back); OCR (Bangla + English,
// the same pipeline the seller studio uses) reads it; the fields are compared with the REGISTERED record of
// this listing, which is exactly one batch.
// Privacy: photos are processed in memory and never stored; they go only to this project's own OCR service
// (or the local fallback) with a neutral file name — never to an external AI. Only the per-field result and
// the short compared values are stored (label_checks), never the photo or the full OCR text.
// Wording: a mismatch means "needs review", never "counterfeit".
export const dynamic = 'force-dynamic';

let limiter: FixedWindowLimiter | null = null;

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const cfg = loadProtectionConfig();
  if (!limiter) limiter = new FixedWindowLimiter(cfg.buyerCheckPerMinute);
  const session = await getSession(req);
  const secret = process.env.SCAN_HASH_SECRET || process.env.JWT_SECRET || 'dev-scan-secret-change-me';
  const key = session ? `u:${session.id}` : `s:${sourceHash(clientIpFromHeaders((n) => req.headers.get(n)), secret)}`;
  if (!limiter.allow(key)) {
    return NextResponse.json({ success: false, message: 'Too many checks. Please wait a minute and try again.', messageBn: 'অনেকবার চেষ্টা করা হয়েছে। এক মিনিট পরে আবার চেষ্টা করুন।' }, { status: 429 });
  }
  if (Number(req.headers.get('content-length') || 0) > 21 * 1024 * 1024) {
    return NextResponse.json({ success: false, message: 'Photos are too large (max 10 MB each).' }, { status: 413 });
  }

  const product = db.prepare(
    `SELECT p.id, p.name, p.status, p.batch_number, p.manufacturing_date, p.expiry_date, p.mrp_paisa, le.name_bn
     FROM products p LEFT JOIN product_label_extractions le ON le.product_id = p.id WHERE p.id = ?`
  ).get(params.id) as Record<string, any> | undefined;
  if (!product) return NextResponse.json({ success: false, message: 'Product not found' }, { status: 404 });

  const form = await req.formData().catch(() => null);
  const front = form?.get('front');
  const backEntry = form?.get('back');
  if (!validImage(front) || (backEntry && !validImage(backEntry))) {
    return NextResponse.json({ success: false, message: 'Upload a JPG, PNG or WEBP photo of the pack (up to 10 MB).', messageBn: 'প্যাকেটের একটি JPG, PNG বা WEBP ছবি দিন (সর্বোচ্চ ১০ MB)।' }, { status: 422 });
  }
  const back = backEntry && typeof backEntry !== 'string' ? backEntry : null;
  for (const f of [front, back]) {
    if (f && (await sniffImageType(f)) !== f.type) {
      return NextResponse.json({ success: false, message: 'The file is not a valid image.', messageBn: 'ফাইলটি সঠিক ছবি নয়।' }, { status: 422 });
    }
  }

  const { ocr, error } = await readLabelOcr(front, back, { anonymiseFilenames: true });
  const now = new Date();
  const identity = publicIdentityFor(db as any, product.id) as any;
  const registered: RegisteredRecord = {
    productName: product.name, productNameBn: product.name_bn ?? null,
    manufacturer: identity?.manufacturer?.name ?? null,
    batchNumber: product.batch_number ?? null, manufacturingDate: product.manufacturing_date ?? null, expiryDate: product.expiry_date ?? null,
    mrpPaisa: product.mrp_paisa === null || product.mrp_paisa === undefined ? null : Number(product.mrp_paisa),
  };
  const fields = compareLabel(registered, { fields: ocr?.fields ?? {}, confidence: ocr?.fieldConfidence ?? null }, cfg.buyerCheckMinConfidence);
  const overall = ocr ? overallResult(fields, product.status === 'PUBLISHED') : {
    overall: 'INSUFFICIENT_IMAGE' as const,
    en: 'The label could not be read. Take a clearer, well-lit photo of the label and try again.',
    bn: 'লেবেলটি পড়া যায়নি। আলোতে লেবেলের আরও পরিষ্কার ছবি তুলে আবার চেষ্টা করুন।',
  };

  // Batch status matters more than any label comparison.
  const prot = protectionFor(db as any, product.id, now, cfg);
  const batchStatus = prot && {
    recalled: !!prot.recall,
    expiry: { state: prot.expiry.state, textEn: prot.expiry.textEn, textBn: prot.expiry.textBn },
    notices: prot.blockers.filter((b) => b.code === 'RECALLED' || b.code === 'EXPIRED' || b.code === 'EXPIRY_UNKNOWN'),
  };

  const checkId = newId('lck');
  db.prepare(
    `INSERT INTO label_checks (id, product_id, checker_user_id, overall, fields_json, ocr_source, policy_version, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(checkId, product.id, session?.id ?? null, overall.overall,
    JSON.stringify(fields.map((f) => ({ field: f.field, result: f.result, observed: f.observed ? String(f.observed).slice(0, 80) : null, confidence: f.confidence }))),
    ocr?.source ?? null, POLICY_VERSION, now.toISOString());

  return NextResponse.json({
    success: true,
    data: {
      checkId,
      overall: overall.overall,
      messageEn: overall.en,
      messageBn: overall.bn,
      fields,
      batchStatus,
      ocr: { source: ocr?.source ?? null, languages: ocr?.languages ?? null, quality: ocr?.quality ?? null, error: ocr ? null : error },
      notice: 'Label comparison only. OCR can misread text; a difference is a reason to check, not proof that a product is fake.',
      noticeBn: 'এটি শুধু লেবেলের তুলনা। OCR ভুল পড়তে পারে; কোনো পার্থক্য মানে যাচাই প্রয়োজন, পণ্য নকল—এমন প্রমাণ নয়।',
      policyVersion: POLICY_VERSION,
    },
  });
}
