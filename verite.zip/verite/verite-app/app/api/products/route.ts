import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import db from '@/lib/db';
import { newId } from '@/lib/ids';
import { getSession } from '@/lib/session';
import { tx } from '@/lib/identity/onboarding';
import { recordProductIdentity } from '@/lib/identity/registration';
import { identityErrorResponse } from '@/lib/identity/http';
import { loadProtectionConfig } from '@/lib/protection/config';
import { dhakaToday, expiryInfo, isValidIsoDate } from '@/lib/protection/expiry';
import { parseTakaToPaisa, paisaToTakaNumber } from '@/lib/protection/money';
import { evaluatePrice } from '@/lib/protection/pricing';
import { sellableSqlFilter } from '@/lib/protection/sellability';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const search = searchParams.get('search') || '';
  const category = searchParams.get('category');
  // v5 buyer protection: recalled, expired, above-MRP (and unpublished) listings are never shown to buyers.
  const now = new Date();
  const cfg = loadProtectionConfig();

  let sql = `SELECT p.*, c.name as category_name, u.name as seller_name,
             bc.keccak_hash, bc.tx_hash, bc.block_number,
             (SELECT image_url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) as cover_image_url
             FROM products p
             LEFT JOIN categories c ON c.id = p.category_id
             LEFT JOIN users u ON u.id = p.seller_id
             LEFT JOIN blockchain_records bc ON bc.product_id = p.id
             WHERE ${sellableSqlFilter('p', cfg, dhakaToday(now))} AND p.name LIKE ?`;
  const params: unknown[] = [`%${search}%`];
  if (category && category !== 'All') {
    sql += ' AND c.name = ?';
    params.push(category);
  }
  sql += ' ORDER BY p.created_at DESC';

  const rows = (db.prepare(sql).all(...params) as Record<string, any>[]).map((r) => {
    const e = expiryInfo(r.expiry_date, now, cfg.expiryDisplayDays);
    return { ...r, expiry: { state: e.state, daysRemaining: e.daysRemaining, textEn: e.textEn, textBn: e.textBn } };
  });
  return NextResponse.json({ success: true, data: rows, meta: { total: rows.length } });
}

const createSchema = z.object({
  name: z.string().min(2),
  brand: z.string().optional(),
  categoryId: z.string().optional(),
  barcode: z.string().min(6),
  batchNumber: z.string().min(1),
  manufacturingDate: z.string(),
  expiryDate: z.string(),
  // v5: the MRP printed on the pack (required for new listings) and the selling price (defaults to the MRP).
  // Amounts are parsed to integer paisa from text, never compared as floats.
  mrp: z.union([z.number(), z.string()]),
  price: z.union([z.number(), z.string()]).optional(),
  stock: z.number().int().min(0).max(100000),
  imageEmoji: z.string().optional(),
  // --- Product_Image_Gallery_Extension.md: optional uploaded image URLs.
  // images[0] is the Cover Image, images[1..3] are Gallery Images 1-3.
  images: z.array(z.string()).max(4).optional(),
  // --- Seller onboarding & licence verification: who made the product, as stated by the seller.
  // SELF = the seller's own reviewed business (needs the MANUFACTURER role); CLAIM = a named
  // manufacturer stored as an UNVERIFIED claim; UNKNOWN = not stated. Never derived from an email.
  manufacturer: z
    .discriminatedUnion('mode', [
      z.object({ mode: z.literal('SELF') }),
      z.object({ mode: z.literal('CLAIM'), name: z.string().min(2).max(200) }),
      z.object({ mode: z.literal('UNKNOWN') }),
    ])
    .optional(),
  brandOwnerIsSeller: z.boolean().optional(),
  labelLicenceClaim: z.string().max(120).optional().nullable(),
  // --- v4 AI-assisted listing: Bangla product name, how each field was obtained (audit), and which
  // gallery images are enhanced versions of the seller's photo (shown with a label to buyers).
  productNameBn: z.string().max(200).optional().nullable(),
  labelExtraction: z
    .object({
      fieldStatus: z.record(z.string(), z.object({ status: z.string().max(40) }).passthrough()).optional(),
      aiProvider: z.string().max(40).nullable().optional(),
      aiModel: z.string().max(80).nullable().optional(),
      ocrSource: z.string().max(40).nullable().optional(),
    })
    .optional(),
  enhancedImageUrls: z.array(z.string()).max(4).optional(),
});

export async function POST(req: NextRequest) {
  const payload = await getSession(req);
  if (!payload || payload.role !== 'SELLER') {
    return NextResponse.json({ success: false, message: 'Seller authentication required' }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, message: 'Validation error', errors: parsed.error.issues }, { status: 422 });
  }
  const d = parsed.data;

  // --- v5 buyer protection: MRP guard and expiry check, on the server.
  const cfg = loadProtectionConfig();
  const mrpPaisa = parseTakaToPaisa(d.mrp);
  if (mrpPaisa === null || mrpPaisa <= 0) {
    return NextResponse.json({ success: false, message: 'Validation error', errors: [{ path: ['mrp'], message: 'Enter the MRP printed on the pack, e.g. 120 or 120.50' }] }, { status: 422 });
  }
  const pricePaisa = d.price === undefined || d.price === '' ? mrpPaisa : parseTakaToPaisa(d.price);
  if (pricePaisa === null || pricePaisa <= 0) {
    return NextResponse.json({ success: false, message: 'Validation error', errors: [{ path: ['price'], message: 'Enter a selling price in taka with at most 2 decimals' }] }, { status: 422 });
  }
  const priceDecision = evaluatePrice(pricePaisa, mrpPaisa, cfg);
  if (!priceDecision.allowed) {
    return NextResponse.json({ success: false, code: priceDecision.decision, message: priceDecision.en, messageBn: priceDecision.bn,
      errors: [{ path: ['price'], message: priceDecision.en }] }, { status: 422 });
  }
  if (!isValidIsoDate(d.manufacturingDate) || !isValidIsoDate(d.expiryDate)) {
    return NextResponse.json({ success: false, message: 'Validation error', errors: [{ path: ['expiryDate'], message: 'Dates must be real dates in YYYY-MM-DD form' }] }, { status: 422 });
  }
  if (expiryInfo(d.expiryDate, new Date(), cfg.expiryDisplayDays).state === 'EXPIRED') {
    return NextResponse.json({ success: false, code: 'EXPIRED', message: 'This batch has already expired and cannot be listed.', messageBn: 'এই ব্যাচের মেয়াদ শেষ, তাই তালিকাভুক্ত করা যাবে না।',
      errors: [{ path: ['expiryDate'], message: 'Expiry date has passed' }] }, { status: 422 });
  }
  // Where the MRP came from (for audit): read from the label by OCR/AI and confirmed by the seller, or typed.
  const mrpStatus = d.labelExtraction?.fieldStatus?.mrp?.status;
  const mrpSource = mrpStatus && mrpStatus !== 'NOT_FOUND' ? 'LABEL_CONFIRMED_BY_SELLER' : 'SELLER_ENTERED';

  if (new Date(d.expiryDate) <= new Date(d.manufacturingDate)) {
    return NextResponse.json(
      { success: false, message: 'Expiry date must be after manufacturing date' },
      { status: 422 }
    );
  }

  const id = newId('prod');
  try {
    // Product, images and identity references are written together, so a draft never exists
    // with a manufacturer reference that failed validation.
    tx(db as any, () => {
      db.prepare(
        `INSERT INTO products
          (id, seller_id, category_id, name, brand, barcode, batch_number, manufacturing_date, expiry_date, price, stock, image_emoji, status, mrp_paisa, mrp_source, mrp_status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'DRAFT', ?, ?, 'UNREVIEWED')`
      ).run(id, payload.id, d.categoryId || null, d.name, d.brand || null, d.barcode, d.batchNumber, d.manufacturingDate, d.expiryDate, paisaToTakaNumber(pricePaisa), d.stock, d.imageEmoji || '📦', mrpPaisa, mrpSource);

      // --- Product_Image_Gallery_Extension.md: save uploaded image URLs.
      if (d.images && d.images.length) {
        const insertImage = db.prepare(
          'INSERT INTO product_images (id, product_id, image_url, sort_order) VALUES (?, ?, ?, ?)'
        );
        d.images.forEach((url, i) => insertImage.run(newId('img'), id, url, i));
      }

      // --- v4: Bangla name + extraction audit; enhanced-image labels (only for this product's own images).
      if (d.productNameBn || d.labelExtraction) {
        db.prepare(
          `INSERT INTO product_label_extractions (product_id, name_bn, fields_json, field_status_json, ai_provider, ai_model, ocr_source)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        ).run(
          id, d.productNameBn?.trim() || null,
          JSON.stringify({ name: d.name, brand: d.brand ?? null, barcode: d.barcode, batchNumber: d.batchNumber, manufacturingDate: d.manufacturingDate, expiryDate: d.expiryDate, price: paisaToTakaNumber(pricePaisa), mrpPaisa }),
          d.labelExtraction?.fieldStatus ? JSON.stringify(d.labelExtraction.fieldStatus) : null,
          d.labelExtraction?.aiProvider ?? null, d.labelExtraction?.aiModel ?? null, d.labelExtraction?.ocrSource ?? null
        );
      }
      for (const url of d.enhancedImageUrls || []) {
        if (d.images?.includes(url)) {
          db.prepare("INSERT OR IGNORE INTO product_image_meta (image_url, product_id, kind) VALUES (?, ?, 'ENHANCED_FROM_SELLER_PHOTO')").run(url, id);
        }
      }

      recordProductIdentity(db as any, { id: payload.id, role: payload.role }, id, {
        manufacturer: d.manufacturer,
        brandOwnerIsSeller: d.brandOwnerIsSeller,
        labelLicenceClaim: d.labelLicenceClaim,
      });
    });
  } catch (err: any) {
    if (/UNIQUE constraint failed: products\.barcode/.test(String(err?.message))) {
      return NextResponse.json({ success: false, message: 'A product with this barcode already exists', errors: [{ path: ['barcode'], message: 'Barcode already exists' }] }, { status: 409 });
    }
    return identityErrorResponse(err);
  }

  return NextResponse.json({ success: true, message: 'Product created as draft', data: { id } }, { status: 201 });
}
