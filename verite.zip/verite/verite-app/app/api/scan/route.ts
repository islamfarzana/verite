import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { loadScanConfig } from '@/lib/trace/config';
import { FixedWindowLimiter } from '@/lib/trace/ratelimit';
import { clientIpFromHeaders } from '@/lib/trace/source';
import { handleScanRequest, pruneScanEvents } from '@/lib/trace/service';
import { loadProtectionConfig } from '@/lib/protection/config';
import { protectionFor } from '@/lib/protection/sellability';
import { runScanRiskCheck } from '@/lib/protection/scan-risk';

// PUBLIC endpoint (no login): a buyer scanning a QR code on a pack has no account.
// It only reads identifier/product data and appends a scan event. Abuse controls: strict
// token format, request size limit, per-source rate limit, generic responses.
export const dynamic = 'force-dynamic';

let limiter: FixedWindowLimiter | null = null;
let served = 0;
const NO_STORE = { 'Cache-Control': 'no-store' };

export async function POST(req: NextRequest) {
  let config;
  try {
    config = loadScanConfig();
  } catch (err) {
    console.error('Invalid scan configuration:', (err as Error).message);
    return NextResponse.json(
      { success: false, data: { status: 'UNAVAILABLE', message: 'The code could not be checked right now. This says nothing about the product. Please try again later.' } },
      { status: 503, headers: NO_STORE }
    );
  }
  if (Number(req.headers.get('content-length') || 0) > 4096) {
    return NextResponse.json({ success: false, data: { status: 'ERROR', message: 'Request too large.' } }, { status: 413, headers: NO_STORE });
  }
  if (!limiter) limiter = new FixedWindowLimiter(config.rateLimitPerMinute);

  const rawBody = await req.text();
  const ip = clientIpFromHeaders((name) => req.headers.get(name));
  const secret = process.env.SCAN_HASH_SECRET || process.env.JWT_SECRET || 'dev-scan-secret-change-me';
  const res = handleScanRequest({ db: db as any, config, secret, limiter }, { rawBody, ip });

  // v5 buyer protection: tell the buyer if this batch is recalled or expired (the scan verdict itself is
  // unchanged), and refresh the seller's clone-risk alert right after a suspicious scan.
  const data = (res.body as any)?.data;
  const productId = typeof data?.product?.productPath === 'string' ? data.product.productPath.split('/').pop() : null;
  if (res.status === 200 && productId) {
    try {
      const prot = protectionFor(db as any, productId, new Date(), loadProtectionConfig());
      if (prot) {
        data.batchStatus = {
          recalled: !!prot.recall,
          expired: prot.expiry.state === 'EXPIRED',
          expiryText: { en: prot.expiry.textEn, bn: prot.expiry.textBn },
          notices: prot.blockers.filter((b) => b.code === 'RECALLED' || b.code === 'EXPIRED' || b.code === 'EXPIRY_UNKNOWN'),
        };
      }
      if (data.status === 'SUSPICIOUS_ACTIVITY') {
        const owner = db.prepare('SELECT seller_id FROM products WHERE id = ?').get(productId) as { seller_id: string } | undefined;
        if (owner) runScanRiskCheck(db as any, owner.seller_id, new Date(), config);
      }
    } catch { /* extra information only: never turn it into a scan failure */ }
  }

  if (res.status === 200 && ++served % 500 === 0) {
    try { pruneScanEvents(db as any, new Date(), config.retentionDays); } catch { /* retention is best-effort */ }
  }
  return NextResponse.json(res.body, { status: res.status, headers: NO_STORE });
}
