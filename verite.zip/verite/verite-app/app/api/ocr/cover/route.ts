import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/session';
import { localCover } from '@/lib/ai/cover-local';

// Enhanced cover photo made from the seller's REAL front photo — not generative AI.
// Primary: OCR microservice /api/v1/ocr/cover (perspective flatten + GrabCut background removal
// + white square canvas). Fallback when the service is not configured/reachable: sharp trims the
// uniform border, and centres the photo on a white square. Packet colours are never altered.
// The result is returned as JPEG bytes; the seller dashboard then uploads it through the
// existing /api/uploads endpoint (no second upload system).

export const dynamic = 'force-dynamic';

const TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_BYTES = 10 * 1024 * 1024;

async function viaMicroservice(file: File): Promise<{ bytes: Buffer; method: string } | null> {
  const url = process.env.OCR_SERVICE_URL;
  if (!url) return null;
  const form = new FormData();
  form.append('image', file);
  const headers: Record<string, string> = {};
  if (process.env.OCR_SERVICE_API_KEY) headers['X-API-Key'] = process.env.OCR_SERVICE_API_KEY;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  try {
    const res = await fetch(`${url.replace(/\/$/, '')}/api/v1/ocr/cover`, { method: 'POST', body: form, headers, signal: controller.signal });
    if (!res.ok || !(res.headers.get('content-type') || '').startsWith('image/')) return null;
    return { bytes: Buffer.from(await res.arrayBuffer()), method: res.headers.get('x-cover-method') || 'grabcut' };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

export async function POST(req: NextRequest) {
  const session = await getSession(req);
  if (!session || session.role !== 'SELLER') {
    return NextResponse.json({ success: false, message: 'Seller authentication required' }, { status: 401 });
  }
  const form = await req.formData().catch(() => null);
  const file = form?.get('image');
  if (!file || typeof file === 'string' || !TYPES.includes(file.type) || file.size === 0 || file.size > MAX_BYTES) {
    return NextResponse.json({ success: false, message: 'Upload a JPG, PNG or WEBP photo up to 10 MB.' }, { status: 422 });
  }
  try {
    const remote = await viaMicroservice(file);
    const bytes = remote?.bytes ?? (await localCover(Buffer.from(await file.arrayBuffer())));
    const method = remote?.method ?? 'crop-only-local';
    return new NextResponse(new Uint8Array(bytes), {
      status: 200,
      headers: { 'Content-Type': 'image/jpeg', 'X-Cover-Method': method, 'Cache-Control': 'no-store' },
    });
  } catch {
    return NextResponse.json({ success: false, message: 'Could not create the enhanced photo. Use the original photo instead.' }, { status: 422 });
  }
}
