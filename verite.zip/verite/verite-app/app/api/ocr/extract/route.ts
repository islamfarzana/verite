import { NextRequest, NextResponse } from 'next/server';
import { OCR_ERROR_MESSAGE as ERROR_MESSAGE, readLabelOcr, validImage } from '@/lib/ocr/read-label';
import { getSession } from '@/lib/session';
import { AiError, loadGeminiConfig } from '@/lib/ai/gemini';
import { aiReadLabel, LABEL_FIELDS, mergeOcrAndAi, type AiLabelResult } from '@/lib/ai/label-extract';
import { allowAiCall } from '@/lib/ai/limits';

// Label reading: OCR microservice (Bangla + English) + Gemini vision, merged with a grounding check.
//
//   front photo ("labelImage", required) + back photo ("backImage", optional)
//     -> OCR: the FastAPI/OpenCV/Tesseract(ben+eng)/PaddleOCR microservice (OCR_SERVICE_URL), or,
//        if it is not configured/reachable, the local tesseract.js fallback (eng+ben)
//     -> AI: Gemini reads both photos (only when GEMINI_API_KEY is set)
//     -> merge: every field gets a value AND a status (agreed / confirmed by OCR text / OCR only /
//        AI only — check / conflict — check). The seller reviews every field before publishing.
//
// Fault tolerance: OCR or AI failing never blocks the seller. With neither available the
// seller types the fields in manually, exactly as before.

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const session = await getSession(req);
  if (!session || session.role !== 'SELLER') {
    return NextResponse.json({ success: false, message: 'Seller authentication required' }, { status: 401 });
  }
  const form = await req.formData().catch(() => null);
  const front = form?.get('labelImage');
  const backEntry = form?.get('backImage');
  if (!front || typeof front === 'string') {
    return NextResponse.json({ success: false, message: 'No label image provided' }, { status: 422 });
  }
  if (!validImage(front) || (backEntry && !validImage(backEntry))) {
    return NextResponse.json({ success: false, message: 'Photos must be JPG, PNG or WEBP, up to 10 MB each.' }, { status: 422 });
  }
  const back = backEntry && typeof backEntry !== 'string' ? backEntry : null;

  // 1) OCR (shared with the buyer label check: lib/ocr/read-label.ts)
  const { ocr, error: ocrError } = await readLabelOcr(front, back);

  // 2) AI (optional)
  const cfg = loadGeminiConfig();
  let ai: AiLabelResult | null = null;
  let aiInfo: { used: boolean; provider: string | null; model: string | null; reason: string | null; legibilityProblems?: string | null } = {
    used: false, provider: null, model: null, reason: cfg ? null : 'NOT_CONFIGURED',
  };
  if (cfg) {
    if (!allowAiCall(session.id)) {
      aiInfo.reason = 'RATE_LIMITED';
    } else {
      try {
        const images = [{ file: front, side: 'front' as const }, ...(back ? [{ file: back, side: 'back' as const }] : [])];
        ai = await aiReadLabel(cfg, await Promise.all(images.map(async (i) => ({
          side: i.side, mimeType: i.file.type, base64: Buffer.from(await i.file.arrayBuffer()).toString('base64'),
        }))));
        aiInfo = { used: true, provider: 'gemini', model: cfg.model, reason: null, legibilityProblems: ai.legibilityProblems };
      } catch (err) {
        aiInfo.reason = err instanceof AiError ? err.category : 'ERROR';
        console.error('AI label reading failed:', aiInfo.reason);
      }
    }
  }

  if (!ocr && !ai) {
    return NextResponse.json({ success: false, message: ocrError || ERROR_MESSAGE, ai: aiInfo }, { status: 422 });
  }

  // 3) Merge with grounding check
  const merged = mergeOcrAndAi(ocr?.fields || {}, ai, ocr?.rawText || '');
  const flat: Record<string, string | number | null> = {};
  for (const f of LABEL_FIELDS) flat[f] = merged[f].value;

  return NextResponse.json({
    success: true,
    data: {
      ...flat,
      ...(ocr?.confidence !== undefined ? { confidence: ocr.confidence } : {}),
      ...(ocr?.rawText ? { rawText: ocr.rawText } : {}),
      // Metadata (not form fields): how each value was obtained.
      fieldStatus: Object.fromEntries(LABEL_FIELDS.map((f) => [f, {
        status: merged[f].status, ocrValue: merged[f].ocrValue, aiValue: merged[f].aiValue,
      }])),
      ai: aiInfo,
      ocr: { used: !!ocr, source: ocr?.source ?? null, error: ocr ? null : ocrError, languages: ocr?.languages ?? null, quality: ocr?.quality ?? null, sides: ocr?.sides ?? null },
    },
  });
}
