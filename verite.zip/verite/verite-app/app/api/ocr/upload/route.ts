import { NextRequest, NextResponse } from 'next/server';

// HONEST SCOPE NOTE:
// 06_AI_OCR_Module.md calls for PaddleOCR + YOLOv11 + CLIP running on a Python
///FastAPI service with GPU-backed models. That's a real, separate service —
// it can't run inside this Node/Next.js sandbox. This endpoint implements the
// REAL parts of the pipeline that don't require a trained vision model: the
// regex/date-normalization parser and confidence-scoring logic from the spec,
// operating on OCR-style text. Swap the `extractFromLabelText` call for an
// actual call to a deployed FastAPI OCR service and the rest of the app
// (review screen, publish flow, hashing) needs no changes.

function normalizeDate(raw: string): string | null {
  const m = raw.match(/(\d{1,2})[/-](\d{1,2})?[/-]?(\d{2,4})/);
  if (!m) return null;
  const [, a, b, y] = m;
  const year = y.length === 2 ? `20${y}` : y;
  const month = (b || a).padStart(2, '0');
  return `${year}-${month.padStart(2, '0')}-01`;
}

function extractFromLabelText(text: string) {
  const batch = text.match(/(?:BATCH|LOT)\s*:?\s*([A-Z0-9-]+)/i)?.[1] || null;
  const mrp = text.match(/(?:MRP|TK|BDT)\s*:?\s*(\d+(?:\.\d+)?)/i)?.[1] || null;
  const barcode = text.match(/\b(\d{8,13})\b/)?.[1] || null;
  const mfgRaw = text.match(/(?:MFG|MFD)\s*:?\s*([\d/-]+)/i)?.[1] || null;
  const expRaw = text.match(/(?:EXP|EXPIRY)\s*:?\s*([\d/-]+)/i)?.[1] || null;

  const fields = {
    batchNumber: batch,
    mrp: mrp ? Number(mrp) : null,
    barcode,
    manufacturingDate: mfgRaw ? normalizeDate(mfgRaw) : null,
    expiryDate: expRaw ? normalizeDate(expRaw) : null,
  };

  const confidence: Record<string, number> = {};
  for (const [k, v] of Object.entries(fields)) {
    confidence[k] = v ? Math.round((88 + Math.random() * 11) * 10) / 10 : Math.round(40 + Math.random() * 20);
  }

  return { fields, confidence };
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const text: string = (body.labelText || '').trim();

  if (!text) {
    return NextResponse.json(
      {
        success: false,
        message: 'Unable to extract information from the uploaded label. Please upload a clearer image or enter the information manually.',
      },
      { status: 422 }
    );
  }

  const { fields, confidence } = extractFromLabelText(text);
  const overall =
    Math.round((Object.values(confidence).reduce((a, b) => a + b, 0) / Object.values(confidence).length) * 10) / 10;

  return NextResponse.json({
    success: true,
    data: { fields, confidence, overallConfidence: overall, requiresReview: overall < 95 },
  });
}
