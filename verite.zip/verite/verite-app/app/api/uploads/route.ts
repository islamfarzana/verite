import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';
import { getSession } from '@/lib/session';
import { newId } from '@/lib/ids';
import { UPLOAD_DIR } from '@/lib/db';
import { sniffImageType } from '@/lib/ocr/read-label';

// Product_Image_Gallery_Extension.md — "Reuse the existing upload endpoint...
// Do NOT introduce a new upload architecture." This project had no existing
// upload system at all, so this is the ONE upload endpoint added, reused for
// every image slot (Cover + Gallery 1-3). It doesn't touch auth, RBAC, OCR,
// blockchain, or any existing route.

const ALLOWED_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
};
const MAX_BYTES = 10 * 1024 * 1024; // 10MB per spec

export async function POST(req: NextRequest) {
  const payload = await getSession(req);
  if (!payload || payload.role !== 'SELLER') {
    return NextResponse.json({ success: false, message: 'Seller authentication required' }, { status: 401 });
  }

  const form = await req.formData().catch(() => null);
  const file = form?.get('file');
  if (!file || typeof file === 'string') {
    return NextResponse.json({ success: false, message: 'No file provided' }, { status: 422 });
  }

  const ext = ALLOWED_TYPES[file.type];
  if (!ext) {
    return NextResponse.json(
      { success: false, message: 'Only JPG, PNG, or WEBP images are supported' },
      { status: 422 }
    );
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ success: false, message: 'Image must be 10MB or smaller' }, { status: 422 });
  }

  // v5: the CONTENT must be the declared image type (not just the file name / MIME header).
  if ((await sniffImageType(file)) !== file.type) {
    return NextResponse.json({ success: false, message: 'The file is not a valid JPG, PNG or WEBP image.' }, { status: 422 });
  }

  // v5: stored next to the database (data/uploads) so images persist and are served in `next start` too.
  await mkdir(UPLOAD_DIR, { recursive: true });

  const filename = `${newId('img')}.${ext}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(UPLOAD_DIR, filename), buffer);

  return NextResponse.json({ success: true, data: { url: `/api/files/${filename}` } }, { status: 201 });
}
