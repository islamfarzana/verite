import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { actorFrom, identityErrorResponse, jsonBody } from '@/lib/identity/http';
import { decideEntity } from '@/lib/identity/onboarding';

export const dynamic = 'force-dynamic';

// Approve / reject / suspend / reinstate / reopen. The client names an action; the allowed status
// transition, the actor and the timestamp are decided on the server and written with an audit entry.
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const actor = await actorFrom(req, 'ADMIN');
    const b = await jsonBody(req);
    const entity = decideEntity(db as any, actor, params.id, { action: b.action, reasonCode: b.reasonCode, note: b.note, publicNote: b.publicNote });
    return NextResponse.json({ success: true, message: `Business is now ${entity.status}.`, data: { status: entity.status } });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
