import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { actorFrom, identityErrorResponse, identityRuntime } from '@/lib/identity/http';
import { REASON_CODES } from '@/lib/identity/labels';
import { adminEntityView } from '@/lib/identity/views';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const actor = await actorFrom(req, 'ADMIN');
    const rt = identityRuntime();
    return NextResponse.json({
      success: true,
      data: { ...adminEntityView(db as any, actor, params.id, { ...rt.policy, now: new Date() }), reasonCodes: REASON_CODES, registryMode: rt.cfg.registryMode, acceptManualReview: rt.cfg.acceptManualReview },
    });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
