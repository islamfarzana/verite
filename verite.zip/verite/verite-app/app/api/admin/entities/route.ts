import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { actorFrom, identityErrorResponse } from '@/lib/identity/http';
import { listEntities } from '@/lib/identity/onboarding';
import { ENTITY_STATUSES } from '@/lib/identity/schema';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const actor = await actorFrom(req, 'ADMIN');
    const s = req.nextUrl.searchParams.get('status');
    const status = s && (ENTITY_STATUSES as readonly string[]).includes(s) ? (s as (typeof ENTITY_STATUSES)[number]) : undefined;
    return NextResponse.json({ success: true, data: listEntities(db as any, actor, status) });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
