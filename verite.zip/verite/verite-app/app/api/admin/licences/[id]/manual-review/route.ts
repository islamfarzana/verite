import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { actorFrom, identityErrorResponse, jsonBody } from '@/lib/identity/http';
import { recordManualLicenceReview } from '@/lib/identity/onboarding';

export const dynamic = 'force-dynamic';

// An admin records the outcome of examining licence evidence by hand. Labelled as a manual review,
// never as a registry result; it only qualifies a seller when LICENCE_ACCEPT_MANUAL_REVIEW=true.
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const actor = await actorFrom(req, 'ADMIN');
    const b = await jsonBody(req);
    const licence = recordManualLicenceReview(db as any, actor, params.id, { result: b.result });
    return NextResponse.json({ success: true, data: { checkResult: licence.check_result, verificationMethod: licence.verification_method } });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
