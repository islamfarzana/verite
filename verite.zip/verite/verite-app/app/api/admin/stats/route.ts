import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { getSession } from '@/lib/session';

export async function GET(req: NextRequest) {
  const payload = await getSession(req);
  if (!payload || payload.role !== 'ADMIN') {
    return NextResponse.json({ success: false, message: 'Admin authentication required' }, { status: 401 });
  }

  const users = db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number };
  const sellers = db.prepare("SELECT COUNT(*) as c FROM users WHERE role='SELLER'").get() as { c: number };
  // Seller onboarding: businesses actually approved by an admin (an account with role SELLER is not approval).
  const approvedSellers = db
    .prepare("SELECT COUNT(*) as c FROM business_entities e JOIN entity_roles r ON r.entity_id = e.id AND r.role = 'SELLER' WHERE e.status = 'APPROVED'")
    .get() as { c: number };
  const pendingReviews = db.prepare("SELECT COUNT(*) as c FROM business_entities WHERE status = 'PENDING'").get() as { c: number };
  const products = db.prepare('SELECT COUNT(*) as c FROM products').get() as { c: number };
  const published = db.prepare("SELECT COUNT(*) as c FROM products WHERE status='PUBLISHED'").get() as { c: number };
  const verifications = db.prepare('SELECT COUNT(*) as c FROM verification_logs').get() as { c: number };
  const failedVerifications = db.prepare("SELECT COUNT(*) as c FROM verification_logs WHERE result='FAILED'").get() as {
    c: number;
  };
  const records = db
    .prepare(
      `SELECT p.name, bc.keccak_hash, bc.tx_hash, bc.block_number
       FROM blockchain_records bc JOIN products p ON p.id = bc.product_id
       ORDER BY bc.created_at DESC LIMIT 20`
    )
    .all();

  return NextResponse.json({
    success: true,
    data: {
      users: users.c,
      sellers: sellers.c,
      approvedSellers: approvedSellers.c,
      pendingReviews: pendingReviews.c,
      products: products.c,
      published: published.c,
      verifications: verifications.c,
      failedVerifications: failedVerifications.c,
      records,
    },
  });
}
