import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { loadProtectionConfig } from '@/lib/protection/config';
import { protectionErrorResponse, requireRole } from '@/lib/protection/http';
import { formatPaisa } from '@/lib/protection/money';
import { listRecalls } from '@/lib/protection/recall';
import { activeRecall, evaluateProtection, type ProductRow } from '@/lib/protection/sellability';

// Admin overview for buyer protection: recalls, buyer label-check review requests, listings whose MRP
// has not been reviewed, and listings currently hidden from buyers with the reason.
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const admin = await requireRole(req, ['ADMIN']);
    const now = new Date();
    const cfg = loadProtectionConfig();
    const products = db.prepare(
      `SELECT p.*, u.name AS seller_name FROM products p JOIN users u ON u.id = p.seller_id WHERE p.status = 'PUBLISHED' ORDER BY p.name`
    ).all() as (ProductRow & Record<string, any>)[];
    const listings = products.map((p) => {
      const prot = evaluateProtection(p, activeRecall(db as any, p.id), now, cfg);
      return {
        id: p.id, name: p.name, sellerName: p.seller_name, batchNumber: p.batch_number, expiryDate: p.expiry_date, price: p.price,
        mrp: formatPaisa(p.mrp_paisa), mrpSource: p.mrp_source ?? null, mrpStatus: p.mrp_status ?? null,
        sellable: prot.sellable, blockers: prot.blockers.map((b) => b.code), expiry: prot.expiry.textEn,
      };
    });
    const reviews = db.prepare(
      `SELECT lc.id, lc.product_id AS productId, p.name AS productName, p.batch_number AS batchNumber, lc.overall, lc.fields_json AS fieldsJson,
              lc.created_at AS createdAt, lc.review_requested_at AS reviewRequestedAt, lc.reviewed_at AS reviewedAt, lc.review_note AS reviewNote
       FROM label_checks lc JOIN products p ON p.id = lc.product_id
       WHERE lc.review_requested_at IS NOT NULL ORDER BY lc.reviewed_at IS NOT NULL, lc.review_requested_at DESC LIMIT 100`
    ).all() as any[];
    const checkStats = db.prepare('SELECT overall, COUNT(*) AS n FROM label_checks GROUP BY overall').all();
    return NextResponse.json({
      success: true,
      data: {
        recalls: listRecalls(db as any, admin),
        reviews: reviews.map((r) => ({ ...r, fields: JSON.parse(r.fieldsJson), fieldsJson: undefined })),
        checkStats,
        listings,
      },
    });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
