import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { tx } from '@/lib/identity/onboarding';
import { ProtectionError } from '@/lib/protection/errors';
import { protectionErrorResponse, readJson, requireRole } from '@/lib/protection/http';
import { formatPaisa, parseTakaToPaisa } from '@/lib/protection/money';
import { audit } from '@/lib/protection/sellability';

// Admin marks a listing's MRP as reviewed against the physical pack, optionally correcting it.
// Only admins can set mrp_status = ADMIN_REVIEWED. If the corrected MRP is below the current price, the
// listing is automatically hidden by the price-above-MRP guard until the seller lowers the price.
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const admin = await requireRole(req, ['ADMIN']);
    const body = await readJson(req);
    const p = db.prepare('SELECT id, mrp_paisa, mrp_source, mrp_status FROM products WHERE id = ?').get(params.id) as any;
    if (!p) throw new ProtectionError('NOT_FOUND', 'Product not found.');
    let mrpPaisa = p.mrp_paisa === null ? null : Number(p.mrp_paisa);
    let source = p.mrp_source;
    if (body.mrp !== undefined && body.mrp !== null && body.mrp !== '') {
      const v = parseTakaToPaisa(body.mrp);
      if (v === null || v <= 0) throw new ProtectionError('INVALID', 'Enter the MRP in taka, e.g. 120 or 120.50.');
      if (v !== mrpPaisa) source = 'ADMIN_CORRECTED';
      mrpPaisa = v;
    }
    if (mrpPaisa === null) throw new ProtectionError('INVALID', 'This listing has no MRP. Enter the MRP printed on the pack.');
    const now = new Date();
    tx(db as any, () => {
      db.prepare("UPDATE products SET mrp_paisa = ?, mrp_source = ?, mrp_status = 'ADMIN_REVIEWED' WHERE id = ?").run(mrpPaisa, source, p.id);
      audit(db as any, { actorId: admin.id, actorRole: 'ADMIN', action: 'MRP_REVIEWED', productId: p.id,
        before: { mrpPaisa: p.mrp_paisa, source: p.mrp_source, status: p.mrp_status }, after: { mrpPaisa, source, status: 'ADMIN_REVIEWED' } }, now);
    });
    return NextResponse.json({ success: true, data: { mrp: formatPaisa(mrpPaisa), source, status: 'ADMIN_REVIEWED' } });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
