import { NextRequest, NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import path from 'path';
import { UPLOAD_DIR } from '@/lib/db';

// Serves product images uploaded through /api/uploads from data/uploads (v5). Public, read-only.
// Only names this app generates are accepted, so no path can escape the upload folder.
export const dynamic = 'force-dynamic';

const NAME_RE = /^img_[0-9a-f-]{36}\.(jpg|png|webp)$/;
const TYPES: Record<string, string> = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' };

export async function GET(_req: NextRequest, { params }: { params: { name: string } }) {
  const name = params.name;
  if (!NAME_RE.test(name)) return NextResponse.json({ success: false, message: 'Not found' }, { status: 404 });
  try {
    const bytes = await readFile(path.join(UPLOAD_DIR, name));
    return new NextResponse(bytes, {
      status: 200,
      headers: {
        'Content-Type': TYPES[name.split('.').pop()!],
        'Cache-Control': 'public, max-age=31536000, immutable',
        'X-Content-Type-Options': 'nosniff',
      },
    });
  } catch {
    return NextResponse.json({ success: false, message: 'Not found' }, { status: 404 });
  }
}
