import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { getSession } from '@/lib/session';

export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ success: false, message: 'Not authenticated' }, { status: 401 });

  const user = db.prepare('SELECT id, name, email, role FROM users WHERE id = ?').get(session.id);
  if (!user) return NextResponse.json({ success: false, message: 'User not found' }, { status: 404 });

  return NextResponse.json({ success: true, data: user });
}
