import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { loadProtectionConfig } from '@/lib/protection/config';
import { protectionErrorResponse, readJson, requireRole } from '@/lib/protection/http';
import { listRecalls, openRecall } from '@/lib/protection/recall';

// Batch recalls. GET: admin sees all, a seller sees their own. POST {productId, reasonCode, publicMessage?}:
// a seller recalls their OWN listing's batch, an admin any listing. Sales stop immediately; buyers with
// matching (non-simulated) orders get an in-app notice in the same transaction. Repeating the request
// while a recall is active returns the existing recall (idempotent).
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const actor = await requireRole(req, ['SELLER', 'ADMIN']);
    return NextResponse.json({ success: true, data: listRecalls(db as any, actor) });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const actor = await requireRole(req, ['SELLER', 'ADMIN']);
    const body = await readJson(req);
    const r = openRecall(db as any, actor, { productId: body.productId, reasonCode: body.reasonCode, publicMessage: body.publicMessage }, new Date(), loadProtectionConfig());
    return NextResponse.json({
      success: true,
      message: r.alreadyActive ? 'This batch is already recalled.' : `Batch recalled. Sales stopped. ${r.buyersNotified} buyer(s) notified in the app.`,
      data: {
        id: r.recall.id, status: r.recall.status, batchNumber: r.recall.batch_number, alreadyActive: r.alreadyActive,
        buyersNotified: r.buyersNotified, simulatedOrdersSkipped: r.simulatedOrdersSkipped,
        channel: 'IN_APP', onChain: false,
      },
    }, { status: r.alreadyActive ? 200 : 201 });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
