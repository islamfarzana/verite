import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { loadProtectionConfig } from '@/lib/protection/config';
import { ProtectionError } from '@/lib/protection/errors';
import { protectionErrorResponse, readJson, requireRole } from '@/lib/protection/http';
import { closeRecall, resendRecallNotices } from '@/lib/protection/recall';

// Admin only. {action:'CLOSE', note?} ends a recall (the listing becomes sellable again only if every other
// rule allows it). {action:'RESEND'} re-runs buyer targeting; existing notices are never duplicated.
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const admin = await requireRole(req, ['ADMIN']);
    const body = await readJson(req);
    const now = new Date();
    if (body.action === 'CLOSE') return NextResponse.json({ success: true, data: closeRecall(db as any, admin, params.id, body.note, now) });
    if (body.action === 'RESEND') return NextResponse.json({ success: true, data: resendRecallNotices(db as any, admin, params.id, now, loadProtectionConfig()) });
    throw new ProtectionError('INVALID', 'Unknown action.');
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
