import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { MOCK_LABEL, UNCONFIGURED_LABEL } from '@/lib/identity/labels';
import { actorFrom, identityErrorResponse, identityRuntime, jsonBody } from '@/lib/identity/http';
import { submitBusinessProfile } from '@/lib/identity/onboarding';
import { sellerOnboardingView } from '@/lib/identity/views';

export const dynamic = 'force-dynamic';

function registryInfo(rt: ReturnType<typeof identityRuntime>) {
  return {
    mode: rt.cfg.registryMode,
    label: rt.adapter.mode === 'MOCK' ? MOCK_LABEL : rt.adapter.mode === 'REAL' ? rt.adapter.sourceLabel : UNCONFIGURED_LABEL,
    note: rt.cfg.modeNote,
  };
}

// The seller's own business profile, licences, review history (public notes only) and eligibility.
export async function GET(req: NextRequest) {
  try {
    const actor = await actorFrom(req, 'SELLER');
    const rt = identityRuntime();
    return NextResponse.json({ success: true, data: sellerOnboardingView(db as any, actor, { ...rt.policy, now: new Date() }, registryInfo(rt)) });
  } catch (err) {
    return identityErrorResponse(err);
  }
}

// Submit, correct or resubmit the business profile with one licence claim. Status is set server-side.
export async function POST(req: NextRequest) {
  try {
    const actor = await actorFrom(req, 'SELLER');
    const body = await jsonBody(req);
    const rt = identityRuntime();
    const result = await submitBusinessProfile(db as any, actor, {
      legalName: body.legalName, displayName: body.displayName, entityType: body.entityType, roles: body.roles,
      contactEmail: body.contactEmail, licence: body.licence && {
        licenceType: body.licence.licenceType, licenceNumber: body.licence.licenceNumber, issuingAuthority: body.licence.issuingAuthority,
        claimedIssueDate: body.licence.claimedIssueDate, claimedExpiryDate: body.licence.claimedExpiryDate,
        claimedStatus: body.licence.claimedStatus, claimSource: body.licence.claimSource,
      },
    }, { adapter: rt.adapter });
    return NextResponse.json(
      { success: true, message: 'Business profile submitted for review.', data: sellerOnboardingView(db as any, actor, { ...rt.policy, now: new Date() }, registryInfo(rt)), status: result.entity.status },
      { status: 201 }
    );
  } catch (err) {
    return identityErrorResponse(err);
  }
}
