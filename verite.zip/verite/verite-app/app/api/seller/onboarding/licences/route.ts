import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { actorFrom, identityErrorResponse, identityRuntime, jsonBody } from '@/lib/identity/http';
import { submitLicence } from '@/lib/identity/onboarding';

export const dynamic = 'force-dynamic';

// Add or renew a licence on an existing business profile. Does not change the business's review status.
export async function POST(req: NextRequest) {
  try {
    const actor = await actorFrom(req, 'SELLER');
    const b = await jsonBody(req);
    const rt = identityRuntime();
    const licence = await submitLicence(db as any, actor, {
      licenceType: b.licenceType, licenceNumber: b.licenceNumber, issuingAuthority: b.issuingAuthority,
      claimedIssueDate: b.claimedIssueDate, claimedExpiryDate: b.claimedExpiryDate, claimedStatus: b.claimedStatus, claimSource: b.claimSource,
    }, { adapter: rt.adapter });
    return NextResponse.json({ success: true, message: 'Licence submitted.', data: { checkResult: licence.check_result } }, { status: 201 });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
