import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { actorFrom, identityErrorResponse, identityRuntime, limitRecheck, requireJson } from '@/lib/identity/http';
import { recheckLicence } from '@/lib/identity/onboarding';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const actor = await actorFrom(req, 'SELLER');
    requireJson(req);
    limitRecheck(actor);
    const licence = await recheckLicence(db as any, actor, params.id, { adapter: identityRuntime().adapter });
    return NextResponse.json({ success: true, data: { checkResult: licence.check_result, checkedAt: licence.checked_at, lastAttemptAt: licence.last_attempt_at } });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
