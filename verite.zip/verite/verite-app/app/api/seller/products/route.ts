import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { loadProtectionConfig } from '@/lib/protection/config';
import { protectionErrorResponse, requireRole } from '@/lib/protection/http';
import { activeRecall, evaluateProtection, type ProductRow } from '@/lib/protection/sellability';
import { runScanRiskCheck } from '@/lib/protection/scan-risk';
import { loadScanConfig } from '@/lib/trace/config';

// "My products": EVERY listing of the signed-in seller, drafts included, read from the database, with
// the reason a listing is or is not visible to buyers. Lets a seller come back later (other browser,
// after a restart) and find, publish, re-price or recall what they created.
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const seller = await requireRole(req, ['SELLER']);
    const now = new Date();
    const cfg = loadProtectionConfig();
    // Cheap, deduplicated per code and day: keeps scan-risk alerts current without a scheduler.
    try { runScanRiskCheck(db as any, seller.id, now, loadScanConfig()); } catch { /* alerts are best-effort */ }

    const rows = db.prepare(
      `SELECT p.*, c.name AS category_name, bc.tx_hash, bc.network,
              (SELECT image_url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS cover_image_url,
              (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi JOIN orders o ON o.id = oi.order_id
                WHERE oi.product_id = p.id AND o.status <> 'CANCELLED' AND o.order_number NOT LIKE 'SIM-%') AS units_sold,
              (SELECT COUNT(*) FROM label_checks lc WHERE lc.product_id = p.id AND lc.review_requested_at IS NOT NULL AND lc.reviewed_at IS NULL) AS open_reviews
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
       LEFT JOIN blockchain_records bc ON bc.product_id = p.id
       WHERE p.seller_id = ? ORDER BY p.created_at DESC`
    ).all(seller.id) as (ProductRow & Record<string, any>)[];

    const data = rows.map((p) => {
      const prot = evaluateProtection(p, activeRecall(db as any, p.id), now, cfg);
      const visibleToBuyers = prot.blockers.every((b) => b.code === 'OUT_OF_STOCK');
      return {
        id: p.id, name: p.name, brand: p.brand, batchNumber: p.batch_number, barcode: p.barcode,
        manufacturingDate: p.manufacturing_date, expiryDate: p.expiry_date, price: p.price, stock: p.stock,
        status: p.status, verificationStatus: p.verification_status, coverImageUrl: p.cover_image_url, imageEmoji: p.image_emoji,
        createdAt: p.created_at, unitsSold: Number(p.units_sold), openReviews: Number(p.open_reviews), anchored: !!p.tx_hash, network: p.network ?? null,
        visibleToBuyers, sellable: prot.sellable, blockers: prot.blockers, expiry: prot.expiry, mrp: prot.mrp, pricing: { decision: prot.pricing.decision },
        recall: prot.recall,
      };
    });
    return NextResponse.json({ success: true, data, meta: { total: data.length, drafts: data.filter((d) => d.status === 'DRAFT').length } });
  } catch (err) {
    return protectionErrorResponse(err);
  }
}
