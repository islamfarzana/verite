import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { loadGeminiConfig } from '@/lib/ai/gemini';
import { allowAiCall } from '@/lib/ai/limits';
import { answer, interpret, keywordInterpret } from '@/lib/assistant/ask';
import { actorFrom, identityErrorResponse, jsonBody } from '@/lib/identity/http';
import { IdentityError } from '@/lib/identity/types';

export const dynamic = 'force-dynamic';

// "Ask your shop". The AI (if configured) only classifies the question; the answer is computed
// from the seller's own data by a fixed query and template.
export async function POST(req: NextRequest) {
  try {
    const actor = await actorFrom(req, 'SELLER');
    const b = await jsonBody(req);
    const question = typeof b.question === 'string' ? b.question.trim() : '';
    if (question.length < 2 || question.length > 500) throw new IdentityError('INVALID', 'Ask a question of 2-500 characters.');
    const cfg = loadGeminiConfig();
    const meaning = cfg && allowAiCall(actor.id) ? await interpret(cfg, question) : keywordInterpret(question);
    const result = answer(db as any, actor.id, new Date(), meaning);
    return NextResponse.json({ success: true, data: { answer: result.text, interpretation: meaning } });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
