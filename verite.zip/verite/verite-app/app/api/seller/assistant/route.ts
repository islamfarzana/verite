import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { loadGeminiConfig } from '@/lib/ai/gemini';
import { listNotifications, loadAlertConfig, runChecksIfDue, unreadCount } from '@/lib/assistant/alerts';
import { dailySeries, productStats, simulatedOrderCount, slowMovers, topProducts, weeklyFacts } from '@/lib/assistant/analytics';
import { actorFrom, identityErrorResponse } from '@/lib/identity/http';
import { runScanRiskCheck } from '@/lib/protection/scan-risk';
import { loadScanConfig } from '@/lib/trace/config';

export const dynamic = 'force-dynamic';

// Seller assistant dashboard data. Opening the page also runs the stock/expiry checks if they
// have not run in the last hour (production should also run `npm run assistant:check` on a schedule).
export async function GET(req: NextRequest) {
  try {
    const actor = await actorFrom(req, 'SELLER');
    const now = new Date();
    const check = runChecksIfDue(db as any, actor.id, now, loadAlertConfig());
    // v5: QR clone-risk alerts from stored scan events (deduplicated per code and day).
    try { runScanRiskCheck(db as any, actor.id, now, loadScanConfig()); } catch { /* best-effort */ }
    const stats = productStats(db as any, actor.id, now);
    const period = req.nextUrl.searchParams.get('period') === '7d' ? '7d' : req.nextUrl.searchParams.get('period') === '90d' ? '90d' : '30d';
    return NextResponse.json({
      success: true,
      data: {
        notifications: listNotifications(db as any, actor.id),
        unread: unreadCount(db as any, actor.id),
        checkedNow: check.ran,
        facts: weeklyFacts(db as any, actor.id, now),
        products: stats,
        top: topProducts(db as any, actor.id, now, period, 'units', 5),
        topRevenue: topProducts(db as any, actor.id, now, period, 'revenue', 5),
        slow: slowMovers(stats, now),
        series: dailySeries(db as any, actor.id, now, 28),
        simulatedOrders: simulatedOrderCount(db as any, actor.id),
        aiConfigured: !!loadGeminiConfig(),
        period,
      },
    });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
