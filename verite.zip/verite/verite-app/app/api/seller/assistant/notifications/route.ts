import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { markRead } from '@/lib/assistant/alerts';
import { actorFrom, identityErrorResponse, jsonBody } from '@/lib/identity/http';

export const dynamic = 'force-dynamic';

// Mark the seller's OWN notifications as read: { ids: string[] } or { all: true }.
export async function POST(req: NextRequest) {
  try {
    const actor = await actorFrom(req, 'SELLER');
    const b = await jsonBody(req);
    const ids = b.all === true ? 'all' : Array.isArray(b.ids) ? b.ids.filter((x: unknown): x is string => typeof x === 'string') : [];
    return NextResponse.json({ success: true, data: { updated: markRead(db as any, actor.id, ids, new Date()) } });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
