import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { newId } from '@/lib/ids';
import { loadGeminiConfig } from '@/lib/ai/gemini';
import { allowAiCall } from '@/lib/ai/limits';
import { weeklyFacts } from '@/lib/assistant/analytics';
import { templateSummary, weeklySummary } from '@/lib/assistant/summary';
import { actorFrom, identityErrorResponse, jsonBody } from '@/lib/identity/http';

export const dynamic = 'force-dynamic';

// Weekly summary in English or Bangla. AI-written when a key is configured and every number in
// the AI text matches the facts; otherwise the deterministic template.
export async function POST(req: NextRequest) {
  try {
    const actor = await actorFrom(req, 'SELLER');
    const b = await jsonBody(req);
    const lang = b.lang === 'bn' ? 'bn' : 'en';
    const now = new Date();
    const facts = weeklyFacts(db as any, actor.id, now);
    const cfg = loadGeminiConfig();
    const result = cfg && allowAiCall(actor.id)
      ? await weeklySummary(cfg, facts, lang)
      : { text: templateSummary(facts, lang), source: 'TEMPLATE' as const, model: null, fallbackReason: cfg ? 'RATE_LIMITED' : 'NOT_CONFIGURED' };
    db.prepare(
      'INSERT INTO assistant_summaries (id, seller_id, language, text, source, model, facts_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(newId('sum'), actor.id, lang, result.text, result.source, result.model, JSON.stringify(facts), now.toISOString());
    return NextResponse.json({ success: true, data: { ...result, facts } });
  } catch (err) {
    return identityErrorResponse(err);
  }
}
