import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import db from '@/lib/db';
import { getSession } from '@/lib/session';
import { newId, newOrderNumber } from '@/lib/ids';
import { loadProtectionConfig } from '@/lib/protection/config';
import { ProtectionError } from '@/lib/protection/errors';
import { activeRecall, evaluateProtection, loadProduct } from '@/lib/protection/sellability';

const DELIVERY_CHARGES: Record<string, number> = { STANDARD: 60, EXPRESS: 150, PICKUP: 0 };
const VAT_RATE = 0.05;

const schema = z.object({
  items: z.array(z.object({ productId: z.string(), quantity: z.number().int().positive() })).min(1),
  shippingAddress: z.object({
    name: z.string().min(2),
    phone: z.string().min(6),
    division: z.string().optional(),
    district: z.string().optional(),
    addressLine: z.string().min(4),
  }),
  paymentMethod: z.enum(['COD', 'SSLCOMMERZ', 'BKASH', 'NAGAD', 'ROCKET', 'STRIPE']).default('COD'),
  deliveryMethod: z.enum(['STANDARD', 'EXPRESS', 'PICKUP']).default('STANDARD'),
});

// GET /api/orders - the signed-in buyer's own order history with status + tracking
export async function GET(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ success: false, message: 'Authentication required' }, { status: 401 });

  const orders = db
    .prepare('SELECT * FROM orders WHERE buyer_id = ? ORDER BY created_at DESC')
    .all(session.id) as Record<string, any>[];

  const withDetails = orders.map((o) => {
    const items = db
      .prepare(
        `SELECT oi.*, p.name, p.image_emoji FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?`
      )
      .all(o.id);
    const shipment = db.prepare('SELECT * FROM shipments WHERE order_id = ?').get(o.id);
    const payment = db.prepare('SELECT * FROM payments WHERE order_id = ?').get(o.id);
    return { ...o, items, shipment, payment };
  });

  return NextResponse.json({ success: true, data: withDetails });
}

// POST /api/orders - full checkout: address, delivery method, payment method,
// order + items + payment + shipment records, real stock decrement transaction.
export async function POST(req: NextRequest) {
  const session = await getSession(req);
  if (!session) return NextResponse.json({ success: false, message: 'Authentication required' }, { status: 401 });
  // v5: only buyer accounts place orders (sellers/admins cannot buy through the API either).
  if (session.role !== 'BUYER') return NextResponse.json({ success: false, message: 'Only buyer accounts can place orders.' }, { status: 403 });
  const now = new Date();
  const protectionCfg = loadProtectionConfig();

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, message: 'Validation error', errors: parsed.error.issues }, { status: 422 });
  }
  const { items, shippingAddress, paymentMethod, deliveryMethod } = parsed.data;

  const orderId = newId('ord');
  const orderNumber = newOrderNumber();
  const invoiceNumber = `INV-${orderNumber.split('-')[1]}`;
  const trackingNumber = `TRK${Math.floor(1_000_000 + Math.random() * 9_000_000)}`;

  const tx = db.transaction(() => {
    let subtotal = 0;
    const itemRows: { productId: string; quantity: number; price: number; name: string; batchNumber: string | null; expiryDate: string | null }[] = [];

    // Same product twice in one request counts as one line (so the stock/sellability check sees the total).
    const merged = new Map<string, number>();
    for (const item of items) merged.set(item.productId, (merged.get(item.productId) || 0) + item.quantity);

    for (const [productId, quantity] of merged) {
      const item = { productId, quantity };
      const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.productId) as
        | Record<string, any>
        | undefined;
      if (!product) throw new Error(`Product ${item.productId} not found`);
      // v5 buyer protection, re-checked INSIDE the order transaction with the current data (a stale cart
      // or a direct API call cannot buy a recalled, expired, unpublished or above-MRP batch).
      const prot = evaluateProtection(loadProduct(db as any, item.productId)!, activeRecall(db as any, item.productId), now, protectionCfg, item.quantity);
      if (!prot.sellable) {
        const b = prot.blockers[0];
        throw new ProtectionError('NOT_SELLABLE', `${product.name}: ${b.en}`, prot.blockers, `${product.name}: ${b.bn}`);
      }
      if (product.stock < item.quantity) throw new Error(`Insufficient stock for ${product.name}`);

      db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(item.quantity, item.productId);
      subtotal += product.price * item.quantity;
      itemRows.push({ productId: item.productId, quantity: item.quantity, price: product.price, name: product.name, batchNumber: product.batch_number ?? null, expiryDate: product.expiry_date ?? null });
    }

    const deliveryCharge = DELIVERY_CHARGES[deliveryMethod];
    const vat = Math.round(subtotal * VAT_RATE * 100) / 100;
    const discount = 0;
    const grandTotal = Math.round((subtotal + vat + deliveryCharge - discount) * 100) / 100;

    // Save/insert a shipping address for this buyer (spec's `addresses` table)
    const addressId = newId('addr');
    db.prepare(
      `INSERT INTO addresses (id, buyer_id, name, phone, division, district, address_line)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(addressId, session.id, shippingAddress.name, shippingAddress.phone, shippingAddress.division || null, shippingAddress.district || null, shippingAddress.addressLine);

    db.prepare(
      `INSERT INTO orders
        (id, buyer_id, order_number, invoice_number, subtotal, vat, delivery_charge, discount, grand_total, total,
         payment_method, delivery_method, shipping_name, shipping_phone, shipping_address, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CONFIRMED')`
    ).run(
      orderId, session.id, orderNumber, invoiceNumber, subtotal, vat, deliveryCharge, discount, grandTotal, grandTotal,
      paymentMethod, deliveryMethod, shippingAddress.name, shippingAddress.phone, shippingAddress.addressLine
    );

    for (const it of itemRows) {
      // v5: the batch and expiry sold are snapshotted on the order item (exact recall targeting).
      db.prepare('INSERT INTO order_items (id, order_id, product_id, quantity, price, batch_number, expiry_date) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
        newId('oit'), orderId, it.productId, it.quantity, it.price, it.batchNumber, it.expiryDate
      );
      // v5: bought items leave the buyer's saved cart in the same transaction.
      db.prepare('DELETE FROM cart_items WHERE buyer_id = ? AND product_id = ?').run(session.id, it.productId);
    }

    // Payment record. COD is "pending collection" but still logged as a
    // payment method choice; digital gateways are simulated as immediately
    // successful since no real payment gateway credentials exist here.
    db.prepare(
      `INSERT INTO payments (id, order_id, gateway, transaction_id, amount, status) VALUES (?, ?, ?, ?, ?, ?)`
    ).run(newId('pay'), orderId, paymentMethod, `TXN-${newId('').slice(1, 13).toUpperCase()}`, grandTotal, paymentMethod === 'COD' ? 'PENDING' : 'SUCCESS');

    // Shipment record with a naive estimated delivery date.
    const days = deliveryMethod === 'EXPRESS' ? 1 : deliveryMethod === 'PICKUP' ? 0 : 4;
    const eta = new Date(Date.now() + days * 86400000).toISOString().slice(0, 10);
    db.prepare(
      `INSERT INTO shipments (id, order_id, courier, tracking_number, status, estimated_delivery) VALUES (?, ?, ?, ?, ?, ?)`
    ).run(newId('ship'), orderId, deliveryMethod === 'PICKUP' ? 'Store Pickup' : 'Standard Courier', trackingNumber, 'PACKED', eta);

    return { subtotal, vat, deliveryCharge, discount, grandTotal };
  });

  try {
    const totals = tx();
    return NextResponse.json({
      success: true,
      message: 'Order placed successfully',
      data: { orderId, orderNumber, invoiceNumber, trackingNumber, ...totals },
    });
  } catch (e: any) {
    if (e instanceof ProtectionError) return NextResponse.json(e.toBody(), { status: e.status });
    return NextResponse.json({ success: false, message: e.message || 'Checkout failed' }, { status: 400 });
  }
}
