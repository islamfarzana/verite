import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import db from '@/lib/db';
import { verifyPassword, signToken, AUTH_COOKIE, dashboardPathFor } from '@/lib/auth';

const schema = z.object({ email: z.string().email(), password: z.string() });

interface UserRow {
  id: string;
  name: string;
  email: string;
  password_hash: string;
  role: 'BUYER' | 'SELLER' | 'ADMIN';
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, message: 'Validation error' }, { status: 422 });
  }
  const { email, password } = parsed.data;

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as UserRow | undefined;
  if (!user || !(await verifyPassword(password, user.password_hash))) {
    return NextResponse.json({ success: false, message: 'Invalid email or password' }, { status: 401 });
  }

  const token = await signToken({ id: user.id, email: user.email, role: user.role });
  const res = NextResponse.json({
    success: true,
    message: 'Login successful',
    data: {
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      redirectTo: dashboardPathFor(user.role),
    },
  });
  res.cookies.set(AUTH_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
  return res;
}
