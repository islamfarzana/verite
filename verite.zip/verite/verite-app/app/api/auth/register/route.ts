import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import db from '@/lib/db';
import { hashPassword, signToken, AUTH_COOKIE, dashboardPathFor } from '@/lib/auth';
import { newId } from '@/lib/ids';

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8),
  role: z.enum(['BUYER', 'SELLER']).default('BUYER'),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { success: false, message: 'Validation error', errors: parsed.error.issues },
      { status: 422 }
    );
  }
  const { name, email, password, role } = parsed.data;

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return NextResponse.json(
      { success: false, message: 'Email already registered', errors: [{ field: 'email', message: 'Email already exists' }] },
      { status: 409 }
    );
  }

  const id = newId('usr');
  const passwordHash = await hashPassword(password);
  db.prepare(
    'INSERT INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)'
  ).run(id, name, email, passwordHash, role);

  const token = await signToken({ id, email, role });
  const user = { id, name, email, role };

  const res = NextResponse.json({
    success: true,
    message: 'Registration successful',
    data: { user, redirectTo: dashboardPathFor(role) },
  });
  res.cookies.set(AUTH_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
  return res;
}
