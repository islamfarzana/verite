'use client';
import { useEffect, useState } from 'react';
import { useSession } from '@/lib/client-auth';
import { Badge, EntityStatusBadge, LicenceBadge, fmtTime } from '@/components/IdentityBadges';
import { MOCK_REGISTRY_RECORDS } from '@/lib/identity/mock-registry-data';

// Seller: submit the business profile and licence claim, see review status, licence evidence and
// whether products can be published. Status is always decided by the server.

const LICENCE_TYPES: [string, string][] = [
  ['TRADE_LICENCE', 'Trade licence'],
  ['BSTI_CM_LICENCE', 'BSTI certification-mark (CM) licence'],
  ['BFSA_REGISTRATION', 'BFSA food business registration'],
  ['DGDA_LICENCE', 'DGDA licence'],
  ['OTHER', 'Other'],
];

const emptyLicence = { licenceType: 'TRADE_LICENCE', licenceNumber: '', issuingAuthority: '', claimedIssueDate: '', claimedExpiryDate: '', claimSource: 'MANUAL_ENTRY' };

function LicenceFields({ value, onChange }: { value: typeof emptyLicence; onChange: (v: typeof emptyLicence) => void }) {
  const set = (k: keyof typeof emptyLicence) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => onChange({ ...value, [k]: e.target.value });
  return (
    <div className="grid sm:grid-cols-2 gap-3">
      <label className="text-xs text-muted">Licence type
        <select className="input mt-1" value={value.licenceType} onChange={set('licenceType')}>
          {LICENCE_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </label>
      <label className="text-xs text-muted">Licence number
        <input className="input mt-1" value={value.licenceNumber} onChange={set('licenceNumber')} />
      </label>
      <label className="text-xs text-muted">Issuing authority
        <input className="input mt-1" value={value.issuingAuthority} onChange={set('issuingAuthority')} placeholder="e.g. the city corporation that issued it" />
      </label>
      <label className="text-xs text-muted">Where did this number come from?
        <select className="input mt-1" value={value.claimSource} onChange={set('claimSource')}>
          <option value="MANUAL_ENTRY">I typed it from my licence</option>
          <option value="OCR_EXTRACTED">Copied from OCR of my document</option>
        </select>
      </label>
      <label className="text-xs text-muted">Issue date (optional)
        <input type="date" className="input mt-1" value={value.claimedIssueDate} onChange={set('claimedIssueDate')} />
      </label>
      <label className="text-xs text-muted">Expiry date (optional)
        <input type="date" className="input mt-1" value={value.claimedExpiryDate} onChange={set('claimedExpiryDate')} />
      </label>
    </div>
  );
}

export default function SellerOnboarding() {
  const { user, loading } = useSession();
  const [data, setData] = useState<any>(null);
  const [form, setForm] = useState({ legalName: '', displayName: '', entityType: 'ORGANIZATION', contactEmail: '', manufacturer: false, brandOwner: false });
  const [licence, setLicence] = useState(emptyLicence);
  const [renewal, setRenewal] = useState(emptyLicence);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const load = async () => {
    const res = await fetch('/api/seller/onboarding');
    const j = await res.json();
    if (!j.success) return;
    setData(j.data);
    const e = j.data.entity;
    if (e) {
      setForm({
        legalName: e.legalName, displayName: e.displayName, entityType: e.entityType, contactEmail: e.contactEmail || '',
        manufacturer: e.roles.includes('MANUFACTURER'), brandOwner: e.roles.includes('BRAND_OWNER'),
      });
      const l = j.data.licences[0];
      if (l) {
        setLicence({
          licenceType: l.licenceType, licenceNumber: l.licenceNumber, issuingAuthority: l.issuingAuthority,
          claimedIssueDate: l.claimedIssueDate || '', claimedExpiryDate: l.claimedExpiryDate || '', claimSource: l.claimSource,
        });
      }
    }
  };
  useEffect(() => { if (user?.role === 'SELLER') load(); }, [user]);

  const post = async (url: string, body: unknown) => {
    setBusy(true); setMsg(null);
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await res.json().catch(() => ({ success: false, message: 'Unexpected response.' }));
    setMsg({ ok: !!j.success, text: j.message || (j.success ? 'Done.' : 'Something went wrong.') });
    await load();
    setBusy(false);
    return j;
  };

  const submitProfile = () => post('/api/seller/onboarding', {
    legalName: form.legalName, displayName: form.displayName, entityType: form.entityType, contactEmail: form.contactEmail || null,
    roles: ['SELLER', ...(form.manufacturer ? ['MANUFACTURER'] : []), ...(form.brandOwner ? ['BRAND_OWNER'] : [])],
    licence: { ...licence, claimedIssueDate: licence.claimedIssueDate || null, claimedExpiryDate: licence.claimedExpiryDate || null },
  });
  const submitRenewal = () => post('/api/seller/onboarding/licences', {
    ...renewal, claimedIssueDate: renewal.claimedIssueDate || null, claimedExpiryDate: renewal.claimedExpiryDate || null,
  });
  const recheck = (id: string) => post(`/api/seller/onboarding/licences/${id}/recheck`, {});

  if (!loading && (!user || user.role !== 'SELLER')) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h2 className="font-display text-xl mb-2">Seller sign-in required</h2>
        <a href="/login" className="btn btn-primary px-6 py-3">Sign In</a>
      </div>
    );
  }
  if (!data) return <div className="max-w-5xl mx-auto px-6 py-16 text-muted">Loading…</div>;

  const e = data.entity;
  const editable = !e || e.status === 'PENDING' || e.status === 'REJECTED';
  const el = data.eligibility;

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-1">Business Verification</h1>
      <p className="text-muted text-sm mb-6">
        Tell us who your business is and which licence it holds. An administrator reviews your business; your licence is checked
        separately. These are two different things, and both are shown to buyers exactly as they are.
      </p>

      {data.registry.mode === 'mock' && (
        <div className="card p-4 mb-6 border-2 border-warning/40 bg-warning/5 text-sm">
          <div className="font-bold text-[#B45309] mb-1">{data.registry.mockLabel}</div>
          Licence checks in this installation use a demo registry with fictitious records. A result here does not mean any real
          licence is valid. Demo numbers you can try:{' '}
          {MOCK_REGISTRY_RECORDS.map((r) => <code key={r.licenceNumber} className="font-mono text-[11px] mr-2">{r.licenceNumber}</code>)}
          <span className="text-muted">(…0001 active, …0003 expired, …0004 revoked, …CM-…0005 suspended, …0006 invalid, …OUTAGE simulates an outage)</span>
        </div>
      )}
      {data.registry.mode !== 'mock' && (
        <div className="card p-4 mb-6 text-sm">
          <div className="font-bold mb-1">Licence registry: {data.registry.label}</div>
          {data.registry.note && <div className="text-muted">{data.registry.note}</div>}
        </div>
      )}

      <div className={`card p-5 mb-6 ${el.canRegister ? 'border-2 border-secondary/40' : 'border-2 border-warning/40'}`}>
        <div className="flex items-center gap-3 mb-1">
          <div className="font-bold">Can I publish products?</div>
          {el.canRegister ? <Badge tone={el.basis === 'MOCK_REGISTRY_DEMO' ? 'amber' : 'green'}>{el.basis === 'MOCK_REGISTRY_DEMO' ? 'Yes — demo mode only' : 'Yes'}</Badge> : <Badge tone="amber">Not yet</Badge>}
        </div>
        <div className="text-sm text-muted">{el.message}</div>
      </div>

      {e && (
        <div className="card p-5 mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="font-bold">{e.displayName}</div>
            <EntityStatusBadge status={e.status} />
          </div>
          <div className="text-sm text-muted">{e.legalName} · {e.entityType === 'ORGANIZATION' ? 'Organisation' : 'Sole proprietor'} · Roles: {e.roles.join(', ').toLowerCase()}</div>
          <div className="text-xs text-muted mt-1">Submitted {fmtTime(e.submittedAt)} · Status changed {fmtTime(e.statusChangedAt)}</div>
          {e.publicStatusNote && <div className="text-sm mt-3 p-3 rounded-lg bg-slate-50 border border-slate-200">Message from the reviewer: {e.publicStatusNote}</div>}
        </div>
      )}

      {editable && (
        <div className="card p-6 mb-6">
          <div className="font-bold mb-1">{!e ? 'Submit your business for review' : e.status === 'REJECTED' ? 'Correct and resubmit' : 'Update your pending application'}</div>
          <p className="text-muted text-xs mb-4">Your contact email is kept private. It is never shown to buyers and is not used as your business identity.</p>
          <div className="grid sm:grid-cols-2 gap-3 mb-4">
            <label className="text-xs text-muted">Legal business name<input className="input mt-1" value={form.legalName} onChange={(x) => setForm({ ...form, legalName: x.target.value })} /></label>
            <label className="text-xs text-muted">Public display name<input className="input mt-1" value={form.displayName} onChange={(x) => setForm({ ...form, displayName: x.target.value })} /></label>
            <label className="text-xs text-muted">Business type
              <select className="input mt-1" value={form.entityType} onChange={(x) => setForm({ ...form, entityType: x.target.value })}>
                <option value="ORGANIZATION">Organisation (company, partnership)</option>
                <option value="SOLE_PROPRIETOR">Sole proprietor</option>
              </select>
            </label>
            <label className="text-xs text-muted">Business contact email (private, optional)<input className="input mt-1" value={form.contactEmail} onChange={(x) => setForm({ ...form, contactEmail: x.target.value })} /></label>
          </div>
          <div className="flex gap-6 text-sm mb-4">
            <label className="flex items-center gap-2"><input type="checkbox" checked={form.manufacturer} onChange={(x) => setForm({ ...form, manufacturer: x.target.checked })} /> We manufacture our products</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={form.brandOwner} onChange={(x) => setForm({ ...form, brandOwner: x.target.checked })} /> We own the brand(s) we sell</label>
          </div>
          <div className="font-semibold text-sm mb-2">Licence</div>
          <LicenceFields value={licence} onChange={setLicence} />
          <button className="btn btn-primary px-5 py-2.5 mt-4" onClick={submitProfile} disabled={busy}>{busy ? 'Submitting…' : 'Submit for review'}</button>
        </div>
      )}

      {e && !editable && (
        <div className="card p-6 mb-6">
          <div className="font-bold mb-1">Add or renew a licence</div>
          <p className="text-muted text-xs mb-4">A new number for the same licence type replaces the old one (the old record is kept). Your business status does not change.</p>
          <LicenceFields value={renewal} onChange={setRenewal} />
          <button className="btn btn-primary px-5 py-2.5 mt-4" onClick={submitRenewal} disabled={busy}>{busy ? 'Submitting…' : 'Submit licence'}</button>
        </div>
      )}

      {msg && <div className={`text-sm mb-6 ${msg.ok ? 'text-[#16803C]' : 'text-danger'}`}>{msg.text}</div>}

      {data.licences.length > 0 && (
        <div className="mb-6">
          <div className="font-bold mb-3">Licences</div>
          {data.licences.map((l: any) => (
            <div key={l.id} className="card p-4 mb-3 text-sm">
              <div className="flex flex-wrap items-center gap-3 mb-1">
                <div className="font-semibold">{l.licenceTypeLabel}</div>
                <span className="font-mono text-xs">{l.licenceNumber}</span>
                <LicenceBadge checkResult={l.checkResult} method={l.verificationMethod} />
              </div>
              <div className="text-xs text-muted">
                Issued by (as you stated): {l.issuingAuthority}
                {l.claimSource === 'OCR_EXTRACTED' && ' · number extracted from your document by OCR — not independently verified'}
              </div>
              <div className="text-xs text-muted">
                Checked by: {l.sourceLabel || 'not checked'} · Result time: {fmtTime(l.checkedAt)}
                {l.lastAttemptAt && l.lastAttemptAt !== l.checkedAt && ` · Last attempt: ${fmtTime(l.lastAttemptAt)}${l.errorCategory ? ` (${l.errorCategory})` : ''}`}
                {l.registryExpiryDate && ` · Expiry per registry: ${l.registryExpiryDate}`}
              </div>
              <button className="text-xs font-semibold text-primary mt-2" onClick={() => recheck(l.id)} disabled={busy}>Check again</button>
            </div>
          ))}
        </div>
      )}

      {data.history.length > 0 && (
        <div>
          <div className="font-bold mb-3">Review history</div>
          <div className="card overflow-hidden text-sm">
            {data.history.map((h: any, i: number) => (
              <div key={i} className={`px-5 py-2.5 flex gap-4 ${i < data.history.length - 1 ? 'border-b border-line' : ''}`}>
                <div className="text-muted w-56">{fmtTime(h.createdAt)}</div>
                <div className="font-semibold w-48">{h.previousStatus ? `${h.previousStatus} → ${h.newStatus}` : h.newStatus}</div>
                <div className="text-muted flex-1">{h.reasonCode.replace(/_/g, ' ').toLowerCase()}{h.publicNote ? ` — ${h.publicNote}` : ''}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
