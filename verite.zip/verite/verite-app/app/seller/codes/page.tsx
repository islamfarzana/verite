'use client';
import { useEffect, useState } from 'react';
import { useSession } from '@/lib/client-auth';

// Seller tool: issue batch/unit QR codes for a published product, print them, revoke them.
// Codes are generated on the server; the browser only draws the QR image from the URL it is given.

type Ident = {
  id: string; token: string; scope: 'UNIT' | 'BATCH'; unitSerial: number | null; batchNumber: string | null;
  status: 'ACTIVE' | 'REVOKED'; scanCount?: number; warningCount?: number; lastScanAt?: string | null; scanUrl: string;
};

function QrImage({ url }: { url: string }) {
  const [src, setSrc] = useState('');
  useEffect(() => {
    let alive = true;
    import('qrcode')
      .then((m: any) => (m.default ?? m).toDataURL(url, { margin: 1, width: 180 }))
      .then((d: string) => alive && setSrc(d))
      .catch(() => alive && setSrc(''));
    return () => { alive = false; };
  }, [url]);
  return src ? <img src={src} alt="QR code" width={110} height={110} /> : <div style={{ width: 110, height: 110 }} className="bg-slate-100" />;
}

export default function SellerCodes() {
  const { user, loading } = useSession();
  const [products, setProducts] = useState<any[]>([]);
  const [productId, setProductId] = useState('');
  const [scope, setScope] = useState<'BATCH' | 'UNIT'>('BATCH');
  const [quantity, setQuantity] = useState(10);
  const [list, setList] = useState<Ident[]>([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (!user) return;
    fetch('/api/products').then((r) => r.json()).then((j) => {
      const mine = (j.data || []).filter((p: any) => p.seller_id === user.id);
      setProducts(mine);
      if (mine[0]) setProductId(mine[0].id);
    });
  }, [user]);

  const load = async (id: string) => {
    if (!id) return;
    const res = await fetch(`/api/identifiers?productId=${encodeURIComponent(id)}`);
    const j = await res.json();
    setList(j.success ? j.data : []);
  };
  useEffect(() => { load(productId); }, [productId]);

  const issue = async () => {
    setBusy(true); setMsg('');
    const res = await fetch('/api/identifiers', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, scope, quantity: scope === 'UNIT' ? Number(quantity) : undefined, requestId: crypto.randomUUID() }),
    });
    const j = await res.json();
    setMsg(j.success ? (j.created ? 'Codes issued.' : 'These codes already existed; showing them.') : j.message || 'Could not issue codes.');
    await load(productId);
    setBusy(false);
  };

  const revoke = async (id: string) => {
    const reason = window.prompt('Reason for revoking this code (kept for the audit trail):');
    if (!reason) return;
    const res = await fetch(`/api/identifiers/${id}/revoke`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ reason }) });
    const j = await res.json();
    if (!j.success) alert(j.message);
    await load(productId);
  };

  if (!loading && (!user || user.role !== 'SELLER')) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h2 className="font-display text-xl mb-2">Seller sign-in required</h2>
        <a href="/login" className="btn btn-primary px-6 py-3">Sign In</a>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-1">QR Codes</h1>
      <p className="text-muted text-sm mb-2">
        Issue a code for a whole production batch, or one code per pack. Print and attach it to the product.
      </p>
      <p className="text-xs text-muted mb-6">
        A QR code can be photographed and copied. Repeated scans of one code raise a "possible cloned code" warning for buyers; this is a warning signal, not proof.
        A batch code is shared by many packs, so repeated scans of it are normal.
      </p>

      <div className="card p-5 mb-6 flex flex-wrap gap-4 items-end">
        <div>
          <div className="text-xs text-muted mb-1">Published product</div>
          <select className="input" value={productId} onChange={(e) => setProductId(e.target.value)}>
            {products.map((p) => <option key={p.id} value={p.id}>{p.name} (batch {p.batch_number})</option>)}
          </select>
        </div>
        <div>
          <div className="text-xs text-muted mb-1">Code type</div>
          <select className="input" value={scope} onChange={(e) => setScope(e.target.value as 'BATCH' | 'UNIT')}>
            <option value="BATCH">Batch code (one per batch)</option>
            <option value="UNIT">Unit codes (one per pack)</option>
          </select>
        </div>
        {scope === 'UNIT' && (
          <div>
            <div className="text-xs text-muted mb-1">How many (1-200)</div>
            <input className="input w-24" type="number" min={1} max={200} value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} />
          </div>
        )}
        <button className="btn btn-primary px-5 py-2.5" onClick={issue} disabled={busy || !productId}>{busy ? 'Working…' : 'Issue codes'}</button>
        <button className="btn btn-ghost px-5 py-2.5" onClick={() => window.print()} disabled={!list.length}>Print</button>
        {msg && <div className="text-sm text-muted w-full">{msg}</div>}
      </div>

      {products.length === 0 && <div className="text-muted text-sm">You have no published products yet. Publish a product in Seller Studio first.</div>}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map((i) => (
          <div key={i.id} className="card p-4 flex gap-3">
            <QrImage url={i.scanUrl} />
            <div className="text-xs">
              <div className="font-bold">{i.scope === 'UNIT' ? `Unit #${i.unitSerial}` : 'Batch code'}</div>
              <div className="text-muted">Batch {i.batchNumber}</div>
              <div className={i.status === 'ACTIVE' ? 'text-[#16803C]' : 'text-[#B91C1C]'}>{i.status}</div>
              <div className="text-muted">Scans: {i.scanCount ?? 0}{i.warningCount ? ` (${i.warningCount} warning${i.warningCount > 1 ? 's' : ''})` : ''}</div>
              {i.status === 'ACTIVE' && <button className="text-[#B91C1C] font-semibold mt-1 print:hidden" onClick={() => revoke(i.id)}>Revoke</button>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
