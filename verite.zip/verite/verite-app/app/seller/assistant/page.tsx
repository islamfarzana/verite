'use client';
import { useEffect, useState } from 'react';
import { useSession } from '@/lib/client-auth';

// Seller Assistant: stock and expiry alerts, sales performance, weekly summary and "ask your shop".
// All numbers come from the seller's own orders and products; the AI (if configured) only writes
// the summary text (checked against the numbers) and classifies questions.

type Lang = 'en' | 'bn';
const T = {
  en: {
    title: 'Seller Assistant', sub: 'Stock and expiry alerts, sales performance and a weekly summary, from your own orders.',
    alerts: 'Alerts', none: 'No alerts. Stock and expiry look fine.', markAll: 'Mark all read',
    week: 'Last 7 days', revenue: 'Revenue', units: 'Units sold', orders: 'Orders', change: 'vs previous week',
    trend: 'Units sold per day (last 28 days)', top: 'Best sellers', byUnits: 'by units', byRevenue: 'by revenue',
    slow: 'Not selling (14 days)', allSelling: 'Every product in stock sold recently.',
    stock: 'Stock and expiry', product: 'Product', inStock: 'In stock', perDay: 'Sold / day', daysLeft: 'Days of stock', expires: 'Expires in',
    notSelling: 'not selling', expired: 'EXPIRED', days: 'days',
    summary: 'Weekly summary', write: 'Write summary', writing: 'Writing…', ai: 'Written by AI, numbers checked', tpl: 'Template (exact numbers)',
    ask: 'Ask your shop', askPh: 'e.g. Which product sold most this month?', go: 'Ask',
    sim: (n: number) => `Includes ${n} SIMULATED demo orders (order numbers start with SIM-). Remove them with npm run simulate:sales -- --clear.`,
    aiOff: 'AI is not configured: summaries use the template and questions use keyword matching.',
    examples: ['Which product sold most this month?', 'What is running out of stock?', 'Which products are expiring?', 'How much did I sell this week?'],
  },
  bn: {
    title: 'বিক্রেতা সহকারী', sub: 'আপনার নিজের অর্ডার থেকে স্টক ও মেয়াদের সতর্কতা, বিক্রির অবস্থা এবং সাপ্তাহিক সারসংক্ষেপ।',
    alerts: 'সতর্কতা', none: 'কোনো সতর্কতা নেই। স্টক ও মেয়াদ ঠিক আছে।', markAll: 'সব পড়া হয়েছে',
    week: 'গত ৭ দিন', revenue: 'বিক্রির টাকা', units: 'বিক্রিত পণ্য', orders: 'অর্ডার', change: 'আগের সপ্তাহের তুলনায়',
    trend: 'প্রতিদিন বিক্রিত পণ্য (গত ২৮ দিন)', top: 'সবচেয়ে বেশি বিক্রি', byUnits: 'সংখ্যায়', byRevenue: 'টাকায়',
    slow: 'বিক্রি হচ্ছে না (১৪ দিন)', allSelling: 'স্টকের সব পণ্য সম্প্রতি বিক্রি হয়েছে।',
    stock: 'স্টক ও মেয়াদ', product: 'পণ্য', inStock: 'স্টকে', perDay: 'দিনে বিক্রি', daysLeft: 'কত দিন চলবে', expires: 'মেয়াদ শেষ',
    notSelling: 'বিক্রি হচ্ছে না', expired: 'মেয়াদ শেষ', days: 'দিন',
    summary: 'সাপ্তাহিক সারসংক্ষেপ', write: 'সারসংক্ষেপ লিখুন', writing: 'লেখা হচ্ছে…', ai: 'AI লিখেছে, সংখ্যা যাচাই করা', tpl: 'টেমপ্লেট (সঠিক সংখ্যা)',
    ask: 'আপনার দোকানকে প্রশ্ন করুন', askPh: 'যেমন: এই মাসে কোন পণ্য সবচেয়ে বেশি বিক্রি হয়েছে?', go: 'জিজ্ঞাসা',
    sim: (n: number) => `এখানে ${n} টি সিমুলেটেড ডেমো অর্ডার আছে (অর্ডার নম্বর SIM- দিয়ে শুরু)।`,
    aiOff: 'AI চালু নেই: সারসংক্ষেপ টেমপ্লেট থেকে, আর প্রশ্ন কীওয়ার্ড দিয়ে বোঝা হচ্ছে।',
    examples: ['এই মাসে কোন পণ্য সবচেয়ে বেশি বিক্রি হয়েছে?', 'কোন পণ্যের স্টক শেষ হয়ে যাচ্ছে?', 'কোন পণ্যের মেয়াদ শেষ হচ্ছে?', 'এই সপ্তাহে কত টাকার বিক্রি হয়েছে?'],
  },
};

const SEV: Record<string, string> = {
  CRITICAL: 'border-l-4 border-danger bg-danger/5', WARNING: 'border-l-4 border-warning bg-warning/5', INFO: 'border-l-4 border-slate-300',
};

function Bars({ series }: { series: { day: string; units: number }[] }) {
  const max = Math.max(1, ...series.map((s) => s.units));
  const w = 560, h = 120, bw = w / Math.max(1, series.length);
  return (
    <svg viewBox={`0 0 ${w} ${h + 18}`} className="w-full" role="img" aria-label="Units sold per day">
      {series.map((s, i) => {
        const bh = (s.units / max) * h;
        return (
          <g key={s.day}>
            <title>{`${s.day}: ${s.units}`}</title>
            <rect x={i * bw + 2} y={h - bh} width={Math.max(1, bw - 4)} height={bh} rx={2} fill="#2563EB" opacity={0.85} />
          </g>
        );
      })}
      <text x={0} y={h + 14} fontSize={10} fill="#64748b">{series[0]?.day}</text>
      <text x={w} y={h + 14} fontSize={10} fill="#64748b" textAnchor="end">{series[series.length - 1]?.day}</text>
    </svg>
  );
}

export default function SellerAssistant() {
  const { user, loading } = useSession();
  const [lang, setLang] = useState<Lang>('en');
  const [period, setPeriod] = useState<'7d' | '30d' | '90d'>('30d');
  const [metric, setMetric] = useState<'units' | 'revenue'>('units');
  const [data, setData] = useState<any>(null);
  const [summary, setSummary] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);
  const t = T[lang];

  const load = async (p = period) => {
    const j = await (await fetch(`/api/seller/assistant?period=${p}`)).json();
    if (j.success) setData(j.data);
  };
  useEffect(() => { if (user?.role === 'SELLER') load(); }, [user, period]);

  const post = (url: string, body: unknown) =>
    fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json());

  const markAll = async () => { await post('/api/seller/assistant/notifications', { all: true }); load(); };
  const writeSummary = async () => {
    setBusy(true);
    const j = await post('/api/seller/assistant/summary', { lang });
    setSummary(j.success ? j.data : { text: j.message, source: 'TEMPLATE' });
    setBusy(false);
  };
  const ask = async (question: string) => {
    if (!question.trim()) return;
    setQ(question);
    setAnswer('…');
    const j = await post('/api/seller/assistant/ask', { question });
    setAnswer(j.success ? j.data.answer : j.message);
  };

  if (!loading && (!user || user.role !== 'SELLER')) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h2 className="font-display text-xl mb-2">Seller sign-in required</h2>
        <a href="/login" className="btn btn-primary px-6 py-3">Sign In</a>
      </div>
    );
  }
  if (!data) return <div className="max-w-6xl mx-auto px-6 py-16 text-muted">Loading…</div>;

  const f = data.facts;
  const money = (n: number) => (lang === 'bn' ? `৳${n.toLocaleString('bn-BD')}` : `Tk ${n.toLocaleString('en-US')}`);
  const num = (n: number) => (lang === 'bn' ? n.toLocaleString('bn-BD') : n.toLocaleString('en-US'));
  const top = metric === 'revenue' ? data.topRevenue : data.top;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10" lang={lang}>
      <div className="flex flex-wrap justify-between items-start gap-4 mb-6">
        <div>
          <h1 className="font-display text-2xl mb-1">{t.title}</h1>
          <p className="text-muted text-sm">{t.sub}</p>
        </div>
        <div className="flex gap-2">
          <button className={`btn text-xs px-3 py-1.5 ${lang === 'en' ? 'btn-primary' : 'btn-ghost'}`} onClick={() => { setLang('en'); setSummary(null); }}>English</button>
          <button className={`btn text-xs px-3 py-1.5 ${lang === 'bn' ? 'btn-primary' : 'btn-ghost'}`} onClick={() => { setLang('bn'); setSummary(null); }}>বাংলা</button>
        </div>
      </div>

      {data.simulatedOrders > 0 && <div className="card p-3 mb-4 text-xs border border-warning/40 text-[#B45309]">{t.sim(data.simulatedOrders)}</div>}
      {!data.aiConfigured && <div className="text-[11px] text-muted mb-4">{t.aiOff}</div>}

      <div className="grid md:grid-cols-[1fr_1.4fr] gap-6 mb-8">
        <div className="card p-5">
          <div className="flex justify-between items-center mb-3">
            <div className="font-bold">{t.alerts} {data.unread > 0 && <span className="ml-1 text-xs bg-danger text-white rounded-full px-2 py-0.5">{num(data.unread)}</span>}</div>
            {data.unread > 0 && <button className="text-xs text-primary font-semibold" onClick={markAll}>{t.markAll}</button>}
          </div>
          {data.notifications.length === 0 && <div className="text-sm text-muted">{t.none}</div>}
          <div className="space-y-2 max-h-[420px] overflow-y-auto">
            {data.notifications.map((n: any) => (
              <div key={n.id} className={`rounded-lg p-3 text-sm ${SEV[n.severity]} ${n.readAt ? 'opacity-60' : ''}`}>
                <div className="font-semibold">{lang === 'bn' ? n.titleBn : n.titleEn}</div>
                <div className="text-muted text-xs mt-0.5">{lang === 'bn' ? n.bodyBn : n.bodyEn}</div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="card p-4"><div className="text-xs text-muted">{t.revenue} · {t.week}</div><div className="font-mono text-xl font-bold">{money(f.thisWeek.revenue)}</div>
              {f.revenueChangePercent !== null && <div className={`text-xs ${f.revenueChangePercent >= 0 ? 'text-[#16803C]' : 'text-danger'}`}>{f.revenueChangePercent >= 0 ? '▲' : '▼'} {num(Math.abs(f.revenueChangePercent))}% {t.change}</div>}</div>
            <div className="card p-4"><div className="text-xs text-muted">{t.units}</div><div className="font-mono text-xl font-bold">{num(f.thisWeek.units)}</div></div>
            <div className="card p-4"><div className="text-xs text-muted">{t.orders}</div><div className="font-mono text-xl font-bold">{num(f.thisWeek.orders)}</div></div>
          </div>
          <div className="card p-4">
            <div className="text-xs text-muted mb-2">{t.trend}</div>
            <Bars series={data.series} />
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <div className="card p-5">
          <div className="flex flex-wrap justify-between items-center gap-2 mb-3">
            <div className="font-bold">{t.top}</div>
            <div className="flex gap-1">
              {(['7d', '30d', '90d'] as const).map((p) => (
                <button key={p} className={`text-xs px-2 py-1 rounded ${period === p ? 'bg-primary text-white' : 'bg-slate-100'}`} onClick={() => setPeriod(p)}>{p}</button>
              ))}
              <button className={`text-xs px-2 py-1 rounded ${metric === 'units' ? 'bg-primary text-white' : 'bg-slate-100'}`} onClick={() => setMetric('units')}>{t.byUnits}</button>
              <button className={`text-xs px-2 py-1 rounded ${metric === 'revenue' ? 'bg-primary text-white' : 'bg-slate-100'}`} onClick={() => setMetric('revenue')}>{t.byRevenue}</button>
            </div>
          </div>
          {top.length === 0 && <div className="text-sm text-muted">—</div>}
          {top.map((p: any, i: number) => {
            const max = Math.max(1, ...top.map((x: any) => (metric === 'revenue' ? x.revenue : x.units)));
            const v = metric === 'revenue' ? p.revenue : p.units;
            return (
              <div key={p.id} className="mb-2 text-sm">
                <div className="flex justify-between"><span>{num(i + 1)}. {p.name}</span><span className="font-mono">{metric === 'revenue' ? money(v) : num(v)}</span></div>
                <div className="h-1.5 bg-slate-100 rounded"><div className="h-1.5 bg-primary rounded" style={{ width: `${(v / max) * 100}%` }} /></div>
              </div>
            );
          })}
          <div className="font-bold mt-5 mb-2 text-sm">{t.slow}</div>
          {data.slow.length === 0 ? <div className="text-xs text-muted">{t.allSelling}</div> : data.slow.map((s: any) => (
            <div key={s.id} className="text-xs text-muted">• {s.name} ({num(s.stock)})</div>
          ))}
        </div>

        <div className="card p-5 overflow-x-auto">
          <div className="font-bold mb-3">{t.stock}</div>
          <table className="w-full text-xs">
            <thead><tr className="text-left text-muted"><th className="py-1">{t.product}</th><th>{t.inStock}</th><th>{t.perDay}</th><th>{t.daysLeft}</th><th>{t.expires}</th></tr></thead>
            <tbody>
              {data.products.filter((p: any) => p.status === 'PUBLISHED').map((p: any) => (
                <tr key={p.id} className="border-t border-line">
                  <td className="py-1.5 pr-2">{p.name}</td>
                  <td className={p.stock === 0 ? 'text-danger font-bold' : ''}>{num(p.stock)}</td>
                  <td>{num(p.dailyVelocity)}</td>
                  <td className={p.daysOfCover !== null && p.daysOfCover <= 7 ? 'text-[#B45309] font-bold' : ''}>{p.daysOfCover === null ? t.notSelling : num(Math.round(p.daysOfCover))}</td>
                  <td className={p.daysToExpiry !== null && p.daysToExpiry < 0 ? 'text-danger font-bold' : p.daysToExpiry !== null && p.daysToExpiry <= 30 ? 'text-[#B45309]' : ''}>
                    {p.daysToExpiry === null ? '—' : p.daysToExpiry < 0 ? t.expired : `${num(p.daysToExpiry)} ${t.days}`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card p-5">
          <div className="flex justify-between items-center mb-3">
            <div className="font-bold">{t.summary}</div>
            <button className="btn btn-primary text-xs px-3 py-1.5" onClick={writeSummary} disabled={busy}>{busy ? t.writing : t.write}</button>
          </div>
          {summary && (
            <div>
              <span className={`text-[10px] font-bold rounded-full px-2 py-0.5 ${summary.source === 'AI' ? 'bg-primary/10 text-primary' : 'bg-slate-100 text-slate-600'}`}>
                {summary.source === 'AI' ? t.ai : t.tpl}
              </span>
              <p className="text-sm mt-2 whitespace-pre-line">{summary.text}</p>
            </div>
          )}
        </div>

        <div className="card p-5">
          <div className="font-bold mb-3">{t.ask}</div>
          <div className="flex gap-2 mb-2">
            <input className="input flex-1" value={q} placeholder={t.askPh} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') ask(q); }} />
            <button className="btn btn-primary px-4" onClick={() => ask(q)}>{t.go}</button>
          </div>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {t.examples.map((ex) => <button key={ex} className="text-[11px] bg-slate-100 rounded-full px-2.5 py-1" onClick={() => ask(ex)}>{ex}</button>)}
          </div>
          {answer && <pre className="text-sm whitespace-pre-wrap font-sans bg-slate-50 border border-slate-200 rounded-lg p-3">{answer}</pre>}
        </div>
      </div>
    </div>
  );
}
