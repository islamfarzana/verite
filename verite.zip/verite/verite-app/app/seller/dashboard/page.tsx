'use client';
import { useEffect, useState, useRef } from 'react';
import { useSession } from '@/lib/client-auth';

export default function SellerStudio() {
  const { user, loading: sessionLoading } = useSession();
  const [ocr, setOcr] = useState<any>(null);
  const [fields, setFields] = useState<any>(null);
  const [productId, setProductId] = useState<string | null>(null);
  const [published, setPublished] = useState<any>(null);
  const [labelText, setLabelText] = useState('');
  const [busy, setBusy] = useState(false);
  // --- Seller onboarding & licence verification: who made the product, and can this seller publish?
  const [maker, setMaker] = useState<'SELF' | 'CLAIM' | 'UNKNOWN'>('CLAIM');
  const [brandOwnerIsSeller, setBrandOwnerIsSeller] = useState(false);
  const [claimName, setClaimName] = useState('');
  const [onboarding, setOnboarding] = useState<any>(null);
  const [publishError, setPublishError] = useState<string | null>(null);
  // v5: selling price (must not exceed the MRP printed on the pack) and stock, set by the seller.
  const [sellPrice, setSellPrice] = useState('');
  const [stockQty, setStockQty] = useState('50');
  useEffect(() => {
    if (user?.role !== 'SELLER') return;
    fetch('/api/seller/onboarding').then((r) => r.json()).then((j) => setOnboarding(j.success ? j.data : null)).catch(() => setOnboarding(null));
  }, [user]);
  const sellerRoles: string[] = onboarding?.entity?.roles || [];

  // --- Product_Image_Gallery_Extension.md: Product Images section ---
  const IMAGE_SLOTS = [
    { label: 'Cover Image', required: true, help: 'Upload the main product image that customers will see throughout the marketplace.' },
    { label: 'Gallery Image 1', required: false, help: 'Upload additional product images to showcase the product from different angles.' },
    { label: 'Gallery Image 2', required: false, help: '' },
    { label: 'Gallery Image 3', required: false, help: '' },
  ];
  const [images, setImages] = useState<(string | null)[]>([null, null, null, null]);
  const [imageBusy, setImageBusy] = useState<boolean[]>([false, false, false, false]);
  const fileInputRefs = [useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null), useRef<HTMLInputElement>(null)];

  const onImageChange = async (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-selecting the same file for Replace
    if (!file) return;
    setImageBusy((prev) => prev.map((b, i) => (i === index ? true : b)));
    const form = new FormData();
    form.append('file', file);
    const res = await fetch('/api/uploads', { method: 'POST', body: form });
    const json = await res.json();
    if (json.success) {
      setImages((prev) => prev.map((u, i) => (i === index ? json.data.url : u)));
    } else {
      alert(json.message);
    }
    setImageBusy((prev) => prev.map((b, i) => (i === index ? false : b)));
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.map((u, i) => (i === index ? null : u)));
  };

  // --- Product_Label_AI_OCR_Extension.md: Product Label upload ---
  const [labelImage, setLabelImage] = useState<string | null>(null);
  const [labelStatus, setLabelStatus] = useState<'idle' | 'uploading' | 'processing' | 'success' | 'error'>('idle');
  const [rawOcrText, setRawOcrText] = useState<string | null>(null);
  const labelFileInputRef = useRef<HTMLInputElement>(null);
  // --- v4: front + back photos, AI reading with per-field status, enhanced cover photo ---
  const [frontFile, setFrontFile] = useState<File | null>(null);
  const [backFile, setBackFile] = useState<File | null>(null);
  const [backPreview, setBackPreview] = useState<string | null>(null);
  const backFileInputRef = useRef<HTMLInputElement>(null);
  const [fieldStatus, setFieldStatus] = useState<Record<string, { status: string; ocrValue: any; aiValue: any }>>({});
  const [aiInfo, setAiInfo] = useState<any>(null);
  const [ocrInfo, setOcrInfo] = useState<any>(null);
  const [enhancedUrls, setEnhancedUrls] = useState<string[]>([]);
  const [coverBusy, setCoverBusy] = useState(false);

  if (!sessionLoading && (!user || user.role !== 'SELLER')) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h2 className="font-display text-xl mb-2">Seller sign-in required</h2>
        <p className="text-muted text-sm mb-5">Sign in with a seller account to upload and publish products.</p>
        <a href="/login" className="btn btn-primary px-6 py-3">Sign In</a>
      </div>
    );
  }

  const runOcr = async () => {
    setBusy(true);
    setPublished(null);
    const res = await fetch('/api/ocr/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ labelText: labelText || undefined }),
    });
    const json = await res.json();
    if (!json.success) {
      setOcr(null);
      setFields(null);
      setBusy(false);
      alert(json.message);
      return false;
    }
    setOcr(json.data);
    // The paste-text OCR endpoint only ever extracts batchNumber/mrp/barcode/
    // manufacturingDate/expiryDate. productName/brand/weight are guaranteed
    // present here (as null, never fabricated) so they're always reviewable
    // and editable before publishing, regardless of which OCR path was used.
    setFields({ productName: null, brand: null, weight: null, ...json.data.fields });
    setBusy(false);
    return true;
  };

  // Uploads the label image via the existing upload endpoint, then sends the
  // SAME image to the (new) OCR extraction endpoint — real text recognition
  // on the actual uploaded image, not sample/demo data.
  const onLabelImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setLabelStatus('uploading');
    setOcr(null);
    setFields(null);
    setPublished(null);
    setRawOcrText(null);

    const uploadForm = new FormData();
    uploadForm.append('file', file);
    const uploadRes = await fetch('/api/uploads', { method: 'POST', body: uploadForm });
    const uploadJson = await uploadRes.json();
    if (!uploadJson.success) {
      setLabelStatus('error');
      alert(uploadJson.message);
      return;
    }
    setLabelImage(uploadJson.data.url);
    setFrontFile(file);
    await extractFromPhotos(file, backFile);
  };

  // v4: read the front (and, if added, the back) photo: OCR (Bangla + English) + AI, merged.
  const extractFromPhotos = async (front: File, back: File | null) => {
    setLabelStatus('processing');
    const ocrForm = new FormData();
    ocrForm.append('labelImage', front);
    if (back) ocrForm.append('backImage', back);
    const ocrRes = await fetch('/api/ocr/extract', { method: 'POST', body: ocrForm });
    const ocrJson = await ocrRes.json().catch(() => ({ success: false }));

    if (!ocrJson.success) {
      setAiInfo(ocrJson.ai || null);
      setLabelStatus('error');
      return;
    }

    const { confidence, rawText, fieldStatus: status, ai, ocr: ocrMeta, ...extractedFields } = ocrJson.data;
    setFields(extractedFields);
    setFieldStatus(status || {});
    setAiInfo(ai || null);
    setOcrInfo(ocrMeta || null);
    setOcr(confidence !== undefined ? { overallConfidence: confidence } : {});
    setRawOcrText(rawText || null);
    setLabelStatus('success');
  };

  const onBackImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setBackFile(file);
    setBackPreview(URL.createObjectURL(file));
    if (frontFile) await extractFromPhotos(frontFile, file);
  };

  // v4: enhanced cover made from the REAL front photo (background removed, straightened, white
  // square). Uploaded through the existing upload endpoint. The original photo is kept in the gallery.
  const makeEnhancedCover = async () => {
    if (!frontFile) return;
    setCoverBusy(true);
    try {
      const form = new FormData();
      form.append('image', frontFile);
      const res = await fetch('/api/ocr/cover', { method: 'POST', body: form });
      if (!res.ok || !(res.headers.get('content-type') || '').startsWith('image/')) {
        const j = await res.json().catch(() => null);
        alert(j?.message || 'Could not create the enhanced photo. Use the original photo instead.');
        return;
      }
      const blob = await res.blob();
      const up = new FormData();
      up.append('file', new File([blob], 'enhanced-cover.jpg', { type: 'image/jpeg' }));
      const upJson = await (await fetch('/api/uploads', { method: 'POST', body: up })).json();
      if (!upJson.success) { alert(upJson.message); return; }
      const url = upJson.data.url as string;
      setEnhancedUrls((prev) => [...prev, url]);
      setImages((prev) => {
        const next = [...prev];
        const original = labelImage;
        next[0] = url;
        // keep the real front photo visible to buyers in the first free gallery slot
        if (original && !next.includes(original)) {
          const free = next.findIndex((u, i) => i > 0 && !u);
          if (free > 0) next[free] = original;
        }
        return next;
      });
    } finally {
      setCoverBusy(false);
    }
  };

  const createAndPublish = async () => {
    if (!images[0]) { alert('Please upload a Cover Image before publishing.'); return; }
    const required: [string, string][] = [
      ['productName', 'Product Name'],
      ['brand', 'Brand'],
      ['barcode', 'Barcode'],
      ['batchNumber', 'Batch Number'],
      ['manufacturingDate', 'Manufacturing Date'],
      ['expiryDate', 'Expiry Date'],
      ['mrp', 'MRP'],
    ];
    const missing = required.filter(([key]) => !fields[key]).map(([, label]) => label);
    if (missing.length) {
      alert(`Please review and fill in: ${missing.join(', ')} before publishing.`);
      return;
    }
    const stockNum = Number(stockQty);
    if (!Number.isInteger(stockNum) || stockNum < 0) { alert('Stock must be a whole number (0 or more).'); return; }

    setBusy(true);
    setPublishError(null);
    const manufacturerName = (typeof fields.manufacturer === 'string' && fields.manufacturer.trim() ? fields.manufacturer : claimName).trim();
    if (maker === 'CLAIM' && manufacturerName.length < 2) {
      alert('Enter the manufacturer name, or choose "Not stated".');
      setBusy(false);
      return;
    }
    const createRes = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: fields.productName,
        brand: fields.brand,
        barcode: fields.barcode,
        batchNumber: fields.batchNumber,
        manufacturingDate: fields.manufacturingDate,
        expiryDate: fields.expiryDate,
        // v5: MRP as printed on the pack, and the selling price (empty = sell at MRP). The server rejects
        // a price above the MRP.
        mrp: String(fields.mrp),
        price: sellPrice.trim() || undefined,
        stock: stockNum,
        imageEmoji: '🏷️',
        images: images.filter((u): u is string => !!u),
        manufacturer: maker === 'SELF' ? { mode: 'SELF' } : maker === 'CLAIM' ? { mode: 'CLAIM', name: manufacturerName } : { mode: 'UNKNOWN' },
        productNameBn: typeof fields.productNameBn === 'string' && fields.productNameBn.trim() ? fields.productNameBn.trim() : null,
        labelExtraction: {
          fieldStatus,
          aiProvider: aiInfo?.used ? aiInfo.provider : null,
          aiModel: aiInfo?.used ? aiInfo.model : null,
          ocrSource: ocrInfo?.source ?? null,
        },
        enhancedImageUrls: enhancedUrls.filter((u) => images.includes(u)),
        brandOwnerIsSeller,
        labelLicenceClaim: typeof fields.licenceNumber === 'string' && fields.licenceNumber.trim() ? fields.licenceNumber.trim() : null,
      }),
    });
    const createJson = await createRes.json();
    if (!createJson.success) {
      // Show WHICH field failed validation instead of a bare "Validation error".
      const details = Array.isArray(createJson.errors)
        ? createJson.errors.map((e: any) => `${(e.path || []).join('.') || e.field || 'field'}: ${e.message}`).join('\n')
        : '';
      alert(`${createJson.message}${details ? `\n\n${details}` : ''}`);
      setBusy(false);
      return;
    }

    const pubRes = await fetch(`/api/products/${createJson.data.id}`, {
      method: 'PATCH',
      
    });
    const pubJson = await pubRes.json();
    setProductId(createJson.data.id);
    if (pubJson.success) setPublished(pubJson.data);
    else setPublishError([pubJson.messageBn, pubJson.message].filter(Boolean).join(' — ') || 'The product was saved as a draft but could not be published.');
    setBusy(false);
  };

  // Re-try publishing the draft created above (e.g. after the business was approved), instead of
  // creating a second product with the same barcode.
  const retryPublish = async () => {
    if (!productId) return;
    setBusy(true);
    const pubRes = await fetch(`/api/products/${productId}`, { method: 'PATCH' });
    const pubJson = await pubRes.json();
    if (pubJson.success) { setPublished(pubJson.data); setPublishError(null); }
    else setPublishError(pubJson.message || 'The product could not be published.');
    setBusy(false);
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-1">Seller Studio</h1>
      <p className="text-muted text-sm mb-8">Upload a product label image below, or paste raw label text. Extracted fields are shown for you to review and correct before publishing and anchoring on-chain.</p>

      {onboarding && !onboarding.eligibility.canRegister && (
        <div className="card p-4 mb-6 border-2 border-warning/40 bg-warning/5 text-sm">
          <div className="font-bold text-[#B45309] mb-1">You cannot publish products yet</div>
          {onboarding.eligibility.message}{' '}
          <a href="/seller/onboarding" className="text-primary font-semibold">Go to Business Verification →</a>
        </div>
      )}
      {onboarding?.eligibility.canRegister && onboarding.eligibility.basis === 'MOCK_REGISTRY_DEMO' && (
        <div className="card p-3 mb-6 border border-warning/40 text-xs text-[#B45309]">
          Demo mode: your licence was checked against the MOCK/DEMO REGISTRY — NOT OFFICIAL VERIFICATION. Products you publish will be labelled accordingly.
        </div>
      )}

      <div className="card p-6 mb-8">
        <div className="font-bold mb-1">Product Label</div>
        <p className="text-muted text-sm mb-3">
          Upload a clear image of the product label. Our AI will automatically extract the product information and fill in the form for you.
        </p>

        <input
          ref={labelFileInputRef}
          type="file"
          accept="image/jpeg,image/jpg,image/png,image/webp"
          className="hidden"
          onChange={onLabelImageChange}
        />

        {labelImage && (
          <div className="h-24 w-24 rounded-lg border border-slate-200 overflow-hidden bg-slate-50 mb-3">
            <img src={labelImage} alt="Product label" className="w-full h-full object-cover" />
          </div>
        )}

        <input
          ref={backFileInputRef}
          type="file"
          accept="image/jpeg,image/jpg,image/png,image/webp"
          className="hidden"
          onChange={onBackImageChange}
        />
        {backPreview && (
          <div className="h-24 w-24 rounded-lg border border-slate-200 overflow-hidden bg-slate-50 mb-3 inline-block ml-3 align-top">
            <img src={backPreview} alt="Back of pack" className="w-full h-full object-cover" />
          </div>
        )}

        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            className="btn btn-primary px-5 py-2.5"
            onClick={() => labelFileInputRef.current?.click()}
            disabled={labelStatus === 'uploading' || labelStatus === 'processing'}
          >
            {labelStatus === 'uploading' ? 'Uploading…' : frontFile ? 'Replace front photo' : 'Upload Label (front of pack)'}
          </button>
          <button
            type="button"
            className="btn btn-ghost px-5 py-2.5"
            onClick={() => backFileInputRef.current?.click()}
            disabled={labelStatus === 'uploading' || labelStatus === 'processing'}
          >
            {backFile ? 'Replace back photo' : 'Add back of pack (optional)'}
          </button>
          {frontFile && (
            <button type="button" className="btn btn-ghost px-5 py-2.5" onClick={makeEnhancedCover} disabled={coverBusy}>
              {coverBusy ? 'Creating…' : 'Make enhanced cover photo'}
            </button>
          )}
        </div>
        <p className="text-muted text-[11px] mt-3">
          Supported: JPG, JPEG, PNG, WEBP · Max 10 MB · Bangla and English text are read. The back of the pack usually has the
          dates, batch, MRP and manufacturer.
        </p>
        {aiInfo && (
          <p className="text-[11px] mt-1 text-muted">
            {aiInfo.used
              ? `AI reading: on (${aiInfo.provider}, ${aiInfo.model}). Values only the AI read are marked for you to check.`
              : `AI reading: off (${aiInfo.reason === 'NOT_CONFIGURED' ? 'no AI key configured' : aiInfo.reason === 'RATE_LIMITED' ? 'free-tier limit reached — try again later' : 'AI unavailable right now'}). OCR results only.`}
            {aiInfo.legibilityProblems ? ` Note from AI: ${aiInfo.legibilityProblems}` : ''}
          </p>
        )}

        {labelStatus === 'processing' && (
          <div className="mt-3 text-sm text-muted">
            Photo uploaded.<br />
            Reading Bangla and English text (OCR) and, if an AI key is set, checking it with AI…<br />
            This can take up to a minute for two photos.
          </div>
        )}
        {labelStatus === 'success' && (
          <div className="mt-3 text-sm">
            <div className="text-[#16803C] font-semibold">✓ Product information extracted successfully.</div>
            <div className="text-muted">Please review the information before publishing.</div>
          </div>
        )}
        {labelStatus === 'error' && (
          <div className="mt-3 text-sm text-danger">
            Unable to read the label. Please upload a clearer image or enter the information manually.
          </div>
        )}

        {rawOcrText && (
          <div className="mt-4 pt-4 border-t border-slate-200">
            <div className="text-xs font-semibold mb-1">Raw text OCR read from your image</div>
            <p className="text-muted text-[11px] mb-2">
              Only fields with a recognizable label (e.g. "BATCH:", "MRP:") get auto-filled below. If something's missing from
              the review panel, you can see it here and fill it in manually — or copy this into the box on the left and add
              labels, then click Run AI Extraction again.
            </p>
            <pre className="text-[11px] font-mono bg-slate-50 border border-slate-200 rounded-lg p-3 whitespace-pre-wrap max-h-32 overflow-y-auto">{rawOcrText}</pre>
            <button
              type="button"
              className="text-xs font-semibold text-primary mt-2"
              onClick={() => setLabelText(rawOcrText)}
            >
              Copy into paste box →
            </button>
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="card p-6">
          <textarea
            className="input h-28 mb-3"
            placeholder="Paste raw label OCR text here, e.g. PRODUCT: Rice 5kg  BRAND: Acme  BATCH: LOTA1B2  MFG: 03/2026  EXP: 09/2027  MRP: 650"
            value={labelText}
            onChange={(e) => setLabelText(e.target.value)}
          />
          <button className="btn btn-primary px-5 py-2.5" onClick={runOcr} disabled={busy}>
            {busy ? 'Processing…' : 'Run AI Extraction'}
          </button>
        </div>

        <div>
          {!fields && <div className="text-muted text-sm pt-4">Extracted fields will appear here.</div>}
          {fields && (
            <div className="card p-6">
              <div className="flex justify-between items-center mb-4">
                <div className="font-bold">Review Extracted Fields</div>
                {typeof ocr?.overallConfidence === 'number' && (
                  <span className={`text-xs font-bold rounded-full px-2.5 py-1 ${ocr.overallConfidence >= 95 ? 'bg-secondary/15 text-[#16803C]' : ocr.overallConfidence >= 90 ? 'bg-warning/15 text-[#B45309]' : 'bg-danger/15 text-danger'}`}>
                    {ocr.overallConfidence}% confidence
                  </span>
                )}
              </div>
              {Object.keys(fields).map((k) => (
                <div key={k} className="mb-3">
                  <div className="flex justify-between text-xs text-muted mb-1">
                    <span className="capitalize">{k === 'productNameBn' ? 'Product name (Bangla)' : k.replace(/([A-Z])/g, ' $1')}</span>
                    {typeof ocr?.confidence?.[k] === 'number' && <span className="font-mono">{ocr.confidence[k]}%</span>}
                    {fieldStatus[k] && <FieldStatusChip status={fieldStatus[k].status} />}
                  </div>
                  {fieldStatus[k]?.status === 'CONFLICT' && (
                    <div className="text-[11px] text-danger mb-1">OCR read “{String(fieldStatus[k].ocrValue)}”, AI read “{String(fieldStatus[k].aiValue)}”. Check the pack and correct this field.</div>
                  )}
                  <input
                    className="input"
                    value={fields[k] ?? ''}
                    onChange={(e) => setFields({ ...fields, [k]: e.target.value })}
                  />
                </div>
              ))}

              <div className="mt-5 pt-5 border-t border-slate-200">
                <div className="font-bold mb-1">Price &amp; stock</div>
                <p className="text-muted text-[11px] mb-2">
                  The <b>MRP</b> field above is the maximum retail price printed on the pack. Your selling price can be equal to or lower than it —
                  a higher price is refused (দাম MRP-এর চেয়ে বেশি হতে পারবে না).
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs">Selling price ৳ <span className="text-muted">(empty = MRP)</span>
                    <input className="input" inputMode="decimal" placeholder={fields.mrp ? String(fields.mrp) : 'e.g. 120'} value={sellPrice} onChange={(e) => setSellPrice(e.target.value)} />
                  </label>
                  <label className="text-xs">Units in stock
                    <input className="input" type="number" min={0} value={stockQty} onChange={(e) => setStockQty(e.target.value)} />
                  </label>
                </div>
                {sellPrice && fields.mrp && Number(sellPrice) > Number(fields.mrp) && (
                  <div className="text-[11px] text-danger mt-1" lang="bn">দেওয়া দাম নিবন্ধিত MRP-এর চেয়ে বেশি। MRP ও প্যাকের আকার যাচাই করুন।</div>
                )}
              </div>

              <div className="mt-5 pt-5 border-t border-slate-200">
                <div className="font-bold mb-1">Manufacturer &amp; brand</div>
                <p className="text-muted text-[11px] mb-2">
                  Your account email is never used as the manufacturer. A manufacturer you name is shown to buyers as an unverified claim.
                </p>
                <div className="flex flex-col gap-1.5 text-sm">
                  <label className="flex items-center gap-2">
                    <input type="radio" checked={maker === 'SELF'} disabled={!sellerRoles.includes('MANUFACTURER')} onChange={() => setMaker('SELF')} />
                    My reviewed business made this product{!sellerRoles.includes('MANUFACTURER') && <span className="text-muted text-[11px]">(add the manufacturer role in Business Verification)</span>}
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="radio" checked={maker === 'CLAIM'} onChange={() => setMaker('CLAIM')} />
                    Another company made it{'manufacturer' in fields ? ' — the "Manufacturer" field above' : ''}{fields.manufacturer ? `: ${fields.manufacturer}` : ''}
                  </label>
                  {maker === 'CLAIM' && !('manufacturer' in fields) && (
                    <input className="input ml-6" placeholder="Manufacturer name as printed on the label" value={claimName}
                      onChange={(e) => setClaimName(e.target.value)} />
                  )}
                  <label className="flex items-center gap-2">
                    <input type="radio" checked={maker === 'UNKNOWN'} onChange={() => setMaker('UNKNOWN')} />
                    Not stated
                  </label>
                  <label className="flex items-center gap-2 mt-1">
                    <input type="checkbox" checked={brandOwnerIsSeller} disabled={!sellerRoles.includes('BRAND_OWNER')} onChange={(e) => setBrandOwnerIsSeller(e.target.checked)} />
                    My business owns this brand
                  </label>
                </div>
                {fields.licenceNumber && (
                  <p className="text-muted text-[11px] mt-2">Licence text from the label (&quot;{fields.licenceNumber}&quot;) is stored as printed on the label — not independently verified.</p>
                )}
              </div>

              <div className="mt-5 pt-5 border-t border-slate-200">
                <div className="font-bold mb-3">Product Images</div>
                <div className="grid grid-cols-2 gap-3">
                  {IMAGE_SLOTS.map((slot, i) => (
                    <div key={slot.label}>
                      <div className="text-xs font-semibold mb-1">
                        {slot.label}{slot.required && <span className="text-danger"> *</span>}
                      </div>
                      {slot.help && <p className="text-muted text-[11px] mb-1.5">{slot.help}</p>}

                      <input
                        ref={fileInputRefs[i]}
                        type="file"
                        accept="image/jpeg,image/jpg,image/png,image/webp"
                        className="hidden"
                        onChange={(e) => onImageChange(i, e)}
                      />

                      {images[i] ? (
                        <div>
                          {enhancedUrls.includes(images[i] as string) && (
                            <div className="text-[10px] text-primary font-semibold mb-1">Enhanced from your photo — buyers see this label</div>
                          )}
                          <div className="h-24 w-24 rounded-lg border border-slate-200 overflow-hidden bg-slate-50">
                            <img src={images[i] as string} alt={slot.label} className="w-full h-full object-cover" />
                          </div>
                          <div className="flex gap-3 mt-1.5 text-xs font-semibold">
                            <button type="button" className="text-primary" onClick={() => fileInputRefs[i].current?.click()} disabled={imageBusy[i]}>Replace</button>
                            <button type="button" className="text-danger" onClick={() => removeImage(i)} disabled={imageBusy[i]}>Remove</button>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          className="btn btn-ghost text-xs px-3 py-2"
                          onClick={() => fileInputRefs[i].current?.click()}
                          disabled={imageBusy[i]}
                        >
                          {imageBusy[i] ? 'Uploading…' : 'Upload Image'}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <p className="text-muted text-[11px] mt-3 leading-relaxed">
                  Supported formats: JPG, JPEG, PNG, WEBP<br />
                  Maximum 4 images<br />
                  Maximum size: 10 MB each
                </p>
              </div>

              <button className="btn btn-secondary px-5 py-2.5 mt-4 w-full" onClick={createAndPublish} disabled={busy}>
                {busy ? 'Publishing…' : 'Confirm, Generate Hash & Publish'}
              </button>

              {publishError && (
                <div className="mt-4 p-3.5 bg-warning/10 rounded-xl border border-warning/30 text-sm">
                  <div className="font-bold text-[#B45309] mb-1">Saved as draft — not published</div>
                  <div className="text-muted">{publishError}</div>
                  <button type="button" className="btn btn-ghost text-xs px-3 py-1.5 mt-2 mr-3" disabled={busy} onClick={retryPublish}>
                    Try publishing this draft again
                  </button>
                  <a href="/seller/onboarding" className="text-xs font-semibold text-primary mt-2 inline-block mr-4">Business Verification →</a>
                  <a href="/seller/products" className="text-xs font-semibold text-primary mt-2 inline-block">Your drafts are saved in My products →</a>
                </div>
              )}

              {published && (
                <div className="mt-4 p-3.5 bg-secondary/10 rounded-xl border border-secondary/30">
                  <div className="font-bold text-[#16803C] text-sm mb-1">Published & anchored</div>
                  <div className="font-mono text-[10px] break-all text-[#166534]">{published.hash}</div>
                  {published.registrationBasis === 'MOCK_REGISTRY_DEMO' && (
                    <div className="text-[11px] text-[#B45309] mt-1">Seller licence basis: MOCK/DEMO REGISTRY — NOT OFFICIAL VERIFICATION</div>
                  )}
                  <a href={`/product/${productId}`} className="text-xs font-semibold text-primary mt-2 inline-block mr-4">View live product page →</a>
                  <a href="/seller/products" className="text-xs font-semibold text-primary mt-2 inline-block">My products →</a>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// v4: how a field's value was obtained. Only "agreed" / "confirmed by OCR text" are green.
function FieldStatusChip({ status }: { status: string }) {
  const map: Record<string, [string, string]> = {
    AGREED: ['OCR + AI agree', 'bg-secondary/15 text-[#16803C]'],
    AI_CONFIRMED_BY_TEXT: ['AI, confirmed by OCR text', 'bg-secondary/15 text-[#16803C]'],
    OCR_ONLY: ['OCR only', 'bg-slate-100 text-slate-600'],
    AI_ONLY_CHECK: ['AI only — please check', 'bg-warning/15 text-[#B45309]'],
    CONFLICT: ['OCR and AI disagree — check', 'bg-danger/15 text-danger'],
    NOT_FOUND: ['Not found — enter manually', 'bg-slate-100 text-slate-500'],
  };
  const [text, cls] = map[status] || [status, 'bg-slate-100 text-slate-600'];
  return <span className={`text-[10px] font-bold rounded-full px-2 py-0.5 ${cls}`}>{text}</span>;
}
