'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Badge } from '@/components/IdentityBadges';
import { BlockerList, ExpiryBadge } from '@/components/ProtectionBadges';

// v5 "My products": every listing you created, loaded from the database (drafts included), so nothing is
// lost when you close the browser. Shows whether buyers can see each one and why not, and lets you
// publish a draft, change price/stock (checked against the MRP) or recall a batch.

const REASONS: [string, string][] = [
  ['QUALITY_ISSUE', 'Quality issue / মানগত সমস্যা'],
  ['SAFETY_RISK', 'Possible safety risk / সম্ভাব্য নিরাপত্তা ঝুঁকি'],
  ['LABELLING_ERROR', 'Labelling error / লেবেলে ভুল'],
  ['REGULATOR_INSTRUCTION', 'Regulator instruction / নিয়ন্ত্রক সংস্থার নির্দেশনা'],
  ['MANUFACTURER_REQUEST', 'Manufacturer request / প্রস্তুতকারকের অনুরোধ'],
  ['OTHER', 'Other / অন্য কারণ'],
];

function StatusBadge({ p }: { p: any }) {
  if (p.recall) return <Badge tone="red">Recalled — hidden</Badge>;
  if (p.status === 'DRAFT') return <Badge tone="gray">Draft — not published</Badge>;
  if (p.expiry.state === 'EXPIRED') return <Badge tone="red">Expired — hidden</Badge>;
  if (!p.visibleToBuyers) return <Badge tone="amber">Hidden from buyers</Badge>;
  if (p.stock === 0) return <Badge tone="amber">On sale · out of stock</Badge>;
  return <Badge tone="green">On sale</Badge>;
}

export default function SellerProducts() {
  const [rows, setRows] = useState<any[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<Record<string, { ok: boolean; text: string }>>({});
  const [edit, setEdit] = useState<Record<string, { price: string; stock: string }>>({});
  const [recallFor, setRecallFor] = useState<string | null>(null);
  const [recallForm, setRecallForm] = useState({ reasonCode: 'QUALITY_ISSUE', publicMessage: '' });
  const [busy, setBusy] = useState<string | null>(null);

  const load = async () => {
    const j = await (await fetch('/api/seller/products')).json().catch(() => ({}));
    if (j.success) setRows(j.data);
    else setError(j.message || 'Could not load your products.');
  };
  useEffect(() => { load(); }, []);

  const say = (id: string, ok: boolean, text: string) => setMsg((m) => ({ ...m, [id]: { ok, text } }));

  const publish = async (id: string) => {
    setBusy(id);
    const j = await (await fetch(`/api/products/${id}`, { method: 'PATCH' })).json().catch(() => ({}));
    say(id, !!j.success, j.success ? 'Published and anchored.' : [j.messageBn, j.message].filter(Boolean).join(' — '));
    setBusy(null); load();
  };

  const saveListing = async (p: any) => {
    const e = edit[p.id];
    const body: any = {};
    if (e.price !== String(p.price)) body.price = e.price;
    if (e.stock !== String(p.stock)) body.stock = Number(e.stock);
    if (!Object.keys(body).length) { setEdit((x) => { const n = { ...x }; delete n[p.id]; return n; }); return; }
    setBusy(p.id);
    const j = await (await fetch(`/api/products/${p.id}/listing`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json().catch(() => ({}));
    say(p.id, !!j.success, j.success ? 'Saved.' : [j.messageBn, j.message].filter(Boolean).join(' — '));
    if (j.success) setEdit((x) => { const n = { ...x }; delete n[p.id]; return n; });
    setBusy(null); load();
  };

  const recall = async (id: string) => {
    setBusy(id);
    const j = await (await fetch('/api/recalls', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId: id, reasonCode: recallForm.reasonCode, publicMessage: recallForm.publicMessage || undefined }) })).json().catch(() => ({}));
    say(id, !!j.success, j.success
      ? `${j.message}${j.data.simulatedOrdersSkipped ? ` (${j.data.simulatedOrdersSkipped} simulated demo order(s) were not counted.)` : ''} Notices are in-app only; the on-chain record is unchanged.`
      : j.message || 'Recall failed.');
    setRecallFor(null); setBusy(null); load();
  };

  if (!rows) return <div className="max-w-6xl mx-auto px-6 py-12 text-muted">{error || 'Loading your products…'}</div>;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="flex flex-wrap justify-between items-end gap-3 mb-6">
        <div>
          <h1 className="font-display text-2xl">My products</h1>
          <p className="text-sm text-muted">{rows.length} listing(s) saved in the database · {rows.filter((r) => r.status === 'DRAFT').length} draft(s). They stay here after you close the browser or restart the app.</p>
        </div>
        <Link href="/seller/dashboard" className="btn btn-primary px-5 py-2.5">+ Add a product</Link>
      </div>

      {rows.length === 0 && <div className="card p-6 text-sm text-muted">No products yet. Add one in Seller Studio.</div>}

      <div className="space-y-3">
        {rows.map((p) => (
          <div key={p.id} className="card p-4">
            <div className="flex flex-wrap gap-4 items-start">
              <div className="w-16 h-16 rounded-lg bg-slate-100 flex items-center justify-center text-3xl overflow-hidden">
                {p.coverImageUrl ? <img src={p.coverImageUrl} alt="" className="w-full h-full object-cover" /> : p.imageEmoji}
              </div>
              <div className="flex-1 min-w-[220px]">
                <div className="flex flex-wrap items-center gap-2">
                  <Link href={`/product/${p.id}`} className="font-bold">{p.name}</Link>
                  <StatusBadge p={p} />
                  <ExpiryBadge expiry={p.expiry} compact />
                  {p.openReviews > 0 && <Badge tone="amber">{p.openReviews} buyer label check(s) sent for review</Badge>}
                </div>
                <div className="text-xs text-muted mt-1 font-mono">
                  Batch {p.batchNumber} · EXP {p.expiryDate} · MRP {p.mrp.amount ? `৳${p.mrp.amount}` : 'not registered'}
                  {p.mrp.status === 'ADMIN_REVIEWED' ? ' (admin-reviewed)' : ''} · sold {p.unitsSold}
                </div>
                {!p.visibleToBuyers && p.status !== 'DRAFT' && <div className="mt-1"><BlockerList blockers={p.blockers.filter((b: any) => b.code !== 'OUT_OF_STOCK')} /></div>}
              </div>

              <div className="text-sm">
                {edit[p.id] ? (
                  <div className="flex items-end gap-2">
                    <label className="text-xs">Price ৳<input className="input w-24" value={edit[p.id].price} onChange={(e) => setEdit({ ...edit, [p.id]: { ...edit[p.id], price: e.target.value } })} /></label>
                    <label className="text-xs">Stock<input className="input w-20" type="number" min={0} value={edit[p.id].stock} onChange={(e) => setEdit({ ...edit, [p.id]: { ...edit[p.id], stock: e.target.value } })} /></label>
                    <button className="btn btn-primary text-xs px-3 py-2" disabled={busy === p.id} onClick={() => saveListing(p)}>Save</button>
                  </div>
                ) : (
                  <div className="text-right">
                    <div className="font-mono font-bold">৳{p.price}</div>
                    <div className="text-xs text-muted">stock {p.stock}</div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-wrap gap-2 mt-3 text-xs">
              {p.status === 'DRAFT' && <button className="btn btn-secondary px-3 py-1.5" disabled={busy === p.id} onClick={() => publish(p.id)}>Publish</button>}
              {!edit[p.id] && <button className="btn btn-ghost px-3 py-1.5" onClick={() => setEdit({ ...edit, [p.id]: { price: String(p.price), stock: String(p.stock) } })}>Change price / stock</button>}
              {p.status === 'PUBLISHED' && !p.recall && <button className="btn btn-ghost px-3 py-1.5 text-danger" onClick={() => setRecallFor(recallFor === p.id ? null : p.id)}>Recall batch…</button>}
              {p.status === 'PUBLISHED' && <Link href="/seller/codes" className="btn btn-ghost px-3 py-1.5">QR codes</Link>}
            </div>

            {recallFor === p.id && (
              <div className="mt-3 p-3 rounded-xl border-2 border-danger/40 bg-danger/5 text-sm">
                <div className="font-bold text-danger mb-1">Recall batch {p.batchNumber}</div>
                <p className="text-xs text-muted mb-2">
                  Sales stop immediately. Buyers whose orders contain this batch get an in-app notice (simulated demo orders are not counted).
                  Only an administrator can close a recall. This is recorded in Verité’s database, not on the blockchain.
                </p>
                <select className="input mb-2" value={recallForm.reasonCode} onChange={(e) => setRecallForm({ ...recallForm, reasonCode: e.target.value })}>
                  {REASONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
                <input className="input mb-2" maxLength={300} placeholder="Message to buyers (optional, max 300 characters)" value={recallForm.publicMessage}
                  onChange={(e) => setRecallForm({ ...recallForm, publicMessage: e.target.value })} />
                <button className="btn px-4 py-2 bg-danger text-white" disabled={busy === p.id} onClick={() => recall(p.id)}>Confirm recall</button>
              </div>
            )}
            {msg[p.id] && <div className={`text-xs mt-2 ${msg[p.id].ok ? 'text-[#16803C]' : 'text-danger'}`}>{msg[p.id].text}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}
