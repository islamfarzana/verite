'use client';
import { useState } from 'react';

export default function VerifyPage() {
  const [barcode, setBarcode] = useState('8901234567890');
  const [state, setState] = useState<'idle' | 'running' | 'done'>('idle');
  const [result, setResult] = useState<any>(null);

  const check = async () => {
    setState('running');
    setResult(null);
    const listRes = await fetch(`/api/products?search=`);
    const list = (await listRes.json()).data as any[];
    const match = list.find((p) => String(p.barcode) === barcode.trim());

    if (!match) {
      setTimeout(() => { setResult(null); setState('done'); }, 1000);
      return;
    }
    const verifyRes = await fetch(`/api/products/${match.id}/verify`, { method: 'POST' });
    const verifyJson = await verifyRes.json();
    setTimeout(() => {
      setResult({ ...verifyJson.data, product: match });
      setState('done');
    }, 1000);
  };

  return (
    <div className="max-w-lg mx-auto px-6 py-16">
      <h1 className="font-display text-2xl mb-2">Verify a Product</h1>
      <p className="text-muted text-sm mb-6">
        Enter a barcode. This calls the same real verification endpoint the product page uses — it recomputes the Keccak-256 hash and compares it to the stored on-chain record. A barcode identifies a product type, not an individual pack: to check the batch or unit code printed on your pack, scan its QR code.
      </p>
      <div className="flex gap-2">
        <input className="input" value={barcode} onChange={(e) => setBarcode(e.target.value)} />
        <button className="btn btn-primary px-5 py-2.5" onClick={check}>Verify</button>
      </div>

      {state === 'running' && <div className="card mt-6 p-5 text-sm animate-pulse">Comparing hashes…</div>}

      {state === 'done' && (
        result ? (
          result.verified ? (
            <div className="card mt-6 p-5 border-secondary">
              <div className="font-bold text-[#16803C] mb-1">✅ Authentic Product</div>
              <div className="text-sm">{result.product.name}</div>
              <div className="font-mono text-[11px] text-muted mt-2 break-all">{result.onChainHash}</div>
            </div>
          ) : (
            <div className="card mt-6 p-5 border-danger">
              <div className="font-bold text-danger mb-1">⚠ Hash Mismatch</div>
              <div className="text-sm text-muted">This product failed verification.</div>
            </div>
          )
        ) : (
          <div className="card mt-6 p-5 border-danger">
            <div className="font-bold text-danger mb-1">⚠ No record found</div>
            <div className="text-sm text-muted">This barcode isn't registered on the marketplace.</div>
          </div>
        )
      )}
    </div>
  );
}
