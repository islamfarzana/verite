'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSession } from '@/lib/client-auth';

export default function BuyerDashboard() {
  const { user } = useSession();
  const [orders, setOrders] = useState<any[]>([]);
  const [cartCount, setCartCount] = useState(0);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    fetch('/api/orders').then((r) => r.json()).then((res) => setOrders(res.data || []));
    // v5: the cart is saved in the database for this account.
    fetch('/api/cart').then((r) => r.json()).then((res) => setCartCount(res.data?.itemCount || 0)).catch(() => setCartCount(0));
    fetch('/api/buyer/notifications').then((r) => r.json()).then((res) => setUnread(res.data?.unread || 0)).catch(() => setUnread(0));
  }, []);

  const pending = orders.filter((o) => o.status !== 'DELIVERED').length;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-1">Welcome back{user ? `, ${user.name}` : ''}!</h1>
      <p className="text-muted text-sm mb-8">Your shopping summary.</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        {[
          ['Total Orders', orders.length],
          ['Pending Orders', pending],
          ['Items in Cart', cartCount],
          ['Unread notices', unread],
        ].map(([l, v]) => (
          <div key={l as string} className="card p-5">
            <div className="text-xs text-muted mb-1">{l}</div>
            <div className="font-mono text-2xl font-bold">{v as number}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-3 mb-10">
        <Link href="/" className="btn btn-primary px-5 py-2.5">Browse Products</Link>
        <Link href="/buyer/orders" className="btn btn-ghost px-5 py-2.5">Track Orders</Link>
        <Link href="/buyer/cart" className="btn btn-ghost px-5 py-2.5">View Cart</Link>
        <Link href="/buyer/notifications" className="btn btn-ghost px-5 py-2.5">Notifications{unread ? ` (${unread})` : ''}</Link>
      </div>

      <div className="font-bold mb-3">Recent Orders</div>
      {orders.length === 0 ? (
        <div className="card p-6 text-sm text-muted">You haven't placed any orders yet.</div>
      ) : (
        <div className="card overflow-hidden">
          {orders.slice(0, 5).map((o, idx) => (
            <div key={o.id} className={`flex justify-between items-center px-5 py-3 text-sm ${idx < 4 ? 'border-b border-line' : ''}`}>
              <span className="font-mono text-muted">{o.order_number}</span>
              <span>৳{o.grand_total}</span>
              <span className="bg-primary/10 text-primary rounded-full px-2.5 py-1 text-xs font-semibold">{o.status}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
