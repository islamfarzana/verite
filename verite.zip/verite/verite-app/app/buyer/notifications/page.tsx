'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

// v5: the buyer's in-app notices (batch recalls for products they ordered). In-app only — Verité has no
// email/SMS provider configured, so nothing is sent outside the app.

export default function BuyerNotifications() {
  const [data, setData] = useState<{ notifications: any[]; unread: number } | null>(null);
  const load = () => fetch('/api/buyer/notifications').then((r) => r.json()).then((j) => setData(j.data || { notifications: [], unread: 0 }));
  useEffect(() => { load(); }, []);

  const markAll = async () => {
    await fetch('/api/buyer/notifications', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ all: true }) });
    load();
  };

  if (!data) return <div className="max-w-3xl mx-auto px-6 py-12 text-muted">Loading…</div>;
  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="font-display text-2xl" lang="bn">বিজ্ঞপ্তি</h1>
          <div className="text-sm text-muted">Notifications · {data.unread} unread</div>
        </div>
        {data.unread > 0 && <button className="btn btn-ghost text-xs px-3 py-1.5" onClick={markAll}>Mark all as read</button>}
      </div>
      {data.notifications.length === 0 && <div className="card p-6 text-sm text-muted">No notifications. If a batch you bought is recalled, you will see it here.</div>}
      {data.notifications.map((n) => (
        <div key={n.id} className={`card p-4 mb-3 ${n.readAt ? '' : 'border-2 border-danger/40'}`}>
          <div className="font-bold text-danger" lang="bn">{n.titleBn}</div>
          <div className="text-sm mt-1" lang="bn">{n.bodyBn}</div>
          <div className="text-xs text-muted mt-2">{n.titleEn}. {n.bodyEn}</div>
          <div className="text-[11px] text-muted mt-2 flex gap-3">
            <span>{n.createdAt.slice(0, 16).replace('T', ' ')} UTC</span>
            <span>In-app notice</span>
            {n.productId && <Link href={`/product/${n.productId}`} className="text-primary font-semibold">Product page →</Link>}
          </div>
        </div>
      ))}
    </div>
  );
}
