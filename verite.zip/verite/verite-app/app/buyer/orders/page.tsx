'use client';
import { useEffect, useState } from 'react';

const STATUS_FLOW = ['PENDING', 'CONFIRMED', 'PACKED', 'SHIPPED', 'DELIVERED'];

export default function OrdersPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/orders')
      .then((r) => r.json())
      .then((res) => setOrders(res.data || []))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="max-w-4xl mx-auto px-6 py-16 text-muted">Loading…</div>;

  if (orders.length === 0) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h3 className="font-bold mb-1">No orders found.</h3>
        <a href="/" className="btn btn-primary px-6 py-3 mt-4 inline-block">Browse Products</a>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-6">My Orders</h1>
      <div className="space-y-4">
        {orders.map((o) => {
          const stepIndex = Math.max(STATUS_FLOW.indexOf(o.status), 0);
          return (
            <div key={o.id} className="card p-5">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="font-mono font-bold text-sm">{o.order_number}</div>
                  <div className="text-xs text-muted">{new Date(o.created_at).toLocaleDateString()} · {o.payment_method} · {o.delivery_method}</div>
                </div>
                <div className="font-mono font-bold text-primary">৳{o.grand_total}</div>
              </div>

              <div className="flex items-center mb-4">
                {STATUS_FLOW.map((s, i) => (
                  <div key={s} className="flex items-center flex-1 last:flex-none">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${i <= stepIndex ? 'bg-secondary text-white' : 'bg-slate-200 text-muted'}`}>
                      {i < stepIndex ? '✓' : i + 1}
                    </div>
                    {i < STATUS_FLOW.length - 1 && <div className={`flex-1 h-0.5 ${i < stepIndex ? 'bg-secondary' : 'bg-slate-200'}`} />}
                  </div>
                ))}
              </div>
              <div className="text-xs text-muted mb-3">{STATUS_FLOW[stepIndex]}{o.shipment ? ` · Tracking ${o.shipment.tracking_number} · ETA ${o.shipment.estimated_delivery}` : ''}</div>

              {o.items.map((it: any) => (
                <div key={it.id} className="flex justify-between text-sm py-1">
                  <span>{it.image_emoji} {it.name} × {it.quantity}</span>
                  <span className="font-mono">৳{it.price * it.quantity}</span>
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}
