'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ExpiryBadge } from '@/components/ProtectionBadges';

// v5: the cart is stored in the database for your account (not in this browser), so it is still here after
// you close the browser, restart the app, or sign in on another device. Items that can no longer be sold
// (recalled, expired, out of stock…) stay visible with the reason, but are not counted or checked out.

export default function CartPage() {
  const [cart, setCart] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const router = useRouter();

  const load = async () => {
    const json = await (await fetch('/api/cart')).json().catch(() => ({}));
    if (json.success) setCart(json.data);
    else setError(json.message || 'Could not load your cart.');
  };

  useEffect(() => {
    (async () => {
      // One-time move of a cart saved by an older version in this browser into your account.
      let legacy: any[] = [];
      try { legacy = JSON.parse(localStorage.getItem('verite_cart') || '[]'); } catch { legacy = []; }
      if (Array.isArray(legacy) && legacy.length) {
        const json = await (await fetch('/api/cart', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ items: legacy.map((i) => ({ productId: i.id, quantity: i.qty })) }) })).json().catch(() => ({}));
        if (json.success) {
          try { localStorage.removeItem('verite_cart'); } catch { /* ignore */ }
          setNotice(`Moved ${json.data.added} item(s) from this browser into your saved cart${json.data.skipped ? ` (${json.data.skipped} could not be added because they are no longer for sale)` : ''}.`);
        }
      }
      await load();
    })();
  }, []);

  const change = async (method: 'PATCH' | 'DELETE', productId: string, quantity?: number) => {
    setError(null);
    const res = method === 'DELETE'
      ? await fetch(`/api/cart?productId=${encodeURIComponent(productId)}`, { method })
      : await fetch('/api/cart', { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productId, quantity }) });
    const json = await res.json().catch(() => ({}));
    if (json.success) setCart(json.data);
    else setError([json.messageBn, json.message].filter(Boolean).join(' — '));
  };

  if (!cart) return <div className="max-w-2xl mx-auto px-6 py-12 text-muted">{error || 'Loading your cart…'}</div>;

  if (cart.lines.length === 0) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <div className="text-4xl mb-3">🛒</div>
        <h3 className="font-bold mb-1">Your cart is empty</h3>
        {notice && <p className="text-xs text-muted">{notice}</p>}
        <a href="/" className="btn btn-primary px-6 py-3 mt-4 inline-block">Continue Shopping</a>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-6 py-12">
      <h1 className="font-display text-2xl mb-1">Shopping Cart</h1>
      <p className="text-xs text-muted mb-6">Saved to your account — it stays here after you close the browser.</p>
      {notice && <div className="card p-3 mb-4 text-xs">{notice}</div>}
      {error && <div className="card p-3 mb-4 text-sm text-danger">{error}</div>}
      {cart.lines.map((item: any) => (
        <div key={item.productId} className={`card p-3.5 mb-2.5 ${item.available ? '' : 'opacity-80 border-danger/40'}`}>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-slate-100 flex items-center justify-center text-2xl overflow-hidden">
              {item.coverImageUrl ? <img src={item.coverImageUrl} alt="" className="w-full h-full object-cover" /> : item.emoji}
            </div>
            <div className="flex-1">
              <Link href={`/product/${item.productId}`} className="font-bold text-sm">{item.name}</Link>
              <div className="text-muted text-xs">৳{item.price} each</div>
              <ExpiryBadge expiry={item.expiry} compact />
            </div>
            <div className="flex items-center gap-2">
              <button className="btn btn-ghost w-7 h-7 flex items-center justify-center p-0" onClick={() => item.quantity > 1 && change('PATCH', item.productId, item.quantity - 1)}>-</button>
              <span className="font-mono text-sm w-5 text-center">{item.quantity}</span>
              <button className="btn btn-ghost w-7 h-7 flex items-center justify-center p-0" disabled={!item.available} onClick={() => change('PATCH', item.productId, item.quantity + 1)}>+</button>
            </div>
            <div className="font-mono font-bold w-20 text-right">{item.available ? `৳${item.lineTotal}` : '—'}</div>
            <button className="btn btn-ghost text-xs px-3 py-1.5" onClick={() => change('DELETE', item.productId)}>Remove</button>
          </div>
          {!item.available && (
            <div className="text-xs text-danger mt-2">
              <span lang="bn">{item.reasons[0]?.bn}</span> — {item.reasons[0]?.en} This item will not be ordered.
            </div>
          )}
        </div>
      ))}
      <div className="card p-5 mt-4 flex justify-between items-center">
        <div>
          <div className="text-muted text-xs">Subtotal (VAT & shipping calculated at checkout)</div>
          <div className="font-mono text-xl font-bold">৳{cart.subtotal}</div>
          {cart.unavailableCount > 0 && <div className="text-[11px] text-danger">{cart.unavailableCount} item(s) not available are excluded.</div>}
        </div>
        <button className="btn btn-secondary px-6 py-3 disabled:opacity-50" disabled={cart.lines.every((l: any) => !l.available)} onClick={() => router.push('/buyer/checkout')}>
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
}
