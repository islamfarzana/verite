'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

const PAYMENT_METHODS = [
  ['COD', 'Cash on Delivery'],
  ['SSLCOMMERZ', 'SSLCommerz'],
  ['BKASH', 'bKash'],
  ['NAGAD', 'Nagad'],
  ['ROCKET', 'Rocket'],
  ['STRIPE', 'Credit / Debit Card (Stripe)'],
];
const DELIVERY_METHODS = [
  ['STANDARD', 'Standard (3–4 days)', 60],
  ['EXPRESS', 'Express (next day)', 150],
  ['PICKUP', 'Store Pickup', 0],
];

export default function CheckoutPage() {
  const [cart, setCart] = useState<any[]>([]);
  const [address, setAddress] = useState({ name: '', phone: '', division: '', district: '', addressLine: '' });
  const [payment, setPayment] = useState('COD');
  const [delivery, setDelivery] = useState('STANDARD');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  // v5: items come from the cart saved in the database; only items that can still be sold are ordered.
  // The server re-checks every item again inside the order transaction.
  useEffect(() => {
    fetch('/api/cart').then((r) => r.json()).then((json) => {
      const lines = (json.data?.lines || []).filter((l: any) => l.available)
        .map((l: any) => ({ id: l.productId, name: l.name, price: l.price, qty: l.quantity }));
      if (lines.length === 0) router.push('/buyer/cart');
      setCart(lines);
    }).catch(() => router.push('/buyer/cart'));
  }, []);

  const subtotal = Math.round(cart.reduce((s, i) => s + Math.round(i.price * 100) * i.qty, 0)) / 100;
  const deliveryCharge = DELIVERY_METHODS.find((d) => d[0] === delivery)![2] as number;
  const vat = Math.round(subtotal * 0.05 * 100) / 100;
  const grandTotal = subtotal + vat + deliveryCharge;

  const placeOrder = async () => {
    setError('');
    if (!address.name || !address.phone || !address.addressLine) {
      setError('Please fill in your name, phone, and address.');
      return;
    }
    setBusy(true);
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items: cart.map((i) => ({ productId: i.id, quantity: i.qty })),
        shippingAddress: address,
        paymentMethod: payment,
        deliveryMethod: delivery,
      }),
    });
    const json = await res.json();
    setBusy(false);
    if (!json.success) {
      // A buyer-protection refusal (recalled / expired / above MRP / stock) is shown here with the reason.
      if (json.code === 'NOT_SELLABLE') { setError([json.messageBn, json.message].filter(Boolean).join(' — ')); return; }
      setError(json.message);
      router.push('/payment/failed');
      return;
    }
    router.push(`/payment/success?order=${json.data.orderNumber}&invoice=${json.data.invoiceNumber}&tracking=${json.data.trackingNumber}&total=${json.data.grandTotal}`);
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-8">Checkout</h1>
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <div className="card p-5">
            <div className="font-bold mb-3">Shipping Address</div>
            <div className="grid grid-cols-2 gap-3">
              <input className="input col-span-2" placeholder="Full name" value={address.name} onChange={(e) => setAddress({ ...address, name: e.target.value })} />
              <input className="input col-span-2" placeholder="Phone number" value={address.phone} onChange={(e) => setAddress({ ...address, phone: e.target.value })} />
              <input className="input" placeholder="Division" value={address.division} onChange={(e) => setAddress({ ...address, division: e.target.value })} />
              <input className="input" placeholder="District" value={address.district} onChange={(e) => setAddress({ ...address, district: e.target.value })} />
              <textarea className="input col-span-2 h-20" placeholder="Address line (house, road, area)" value={address.addressLine} onChange={(e) => setAddress({ ...address, addressLine: e.target.value })} />
            </div>
          </div>

          <div className="card p-5">
            <div className="font-bold mb-3">Delivery Method</div>
            {DELIVERY_METHODS.map(([code, label, price]) => (
              <label key={code as string} className="flex items-center justify-between py-2 border-b border-line last:border-0 cursor-pointer text-sm">
                <span className="flex items-center gap-2">
                  <input type="radio" name="delivery" checked={delivery === code} onChange={() => setDelivery(code as string)} />
                  {label}
                </span>
                <span className="font-mono">{price === 0 ? 'Free' : `৳${price}`}</span>
              </label>
            ))}
          </div>

          <div className="card p-5">
            <div className="font-bold mb-3">Payment Method</div>
            {PAYMENT_METHODS.map(([code, label]) => (
              <label key={code} className="flex items-center gap-2 py-2 border-b border-line last:border-0 cursor-pointer text-sm">
                <input type="radio" name="payment" checked={payment === code} onChange={() => setPayment(code)} />
                {label}
              </label>
            ))}
          </div>
        </div>

        <div>
          <div className="card p-5 sticky top-20">
            <div className="font-bold mb-3">Order Summary</div>
            {cart.map((i) => (
              <div key={i.id} className="flex justify-between text-xs text-muted py-1">
                <span>{i.name} × {i.qty}</span><span>৳{i.price * i.qty}</span>
              </div>
            ))}
            <div className="border-t border-line mt-3 pt-3 space-y-1.5 text-sm">
              <div className="flex justify-between"><span className="text-muted">Subtotal</span><span>৳{subtotal}</span></div>
              <div className="flex justify-between"><span className="text-muted">VAT (5%)</span><span>৳{vat}</span></div>
              <div className="flex justify-between"><span className="text-muted">Shipping</span><span>{deliveryCharge === 0 ? 'Free' : `৳${deliveryCharge}`}</span></div>
              <div className="flex justify-between font-bold text-base pt-2 border-t border-line">
                <span>Grand Total</span><span className="font-mono text-primary">৳{grandTotal.toFixed(2)}</span>
              </div>
            </div>
            {error && <div className="text-danger text-xs mt-3">{error}</div>}
            <button className="btn btn-secondary w-full py-3 mt-4" onClick={placeOrder} disabled={busy}>
              {busy ? 'Placing order…' : 'Place Order'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
