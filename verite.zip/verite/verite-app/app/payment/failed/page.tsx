'use client';
import Link from 'next/link';

export default function PaymentFailedPage() {
  return (
    <div className="max-w-md mx-auto px-6 py-20 text-center">
      <div className="text-5xl mb-4">⚠</div>
      <h1 className="font-display text-2xl mb-2">Payment Failed</h1>
      <p className="text-muted text-sm mb-6">Something went wrong placing your order. No charge was made.</p>
      <div className="flex gap-3 justify-center">
        <Link href="/buyer/checkout" className="btn btn-primary px-5 py-2.5">Back to Checkout</Link>
        <Link href="/" className="btn btn-ghost px-5 py-2.5">Continue Shopping</Link>
      </div>
    </div>
  );
}
