'use client';
import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';

function SuccessContent() {
  const params = useSearchParams();
  return (
    <div className="max-w-md mx-auto px-6 py-20 text-center">
      <div className="text-5xl mb-4">✅</div>
      <h1 className="font-display text-2xl mb-2">Order Placed Successfully</h1>
      <p className="text-muted text-sm mb-6">Thank you for your purchase. We'll notify you as it ships.</p>
      <div className="card p-5 text-left text-sm space-y-2 mb-6">
        <div className="flex justify-between"><span className="text-muted">Order Number</span><span className="font-mono font-semibold">{params.get('order')}</span></div>
        <div className="flex justify-between"><span className="text-muted">Invoice</span><span className="font-mono font-semibold">{params.get('invoice')}</span></div>
        <div className="flex justify-between"><span className="text-muted">Tracking No.</span><span className="font-mono font-semibold">{params.get('tracking')}</span></div>
        <div className="flex justify-between"><span className="text-muted">Total Paid</span><span className="font-mono font-semibold">৳{params.get('total')}</span></div>
      </div>
      <div className="flex gap-3 justify-center">
        <Link href="/buyer/orders" className="btn btn-primary px-5 py-2.5">Track Order</Link>
        <Link href="/" className="btn btn-ghost px-5 py-2.5">Continue Shopping</Link>
      </div>
    </div>
  );
}

export default function PaymentSuccessPage() {
  return (
    <Suspense fallback={null}>
      <SuccessContent />
    </Suspense>
  );
}
