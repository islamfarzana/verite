'use client';
import { Suspense, useState } from 'react';
import { useSearchParams } from 'next/navigation';

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [form, setForm] = useState({ name: '', email: 'buyer@verite.app', password: 'Password123!', role: 'BUYER' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const params = useSearchParams();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const url = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const json = await res.json();
    setLoading(false);
    if (!json.success) {
      setError(json.message || 'Something went wrong');
      return;
    }
    // JWT is now set as a secure httpOnly cookie by the server. Just navigate
    // to wherever they were headed (?next=) or their role's dashboard.
    const next = params.get('next');
    location.href = next || json.data.redirectTo;
  };

  return (
    <div className="max-w-md mx-auto px-6 py-16">
      <h1 className="font-display text-2xl mb-1">{mode === 'login' ? 'Welcome Back' : 'Create Your Account'}</h1>
      <p className="text-muted text-sm mb-6">{mode === 'login' ? 'Sign in to continue.' : 'Join the trusted FMCG marketplace.'}</p>

      <form onSubmit={submit} className="space-y-3">
        {mode === 'register' && (
          <input className="input" placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        )}
        <input className="input" type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
        <input className="input" type="password" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required minLength={8} />
        {mode === 'register' && (
          <select className="input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
            <option value="BUYER">I'm a Buyer</option>
            <option value="SELLER">I'm a Seller</option>
          </select>
        )}
        {error && <div className="text-danger text-sm">{error}</div>}
        <button className="btn btn-primary w-full py-3" disabled={loading}>
          {loading ? 'Please wait…' : mode === 'login' ? 'Sign In' : 'Create Account'}
        </button>
      </form>

      <button className="text-sm text-primary font-semibold mt-5" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
        {mode === 'login' ? "Don't have an account? Create one" : 'Already have an account? Sign in'}
      </button>

      <div className="mt-8 card p-4 text-xs text-muted">
        Seeded demo accounts (password <span className="font-mono">Password123!</span>):
        <div className="font-mono mt-1">buyer@verite.app · seller@verite.app · admin@verite.app</div>
      </div>
    </div>
  );
}
