'use client';
import { useEffect, useState } from 'react';
import { useSession } from '@/lib/client-auth';
import { Badge, EntityStatusBadge, LicenceBadge, fmtTime } from '@/components/IdentityBadges';

// Admin: review seller businesses. Approval of the business and the licence check are shown and
// recorded separately. Every decision needs a reason and is written to an append-only history.

const ACTION_LABEL: Record<string, string> = {
  APPROVE: 'Approve', REJECT: 'Reject', SUSPEND: 'Suspend', REINSTATE: 'Reinstate (approve again)', REOPEN: 'Reopen review (back to pending)',
};

export default function AdminSellers() {
  const { user, loading } = useSession();
  const [filter, setFilter] = useState('PENDING');
  const [list, setList] = useState<any[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [detail, setDetail] = useState<any>(null);
  const [decision, setDecision] = useState({ action: '', reasonCode: '', note: '', publicNote: '' });
  const [manual, setManual] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const loadList = async () => {
    const j = await (await fetch(`/api/admin/entities${filter ? `?status=${filter}` : ''}`)).json();
    setList(j.success ? j.data : []);
  };
  const loadDetail = async (id: string) => {
    const j = await (await fetch(`/api/admin/entities/${id}`)).json();
    setDetail(j.success ? j.data : null);
    const first = j.success ? j.data.allowedActions[0] || '' : '';
    setDecision({ action: first, reasonCode: first === 'APPROVE' ? 'REVIEW_PASSED' : '', note: '', publicNote: '' });
  };
  useEffect(() => { if (user?.role === 'ADMIN') loadList(); }, [user, filter]);
  useEffect(() => { if (selected) loadDetail(selected); }, [selected]);

  const post = async (url: string, body: unknown) => {
    setBusy(true); setMsg(null);
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await res.json().catch(() => ({ success: false, message: 'Unexpected response.' }));
    setMsg({ ok: !!j.success, text: j.message || (j.success ? 'Done.' : 'Something went wrong.') });
    if (selected) await loadDetail(selected);
    await loadList();
    setBusy(false);
  };

  if (!loading && (!user || user.role !== 'ADMIN')) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h2 className="font-display text-xl mb-2">Admin sign-in required</h2>
        <a href="/login" className="btn btn-primary px-6 py-3">Sign In</a>
      </div>
    );
  }

  const reasonOptions: string[] = detail && decision.action
    ? decision.action === 'APPROVE' ? ['REVIEW_PASSED'] : detail.reasonCodes[decision.action] || []
    : [];

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-1">Seller Reviews</h1>
      <p className="text-muted text-sm mb-6">
        Approving a business confirms that an administrator reviewed its identity. It does not verify its licence; the licence result is
        shown separately with its source. Registry mode: <b>{detail?.registryMode ?? '…'}</b>.
      </p>

      <div className="flex gap-2 mb-5">
        {['PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED', ''].map((s) => (
          <button key={s || 'ALL'} className={`btn text-xs px-3 py-1.5 ${filter === s ? 'btn-primary' : 'btn-ghost'}`} onClick={() => { setFilter(s); setSelected(null); setDetail(null); }}>
            {s || 'All'}
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-[320px_1fr] gap-6">
        <div className="card overflow-hidden self-start">
          {list.length === 0 && <div className="p-5 text-sm text-muted">No businesses in this list.</div>}
          {list.map((e, i) => (
            <button key={e.id} onClick={() => setSelected(e.id)}
              className={`w-full text-left px-4 py-3 text-sm ${i < list.length - 1 ? 'border-b border-line' : ''} ${selected === e.id ? 'bg-primary/5' : ''}`}>
              <div className="font-semibold">{e.displayName}</div>
              <div className="text-xs text-muted">{e.legalName} · {e.managedByName || 'no account'}</div>
              <div className="mt-1"><EntityStatusBadge status={e.status} /></div>
            </button>
          ))}
        </div>

        <div>
          {!detail && <div className="text-muted text-sm">Select a business to review.</div>}
          {detail && (
            <div>
              <div className="card p-5 mb-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="font-display text-lg">{detail.entity.displayName}</div>
                  <EntityStatusBadge status={detail.entity.status} />
                </div>
                <div className="text-sm">{detail.entity.legalName} · {detail.entity.entityType === 'ORGANIZATION' ? 'Organisation' : 'Sole proprietor'}</div>
                <div className="text-xs text-muted mt-1">
                  Roles: {detail.entity.roles.join(', ')} · Account: {detail.entity.managedBy ? `${detail.entity.managedBy.name} <${detail.entity.managedBy.email}>` : '—'}
                  {detail.entity.contactEmail && ` · Contact: ${detail.entity.contactEmail}`}
                </div>
                <div className="text-xs text-muted">Submitted {fmtTime(detail.entity.submittedAt)}</div>
                <div className="text-sm mt-3 p-3 rounded-lg bg-slate-50 border border-slate-200">
                  If approved now, product registration would be: <b>{detail.eligibilityIfApproved.canRegister ? 'allowed' : 'blocked'}</b> — {detail.eligibilityIfApproved.message}
                </div>
              </div>

              <div className="font-bold mb-3">Licences</div>
              {detail.licences.map((l: any) => (
                <div key={l.id} className={`card p-4 mb-3 text-sm ${l.supersededAt ? 'opacity-60' : ''}`}>
                  <div className="flex flex-wrap items-center gap-3 mb-1">
                    <div className="font-semibold">{l.licenceTypeLabel}</div>
                    <span className="font-mono text-xs">{l.licenceNumber}</span>
                    <LicenceBadge checkResult={l.checkResult} method={l.verificationMethod} />
                    {l.supersededAt && <Badge tone="gray">Superseded {fmtTime(l.supersededAt)}</Badge>}
                  </div>
                  <div className="text-xs text-muted">
                    Claimed authority: {l.issuingAuthority} · Claimed status: {l.claimedStatus} · Claimed expiry: {l.claimedExpiryDate || '—'} ·
                    Source of number: {l.claimSource === 'OCR_EXTRACTED' ? 'OCR (unverified extraction)' : 'typed by seller'}
                  </div>
                  <div className="text-xs text-muted">
                    Method: {l.verificationMethod} · {l.sourceLabel || 'not checked'} · Result time {fmtTime(l.checkedAt)}
                    {l.registryReference && ` · Ref ${l.registryReference}`}
                  </div>
                  {l.events.length > 0 && (
                    <details className="mt-2 text-xs">
                      <summary className="cursor-pointer text-primary font-semibold">Check history ({l.events.length})</summary>
                      {l.events.map((ev: any, i: number) => (
                        <div key={i} className="text-muted mt-1">
                          {fmtTime(ev.attemptedAt)} · {ev.triggerReason} · {ev.result} via {ev.method}{ev.errorCategory ? ` (${ev.errorCategory})` : ''}
                        </div>
                      ))}
                    </details>
                  )}
                  {!l.supersededAt && (
                    <div className="flex flex-wrap items-center gap-3 mt-3">
                      <button className="btn btn-ghost text-xs px-3 py-1.5" disabled={busy} onClick={() => post(`/api/admin/licences/${l.id}/recheck`, {})}>Re-check with registry</button>
                      <select className="input w-40 text-xs" value={manual[l.id] || ''} onChange={(e) => setManual({ ...manual, [l.id]: e.target.value })}>
                        <option value="">Manual review result…</option>
                        {['VALID', 'INVALID', 'EXPIRED', 'REVOKED', 'SUSPENDED'].map((r) => <option key={r} value={r}>{r}</option>)}
                      </select>
                      <button className="btn btn-ghost text-xs px-3 py-1.5" disabled={busy || !manual[l.id]}
                        onClick={() => post(`/api/admin/licences/${l.id}/manual-review`, { result: manual[l.id] })}>Record manual review</button>
                      {!detail.acceptManualReview && <span className="text-[11px] text-muted">Manual reviews are recorded but do not qualify sellers unless LICENCE_ACCEPT_MANUAL_REVIEW=true.</span>}
                    </div>
                  )}
                </div>
              ))}

              <div className="card p-5 my-5">
                <div className="font-bold mb-3">Decision</div>
                {detail.allowedActions.length === 0 ? (
                  <div className="text-sm text-muted">{detail.entity.selfManaged ? 'You cannot review a business your own account manages.' : 'No action is available for this status.'}</div>
                ) : (
                  <div className="grid sm:grid-cols-2 gap-3">
                    <label className="text-xs text-muted">Action
                      <select className="input mt-1" value={decision.action} onChange={(e) => setDecision({ ...decision, action: e.target.value, reasonCode: e.target.value === 'APPROVE' ? 'REVIEW_PASSED' : '' })}>
                        {detail.allowedActions.map((a: string) => <option key={a} value={a}>{ACTION_LABEL[a]}</option>)}
                      </select>
                    </label>
                    <label className="text-xs text-muted">Reason
                      <select className="input mt-1" value={decision.reasonCode} onChange={(e) => setDecision({ ...decision, reasonCode: e.target.value })}>
                        <option value="">Choose…</option>
                        {reasonOptions.map((r) => <option key={r} value={r}>{r.replace(/_/g, ' ').toLowerCase()}</option>)}
                      </select>
                    </label>
                    <label className="text-xs text-muted">Internal note (admins only)
                      <input className="input mt-1" value={decision.note} onChange={(e) => setDecision({ ...decision, note: e.target.value })} />
                    </label>
                    <label className="text-xs text-muted">Message to the seller (optional)
                      <input className="input mt-1" value={decision.publicNote} onChange={(e) => setDecision({ ...decision, publicNote: e.target.value })} />
                    </label>
                    <button className="btn btn-primary px-5 py-2.5 sm:col-span-2" disabled={busy || !decision.reasonCode}
                      onClick={() => post(`/api/admin/entities/${detail.entity.id}/decision`, decision)}>
                      {busy ? 'Saving…' : `${ACTION_LABEL[decision.action]}`}
                    </button>
                  </div>
                )}
                {msg && <div className={`text-sm mt-3 ${msg.ok ? 'text-[#16803C]' : 'text-danger'}`}>{msg.text}</div>}
              </div>

              <div className="font-bold mb-3">Audit history</div>
              <div className="card overflow-hidden text-xs">
                {detail.history.map((h: any, i: number) => (
                  <div key={i} className={`px-4 py-2.5 ${i < detail.history.length - 1 ? 'border-b border-line' : ''}`}>
                    <span className="text-muted">{fmtTime(h.createdAt)}</span> · <b>{h.previousStatus ? `${h.previousStatus} → ${h.newStatus}` : h.newStatus}</b> · {h.reasonCode}
                    · by {h.actorName || h.actorRole}{h.internalNote ? ` · note: ${h.internalNote}` : ''}{h.publicNote ? ` · to seller: ${h.publicNote}` : ''}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
