'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Badge } from '@/components/IdentityBadges';
import { ResultChip } from '@/components/ProtectionBadges';

// v5 admin "Buyer protection": recalls (open/close/resend), buyer label-check review requests, and every
// published listing with its MRP review state and whether buyers can currently buy it.

const REASONS = ['QUALITY_ISSUE', 'SAFETY_RISK', 'LABELLING_ERROR', 'REGULATOR_INSTRUCTION', 'MANUFACTURER_REQUEST', 'OTHER'];

export default function AdminProtection() {
  const [data, setData] = useState<any>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [recallReason, setRecallReason] = useState('SAFETY_RISK');
  const [mrpEdit, setMrpEdit] = useState<Record<string, string>>({});

  const load = () => fetch('/api/admin/protection').then((r) => r.json()).then((j) => (j.success ? setData(j.data) : setMsg(j.message)));
  useEffect(() => { load(); }, []);

  const post = async (url: string, body: unknown, ok: (j: any) => string) => {
    const j = await (await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json().catch(() => ({}));
    setMsg(j.success ? ok(j) : j.message || 'Failed.');
    load();
  };

  if (!data) return <div className="max-w-6xl mx-auto px-6 py-12 text-muted">{msg || 'Loading…'}</div>;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10 space-y-8">
      <div>
        <h1 className="font-display text-2xl">Buyer protection</h1>
        <p className="text-sm text-muted">Recalls, buyer label-check reviews and MRP review. Notices are in-app only; recalls are off-chain.</p>
        {msg && <div className="card p-3 mt-3 text-sm">{msg}</div>}
      </div>

      <section>
        <h2 className="font-bold mb-2">Recalls</h2>
        {data.recalls.length === 0 && <div className="card p-4 text-sm text-muted">No recalls.</div>}
        {data.recalls.map((r: any) => (
          <div key={r.id} className="card p-4 mb-2 text-sm flex flex-wrap gap-3 items-center">
            <Badge tone={r.status === 'ACTIVE' ? 'red' : 'gray'}>{r.status}</Badge>
            <Link href={`/product/${r.productId}`} className="font-semibold">{r.productName}</Link>
            <span className="font-mono text-xs">batch {r.batchNumber}</span>
            <span className="text-xs text-muted">{r.reasonCode} · by {r.initiatedRole.toLowerCase()} · {r.createdAt.slice(0, 10)}</span>
            <span className="text-xs">{r.buyersNotified} buyer(s) notified in-app{r.simulatedOrdersSkipped ? `, ${r.simulatedOrdersSkipped} simulated order(s) skipped` : ''}</span>
            {r.status === 'ACTIVE' && (
              <span className="ml-auto flex gap-2">
                <button className="btn btn-ghost text-xs px-3 py-1.5" onClick={() => post(`/api/recalls/${r.id}`, { action: 'RESEND' }, (j) => `${j.data.added} new notice(s); ${j.data.total} in total.`)}>Re-check buyers</button>
                <button className="btn btn-ghost text-xs px-3 py-1.5" onClick={() => post(`/api/recalls/${r.id}`, { action: 'CLOSE', note: 'Closed by admin' }, () => 'Recall closed.')}>Close recall</button>
              </span>
            )}
          </div>
        ))}
      </section>

      <section>
        <h2 className="font-bold mb-2">Buyer label checks sent for review</h2>
        <div className="text-xs text-muted mb-2">
          All checks so far: {data.checkStats.map((c: any) => `${c.overall} ${c.n}`).join(' · ') || 'none'}. Photos are never stored; only the comparison is.
        </div>
        {data.reviews.length === 0 && <div className="card p-4 text-sm text-muted">No review requests.</div>}
        {data.reviews.map((r: any) => (
          <div key={r.id} className="card p-4 mb-2 text-sm">
            <div className="flex flex-wrap gap-2 items-center mb-2">
              <Link href={`/product/${r.productId}`} className="font-semibold">{r.productName}</Link>
              <span className="font-mono text-xs">batch {r.batchNumber}</span>
              <Badge tone={r.overall === 'MISMATCH_REVIEW' ? 'red' : 'amber'}>{r.overall}</Badge>
              <span className="text-xs text-muted">requested {r.reviewRequestedAt.slice(0, 16).replace('T', ' ')}</span>
              {r.reviewedAt ? <Badge tone="gray">Reviewed: {r.reviewNote || '—'}</Badge> : (
                <button className="btn btn-ghost text-xs px-3 py-1.5 ml-auto" onClick={() => {
                  const note = prompt('Outcome of your review (e.g. "OCR misread, label is fine")') || '';
                  post(`/api/label-checks/${r.id}`, { action: 'RESOLVE', note }, () => 'Review recorded.');
                }}>Record outcome</button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {r.fields.map((f: any) => <span key={f.field} className="text-xs">{f.field}: <ResultChip result={f.result} /> <span className="font-mono">{f.observed ?? ''}</span></span>)}
            </div>
          </div>
        ))}
      </section>

      <section>
        <h2 className="font-bold mb-2">Published listings</h2>
        <div className="flex items-center gap-2 mb-2 text-xs">
          Recall reason for the buttons below:
          <select className="input w-auto py-1" value={recallReason} onChange={(e) => setRecallReason(e.target.value)}>{REASONS.map((x) => <option key={x}>{x}</option>)}</select>
        </div>
        <div className="card overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 text-muted"><tr>
              <th className="text-left p-2">Product</th><th className="text-left p-2">Seller</th><th className="text-left p-2">Batch / EXP</th>
              <th className="text-left p-2">Price</th><th className="text-left p-2">MRP</th><th className="text-left p-2">Buyers can buy?</th><th className="p-2"></th>
            </tr></thead>
            <tbody>
              {data.listings.map((l: any) => (
                <tr key={l.id} className="border-t border-line">
                  <td className="p-2"><Link href={`/product/${l.id}`} className="font-semibold">{l.name}</Link></td>
                  <td className="p-2">{l.sellerName}</td>
                  <td className="p-2 font-mono">{l.batchNumber}<div>{l.expiryDate}{l.expiry ? ` · ${l.expiry}` : ''}</div></td>
                  <td className="p-2 font-mono">৳{l.price}</td>
                  <td className="p-2">
                    <div className="font-mono">{l.mrp ? `৳${l.mrp}` : '—'}</div>
                    <div className="text-muted">{l.mrpSource ?? 'none'} · {l.mrpStatus ?? 'unreviewed'}</div>
                    <div className="flex gap-1 mt-1">
                      <input className="input py-0.5 w-16" placeholder={l.mrp ?? 'MRP'} value={mrpEdit[l.id] ?? ''} onChange={(e) => setMrpEdit({ ...mrpEdit, [l.id]: e.target.value })} />
                      <button className="btn btn-ghost px-2 py-0.5" onClick={() => post(`/api/admin/products/${l.id}/mrp-review`, { mrp: mrpEdit[l.id] || undefined }, (j) => `MRP ৳${j.data.mrp} marked as reviewed.`)}>Mark reviewed</button>
                    </div>
                  </td>
                  <td className="p-2">{l.sellable ? <Badge tone="green">Yes</Badge> : <Badge tone="red">No: {l.blockers.join(', ')}</Badge>}</td>
                  <td className="p-2">
                    {!l.blockers.includes('RECALLED') && (
                      <button className="btn btn-ghost px-2 py-1 text-danger" onClick={() => confirm(`Recall batch ${l.batchNumber} of ${l.name}? Sales stop immediately.`) &&
                        post('/api/recalls', { productId: l.id, reasonCode: recallReason }, (j) => j.message)}>Recall</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
