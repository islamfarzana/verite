'use client';
import { useEffect, useState } from 'react';
import { useSession } from '@/lib/client-auth';

export default function AdminPage() {
  const { user, loading: sessionLoading } = useSession();
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    if (user?.role === 'ADMIN') {
      fetch('/api/admin/stats')
        .then((r) => r.json())
        .then((res) => setStats(res.data));
    }
  }, [user]);

  if (!sessionLoading && (!user || user.role !== 'ADMIN')) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h2 className="font-display text-xl mb-2">Admin sign-in required</h2>
        <p className="text-muted text-sm mb-5">Use the seeded admin@verite.app account.</p>
        <a href="/login" className="btn btn-primary px-6 py-3">Sign In</a>
      </div>
    );
  }

  if (!stats) return <div className="max-w-6xl mx-auto px-6 py-16 text-muted">Loading…</div>;

  const cards = [
    ['Active Users', stats.users],
    ['Seller Accounts', stats.sellers],
    ['Approved Seller Businesses', stats.approvedSellers],
    ['Awaiting Seller Review', stats.pendingReviews],
    ['Products', stats.products],
    ['Published', stats.published],
    ['Verification Checks', stats.verifications],
    ['Failed Verifications', stats.failedVerifications],
  ];

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h1 className="font-display text-2xl mb-1">Administrator Dashboard</h1>
      <p className="text-muted text-sm mb-8">
        Real counts queried live from the database. <a href="/admin/sellers" className="text-primary font-semibold">Review seller businesses →</a>
      </p>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-10">
        {cards.map(([l, v]) => (
          <div key={l as string} className="card p-5">
            <div className="text-xs text-muted mb-1">{l}</div>
            <div className="font-mono text-2xl font-bold">{v as number}</div>
          </div>
        ))}
      </div>

      <div className="font-bold mb-3">On-Chain Records</div>
      <div className="card overflow-hidden">
        {stats.records.map((r: any, idx: number) => (
          <div key={idx} className={`flex justify-between items-center px-5 py-3 text-sm ${idx < stats.records.length - 1 ? 'border-b border-line' : ''}`}>
            <div className="font-semibold w-48 truncate">{r.name}</div>
            <div className="font-mono text-xs text-muted flex-1 truncate mx-4">{r.keccak_hash}</div>
            <div className="font-mono text-xs text-muted">Block #{r.block_number}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
