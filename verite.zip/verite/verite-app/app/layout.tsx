import type { Metadata } from 'next';
import './globals.css';
import NavBar from '@/components/NavBar';

export const metadata: Metadata = {
  title: 'Verité — AI & Blockchain Verified FMCG Marketplace',
  description: 'Buy genuine FMCG products with AI-powered label recognition and real blockchain verification.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans">
        <NavBar />
        {children}
        <footer className="border-t border-line py-8 text-center text-xs text-muted">
          Verité — AI & Blockchain Verified FMCG Marketplace
        </footer>
      </body>
    </html>
  );
}
