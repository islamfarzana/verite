'use client';
import Link from 'next/link';
import { useSession, dashboardPathFor } from '@/lib/client-auth';

export default function ForbiddenPage() {
  const { user } = useSession();
  return (
    <div className="max-w-md mx-auto px-6 py-20 text-center">
      <div className="text-5xl mb-4">🚫</div>
      <h1 className="font-display text-2xl mb-2">Access Denied</h1>
      <p className="text-muted text-sm mb-6">
        Your account doesn't have permission to view that section.
      </p>
      <Link href={user ? dashboardPathFor(user.role) : '/'} className="btn btn-primary px-6 py-3">
        Go to my dashboard
      </Link>
    </div>
  );
}
