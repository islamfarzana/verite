import { redirect } from 'next/navigation';

// Cart now lives under /buyer/cart (protected by role-based middleware),
// per the updated route structure. This keeps the old bookmark/link working.
export default function CartRedirect() {
  redirect('/buyer/cart');
}
