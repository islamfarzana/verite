'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Badge, EntityStatusBadge, fmtTime } from '@/components/IdentityBadges';
import { BlockerList, ExpiryBadge, RecallBanner } from '@/components/ProtectionBadges';
import { useSession } from '@/lib/client-auth';


const STEPS = [
  'Fetching blockchain record…',
  'Recomputing local fingerprint…',
  'Comparing hashes…',
  'Verification complete.',
];

export default function ProductPage({ params }: { params: { id: string } }) {
  const [product, setProduct] = useState<any>(null);
  const [stage, setStage] = useState<'idle' | 'running' | 'done'>('idle');
  const [step, setStep] = useState(0);
  const [result, setResult] = useState<any>(null);
  // --- Product_Image_Gallery_Extension.md: Product Gallery ---
  const [activeImage, setActiveImage] = useState(0);
  const images: string[] = product?.images || [];
  const { user } = useSession();
  const router = useRouter();
  const [cartMsg, setCartMsg] = useState<{ ok: boolean; text: string; bn?: string } | null>(null);
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    fetch(`/api/products/${params.id}`)
      .then((r) => r.json())
      .then((res) => setProduct(res.data));
  }, [params.id]);

  const runVerify = async () => {
    setStage('running');
    setStep(0);
    setResult(null);
    const iv = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 500);

    const res = await fetch(`/api/products/${params.id}/verify`, { method: 'POST' });
    const json = await res.json();

    setTimeout(() => {
      clearInterval(iv);
      setStep(STEPS.length - 1);
      setResult(json.data);
      setStage('done');
    }, 2100);
  };

  // v5: the cart is saved in the database for the signed-in buyer (it survives closing the browser).
  const addToCart = async () => {
    if (!user) { router.push(`/login?next=/product/${params.id}`); return; }
    if (user.role !== 'BUYER') { setCartMsg({ ok: false, text: 'Sign in with a buyer account to buy products.' }); return; }
    setAdding(true);
    setCartMsg(null);
    const res = await fetch('/api/cart', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productId: product.id, quantity: 1 }) });
    const json = await res.json().catch(() => ({}));
    setAdding(false);
    if (json.success) setCartMsg({ ok: true, text: `Added to your cart (${json.data.quantity} in cart). Your cart is saved to your account.` });
    else setCartMsg({ ok: false, text: json.message || 'Could not add to cart.', bn: json.messageBn });
  };

  if (!product) return <div className="max-w-6xl mx-auto px-6 py-16 text-muted">Loading…</div>;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="grid md:grid-cols-2 gap-10">
        <div>
          {images.length > 0 ? (
            <div>
              <div className="card h-96 flex items-center justify-center overflow-hidden">
                <img src={images[activeImage]} alt={product.name} className="w-full h-full object-cover" />
              </div>
              {product.imageLabels?.[images[activeImage]] === 'ENHANCED_FROM_SELLER_PHOTO' && (
                <div className="text-[11px] text-muted mt-1.5">
                  Enhanced from the seller’s photo (background removed, straightened). The original photo is in the gallery.
                </div>
              )}
              {images.length > 1 && (
                <div className="flex gap-2 mt-3">
                  {images.map((src, i) => (
                    <button
                      key={src}
                      onClick={() => setActiveImage(i)}
                      className={`w-16 h-16 rounded-lg overflow-hidden border-2 ${i === activeImage ? 'border-primary' : 'border-transparent'}`}
                    >
                      <img src={src} alt={`${product.name} ${i + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="card h-96 flex items-center justify-center text-8xl">{product.image_emoji}</div>
          )}
        </div>
        <div>
          <div className="flex gap-2 mb-3">
            {product.verification_status === 'VERIFIED' && (
              <span className="text-xs font-semibold text-[#16803C] bg-secondary/10 rounded-full px-2.5 py-1">✓ Fingerprint registered</span>
            )}
          </div>
          <h1 className="font-display text-3xl mb-2">{product.name}</h1>
          {product.nameBn && <div className="text-lg mb-2" lang="bn">{product.nameBn}</div>}
          <div className="text-muted mb-4">{product.brand} · Sold by {product.seller_name}</div>
          <div className="flex items-baseline gap-3 mb-2">
            <div className="font-mono text-2xl font-bold text-primary">৳{product.price}</div>
            {product.protection?.mrp?.amount && (
              <div className="text-sm text-muted">
                MRP ৳{product.protection.mrp.amount}
                <span className="text-[11px]"> ({product.protection.mrp.status === 'ADMIN_REVIEWED' ? 'reviewed by admin' : 'as registered by the seller'})</span>
              </div>
            )}
          </div>
          <div className="flex flex-wrap gap-2 mb-5">
            <ExpiryBadge expiry={product.protection?.expiry} />
            {product.protection && !product.protection.mrp?.amount && <Badge tone="gray">MRP not registered</Badge>}
          </div>
          <RecallBanner recall={product.protection?.recall} />

          <div className="card p-4 mb-5 grid grid-cols-2 gap-3 text-sm">
            <div><div className="text-muted text-xs">Batch Number</div><div className="font-mono font-semibold">{product.batch_number}</div></div>
            <div><div className="text-muted text-xs">Barcode</div><div className="font-mono font-semibold">{product.barcode}</div></div>
            <div><div className="text-muted text-xs">Manufactured</div><div className="font-semibold">{product.manufacturing_date}</div></div>
            <div><div className="text-muted text-xs">Expires</div><div className="font-semibold">{product.expiry_date}</div></div>
          </div>

          {product.identity && <IdentityPanel identity={product.identity} />}

          {product.protection && !product.protection.sellable && !product.protection.recall && (
            <div className="card p-3 mb-4 border-warning/40 bg-warning/5"><BlockerList blockers={product.protection.blockers} /></div>
          )}
          <div className="flex flex-wrap gap-3 mb-3">
            <button className="btn btn-primary px-6 py-3 disabled:opacity-50" onClick={addToCart} disabled={adding || (product.protection && !product.protection.sellable)}>
              {adding ? 'Adding…' : 'Add to Cart'}
            </button>
            <button className="btn btn-ghost px-6 py-3" onClick={runVerify}>Verify Product</button>
            <Link href={`/product/${product.id}/check`} className="btn btn-ghost px-6 py-3">📷 Check my pack</Link>
          </div>
          {cartMsg && (
            <div className={`text-sm mb-4 ${cartMsg.ok ? 'text-[#16803C]' : 'text-danger'}`}>
              {cartMsg.bn && <div lang="bn">{cartMsg.bn}</div>}
              <div>{cartMsg.text} {cartMsg.ok && <Link href="/buyer/cart" className="text-primary font-semibold">View cart →</Link>}</div>
            </div>
          )}
          <div className="mb-6" />

          {stage !== 'idle' && (
            <div className="card p-5">
              {stage === 'running' && (
                <div>
                  {STEPS.slice(0, step + 1).map((s, i) => (
                    <div key={i} className={`text-sm py-1 ${i === step ? 'text-ink font-medium' : 'text-muted'}`}>
                      {i < step ? '✓' : '⟳'} {s}
                    </div>
                  ))}
                </div>
              )}
              {stage === 'done' && result && (
                result.verified ? (
                  <div>
                    <div className="text-lg font-bold text-[#16803C] mb-1">✅ Product Verified</div>
                    <div className="text-sm text-muted mb-3">
                      {result.source === 'blockchain'
                        ? 'The recomputed Keccak-256 fingerprint matches the record read directly from the smart contract.'
                        : 'The recomputed Keccak-256 fingerprint matches the stored record (simulated demo ledger).'}
                    </div>
                    <div className="font-mono text-[11px] bg-slate-100 p-2.5 rounded-lg break-all">{result.onChainHash}</div>
                    <div className="text-xs text-muted mt-2">Tx {result.txHash} · Block #{result.blockNumber}</div>
                    <div className="text-xs text-muted mt-1">
                      {result.hashSchemaVersion === 2
                        ? 'Fingerprint schema v2: covers the product data and the seller/manufacturer identity recorded at registration.'
                        : 'Legacy fingerprint (schema v1): covers the product data only; seller review and manufacturer identity were not recorded.'}
                      {' '}A matching fingerprint shows the record has not changed since registration. It does not by itself prove the physical item is genuine or that a licence is valid.
                    </div>
                    {result.explorerUrl && (
                      <a href={result.explorerUrl} target="_blank" rel="noreferrer" className="text-xs text-primary font-semibold mt-1 inline-block">
                        View transaction on block explorer →
                      </a>
                    )}
                  </div>
                ) : (
                  <div>
                    <div className="text-lg font-bold text-danger mb-1">⚠ Verification Failed</div>
                    <div className="text-sm text-muted">{result.reason || 'The fingerprint did not match the on-chain record.'}</div>
                  </div>
                )
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Seller onboarding & licence verification: who is behind the product, with each claim labelled by
// what actually supports it. Shows names and statuses only (no emails, IDs or licence numbers).
function IdentityPanel({ identity }: { identity: any }) {
  if (!identity.registered) {
    if (!identity.legacy) return null;
    return (
      <div className="card p-4 mb-5 text-sm">
        <div className="font-bold mb-1">Who is behind this product</div>
        <Badge tone="gray">Legacy record</Badge>
        <div className="text-muted text-xs mt-2">{identity.note}</div>
      </div>
    );
  }
  const l = identity.licence;
  return (
    <div className="card p-4 mb-5 text-sm">
      <div className="font-bold mb-2">Who is behind this product</div>
      <div className="mb-2">
        <div className="text-xs text-muted">Seller</div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-semibold">{identity.seller.name}</span>
          <EntityStatusBadge status={identity.seller.currentStatus} />
        </div>
      </div>
      <div className="mb-2">
        <div className="text-xs text-muted">Manufacturer</div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-semibold">{identity.manufacturer.name || 'Not stated'}</span>
          <Badge tone={identity.manufacturer.identity === 'UNVERIFIED_CLAIM' || identity.manufacturer.identity === 'UNKNOWN' ? 'gray' : 'blue'}>
            {identity.manufacturer.identityText}
          </Badge>
        </div>
      </div>
      {identity.brandOwner && <div className="mb-2 text-xs text-muted">Brand owner: <b className="text-ink">{identity.brandOwner.name}</b></div>}
      {l && (
        <div className="mb-1">
          <div className="text-xs text-muted">Seller licence ({l.typeLabel})</div>
          <div className="flex flex-wrap items-center gap-2">
            {l.isMock
              ? <Badge tone="amber">MOCK/DEMO REGISTRY — NOT OFFICIAL VERIFICATION</Badge>
              : l.isRegistryResult
                ? <Badge tone="green">Checked by {l.sourceLabel}</Badge>
                : <Badge tone="blue">Reviewed manually by an admin — not a registry lookup</Badge>}
            <span className="text-xs text-muted">at registration: {l.resultAtRegistration.toLowerCase()} · {fmtTime(l.checkedAt)}</span>
          </div>
          {l.currentResult && l.currentResult !== l.resultAtRegistration && (
            <div className="text-xs text-danger mt-1">Now: {l.currentResultText}</div>
          )}
        </div>
      )}
      {identity.labelLicenceClaim && (
        <div className="text-xs text-muted mt-1">Licence text printed on the label: “{identity.labelLicenceClaim}” (as read from the label — not verified)</div>
      )}
      {identity.warnings.some((w: string) => w.startsWith('SELLER_')) && (
        <div className="text-xs text-danger mt-2">The seller’s status changed after this product was registered.</div>
      )}
    </div>
  );
}
