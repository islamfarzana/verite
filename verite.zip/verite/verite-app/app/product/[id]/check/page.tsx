'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ResultChip } from '@/components/ProtectionBadges';
import { useSession } from '@/lib/client-auth';

// Buyer label check: photograph the pack you are holding; the text on it is compared with the registered
// record of this batch. Photos are not stored. Result wording never says "fake" — a difference means
// "check again / send for review".

const OVERALL: Record<string, { box: string; title: string; titleBn: string }> = {
  MATCH: { box: 'border-[#16803C] bg-[#16803C]/5', title: 'Label matches the registered batch', titleBn: 'লেবেল নিবন্ধিত ব্যাচের সঙ্গে মিলেছে' },
  MISMATCH_REVIEW: { box: 'border-danger bg-danger/5', title: 'Some details do not match — needs checking', titleBn: 'কিছু তথ্য মিলছে না — যাচাই প্রয়োজন' },
  UNCERTAIN: { box: 'border-[#B45309] bg-[#B45309]/10', title: 'Partly confirmed', titleBn: 'আংশিক নিশ্চিত' },
  BATCH_UNRESOLVED: { box: 'border-[#B45309] bg-[#B45309]/10', title: 'Batch could not be confirmed', titleBn: 'ব্যাচ নিশ্চিত করা যায়নি' },
  INSUFFICIENT_IMAGE: { box: 'border-slate-300 bg-slate-50', title: 'Photo could not be read well enough', titleBn: 'ছবি যথেষ্ট পড়া যায়নি' },
  NOT_REGISTERED: { box: 'border-slate-300 bg-slate-50', title: 'No registered record', titleBn: 'নিবন্ধিত তথ্য নেই' },
};

export default function LabelCheckPage({ params }: { params: { id: string } }) {
  const { user } = useSession();
  const [product, setProduct] = useState<any>(null);
  const [front, setFront] = useState<File | null>(null);
  const [back, setBack] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<{ en: string; bn?: string } | null>(null);
  const [review, setReview] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/products/${params.id}`).then((r) => r.json()).then((j) => setProduct(j.data || null));
  }, [params.id]);

  const run = async () => {
    if (!front) return;
    setBusy(true); setResult(null); setError(null); setReview(null);
    const form = new FormData();
    form.append('front', front);
    if (back) form.append('back', back);
    const res = await fetch(`/api/products/${params.id}/label-check`, { method: 'POST', body: form });
    const json = await res.json().catch(() => ({}));
    setBusy(false);
    if (json.success) setResult(json.data);
    else setError({ en: json.message || 'The check failed. Please try again.', bn: json.messageBn });
  };

  const requestReview = async () => {
    const res = await fetch(`/api/label-checks/${result.checkId}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'REQUEST_REVIEW' }) });
    const json = await res.json().catch(() => ({}));
    setReview(json.success ? 'যাচাইয়ের জন্য পাঠানো হয়েছে। Sent for review — an administrator will look at it.' : json.message || 'Could not send.');
  };

  const look = result ? OVERALL[result.overall] || OVERALL.UNCERTAIN : null;

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <Link href={`/product/${params.id}`} className="text-sm text-primary font-semibold">← Back to product</Link>
      <h1 className="font-display text-2xl mt-3 mb-1" lang="bn">প্যাকেট যাচাই</h1>
      <h2 className="font-display text-lg mb-2">Check the pack in your hand</h2>
      {product && (
        <p className="text-sm text-muted mb-6">
          Comparing with the registered record of <b className="text-ink">{product.name}</b>, batch <span className="font-mono">{product.batch_number}</span>.
          Take a clear, well-lit photo of the side with the batch number, dates and MRP. Bangla and English text are read.
        </p>
      )}

      <div className="card p-5 mb-6 grid sm:grid-cols-2 gap-4 text-sm">
        <label className="block">
          <div className="font-semibold mb-1">Front / label photo <span className="text-danger">*</span></div>
          <input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={(e) => setFront(e.target.files?.[0] || null)} />
        </label>
        <label className="block">
          <div className="font-semibold mb-1">Back photo (optional)</div>
          <input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={(e) => setBack(e.target.files?.[0] || null)} />
        </label>
        <div className="sm:col-span-2 text-[11px] text-muted">
          Your photos are read once by Verité’s own OCR service and are <b>not stored</b>. They are not sent to any AI company. Only the comparison result is kept.
        </div>
        <button className="btn btn-primary px-5 py-2.5 sm:col-span-2 disabled:opacity-50" disabled={!front || busy} onClick={run}>
          {busy ? 'Reading the label… (up to a minute)' : 'Compare with registered batch'}
        </button>
      </div>

      {error && <div className="card p-4 mb-6 text-sm text-danger">{error.bn && <div lang="bn">{error.bn}</div>}{error.en}</div>}

      {result && look && (
        <div>
          {result.batchStatus?.notices?.length > 0 && (
            <div className="rounded-xl border-2 border-danger/50 bg-danger/5 p-4 mb-4 text-sm">
              {result.batchStatus.notices.map((n: any) => (
                <div key={n.code}><b lang="bn">{n.bn}</b> <span className="text-muted">{n.en}</span></div>
              ))}
            </div>
          )}
          <div className={`rounded-2xl border-2 p-5 mb-4 ${look.box}`}>
            <div className="font-display text-xl" lang="bn">{look.titleBn}</div>
            <div className="font-semibold mb-2">{look.title}</div>
            <p className="text-sm" lang="bn">{result.messageBn}</p>
            <p className="text-sm text-muted">{result.messageEn}</p>
          </div>

          <div className="card overflow-hidden mb-4">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-muted">
                <tr><th className="text-left p-3">Field</th><th className="text-left p-3">Registered</th><th className="text-left p-3">On your pack</th><th className="text-left p-3">Result</th></tr>
              </thead>
              <tbody>
                {result.fields.map((f: any) => (
                  <tr key={f.field} className="border-t border-line align-top">
                    <td className="p-3 font-semibold">{f.field.replace(/([A-Z])/g, ' $1').replace(/^./, (c: string) => c.toUpperCase())}</td>
                    <td className="p-3 font-mono text-xs">{f.registered ?? '—'}</td>
                    <td className="p-3 font-mono text-xs">{f.observed ?? '—'}{typeof f.confidence === 'number' && <div className="text-[10px] text-muted">OCR confidence {f.confidence}%</div>}</td>
                    <td className="p-3">
                      <ResultChip result={f.result} />
                      <div className="text-[11px] mt-1" lang="bn">{f.reasonBn}</div>
                      <div className="text-[11px] text-muted">{f.reasonEn}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex flex-wrap gap-3 mb-3">
            <button className="btn btn-ghost px-4 py-2 text-sm" onClick={() => { setResult(null); setFront(null); setBack(null); }}>Retake photo</button>
            {result.overall !== 'MATCH' && (
              user
                ? <button className="btn btn-ghost px-4 py-2 text-sm" disabled={!!review} onClick={requestReview}>Send for review</button>
                : <Link href={`/login?next=/product/${params.id}/check`} className="btn btn-ghost px-4 py-2 text-sm">Sign in to send for review</Link>
            )}
          </div>
          {review && <div className="text-sm mb-3">{review}</div>}
          <p className="text-xs text-muted" lang="bn">{result.noticeBn}</p>
          <p className="text-xs text-muted">{result.notice} OCR: {result.ocr?.source ?? 'none'}{result.ocr?.languages ? ` (${result.ocr.languages.join(', ')})` : ''}.</p>
        </div>
      )}
    </div>
  );
}
