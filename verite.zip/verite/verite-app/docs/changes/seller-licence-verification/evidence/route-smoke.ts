import assert from 'node:assert/strict';
process.env.DATABASE_FILE = process.env.DATABASE_FILE || '/tmp/routesmoke.db';
(process.env as any).NODE_ENV = 'development';

const A = '/tmp/proj/v2/verite-app';
const results: string[] = [];
const step = async (name: string, fn: () => Promise<void>) => { await fn(); results.push(`PASS  ${name}`); };

async function main() {
  const { NextRequest } = require('next/server');
  const db = (await import(`${A}/lib/db`)).default;
  const { signToken } = await import(`${A}/lib/auth-edge`);
  const { generateProductHash, simulateChainWrite } = await import(`${A}/lib/blockchain`);
  const onboarding = await import(`${A}/app/api/seller/onboarding/route`);
  const products = await import(`${A}/app/api/products/route`);
  const product = await import(`${A}/app/api/products/[id]/route`);
  const verify = await import(`${A}/app/api/products/[id]/verify/route`);
  const adminList = await import(`${A}/app/api/admin/entities/route`);
  const adminOne = await import(`${A}/app/api/admin/entities/[id]/route`);
  const decision = await import(`${A}/app/api/admin/entities/[id]/decision/route`);
  const stats = await import(`${A}/app/api/admin/stats/route`);
  const recheck = await import(`${A}/app/api/seller/onboarding/licences/[id]/recheck/route`);

  const users = [['u_seller', 'SELLER', 'seller@verite.app'], ['u_buyer', 'BUYER', 'buyer@verite.app'], ['u_admin', 'ADMIN', 'admin@verite.app']];
  for (const [id, role, email] of users) db.prepare('INSERT INTO users (id,name,email,password_hash,role) VALUES (?,?,?,?,?)').run(id, id, email, 'x', role);
  const tok: Record<string, string> = {};
  for (const [id, role, email] of users) tok[role] = await signToken({ id, email, role: role as any });

  const req = (method: string, path: string, who?: string, body?: unknown, contentType = 'application/json') => {
    const headers: Record<string, string> = {};
    if (who) headers.cookie = `verite_session=${tok[who]}`;
    if (body !== undefined) headers['content-type'] = contentType;
    return new NextRequest(`http://localhost:3000${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  };
  const call = async (r: Promise<Response> | Response) => { const res = await r; return { status: res.status, json: await res.json() as any }; };

  // legacy v1 product (as the old seed created it)
  db.prepare(`INSERT INTO products (id, seller_id, name, brand, barcode, batch_number, manufacturing_date, expiry_date, price, stock, status, verification_status)
              VALUES ('legacy1','u_seller','Old Milk','DailyPure','8901234567890','LOT-1','2026-01-01','2026-12-31',120,5,'PUBLISHED','VERIFIED')`).run();
  const v1 = generateProductHash({ productId: 'legacy1', brand: 'DailyPure', productName: 'Old Milk', barcode: '8901234567890', batchNumber: 'LOT-1', manufacturingDate: '2026-01-01', expiryDate: '2026-12-31', manufacturer: 'seller@verite.app' });
  const sw = simulateChainWrite(v1);
  db.prepare('INSERT INTO blockchain_records (id, product_id, keccak_hash, tx_hash, block_number) VALUES (?,?,?,?,?)').run('b1', 'legacy1', v1, sw.txHash, sw.blockNumber);

  const profile = { legalName: 'GreenMart BD Ltd (demo)', displayName: 'GreenMart BD', entityType: 'ORGANIZATION', roles: ['MANUFACTURER'],
    licence: { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2026-0001', issuingAuthority: 'Demo City Corporation (fictitious)', claimSource: 'MANUAL_ENTRY' } };
  let entityId = '';
  let pid = '';

  await step('anonymous → 401, buyer → 403 on seller onboarding', async () => {
    assert.equal((await call(onboarding.GET(req('GET', '/api/seller/onboarding')))).status, 401);
    assert.equal((await call(onboarding.GET(req('GET', '/api/seller/onboarding', 'BUYER')))).status, 403);
  });
  await step('non-JSON POST refused (CSRF guard) → 422', async () => {
    assert.equal((await call(onboarding.POST(req('POST', '/api/seller/onboarding', 'SELLER', profile, 'text/plain')))).status, 422);
  });
  await step('seller submits profile (with a forged status field) → 201 PENDING, mock check labelled', async () => {
    const r = await call(onboarding.POST(req('POST', '/api/seller/onboarding', 'SELLER', { ...profile, status: 'APPROVED' })));
    assert.equal(r.status, 201, JSON.stringify(r.json));
    assert.equal(r.json.data.entity.status, 'PENDING');
    assert.equal(r.json.data.licences[0].checkResult, 'VALID');
    assert.equal(r.json.data.licences[0].evidence, 'MOCK_DEMO_REGISTRY');
    assert.equal(r.json.data.eligibility.code, 'ENTITY_PENDING');
    entityId = (db.prepare('SELECT id FROM business_entities').get() as any).id;
  });
  await step('create product with manufacturer SELF → 201 draft', async () => {
    const r = await call(products.POST(req('POST', '/api/products', 'SELLER', {
      name: 'Basmati Rice 5kg', brand: 'GreenMart', barcode: '8905556667778', batchNumber: 'LOT-9', manufacturingDate: '2026-02-01', expiryDate: '2027-02-01',
      price: 780, stock: 10, manufacturer: { mode: 'SELF' }, labelLicenceClaim: 'BSTI CM 1234 (as printed)' })));
    assert.equal(r.status, 201, JSON.stringify(r.json));
    pid = r.json.data.id;
  });
  await step('duplicate barcode → 409 with field detail (was an unhandled 500)', async () => {
    const r = await call(products.POST(req('POST', '/api/products', 'SELLER', {
      name: 'Dup', barcode: '8905556667778', batchNumber: 'X', manufacturingDate: '2026-02-01', expiryDate: '2027-02-01', price: 1, stock: 1 })));
    assert.equal(r.status, 409);
  });
  await step('publish while PENDING → 409 ENTITY_PENDING, product stays DRAFT, nothing anchored', async () => {
    const r = await call(product.PATCH(req('PATCH', `/api/products/${pid}`, 'SELLER'), { params: { id: pid } }));
    assert.equal(r.status, 409);
    assert.equal(r.json.code, 'ENTITY_PENDING');
    assert.equal((db.prepare('SELECT status FROM products WHERE id=?').get(pid) as any).status, 'DRAFT');
    assert.equal(db.prepare('SELECT 1 FROM blockchain_records WHERE product_id=?').get(pid), undefined);
  });
  await step('seller cannot approve itself → 403; buyer → 403; anonymous → 401', async () => {
    const body = { action: 'APPROVE' };
    assert.equal((await call(decision.POST(req('POST', '', 'SELLER', body), { params: { id: entityId } }))).status, 403);
    assert.equal((await call(decision.POST(req('POST', '', 'BUYER', body), { params: { id: entityId } }))).status, 403);
    assert.equal((await call(decision.POST(req('POST', '', undefined, body), { params: { id: entityId } }))).status, 401);
  });
  await step('admin lists pending, opens detail (full licence number), approves → 200', async () => {
    const l = await call(adminList.GET(req('GET', '/api/admin/entities?status=PENDING', 'ADMIN')));
    assert.equal(l.json.data.length, 1);
    const d = await call(adminOne.GET(req('GET', '', 'ADMIN'), { params: { id: entityId } }));
    assert.equal(d.json.data.licences[0].licenceNumber, 'DEMO-TL-2026-0001');
    assert.deepEqual(d.json.data.allowedActions, ['APPROVE', 'REJECT']);
    const r = await call(decision.POST(req('POST', '', 'ADMIN', { action: 'APPROVE' }), { params: { id: entityId } }));
    assert.equal(r.status, 200, JSON.stringify(r.json));
  });
  await step('publish after approval (demo mode) → 200, schema v2, basis MOCK_REGISTRY_DEMO', async () => {
    const r = await call(product.PATCH(req('PATCH', `/api/products/${pid}`, 'SELLER'), { params: { id: pid } }));
    assert.equal(r.status, 200, JSON.stringify(r.json));
    assert.equal(r.json.data.hashSchemaVersion, 2);
    assert.equal(r.json.data.registrationBasis, 'MOCK_REGISTRY_DEMO');
  });
  await step('verify v2 product → verified, identity block public-safe and labelled demo', async () => {
    const r = await call(verify.POST(req('POST', '', 'BUYER'), { params: { id: pid } }));
    assert.equal(r.json.data.verified, true);
    assert.equal(r.json.data.hashSchemaVersion, 2);
    const s = JSON.stringify(r.json.data.identity);
    for (const leak of ['@', entityId, 'DEMO-TL-2026-0001', 'u_seller']) assert.ok(!s.includes(leak), `leaked ${leak}`);
    assert.equal(r.json.data.identity.manufacturer.identity, 'SAME_ENTITY_AS_SELLER');
    assert.match(r.json.data.identity.licence.sourceLabel, /NOT OFFICIAL/);
  });
  await step('GET product includes identity; label licence text shown as unverified claim', async () => {
    const r = await call(product.GET(req('GET', ''), { params: { id: pid } }));
    assert.equal(r.json.data.identity.labelLicenceClaim, 'BSTI CM 1234 (as printed)');
  });
  await step('legacy v1 product still verifies and is labelled legacy', async () => {
    const r = await call(verify.POST(req('POST', ''), { params: { id: 'legacy1' } }));
    assert.equal(r.json.data.verified, true);
    assert.equal(r.json.data.hashSchemaVersion, 1);
    assert.equal(r.json.data.identity.legacy, true);
  });
  await step('re-publishing the legacy product does not overwrite its v1 hash → 409', async () => {
    const r = await call(product.PATCH(req('PATCH', '/api/products/legacy1', 'SELLER'), { params: { id: 'legacy1' } }));
    assert.equal(r.status, 409);
    assert.equal(r.json.code, 'LEGACY_RECORD_EXISTS');
    assert.equal((db.prepare("SELECT keccak_hash FROM blockchain_records WHERE product_id='legacy1'").get() as any).keccak_hash, v1);
  });
  await step('admin stats count only APPROVED seller businesses', async () => {
    const r = await call(stats.GET(req('GET', '', 'ADMIN')));
    assert.equal(r.json.data.sellers, 1);
    assert.equal(r.json.data.approvedSellers, 1);
    assert.equal(r.json.data.pendingReviews, 0);
  });
  await step('suspend → new publish blocked (409 ENTITY_SUSPENDED); old product still verifies with a warning; profile locked', async () => {
    const s = await call(decision.POST(req('POST', '', 'ADMIN', { action: 'SUSPEND', reasonCode: 'COMPLAINT_UNDER_REVIEW', note: 'smoke' }), { params: { id: entityId } }));
    assert.equal(s.status, 200);
    const c = await call(products.POST(req('POST', '/api/products', 'SELLER', { name: 'Tea 100', barcode: '8903334445556', batchNumber: 'L', manufacturingDate: '2026-02-01', expiryDate: '2027-02-01', price: 3, stock: 1 })));
    const p = await call(product.PATCH(req('PATCH', '', 'SELLER'), { params: { id: c.json.data.id } }));
    assert.equal(p.json.code, 'ENTITY_SUSPENDED');
    const v = await call(verify.POST(req('POST', ''), { params: { id: pid } }));
    assert.equal(v.json.data.verified, true);
    assert.ok(v.json.data.identity.warnings.includes('SELLER_SUSPENDED_AFTER_REGISTRATION'));
    const e = await call(onboarding.POST(req('POST', '/api/seller/onboarding', 'SELLER', profile)));
    assert.equal(e.status, 409);
  });
  await step('invalid transition → 409; missing reason → 422', async () => {
    assert.equal((await call(decision.POST(req('POST', '', 'ADMIN', { action: 'APPROVE' }), { params: { id: entityId } }))).status, 409);
    assert.equal((await call(decision.POST(req('POST', '', 'ADMIN', { action: 'REINSTATE' }), { params: { id: entityId } }))).status, 422);
  });
  await step('tampering the v2 product expiry in the DB → verification fails', async () => {
    db.prepare("UPDATE products SET expiry_date='2031-01-01' WHERE id=?").run(pid);
    const v = await call(verify.POST(req('POST', ''), { params: { id: pid } }));
    assert.equal(v.json.data.verified, false);
  });
  await step('seller re-check is rate limited after 10/min → 429', async () => {
    const lic = (db.prepare('SELECT id FROM licence_records').get() as any).id;
    const codes: number[] = [];
    for (let i = 0; i < 11; i++) codes.push((await call(recheck.POST(req('POST', '', 'SELLER', {}), { params: { id: lic } }))).status);
    assert.deepEqual(codes.slice(0, 10), Array(10).fill(200));
    assert.equal(codes[10], 429);
  });

  console.log(results.join('\n'));
  console.log(`\n${results.length} route-level steps passed`);
}
main().catch((e) => { console.log(results.join('\n')); console.error('FAIL', e); process.exit(1); });
