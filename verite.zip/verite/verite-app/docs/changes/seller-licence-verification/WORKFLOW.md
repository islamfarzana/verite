# Workflow as implemented

```text
Seller account (existing login, unchanged)
        |
        v
/seller/onboarding  ──POST /api/seller/onboarding──►  validate input server-side
        |                                             (status/method/timestamps never read from the request)
        v
business_entities.status = PENDING  + entity_status_history (SUBMITTED)
        |
        v
Licence claim stored (licence_records, claim_source MANUAL_ENTRY | OCR_EXTRACTED)
        |
        v
Registry adapter (lib/identity/registry.ts), chosen by server config
   ├─ mock  : fictitious records → result labelled "MOCK/DEMO REGISTRY — NOT OFFICIAL VERIFICATION"
   ├─ real  : HTTPS registry the deployer is authorised to use (none configured in this project)
   └─ off   : UNAVAILABLE / NOT_CONFIGURED (production default)
        |
        v
licence_records updated with outcome + provenance; licence_check_events appended
   (failed attempts never overwrite an earlier definitive answer or its time)
        |
        v
Admin: /admin/sellers → POST /api/admin/entities/[id]/decision
   APPROVE | REJECT | SUSPEND | REINSTATE | REOPEN, reason required, history appended (one transaction)
   Optional: re-check licence; record a manual licence review (labelled, off by default for eligibility)
        |
        v
Seller Studio: create draft (POST /api/products) with manufacturer SELF | CLAIM | UNKNOWN
   → product_identity row (stable entity IDs or an explicit unverified claim; never an email)
        |
        v
Publish (PATCH /api/products/[id]) → prepareRegistration():
   legacy record already anchored? → 409 LEGACY_RECORD_EXISTS (v1 kept)
   re-check stale/failed registry results
   evaluateEligibility()  ← the ONE policy function
       not eligible → 409 {code, message}; product stays DRAFT; nothing anchored
       eligible     → identity snapshot frozen + hash schema v2
        |
        v
Existing chain step unchanged (real contract if CHAIN_* set, else simulated ledger)
finalizeRegistration(): snapshot + blockchain_records + PUBLISHED written in one transaction
        |
        v
Product page / POST /api/products/[id]/verify
   hash integrity (v2: product + snapshot; v1 legacy: product + seller email)
   + separate public identity block: seller (admin-reviewed, current status), manufacturer
     (same entity / registered / unverified claim / unknown / legacy), licence evidence with
     source, time and current state, warnings (demo result, status changed after registration)
```

## Manual verification (reviewer steps)
1. `npm install`, `cp .env.example .env` (set `JWT_SECRET`), `npm run seed`, `npm run dev`.
2. Sign in as `seller@verite.app`. Seller Studio shows "You cannot publish products yet" (pending review). Open **Business Verification**: amber MOCK/DEMO banner; licence `DEMO-TL-2026-0001` shows an amber "MOCK/DEMO registry: active — NOT OFFICIAL" badge; "Can I publish?" says not yet.
3. Upload a label, fill the fields, choose a manufacturer option, publish → "Saved as draft — not published" with the reason.
4. Sign out; sign in as `admin@verite.app` → **Seller Reviews** → GreenMart BD → choose Approve → save. The audit history shows both entries.
5. Back as the seller: click "Try publishing this draft again" → published, with "Seller licence basis: MOCK/DEMO REGISTRY — NOT OFFICIAL VERIFICATION".
6. Open the product page: "Who is behind this product" panel; Verify → "schema v2" note. An old seeded product shows "Legacy record" and still verifies.
7. As admin, Suspend the business → the product page shows "The seller's status changed after this product was registered"; a new product cannot be published.
8. Try other demo numbers as a renewal (`DEMO-TL-2025-0004` revoked, `DEMO-TL-0000-OUTAGE` outage) and watch eligibility change.
9. Optional: `LICENCE_REGISTRY_MODE=off` in `.env` and restart → licence checks become "Unable to check right now" and publishing is blocked.
