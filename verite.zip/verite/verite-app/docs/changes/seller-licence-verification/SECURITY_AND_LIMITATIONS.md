# Security, privacy and limitations

## Plain statements
- **Real official registry integration:** none. No BSTI, city-corporation trade-licence, BFSA or DGDA API is configured or known to be available to this project. The HTTPS adapter is a template for a registry the deployer is *authorised* to use and is tested only against fake responses.
- **Synthetic/demo results:** every result in mock mode is synthetic and labelled `MOCK/DEMO REGISTRY — NOT OFFICIAL VERIFICATION` in the API and UI. Demo numbers start with `DEMO-` and holders are marked "(fictitious)". Mock mode is off by default in production and is honoured there only with `APP_ENVIRONMENT=demo`.
- **Admin approval:** manual. Nothing approves a business automatically. Approval means "an admin reviewed this identity", and is shown separately from the licence result.
- **What a licence check establishes:** only what the consulted source said at the recorded time. A mock check establishes nothing about any real licence. A manual review is an admin's judgement of evidence, not a registry lookup, and qualifies sellers only if `LICENCE_ACCEPT_MANUAL_REVIEW=true`.
- **What OCR establishes:** only what the image-processing system read from the picture. OCR-extracted licence numbers are stored with `claim_source = OCR_EXTRACTED`, and label licence text is shown as "as read from the label — not verified".
- **Expiry, revocation, unavailability:** expiry is compared on the Asia/Dhaka calendar day. A revoked/suspended/expired/invalid/not-found result blocks new registrations immediately. Unavailable/error never counts as valid or invalid; it blocks registry-dependent registration. A registry `VALID` older than `LICENCE_REGISTRY_RESULT_TTL_HOURS` (24) is re-checked before publishing. Existing products stay visible, with a public warning, when the seller is suspended or the licence status changes after registration (product status itself is not changed automatically).
- **Legacy manufacturer values:** the old "manufacturer" was the seller's email inside the hash. Legacy products keep their v1 hash and verify as before. They are labelled "legacy record — manufacturer identity was not recorded". They are never promoted, re-hashed or overwritten; `npm run identity:report` lists them.
- **What is hashed:** v2 commits to the 7 product fields, the seller entity ID and display name, and the manufacturer/brand-owner identity (entity ID and name, or an unverified claim name, or "unknown"), with `schemaVersion: 2`. Not hashed: emails, licence numbers, licence results, check times, statuses.
- **On-chain:** if `CHAIN_*` is configured, the same Keccak-256 hash goes to the unchanged `ProductRegistry` contract; otherwise it uses the simulated ledger, as before. The hash proves only that the recorded data and identity snapshot have not changed since registration. It does **not** prove a licence is valid or that a physical product is genuine.

## Controls implemented
- Server-side authorisation on every route (seller vs admin), checked again inside the service functions.
- No client-settable status, verification method, outcome or timestamp (mass-assignment tests).
- Admins cannot decide on an entity managed by their own account; sellers cannot reach admin actions.
- Status change and its history row written in one `BEGIN IMMEDIATE` transaction with an optimistic status guard.
- `entity_status_history` and `licence_check_events` are append-only (database triggers). `product_identity` is frozen after registration (trigger).
- One live claim per licence number and type across all businesses (unique index); businesses are never merged by email or name.
- Registry URL, key, label and timeout come from server environment only (no SSRF); https required; bounded timeout (default 5 s, max 30 s).
- State-changing identity routes accept `application/json` only; with the existing `SameSite=Lax` cookie this blocks cross-site form posts.
- Re-check endpoints are rate-limited (10/min per user, in-memory).
- Public responses contain names and statuses only: no emails, user/entity/licence IDs, licence numbers, registry references or internal notes (tested). Errors are logged by category only.
- Seller-facing history shows public notes only; internal notes and reviewer identity are admin-only.

## Remaining risks (prioritised)
- **High — no real registry.** In production with mode `off`, no seller can publish until an authorised registry is configured or manual review is explicitly accepted. That is deliberate (fail-safe), but it is the main gap before real use.
- **High — forged evidence.** A seller can type any licence number; without a real registry, an admin's review is the only check. No document upload or malware scanning exists yet.
- **Medium — third-party manufacturers.** A manufacturer other than the seller is only an unverified claim. There is no flow for a manufacturer to authorise a reseller.
- **Medium — registry data quality and delays.** Even a real registry can be out of date; results carry their check time, and the TTL limits staleness.
- **Medium — rate limiter and SQLite are single-instance.** Inherited limitation.
- **Low — public display names in the hash.** These are public anyway; random UUID entity IDs are not guessable.

## Retention
No licence documents are stored. Licence records and check events are kept indefinitely as audit evidence; a retention policy should be decided before production.
