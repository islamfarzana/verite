# Delta specification: seller onboarding, licence verification, verified identity references

Written after `audit.md` and before implementation. Section numbers follow the master prompt's Phase B list.

## 1. Verified current behaviour
See `audit.md`. In one line: the hash's `manufacturer` field is the seller's login email; there is no business profile, no approval, no licence record and no registry; any seller account can publish immediately.

## 2. Terminology and entity relationships

- **User account** (`users`, unchanged): a login. Role `SELLER` lets it manage a business.
- **Business entity** (`business_entities`, new): a business with a legal name and a public display name. Contact email is a private attribute, never its identity. One entity is managed by at most one seller account. Entities managed by nobody can exist (e.g. a third-party manufacturer added later by an admin).
- **Entity roles** (`entity_roles`, new): `SELLER`, `MANUFACTURER`, `BRAND_OWNER`. One entity can hold several roles, so "we make and sell our own brand" needs no duplicate rows, and "we resell someone else's product" stays separate.
- **Licence record** (`licence_records`, new): a claim (type, number, issuing authority, claimed dates) attached to an entity, plus the latest check outcome and its provenance. Every check attempt is appended to `licence_check_events`.
- **Product identity** (`product_identity`, new, 1:1 with `products`): stable references to the seller, manufacturer and brand-owner entities, or an explicit unverified manufacturer claim, and the identity snapshot frozen at registration.

```
users 1 ──── 0..1 business_entities 1 ──── * entity_roles
                     │ 1
                     ├──── * licence_records 1 ──── * licence_check_events
                     └──── * entity_status_history
products 1 ──── 0..1 product_identity ──► seller_entity_id / manufacturer_entity_id / brand_owner_entity_id
```

## 3. Schema choice and rationale
New tables only, in `lib/identity/schema.ts`, executed from `lib/db.ts` (same pattern as `lib/trace/schema.ts`). No existing table or column is altered or renamed, so all current queries, the cart, orders and the v1 records are untouched. `product_identity` is a side table instead of new `products` columns, so the `products` `CHECK` constraints and every existing `SELECT p.*` remain as they are. The mock registry table (`mock_licence_registry`) is filled with synthetic rows **only when the mock adapter is constructed**, so a production database without demo mode never contains demo licences.

## 4. Onboarding states and transitions (server-enforced in `lib/identity/onboarding.ts`)

| From | To | Who | Reason |
|---|---|---|---|
| (none) | PENDING | seller (own profile) | `SUBMITTED` |
| PENDING | PENDING | seller | `DETAILS_UPDATED` |
| REJECTED | PENDING | seller (resubmission) | `RESUBMITTED` |
| PENDING | APPROVED | admin | `REVIEW_PASSED` |
| PENDING | REJECTED | admin | required code |
| APPROVED | SUSPENDED | admin | required code |
| SUSPENDED | APPROVED | admin (reinstate) | required code |
| SUSPENDED | PENDING | admin (reopen review) | required code |

Anything else is refused with 409. The client never sends a status; the route maps an `action` to a transition. An admin cannot decide on an entity managed by their own account. Each change and its history row are written in one `BEGIN IMMEDIATE` transaction with an optimistic `WHERE status = <expected>` guard. `entity_status_history` and `licence_check_events` are append-only (SQLite triggers abort `UPDATE`/`DELETE`).

## 5. Licence fields: three separate concepts
1. **Claimed state** (`claimed_status`): what the submitter declares (`UNKNOWN`, `ACTIVE`, `EXPIRED`, `REVOKED`, `SUSPENDED`, `INVALID`).
2. **Check outcome** (`check_result`): `NOT_CHECKED`, `VALID`, `INVALID`, `EXPIRED`, `REVOKED`, `SUSPENDED`, `NOT_FOUND`, `UNAVAILABLE`, `ERROR`, `UNSUPPORTED`, with `verification_method` (`UNVERIFIED_CLAIM`, `MOCK_REGISTRY`, `REAL_REGISTRY_API`, `AUTHORIZED_MANUAL_REVIEW`), `verification_environment` (`DEMO`/`PRODUCTION`), `source_label`, `registry_reference`, `registry_expiry_date`, `checked_at` (only when a check actually returned), `last_attempt_at`, `error_category`.
3. **Entity onboarding state** (`business_entities.status`).

`claim_source` records whether the number was typed (`MANUAL_ENTRY`) or extracted from an image (`OCR_EXTRACTED`); the UI says "extracted from your document — not independently verified" for the latter.

## 6. Registry adapter contract (`lib/identity/registry.ts`)
`check({licenceType, licenceNumber, issuingAuthority}) → RegistryResult {outcome, method, environment, mode: 'MOCK'|'REAL'|'NONE', sourceLabel, checkedAt|null, reference|null, expiryDate|null, errorCategory|null}`.

Selection (`lib/identity/config.ts`): `LICENCE_REGISTRY_MODE` = `mock` | `real` | `off`.
- Unset → `mock` outside production, `off` in production.
- `mock` in production is honoured **only** if `APP_ENVIRONMENT=demo`; otherwise it becomes `off`.
- `real` needs `LICENCE_REGISTRY_BASE_URL` (https), `LICENCE_REGISTRY_API_KEY`, `LICENCE_REGISTRY_SOURCE_LABEL`; if any is missing the adapter is the *unconfigured* adapter (`UNAVAILABLE`, `NOT_CONFIGURED`). It never falls back to mock.
- `off` → unconfigured adapter.

The real adapter is a generic HTTPS client for a registry that the deployer must be authorised to use. **No official Bangladeshi registry API (BSTI, city corporation trade licence, BFSA, DGDA) is configured or known to this project**, so the real adapter is tested only against fake HTTP responses.

## 7. Mock/demo behaviour and labels
Synthetic records numbered `DEMO-…`, holders marked "(fictitious)". Every mock result carries `method=MOCK_REGISTRY`, `environment=DEMO`, `sourceLabel="MOCK/DEMO REGISTRY — NOT OFFICIAL VERIFICATION"`. One record (`DEMO-TL-0000-OUTAGE`) simulates an outage so the unavailable path can be demonstrated. UI badges: amber "MOCK/DEMO — NOT OFFICIAL" for any mock result; green only for a real-registry `VALID`.

## 8. Product-registration eligibility (`lib/identity/policy.ts`, one function used by the publish route)
Conservative default; not legal advice; the same licence rule applies to all categories (the project has no per-category licence data).

| Condition | Draft | Register (publish & anchor) | Basis |
|---|---|---|---|
| No business profile | yes | no — `NO_BUSINESS_PROFILE` | |
| Entity PENDING / REJECTED / SUSPENDED | yes | no | |
| APPROVED, no licence or only unverified claim | yes | no — `LICENCE_UNVERIFIED` | |
| APPROVED, any licence REVOKED or SUSPENDED (latest outcome) | yes | no | |
| APPROVED, real `VALID`, not expired, checked within TTL | yes | **yes** | `REAL_REGISTRY` |
| APPROVED, manual-review `VALID` and `LICENCE_ACCEPT_MANUAL_REVIEW=true` | yes | yes | `MANUAL_LICENCE_REVIEW` |
| APPROVED, mock `VALID`, demo mode active | yes | yes, labelled demo | `MOCK_REGISTRY_DEMO` |
| APPROVED, mock `VALID`, demo mode not active | yes | no — `MOCK_NOT_ALLOWED` | |
| `EXPIRED` (outcome, or expiry date before today in Asia/Dhaka) | yes | no | |
| `INVALID` / `NOT_FOUND` | yes | no | |
| `UNAVAILABLE` / `ERROR`, or a `VALID` older than the TTL that could not be re-checked | yes | no — `REGISTRY_UNAVAILABLE` | |
| `UNSUPPORTED` | yes | no | |

"Draft" = the product stays `DRAFT` (the existing status), so nothing new is publicly listed. Before deciding, the publish route re-checks registry-based licences whose result is older than `LICENCE_REGISTRY_RESULT_TTL_HOURS` (default 24).

## 9. Product references and canonical hash
- Product creation accepts `manufacturer: {mode: 'SELF' | 'CLAIM' | 'UNKNOWN', name?}` and `brandOwnerIsSeller`. `SELF` is allowed only when the seller's own entity has the `MANUFACTURER` role (or `BRAND_OWNER` for the brand flag). `CLAIM` stores the typed/OCR name as an **unverified claim**. Nothing is ever derived from an email.
- Referencing *another* entity as manufacturer is supported by the schema and the service (admin actor), but there is no seller UI for it, because it needs an authorisation link from that manufacturer (future work).
- **Hash schema v2** (`lib/identity/hash.ts`): Keccak-256 (unchanged algorithm, same contract) over a recursively key-sorted, NFC-normalised, trimmed JSON object: `{schemaVersion: 2, productId, productName, brand, barcode, batchNumber, manufacturingDate, expiryDate, seller: {entityId, displayName}, manufacturer: {identity, entityId, name}, brandOwner: {entityId, name}}`. Entity IDs are random UUIDs, not emails. Volatile data (licence results, check times, statuses) is **not** hashed; it is kept in the registration snapshot for display.
- The snapshot is frozen in `product_identity.identity_snapshot_json` at registration. Display and recomputation use the snapshot, so renaming an entity later does not break the hash; editing the snapshot in the database does (tamper evident).
- **v1 compatibility:** products without a `product_identity` row with `hash_schema_version = 2` are verified exactly as before (v1, seller email) and labelled "legacy record". Existing commitments are never recomputed or overwritten.

## 10. Failure behaviour
Timeout (`LICENCE_REGISTRY_TIMEOUT_MS`, default 5000), network error, 5xx and 429 → `UNAVAILABLE`; 401/403, malformed JSON, unknown status → `ERROR`; 404 or `NOT_FOUND` → `NOT_FOUND`. None of these becomes `VALID`. A failed re-check keeps the previous definitive outcome and its original `checked_at`, records `last_attempt_at` and `error_category`, and appends an event. No automatic retry loop (fits a request/response app); sellers and admins can trigger a re-check (rate-limited).

## 11. Authorisation matrix

| Action | Buyer/anon | Seller (own) | Seller (other) | Admin |
|---|---|---|---|---|
| Submit/update own profile & licence | – | yes | – | – |
| Re-check own licence | – | yes (10/min) | – | yes |
| List/inspect entities, history, full licence numbers | – | own (no internal notes) | – | yes |
| Approve/reject/suspend/reinstate/reopen | – | – | – | yes, not on own entity |
| Manual licence review | – | – | – | yes |
| Public identity summary | yes (minimised) | yes | yes | yes |

## 12. File zones
**ADDED:** `lib/identity/{schema,types,config,registry,mock-registry-data,onboarding,policy,hash,keccak,registration,public,views,labels,http}.ts`; `components/IdentityBadges.tsx`; `app/api/seller/onboarding/route.ts`; `app/api/seller/onboarding/licences/route.ts`; `app/api/seller/onboarding/licences/[id]/recheck/route.ts`; `app/api/admin/entities/route.ts`; `app/api/admin/entities/[id]/route.ts`; `app/api/admin/entities/[id]/decision/route.ts`; `app/api/admin/licences/[id]/recheck/route.ts`; `app/api/admin/licences/[id]/manual-review/route.ts`; `app/seller/onboarding/page.tsx`; `app/admin/sellers/page.tsx`; `scripts/identity-migration-report.ts`; `tests/identity/*`; `tests/shims/ethers/*` (test-only); docs and `evidence/` in this folder.
**MODIFIED (minimal):** `lib/db.ts` (exec new schema); `app/api/products/route.ts` (accept manufacturer fields, record identity); `app/api/products/[id]/route.ts` (GET adds `identity`; PATCH applies policy and v2 hash); `app/api/products/[id]/verify/route.ts` (v1/v2 recomputation + identity block); `app/api/admin/stats/route.ts` (adds approved-entity count); `app/admin/dashboard/page.tsx` (card label/value); `app/seller/dashboard/page.tsx` (manufacturer inputs, show publish/validation errors, status banner); `app/product/[id]/page.tsx` (identity panel; badge text); `components/NavBar.tsx` (2 links); `scripts/seed.ts` (seller entity as PENDING + demo licence claim); `package.json` (scripts); `.env.example`; `README.md` (short section).
**PROTECTED (unchanged):** auth (`lib/auth*.ts`, `lib/session.ts`, `middleware.ts`, `app/api/auth/*`, `app/login`), buyer pages, cart, checkout, orders, payments, uploads, OCR proxy and microservice, `lib/blockchain.ts`, `lib/chain.ts`, `blockchain/`, `lib/trace/*`.

## 13. Migration, legacy and rollback
- Additive `CREATE TABLE IF NOT EXISTS`; runs on next start. No backfill: legacy products get **no** identity row and are shown as "legacy record — manufacturer identity not recorded". No legacy record is promoted. `npm run identity:report` lists legacy products for review.
- Rollback: `DROP TABLE product_identity; DROP TABLE licence_check_events; DROP TABLE licence_records; DROP TABLE entity_status_history; DROP TABLE entity_roles; DROP TABLE business_entities; DROP TABLE mock_licence_registry;` and revert the modified files. Products registered under v2 would then fail verification (their hash input includes the snapshot), so rollback is only safe before v2 products exist.

## 14. API contracts (envelope unchanged: `{success, message?, data?}`)
- `GET /api/seller/onboarding` → `{entity|null, roles, licences[], history[] (no internal notes), eligibility, registry: {mode, label}}`.
- `POST /api/seller/onboarding` `{legalName, displayName, entityType, roles[], contactEmail?, licence: {licenceType, licenceNumber, issuingAuthority, claimedIssueDate?, claimedExpiryDate?, claimSource}}` → 201/200; 409 locked or conflicting licence; 422 validation.
- `POST /api/seller/onboarding/licences` (add/renew), `POST …/licences/[id]/recheck`.
- `GET /api/admin/entities?status=`; `GET /api/admin/entities/[id]`; `POST /api/admin/entities/[id]/decision` `{action, reasonCode, note?, publicNote?}`; `POST /api/admin/licences/[id]/recheck`; `POST /api/admin/licences/[id]/manual-review` `{result, note?}`.
- `PATCH /api/products/[id]` → 409 `{code, message}` when not eligible; success adds `hashSchemaVersion`, `registrationBasis`.
- `GET /api/products/[id]` and `POST …/verify` add `identity` (public, minimised: names, statuses, method, source label, check date; no emails, IDs or licence numbers).

## 15. Privacy, security, audit
Emails, entity IDs, full licence numbers and internal notes never appear in public responses. Logs print error categories only. Registry URL comes only from server config (no SSRF). State-changing admin/seller routes require `Content-Type: application/json` (with `SameSite=Lax` cookies this blocks cross-site form posts). History and check events are append-only. No documents are uploaded in this iteration (licence data is typed or pasted from OCR text), so no document storage/retention question arises yet.

## 16. Test plan
`tests/identity/` with `node:sqlite` and the real `lib/db.ts` table text: adapter (mock + real with fake fetch: valid, invalid, expired, revoked, suspended, not found, timeout, network, malformed, 401/403, 429, 5xx, unsupported, missing config, no mock fallback, timestamps), config selection, onboarding transitions and authorisation, mass-assignment, history immutability, policy matrix, registration end-to-end, identity separation, hash v1/v2 determinism and compatibility, public response minimisation. Existing `tests/trace` must still pass.

## 17. Known limitations
No real registry; mock only. Manual-review acceptance is off by default. No evidence-document upload. No third-party manufacturer authorisation flow. The in-memory rate limiter is per process. Admin approval is manual.
