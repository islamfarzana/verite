# Test report: seller onboarding and licence verification

**Date:** 2026-10-28. **Environment:** the build sandbox (Linux, Node v22.23.4, tsx 4.23, TypeScript 7.0.2). **Licence registry mode used:** `mock` (fictitious demo records) plus scripted/fake adapters inside tests. **Real registry contacted:** no. **Real blockchain contacted:** no.

## Constraint that shapes this report
The project's dependencies (`next`, `better-sqlite3`, `ethers`, `jose`, …) could not be installed: the sandbox's egress proxy refused the npm registry (`403`, 2026-10-28). So:
- Unit/integration tests run on Node's built-in `node:sqlite`, against tables taken **verbatim from `lib/db.ts`** plus the real identity schema, same as the existing `tests/trace` suite.
- `ethers` is replaced in tests by `tests/shims/ethers` (loaded only through `NODE_PATH=tests/shims`; with a normal `npm install`, Node resolves the real `ethers` first). The shim's Keccak-256 is checked against published vectors (`""`, `"abc"`, "The quick brown fox…") and, with the SHA-3 padding swapped in, against Python's `hashlib.sha3_256` across block boundaries (0, 135, 136, 137, 200, 500 bytes). All matched.
- The route-level smoke run uses sandbox-only stand-ins for `next/server`, `better-sqlite3` (over `node:sqlite`), `jose` (an **unsigned** token, for role checks only) and `bcryptjs`. They are in `evidence/shims/` for reproducibility and are **not** part of the app.

## Commands executed and results

| # | Command | Result |
|---|---|---|
| 1 | `NODE_PATH=tests/shims tsx --test tests/trace/*.test.ts` (baseline, before changes) | 35 pass, 0 fail |
| 2 | `NODE_PATH=tests/shims tsx --test tests/identity/*.test.ts` | **61 pass, 0 fail, 0 skipped** (`evidence/identity-tests.log`) |
| 3 | `NODE_PATH=tests/shims tsx --test tests/trace/*.test.ts` (after changes, regression) | 35 pass, 0 fail (`evidence/trace-tests.log`) |
| 4 | `tsc --strict` over `lib/**`, `app/api/**`, `scripts/*`, `tests/**`, and the changed/added pages, with narrow hand-written stubs for packages that could not be installed | 0 errors (`evidence/typecheck.log`) |
| 5 | Route smoke: `NODE_PATH=evidence/shims tsx evidence/route-smoke.ts` — calls the real route handlers with real SQL | **18/18 steps passed** (`evidence/route-smoke.log`) |
| 6 | `npm run seed` twice on an empty DB, then `npm run identity:report` (with the same stand-ins) | Seed idempotent; demo seller submitted as PENDING; report lists 6 legacy v1 products |

On a normal machine, `npm install` then `npm run test:identity` and `npm run test:trace` run the same suites with the real `ethers` (Node 22.13+ is needed for `node:sqlite`).

## Corrections made while testing
Two tests failed on the first full run; both were mistakes in the tests:
1. A renewal test used an issuing authority of `'x'`, which validation correctly rejects (2–120 chars).
2. A test expected that publishing again after a registry said `REVOKED` would quietly re-ask the registry. The implementation (and the spec: "never rewrite history") keeps a definitive result until someone explicitly asks for a re-check. The test now asserts that behaviour and performs an explicit seller re-check.

One issue found by writing tests changed the code: re-publishing an already-anchored legacy product would have re-hashed it under v2 and overwritten its v1 commitment on the simulated ledger. `prepareRegistration` now refuses with `LEGACY_RECORD_EXISTS`; a test covers it.

## Coverage against the master prompt (§11)
- **Adapter:** valid, invalid, expired (status and by date), revoked, suspended, not found, unavailable (timeout, network, 5xx, 429), error (malformed, unknown status, 401, 403, other 4xx), unsupported, missing/invalid config, no mock fallback, synthetic fixtures, timestamps only on real answers.
- **Identity & onboarding:** email never used as manufacturer; seller ≠ manufacturer; unknown stays unknown; new = PENDING; valid/invalid transitions; unauthorised users; self-approval guard; reasons + audit; mass assignment; pending/rejected/suspended blocked; approval ≠ verification; mock ≠ real outside demo.
- **Policy:** full matrix; Dhaka calendar expiry; unavailable ≠ invalid; later revocation blocks new registrations; unsupported stays unverified; re-checks keep earlier evidence and times.
- **Hash/migration:** deterministic canonical form; explicit schema version; distinct entities don't collide; seller email change doesn't change v2 hash; rename/suspension doesn't change it; snapshot and product tampering detected; legacy v1 verifies unchanged; legacy never promoted or overwritten; no email/licence data in the preimage; public output has no emails, IDs, licence numbers or notes.
- **Routes (smoke):** 401/403/422/409/429 paths, PENDING → blocked, approve → publish v2, verify v2 and v1, suspend → blocked + warning, tamper → fails.

## Not run / not proven
- **Browser UI was not rendered.** The pages (`/seller/onboarding`, `/admin/sellers`, seller dashboard changes, product page panel) were type-checked against stubbed React types only. Click-through is listed in `WORKFLOW.md` → "Manual verification".
- **`next build`** was not run (no dependencies).
- **No real licence registry** was contacted; the HTTPS adapter is tested only with fake responses.
- The JWT used in the smoke run is unsigned (stand-in); real signature checks are the existing, unchanged `lib/auth-edge.ts`.
- The in-memory rate limiter is per process (inherited limitation).
