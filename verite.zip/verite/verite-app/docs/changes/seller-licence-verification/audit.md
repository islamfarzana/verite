# Audit: seller identity, manufacturer identity and licence behaviour

**Date:** 2026-10-28  
**Codebase audited:** `verite-ocr-microservice-v2` (marketplace `verite-app/` + `ocr-service/`), before any change for this task.  
**Method:** read the code paths listed below; ran the existing automated suite (`tsx --test tests/trace/*.test.ts`, 35/35 passed) as the baseline. There are no `CLAUDE.md`, `docs/00_Baseline_State.md`, `docs/01_Dependency_Map.md`, `docs/02_Protected_Boundaries.md` or `REMEDIATION_PLAN.md` files in this repository; the only prior change record is `docs/changes/identifier-scan-protection/`.

## 1. Stack facts that constrain the design

| Item | Evidence |
|---|---|
| Framework | Next.js 14 App Router, React 18, Tailwind (`package.json`) |
| Database | SQLite through `better-sqlite3`; schema is `CREATE TABLE IF NOT EXISTS` in `lib/db.ts`, run at import. No migration tool. Additive feature schemas are kept in their own module and executed from `lib/db.ts` (precedent: `lib/trace/schema.ts`). |
| Auth | JWT (HS256, `jose`) in httpOnly cookie `verite_session`; `lib/auth-edge.ts`, `lib/session.ts`. Roles `BUYER`, `SELLER`, `ADMIN` in `users.role`. API routes check `payload.role` themselves; `middleware.ts` only guards pages `/buyer`, `/seller`, `/admin`. |
| Validation | Zod in each route. |
| Tests | `node:test` via `tsx --test`, in-memory `node:sqlite` built from the real `lib/db.ts` table text (`tests/trace/helpers.ts`). Dependencies cannot be installed in the build sandbox (npm registry blocked: `403` from the egress proxy on 2026-10-28), so Next.js routes cannot be executed here. |

## 2. What the field treated as `manufacturer` actually contains

**Finding: it is the seller's login email. Confirmed.**

- `lib/blockchain.ts` — `CanonicalProduct.manufacturer: string` is one of the 8 hashed fields.
- `app/api/products/[id]/route.ts` line 52 (publish): `manufacturer: payload.email` — the JWT email of the seller who publishes.
- `app/api/products/[id]/verify/route.ts` lines 10 and 34: joins `users` and recomputes with `manufacturer: product.seller_email`.
- `scripts/seed.ts` line 80: `manufacturer: seller.email`.
- The `products` table has **no** manufacturer column (`lib/db.ts`). No table for businesses, manufacturers, brand owners or licences exists.

Consequences verified from the code:
1. The value is never displayed; it only exists inside the hash preimage.
2. A seller who changes their account email would make every product they published fail verification (the recomputation joins the current `users.email`). Nothing in the app lets a user change email today, but the dependency is real.
3. A manufacturer name typed by the seller is **discarded**: the OCR microservice returns `manufacturer` and `licenceNumber` (`ocr-service/app/services/parser.py` lines 141, 155), the proxy passes all fields through (`app/api/ocr/extract/route.ts` `flattenMicroserviceResponse`), the seller dashboard shows them as editable inputs (`app/seller/dashboard/page.tsx`, `Object.keys(fields)`), but `createAndPublish` does not send them and `POST /api/products` (`createSchema`) does not accept them.
4. The hash therefore commits to "this account published it", not to who made the product.

## 3. Licence behaviour

**Finding: licence verification is absent.** `grep -ri "licen\|bsti"` over `verite-app/` returns no matches. The only licence logic is the OCR regex `_LICENCE_RE` in `ocr-service/app/services/parser.py` line 26, which **extracts** text after `LICENCE|REGISTRATION|BSTI|FDA`. It is not syntax-checked, not stored, not compared with any list and not sent to any registry. There is no registry URL, credential or fixture anywhere in the repository.

## 4. Seller onboarding and approval

- Anyone can register as a seller: `app/api/auth/register/route.ts` accepts `role: 'SELLER'` and creates the account immediately.
- `users.status` exists (`DEFAULT 'ACTIVE'`, `lib/db.ts` line 30) but no code reads or writes it.
- A newly registered seller can publish immediately: `PATCH /api/products/[id]` checks only `role === 'SELLER'` and ownership, then sets `status='PUBLISHED', verification_status='VERIFIED'` (line 94).
- **Approval and verification are conflated in the UI:** `verification_status='VERIFIED'` only means "a hash was anchored", yet the product page shows a green "✓ Verified" badge from it (`app/product/[id]/page.tsx`).
- The admin dashboard card "Approved Sellers" (`app/admin/dashboard/page.tsx`) counts `users WHERE role='SELLER'` (`app/api/admin/stats/route.ts`), i.e. every seller account; no approval exists.
- The seller dashboard ignores the publish response status: `setPublished(pubJson.data)` runs even when the request failed, so a refused publish is silent.

## 5. Records affected by any change

- Every existing `blockchain_records` row was hashed with the seller email (schema "v1"). These hashes are also on-chain for products published with `CHAIN_*` configured. **They must keep verifying with the v1 rule**; recomputing or overwriting them would destroy the evidence they represent.
- Seeded demo products (6 rows, seller `seller@verite.app`, simulated ledger).
- No existing data contains a manufacturer name or a licence number, so there is nothing to migrate into those concepts. The only ambiguity is "who manufactured the legacy products": **unknown**. It must stay unknown.

## 6. Behaviour that must remain compatible

Login/registration/session/middleware; buyer flows, cart, checkout, orders, payments; marketplace list; the existing upload endpoint; OCR proxy; blockchain contract, ABI and `lib/chain.ts`; the v1 hash function and the verification of all existing records; identifier/QR feature and its 35 tests.

## 7. Answers to the master prompt's audit questions

| Question | Answer (evidence above) |
|---|---|
| What does `manufacturer` contain? | The seller's account email. |
| Email, name, FK or mixed? | Always the email; never a name or FK. |
| Where used? | Only as hash input at publish, verify and seed; never displayed or returned. |
| Licence: extracted / syntax / manual / local / registry? | Only extracted by OCR text regex; then dropped. |
| Real lookup? | None. |
| Can a pending/unverified seller register a product as approved? | Yes, any seller account can publish immediately. |
| Approval and verification conflated? | Yes (green "Verified" badge = hash anchored; "Approved Sellers" = all sellers). |
| Records affected | All existing `blockchain_records` (v1 hashes) and seeded products. |
| Must remain compatible | Section 6. |
