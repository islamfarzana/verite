# Buyer protection (v5): how it works and how to demo it

## Implemented flows

```text
Buyer photo(s) ──> content check (magic bytes, ≤10 MB) ──> OCR: microservice (Tesseract ben+eng) or local fallback
   (not stored, no AI)                                       │ fields + per-field confidence
                                                             v
Listing id (= one batch) ──> registered record (name, Bangla name, manufacturer, batch, MFG, EXP, MRP)
                                                             │ lib/protection/label-check.ts
                                                             v
        per field: MATCH / MISMATCH / UNCERTAIN / NOT_FOUND_ON_LABEL / NOT_REGISTERED / NOT_APPLICABLE
        overall:   MATCH / MISMATCH_REVIEW / UNCERTAIN / BATCH_UNRESOLVED / INSUFFICIENT_IMAGE / NOT_REGISTERED
                                                             v
        Bangla + English result ──> retake photo, or "send for review" ──> admin Protection page

Seller create / price change / publish ──> integer-paisa MRP guard ──> allowed / refused (409/422) + audit row
Marketplace / add to cart / cart / checkout / publish ──> sellability (lib/protection/sellability.ts):
        RECALLED > EXPIRED / EXPIRY_UNKNOWN > NOT_PUBLISHED > ABOVE_MRP / MRP_MISSING > stock
Stored QR scan events ──> same rule as the buyer warning ──> one SCAN_RISK seller alert per code per day
Seller (own) / admin recall ──> ONE transaction: recall row + in-app notice per affected buyer + audit
        ──> unsellable everywhere; scan and product pages show "recalled"; admin closes it later
```

Persistence:

```text
Every page ──> API route ──> lib/db.ts ──> ONE SQLite file: data/verite.db (or DATABASE_FILE)
   products (drafts too), cart_items, orders, recalls, notices, label_checks, audit ...
Uploads ──> data/uploads ──> GET /api/files/<name>
```

## Run it

```bash
cd verite-app
npm install
npm run seed            # adds demo MRPs and a near-expiry demo product; existing data is kept
npm run simulate:sales  # optional, demo sales for the Assistant (labelled SIM-)
npm run dev
npm run db:status       # where the data is saved and what is in it
```

For the label check with Bangla, start the OCR service in Codespaces and set `OCR_SERVICE_URL` (as in v4). The image must be rebuilt (`docker compose build ocr-api`) so that it contains `tesseract-ocr-ben`. Without the service, the local tesseract.js fallback is used; it needs internet the first time to download Bengali data.

## Demo script (≈10 minutes)

Accounts: `seller@`, `buyer@` and `admin@verite.app`, password `Password123!`.

1. **Data is saved.**
   - As admin, open **Seller Reviews** and approve GreenMart BD.
   - As seller, open **Seller Studio** and add a product. Fill in MRP, selling price and stock, then publish.
   - Close the browser. Run `npm run db:status`: the product is listed.
   - Open **My Products** as seller: it is there. Open the marketplace as buyer: it is there too.
2. **Cart is saved.**
   - As buyer, add two items to the cart and sign out.
   - Sign in again, in another browser if you like. The cart is still there.
3. **Expiry.**
   - The marketplace no longer shows the demo milk and noodles: they are past expiry.
   - The **Mango Juice** card shows "মেয়াদ শেষ হতে ২০ দিন বাকি" (about 20 days, counted from the day you seeded).
   - Opening the milk's product page directly shows "মেয়াদ শেষ" and a disabled Add to Cart.
4. **MRP.**
   - In **My Products**, choose *Change price / stock* and enter a price above the MRP. It is refused with the Bangla message.
   - Optionally, as admin under **Protection**, *Mark reviewed* the MRP.
5. **Check my pack.**
   - As buyer, open the product and choose **📷 Check my pack**. Upload a photo of the pack.
   - Matching fields are green. A different pack shows "কিছু তথ্য মিলছে না… আরও যাচাই প্রয়োজন" and nothing about "fake".
   - Choose **Send for review**. As admin, open **Protection**: the review request is listed.
6. **QR clone-risk.**
   - As seller, open **QR Codes** and issue unit codes. Open one scan link from 3 or more devices or networks.
   - The scan page shows the warning. **Assistant** shows "অস্বাভাবিক স্ক্যান…" with the counts.
7. **Recall.**
   - As buyer, place an order (COD).
   - As seller, open **My Products** and choose *Recall batch…*, then confirm.
   - The product disappears from the marketplace, and its page and scan page say it is recalled.
   - As buyer, **Notifications** shows the Bangla recall notice.
   - As admin, **Protection** shows the recall. Choose *Close recall*.

## API added

| Method and path | Who | Purpose |
|---|---|---|
| `GET/POST/PATCH/DELETE /api/cart` | buyer | Saved cart. `POST {items}` imports an old browser cart once. |
| `GET /api/seller/products` | seller | All own listings, with visibility reasons |
| `PATCH /api/products/:id/listing` | seller (owner) | Price and stock only (strict) |
| `POST /api/products/:id/label-check` | anyone, rate-limited | Buyer label check (multipart `front`, `back`) |
| `POST /api/label-checks/:id` | checker / admin | `REQUEST_REVIEW` / `RESOLVE` |
| `GET/POST /api/recalls` | seller / admin | List and open recalls |
| `POST /api/recalls/:id` | admin | `CLOSE` / `RESEND` |
| `GET/POST /api/buyer/notifications` | buyer | In-app notices and mark-read |
| `GET /api/admin/protection` | admin | Recalls, review requests, listings |
| `POST /api/admin/products/:id/mrp-review` | admin | Mark the MRP reviewed or correct it |
| `GET /api/files/:name` | public | Uploaded images |

Changed contracts:
- `POST /api/products` needs `mrp`, and `price` is optional (default = MRP).
- `POST /api/orders` is buyer-only and refuses unsellable items with `409 NOT_SELLABLE`.
- `GET /api/products` hides unsellable listings and adds `expiry`.
- `GET /api/products/:id` adds `protection`.
- `/api/scan` adds `batchStatus`.
- `/api/uploads` returns `/api/files/...` URLs.
