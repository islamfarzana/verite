# Buyer protection: policy decisions

Every value below is a **provisional product policy chosen for this thesis prototype**. None of them is a legal requirement or a validated threshold. Change them in `.env` (see `.env.example`); the policy version recorded with each decision is `buyer-protection-1`.

## Money and MRP
| Decision | Value | Why |
|---|---|---|
| Representation | Integer **paisa**, parsed from text | No floating-point rounding in any price/MRP comparison. `products.price` stays REAL (legacy) and is converted with nearest-paisa rounding. |
| Comparison basis | Listing item price vs. the MRP registered for **that listing** | One listing = one pack size and one batch, so no pack-size conversion is needed. VAT and delivery are separate order lines, so they are not compared. |
| Price > MRP | **Blocked** (create, price change, publish, checkout); hidden from the marketplace | Safer default; it is enforced on the server. |
| New listing without MRP | **Refused** | The MRP is printed on every FMCG pack and is read by OCR. |
| Old listing without MRP | `MRP_MISSING_POLICY=allow`: it stays on sale, shown as "MRP not registered". `block` hides it. | v4 listings had no MRP column. |
| Who sets MRP | The seller, at creation (from the label, confirmed). It is **locked after creation for sellers**. An admin can mark it reviewed or correct it. | OCR never overwrites a reviewed MRP. Provenance is stored (`mrp_source`, `mrp_status`). |
| Legal wording | Neutral: "দেওয়া দাম নিবন্ধিত MRP-এর চেয়ে বেশি" | See below. |

**Legal source check (2026-10-29).**
- The Consumer Rights Protection Act 2009 (ভোক্তা-অধিকার সংরক্ষণ আইন, ২০০৯), s.40, makes it an offence to sell goods "at a price higher than the price fixed under any Act or rules" (up to 1 year's imprisonment, a fine of up to Tk 50,000, or both). This is as summarised by *The Daily Star*, "Your Advocate", <https://www.thedailystar.net/law-our-rights/your-advocate/news/your-advocate-1635091>.
- It was **not** verified that a manufacturer-printed MRP counts as a price "fixed under any Act or rules", and the official text on bdlaws.minlaw.gov.bd was not checked.
- The app therefore states the fact and not a legal verdict. The product owner should obtain a legal review before adding legal wording.
- The v4 assistant text "selling expired products is a punishable offence" was removed for the same reason.

## Expiry
| Decision | Value |
|---|---|
| Date type | Date only, `YYYY-MM-DD`. A printed month-only expiry is stored as the month's last day; a month-only manufacturing date as the first day. |
| "Today" | Calendar date in **Asia/Dhaka** (UTC+6). |
| Sellable on the expiry day? | **Yes**, through the end of that day; it is expired from the next day. |
| Days remaining | `expiry − today`: 0 on the expiry day, never computed for a missing or invalid date. |
| Display window | `EXPIRY_DISPLAY_DAYS=60`: buyers see "মেয়াদ শেষ হতে X দিন বাকি". |
| Missing or invalid expiry | **Not sellable**, shown as "মেয়াদ যাচাই করা যায়নি". |
| Enforcement | At request time: marketplace query, add to cart, cart view, checkout (inside the order transaction), publish, listing update. **No scheduler** is needed or claimed. `products.status` is not changed automatically. |
| Seller alerts | The existing assistant alerts: `EXPIRING_SOON` (30 days), `EXPIRY_RISK`, `EXPIRED_LISTED`. One per product per Dhaka day, with no buyer data. |

## Buyer label check
| Decision | Value |
|---|---|
| OCR | The project's own OCR (microservice: Tesseract `ben+eng`, plus PaddleOCR for English; or the local fallback). **No AI or third-party service** sees buyer photos. |
| Fields compared | product name (English or Bangla), manufacturer, batch, MFG, EXP, MRP |
| Name rule | Similarity ≥ 0.6 → MATCH; 0.3–0.6 → UNCERTAIN; below → MISMATCH. Similarity is the larger of the token Dice score and the containment length ratio. |
| Batch rule | Exact match on alphanumerics → MATCH. Equal after O/0, I/1, S/5, B/8, Z/2, G/6 folding, or the registered batch is contained in the reading → UNCERTAIN. |
| Date rule | Equal → MATCH. Same month where one side is a month-only default → MATCH. A day/month swap would match → **UNCERTAIN** (never MISMATCH). Same month, other day → UNCERTAIN. |
| Confidence | A field confidence below `BUYER_CHECK_MIN_CONFIDENCE=60` turns MISMATCH into UNCERTAIN. The threshold is **provisional**: no real-photo evaluation exists yet. |
| Overall result | Fewer than 2 fields read → INSUFFICIENT_IMAGE. Any mismatch → MISMATCH_REVIEW. Batch not confirmed → BATCH_UNRESOLVED. ≥3 matches and nothing uncertain → MATCH. Otherwise UNCERTAIN. |
| Wording | Never "fake/counterfeit". A mismatch says it may be an OCR error, a registered-data error or a real difference, and offers retake or review. |
| Retention | Photos are not stored. `label_checks` keeps the result per field and the short compared values only (≤80 characters each). |
| Rate limit | 5 checks per minute per user or network group (in-memory, per server process). |

## QR clone-risk alerts
| Decision | Value |
|---|---|
| Rule | The **same** rule as the buyer-facing scan warning (`evaluateScanPattern`): within `SCAN_WARNING_WINDOW_MINUTES`, VALID+SUSPICIOUS scans ≥ `SCAN_WARNING_THRESHOLD_UNIT` (or `_BATCH`), and distinct network groups ≥ `SCAN_DISTINCT_SOURCE_THRESHOLD`. Defaults: 3 / 100 / 24 h / 1. |
| Data | Stored `scan_events` only. Network group = a keyed hash of an IPv4 /24 or IPv6 /48 prefix (from v2). Only the **count** is shown. |
| Frequency | One alert per code per Dhaka day. Evaluated after a suspicious scan, and when the seller opens My Products or the Assistant. |
| Actions | None automatic: no revocation, no recall, no seller suspension. The alert suggests inspecting packs and revoking the code manually if a problem is confirmed. |
| Calibration | Thresholds are **provisional**. No labelled scan dataset exists, so false-positive and false-negative rates are unknown. |

## Recall
| Decision | Value |
|---|---|
| Scope | One listing = one batch. |
| Who | The seller of the listing, or an admin. **A seller recall takes effect immediately** (stopping sales fast is the safer default). Only an admin can close a recall. *Owner decision still open:* whether seller recalls should first need admin approval. |
| States | `ACTIVE` → `CLOSED`, at most one active recall per listing. |
| Effect | Unsellable everywhere at once. Orders are never changed or deleted. The scan page and product page show the recall. Pending, unpaid or shipped orders are **not** changed automatically (owner decision open). |
| Affected buyers | Non-cancelled orders with an order item for the listing and batch. The batch comes from the order-item snapshot (new in v5), or from the listing batch for older orders; the batch number of a published listing is locked by a trigger. Deduplicated per buyer. **Simulated `SIM-` orders are excluded** (`RECALL_INCLUDE_SIMULATED_ORDERS=false`). |
| Delivery | In-app notice, written in the same transaction as the recall, unique per buyer and recall. **No email, SMS or push provider exists**, so none is claimed. |
| Privacy | Sellers and admins see only the number of buyers notified. |
| Blockchain | The recall is **off-chain**. The on-chain fingerprint does not change and does not show recall status. |
