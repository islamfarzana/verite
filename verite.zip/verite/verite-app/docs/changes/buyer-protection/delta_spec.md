# Buyer protection (v5): delta specification

Written before implementation and based on `audit.md`. The user's request ("implement this on the last existing version", plus making items persist) is the authorisation to implement.

## 0. Persistence (user request)
- **Cart in the database.** New table `cart_items (buyer_id, product_id, quantity, added_at)`, primary key `(buyer_id, product_id)`, served by `/api/cart`.
  - The product page, cart page and checkout use it.
  - An existing `localStorage` cart is merged into the server cart once, then cleared.
  - Checkout empties the server cart in the same transaction as the order.
- **Seller "My products" page** (`/seller/products`, `GET /api/seller/products`). It lists every listing of the seller with:
  - its state: draft, on sale, hidden (expired / recalled / out of stock), or above MRP;
  - publish, change price/stock, and recall actions.
- **Uploads** go to `data/uploads` (next to the database, so one folder holds all data) and are served by `GET /api/files/[name]`. Old `/uploads/...` URLs keep working from `public/`.
- `npm run db:status` prints the database path and row counts, so the user can confirm that data is stored.
- The database file location is unchanged (`data/verite.db`, or `DATABASE_FILE`).

## 1. Schema changes (additive; `lib/protection/schema.ts`, applied from `lib/db.ts`)

| Change | Type |
|---|---|
| `products.mrp_paisa INTEGER NULL` | ADD COLUMN |
| `products.mrp_source TEXT NULL`: `LABEL_CONFIRMED_BY_SELLER` / `SELLER_ENTERED` / `SEED_DEMO` | ADD COLUMN |
| `products.mrp_status TEXT NULL`: `UNREVIEWED` / `ADMIN_REVIEWED` | ADD COLUMN |
| `order_items.batch_number TEXT NULL`, `order_items.expiry_date TEXT NULL` (snapshot at sale) | ADD COLUMN |
| Trigger `trg_products_batch_locked`: `batch_number` cannot change once a product is `PUBLISHED` | NEW |
| `cart_items` | NEW |
| `label_checks`: audit of buyer label checks, per-field statuses only, no image, no raw text | NEW |
| `batch_recalls` (+ unique active recall per product) and `protection_audit` | NEW |
| `buyer_notifications`: in-app, `UNIQUE(buyer_id, dedupe_key)` | NEW |
| `seller_notifications.kind` gains `SCAN_RISK` and `RECALL_ISSUED` | table rebuild, guarded and transactional; done only when the old CHECK is detected |

Rollback:
- Drop the new tables and the trigger.
- The added columns are nullable and unused by older code, so v4 code still runs on a v5 database.

## 2. Central sellability (`lib/protection/sellability.ts`)
The checks run in this order. The first blocking reason wins; all reasons are reported.

1. `RECALLED`: an ACTIVE recall exists for the listing's batch.
2. `EXPIRED`: the Dhaka calendar date is after `expiry_date`. The expiry day itself is still sellable.
3. `EXPIRY_UNKNOWN`: missing or invalid expiry. Blocks, as review is required.
4. `NOT_PUBLISHED`
5. `ABOVE_MRP`: integer paisa comparison.
6. `OUT_OF_STOCK`, or not enough stock for the requested quantity.

The checks run in these places:
- `GET /api/products` (hidden from the marketplace);
- add to cart;
- `GET /api/cart` (each line is re-checked and marked unavailable);
- `POST /api/orders` (inside the order transaction);
- publish (`PATCH /api/products/[id]`);
- the listing update.

The UI is never the only guard.

## 3. Feature specs

### A. Buyer label check: `POST /api/products/[id]/label-check` and `/product/[id]/check`
- **Input:** front photo (required) and back photo (optional), JPG/PNG/WEBP, ≤10 MB.
  - The server checks magic bytes, not only the MIME type.
  - Rate limit: 5 per minute per network source or user.
- **OCR:** the shared `lib/ocr/read-label.ts`, refactored out of `/api/ocr/extract` with the same behaviour. It calls the OCR microservice (`ben+eng`) or the local fallback.
  - **AI is not used** for buyer photos. Images are not sent to a third party.
  - The filename sent to the OCR service is replaced by `label.jpg`.
- **Registered record:** the listing row, plus `name_bn`, the manufacturer name from the identity snapshot and `mrp_paisa`.
- **Field results:** `MATCH`, `MISMATCH`, `UNCERTAIN`, `NOT_FOUND_ON_LABEL`, `NOT_REGISTERED`, `NOT_APPLICABLE`.
  - **Dates** compare as date-only strings.
    - Equal → `MATCH`.
    - Same year and month, where one side is a month-only default (day 1 for MFG or the last day for EXP) → `MATCH (month precision)`.
    - If the read date could be the day/month swap of the registered date (both ≤ 12) → `UNCERTAIN`, never `MISMATCH`.
    - Any other difference → `MISMATCH`.
  - **MRP** compares integer paisa.
  - **Batch** compares uppercase alphanumerics; `O`/`0` and `I`/`1` confusions give `UNCERTAIN`.
  - **Names** use token overlap after normalisation: ≥0.6 → `MATCH`, 0.3–0.6 → `UNCERTAIN`, else `MISMATCH`.
  - **OCR confidence:** a microservice field confidence below `BUYER_CHECK_MIN_CONFIDENCE` (default 60, provisional) turns a would-be `MISMATCH` into `UNCERTAIN`.
- **Overall result:**
  - `INSUFFICIENT_IMAGE`: fewer than 2 fields read.
  - `NOT_REGISTERED`: the listing is not published.
  - `MISMATCH_REVIEW`: any `MISMATCH`.
  - `BATCH_UNRESOLVED`: the batch was not read or is uncertain.
  - `MATCH`: batch matched and ≥3 fields matched, none mismatched.
  - otherwise `UNCERTAIN`.
- Every result carries a Bangla and English explanation. None claims counterfeiting.
- **Stored** in `label_checks`: product, result statuses, the observed values of the *compared fields only* (short strings), policy version and time. No photo or raw text is stored.
- The buyer can press **"Send for review"**. The admin sees these requests on the Protection page.

### B. MRP guard (`lib/protection/money.ts`, `pricing.ts`)
- Money is held as integer paisa, parsed from strings (Bangla digits allowed). No floats are used for comparisons.
- **Policy:**
  - price ≤ MRP → `ALLOWED`;
  - price > MRP → `BLOCKED_ABOVE_MRP`;
  - MRP missing → `ALLOWED_MRP_NOT_REGISTERED`, shown as such. This is configurable with `MRP_MISSING_POLICY=allow|block`, default `allow` for legacy listings.
  - New listings **require** an MRP.
- The comparison is per listing, which is one pack size. Delivery and VAT are separate lines and not compared.
- The seller sets MRP at creation. After publish, MRP is **locked**; price and stock stay editable through `PATCH /api/products/[id]/listing`, which re-runs the guard.
- Only an admin can mark an MRP `ADMIN_REVIEWED` (`POST /api/admin/products/[id]/mrp-review`). Zod schemas reject `mrp_status`, `mrp_source` and other server fields.
- **Legal wording:** the CRPA 2009 s.40 covers prices "fixed under any Act or rules". Whether a printed MRP is such a price was **not** verified. The UI therefore uses neutral wording: "দাম নিবন্ধিত MRP-এর চেয়ে বেশি".

### C. Expiry (`lib/protection/expiry.ts`)
- **Policy:**
  - date-only values;
  - "today" is the **Asia/Dhaka** calendar date;
  - sellable through the end of the expiry day;
  - `daysRemaining = expiry − today`, so it is 0 on the expiry day.
- **Buyer display:**
  - `মেয়াদ শেষ` when expired;
  - `মেয়াদ শেষ হতে X দিন বাকি` when within `EXPIRY_DISPLAY_DAYS` (60);
  - `মেয়াদ যাচাই করা যায়নি` when the date is missing or invalid.
- **Enforcement** is at request time (section 2). There is no scheduler, so `products.status` is not changed automatically; the marketplace simply hides the listing.
- **Seller alerts:** the existing assistant `EXPIRING_SOON` / `EXPIRED_LISTED` alerts, deduplicated per day, with no buyer data. The legal claim in `EXPIRED_LISTED` is replaced with neutral wording.

### D. QR clone-risk alerts (`lib/protection/scan-risk.ts`)
- Uses only stored `scan_events` with outcome `VALID` or `SUSPICIOUS`.
- Window and thresholds come from the existing `ScanConfig`, so buyer and seller see the same rule.
- An identifier is flagged when its in-window count ≥ the scope threshold and its distinct network groups ≥ the distinct threshold.
- Each flag creates a seller notification `SCAN_RISK`, deduplicated per identifier and day. It states the count, the window, the distinct network-group count and the rule, with cautious wording.
- It does not show raw IPs, hashes or buyer data, and takes no automatic revocation or recall.
- **Runs:**
  - when the seller opens the assistant or My products (throttled with the assistant run);
  - right after a scan that was evaluated `SUSPICIOUS`.

### E. Batch recall (`lib/protection/recall.ts`)
- **States:** `ACTIVE` → `CLOSED`.
  - A seller can open a recall on their **own** listing.
  - An admin can open a recall on any listing and is the only one who can close it.
  - At most one ACTIVE recall per listing.
- **Effect:** the listing is immediately unsellable at every guard. Orders are never deleted or changed. The scan result and product page show the recall.
- **Affected buyers:**
  - distinct `orders.buyer_id` over non-cancelled orders whose order item points to the listing;
  - batch = `order_items.batch_number`, or the listing batch for legacy rows. This is reliable because a listing has one batch and the batch is locked after publish.
  - **Simulated orders (`SIM-`) are excluded**, configurable with `RECALL_INCLUDE_SIMULATED_ORDERS`.
- **Delivery:** one in-app `buyer_notifications` row per buyer and recall (`UNIQUE`), written **in the same transaction** as the recall. The status is `DELIVERED_IN_APP`. No email or SMS provider exists, and none is claimed.
- The seller and admin see only the *number* of buyers notified.
- **Audit:** `protection_audit` rows for recall open and close, MRP review, listing price change and blocked publish.
- **Blockchain:** a recall is off-chain. The on-chain fingerprint is unchanged, and the UI says so.

## 4. Files

**ADDED**
- `lib/protection/*`
- `lib/ocr/read-label.ts`
- Routes:
  - `app/api/cart/route.ts`
  - `app/api/seller/products/route.ts`
  - `app/api/products/[id]/listing/route.ts`
  - `app/api/products/[id]/label-check/route.ts`
  - `app/api/label-checks/[id]/route.ts`
  - `app/api/recalls/route.ts`
  - `app/api/recalls/[id]/route.ts`
  - `app/api/buyer/notifications/route.ts`
  - `app/api/admin/protection/route.ts`
  - `app/api/admin/products/[id]/mrp-review/route.ts`
  - `app/api/files/[name]/route.ts`
- Pages:
  - `app/seller/products/page.tsx`
  - `app/product/[id]/check/page.tsx`
  - `app/buyer/notifications/page.tsx`
  - `app/admin/protection/page.tsx`
- `components/ProtectionBadges.tsx`
- `scripts/db-status.ts`
- `tests/protection/*`
- docs

**MODIFIED**
- `lib/db.ts`
- `lib/assistant/schema.ts` (new kinds) and `alerts.ts` (wording)
- `app/api/products/route.ts`, `app/api/products/[id]/route.ts`
- `app/api/orders/route.ts`, `app/api/scan/route.ts`
- `app/api/ocr/extract/route.ts` (uses the shared OCR helper)
- `lib/ocr-extract.ts` (bug fix found while implementing: the local-fallback date parser dropped the printed day, so `31/08/2027` became `2027-08-01`; it now uses the same parser as `lib/ai/normalize.ts`)
- `app/api/uploads/route.ts`, `app/api/seller/assistant/route.ts`
- Pages:
  - `app/page.tsx`
  - `app/product/[id]/page.tsx`
  - `app/buyer/cart/page.tsx`
  - `app/buyer/checkout/page.tsx`
  - `app/buyer/dashboard/page.tsx`
  - `app/seller/dashboard/page.tsx` (MRP, selling price and stock fields)
  - `app/scan/v1/[token]/page.tsx`
- `components/NavBar.tsx`
- `scripts/seed.ts` (demo MRP and a near-expiry demo product)
- `package.json`, `.env.example`, `README.md`

**PROTECTED (unchanged behaviour)**
- Hash schemas
- Registration policy
- Scan verdict rules
- OCR microservice
- `scripts/tamper.ts`

## 5. Test plan
- **Unit tests (`tests/protection`):**
  - money parsing;
  - pricing decisions;
  - expiry boundaries (today, 1 day, the threshold, leap day, Dhaka midnight);
  - sellability precedence;
  - label comparison: every status, date ambiguity, Bangla digits, low confidence;
  - scan-risk window and threshold, the privacy of the output, cross-seller isolation;
  - recall authorisation, targeting, the simulated-order exclusion, idempotency, order history kept;
  - cart rules;
  - schema migration on a v4-shaped database, including the notification-kind rebuild that keeps rows.
- **Route smoke tests:**
  - persistence (cart survives a "restart", i.e. a fresh module load on the same file; seller drafts listed);
  - MRP bypass attempts via a direct API call;
  - expired and recalled listings blocked at checkout;
  - buyer label check with the real OCR pipeline on a synthetic label;
  - recall notification visible to the buyer.
- **Regression:** the existing 133 tests.

## 6. Owner decisions still open (documented in POLICY_DECISIONS.md)
- Whether to block legacy listings without an MRP.
- Seller-initiated recall without admin approval. Currently allowed, because stopping sales fast is the safer default.
- The legal wording for MRP and expiry, pending legal review.
- Real thresholds for scan risk, after collecting real scans.
