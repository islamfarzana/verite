# Test report (v5: buyer protection + persistence)

**Date:** 2026-10-29.

**Environment:** build sandbox (Linux, Node 22.23, Python 3, OpenCV 5.0, Tesseract 5). Tesseract has `eng`, `osd` and the official `ben` model (tessdata_fast). Noto Sans Bengali is used for the synthetic labels.

**What was not contacted:**
- **real notifications:** none sent; the only channel is the in-app table;
- **real Gemini, licence registry or blockchain:** none.

**Test data:**
- All orders, scans and labels in the tests are **synthetic fixtures** created by the tests.
- No production data exists or was touched.

The package registries are blocked here, so `next`, `better-sqlite3`, `jose`, FastAPI and similar packages cannot be installed. Narrow stand-ins are listed at the end.

## Results

| # | What | Command | Result |
|---|---|---|---|
| 0 | Baseline before any change (v4 suites) | `NODE_PATH=tests/shims tsx --test tests/{trace,identity,ai,assistant}/*.test.ts` | **133/133 pass** (`evidence/baseline-before-changes.log`) |
| 1 | New buyer-protection unit tests | `NODE_PATH=tests/shims tsx --test tests/protection/*.test.ts` | **24/24 pass** (`evidence/protection-tests.log`) |
| 2 | Regression: all v2–v4 suites after the changes | same as row 0 | **133/133 pass** (`evidence/regression-tests.log`) |
| 3 | Route-level smoke: real route handlers, real SQL on a database **file**, real OCR pipeline over HTTP for the label check | `NODE_PATH=docs/changes/buyer-protection/evidence/shims:tests/shims:<zod> tsx docs/changes/buyer-protection/evidence/v5-route-smoke.ts` | **15/15 steps pass** (`evidence/v5-route-smoke.log`) |
| 4 | Upgrade of a database created by **v4 code** (v4 seed + simulated sales + v4 alerts), then v5 seed and `db:status` | see `evidence/v4-to-v5-upgrade.log` | Rows kept (2 v4 alerts survive the notification-table rebuild); MRP columns added; demo MRPs set; 127 simulated orders untouched |
| 5 | OCR service regression | `pytest tests` (without the two FastAPI-only files) | **40 pass** (`evidence/ocr-service-pytest.log`) |
| 6 | Type-check of all app, lib, script and test TypeScript | `tsc --strict` with stub types for uninstallable packages | **0 errors** other than 42 × TS7006 "implicit any" on event-handler parameters in `.tsx` pages. These exist because React/JSX types are stubbed (`@types/react` is unavailable here). The same pattern is in the unchanged v4 pages. (`evidence/typecheck-raw.log`) |

### What the unit tests cover (tests/protection)
- **Money / MRP:**
  - paisa parsing, including Bangla digits, "৳", "টাকা" and "/-";
  - float noise and more than 2 decimals rejected;
  - below / equal / above MRP;
  - missing MRP under both policies;
  - neutral wording.
- **Expiry:**
  - Dhaka midnight boundary (17:59Z vs 18:00Z);
  - the expiry day is sellable;
  - 1 day, exactly the 60-day threshold, and 61 days;
  - leap day;
  - invalid dates such as 2027-02-29 and 31/08/2027 give UNKNOWN with no countdown.
- **Sellability:**
  - precedence recall > expiry > unpublished > MRP > stock, with all reasons reported;
  - the marketplace SQL filter, with both MRP policies and an injection attempt on the date.
- **Cart:**
  - per buyer;
  - adding to an existing line;
  - stock limit; expired, unknown or invalid products;
  - a recalled line stays visible but is unavailable and excluded from the subtotal;
  - lowering the quantity is always allowed;
  - remove and clear;
  - import of an old browser cart (unsellable items skipped).
- **Label check:**
  - all fields match in English;
  - a Bangla label (Bangla digits, Bangla month, "টাকা");
  - each field mismatching;
  - DD/MM ↔ MM/DD ambiguity gives UNCERTAIN;
  - month-only labels;
  - O/0 and I/1 batch confusion gives UNCERTAIN, and a missing batch gives BATCH_UNRESOLVED;
  - low confidence gives UNCERTAIN;
  - MRP formats are equivalent;
  - not registered, not applicable, insufficient image;
  - wording never contains fake / counterfeit / নকল / জাল as a verdict.
- **Scan risk:**
  - below / at threshold;
  - events outside the window;
  - UNKNOWN outcomes ignored;
  - many scans from one network not flagged;
  - batch threshold;
  - cross-seller isolation;
  - degraded network signal;
  - wording, counts and no hashes or IPs in the alert;
  - one alert per day.
- **Recall:**
  - buyer forbidden; another seller gets 404; drafts cannot be recalled; only an admin closes;
  - targeting by batch;
  - legacy order items;
  - cancelled and simulated orders excluded;
  - repeat orders give one notice;
  - idempotent repeat and resend;
  - order history kept;
  - other batches stay sellable;
  - the seller gets a count only;
  - audit trail;
  - the batch-number lock after publish, while `scripts/tamper.ts` (expiry edit) still works.
- **Migration:**
  - a v4-shaped `seller_notifications` (old CHECK) is rebuilt with its rows kept;
  - columns are added;
  - running twice is a no-op;
  - the `mrp_paisa > 0` CHECK holds.

### What the route smoke test shows (evidence/v5-route-smoke.log)
1. A seller's product is saved, appears in **My Products** as a draft, and is visible to **a separate process** reading the same database file (`npm run db:status`, the "close and reopen" check).
2. After approval it is published and buyers see it.
3. MRP guard:
   - creating above MRP is refused (Bangla message);
   - creating without MRP is refused;
   - a price change above MRP is refused and audited;
   - mass assignment of `mrp_paisa` / `mrp_status` is refused;
   - another seller gets 404;
   - an admin MRP correction hides the listing until the price is lowered.
4. Cart: saved per buyer; a seller gets 403 and an anonymous user 401; visible to a separate process.
5. Expired batch:
   - hidden;
   - refused on add-to-cart;
   - refused by a **direct order API call** (409, Bangla reason);
   - cannot be listed.
6. Checkout: buyer only; the order item stores batch `LOT-241A` and expiry `2027-01-14`; bought items leave the cart.
7. **Label check with the real OCR pipeline:**
   - On the matching synthetic Bangla+English pack, all six fields are MATCH.
   - On a pack with another batch, expiry and MRP, the result is MISMATCH_REVIEW with no fraud wording. The batch was misread as `10-77/2`, the known batch-number weakness.
   - Review request: only the checker can send it, and the admin sees it.
   - A fake JPEG is refused.
8. QR clone-risk: four scans from four networks give **one** seller alert. It was raised at the 3rd scan (threshold 3), contains no IPs, and the code was **not** revoked.
9. Recall:
   - another seller gets 404 and a buyer 403;
   - one buyer is notified in-app (the buyer without an order is not);
   - repeating it is idempotent;
   - sales stop in the marketplace, cart, checkout, product page and scan page;
   - the order history is kept.
10. Only an admin closes a recall, a resend adds no duplicates, and the listing is sellable again.
11. Uploads are stored next to the database and served by `/api/files`. A path-traversal name gives 404, and a PHP file renamed `.png` gives 422.

## Stand-ins used only for testing
- `tests/shims/ethers`: the Keccak-256 used since v3, validated against published vectors.
- `evidence/shims`:
  - `next/server`;
  - `better-sqlite3` over `node:sqlite`, with `transaction()` added for the orders route;
  - an **unsigned** `jose`;
  - `bcryptjs`;
  - throwing `sharp` / `tesseract.js`. The smoke test uses the OCR service path.
- `zod` resolved from the sandbox's tool folder: the real library, version 3.25.
- `evidence/sandbox_ocr_http_wrapper.py`: serves the real `read_photos` / `make_cover` functions over HTTP with the FastAPI response shape.
- A `pydantic_settings` stand-in for the Python side.

## Not tested here
- `next build`, and the new pages in a browser. They are type-checked only, so click through the demo script in `WORKFLOW.md` once on your machine.
- **Real phone photos** of real packs. All OCR evidence is from synthetic, rendered labels, so it shows the pipeline *works*, not how accurate it is.
- The FastAPI route itself (`test_api_v4.py`, `test_health.py` need FastAPI). PaddleOCR. The tesseract.js local fallback.
- Concurrency under a real multi-user load. SQLite serialises writes, and `BEGIN IMMEDIATE` is used for recalls.
