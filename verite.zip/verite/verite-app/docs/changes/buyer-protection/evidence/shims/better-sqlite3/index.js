// Sandbox-only stand-in: better-sqlite3 API over node:sqlite.
const { DatabaseSync } = require('node:sqlite');
class Database {
  constructor(file) { this.d = new DatabaseSync(file); }
  prepare(sql) { return this.d.prepare(sql); }
  exec(sql) { this.d.exec(sql); return this; }
  pragma(p) { this.d.exec(`PRAGMA ${p}`); }
  // better-sqlite3's db.transaction(fn): BEGIN/COMMIT around fn, ROLLBACK on throw.
  transaction(fn) {
    return (...args) => {
      this.d.exec('BEGIN');
      try { const out = fn(...args); this.d.exec('COMMIT'); return out; } catch (e) { try { this.d.exec('ROLLBACK'); } catch {} throw e; }
    };
  }
}
module.exports = Database; module.exports.default = Database;
