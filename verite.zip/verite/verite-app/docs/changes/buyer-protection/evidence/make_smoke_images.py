"""SYNTHETIC images for the v5 route smoke test (rendered labels, not real photos).
genuine_*: the pack matches the registered batch; other_back: a pack from a different batch/expiry/MRP."""
import sys
sys.path.insert(0, '/home/claude/v5/ocr-service/tests')
import cv2
from synthetic_labels import render_label, as_photo_of_packet, FRONT_LINES, BACK_LINES

out = sys.argv[1]
cv2.imwrite(f'{out}/genuine_front.jpg', render_label(FRONT_LINES))
cv2.imwrite(f'{out}/genuine_back.jpg', as_photo_of_packet(render_label(BACK_LINES)))
other = [l.replace('LOT-241A', 'LOT-777Z').replace('১৪/০১/২০২৭', '৩০/০৬/২০২৬').replace('১৫০ টাকা', '১৯০ টাকা') for l in BACK_LINES]
cv2.imwrite(f'{out}/other_back.jpg', render_label(other))
print('ok')
