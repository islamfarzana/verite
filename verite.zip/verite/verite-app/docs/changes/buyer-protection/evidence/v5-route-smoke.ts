// v5 route-level smoke test: calls the REAL Next.js route handlers with real SQL on a database FILE,
// and (for the buyer label check) the REAL OCR pipeline served over HTTP by sandbox_ocr_http_wrapper.py.
// Sandbox stand-ins (evidence/shims): next/server, better-sqlite3 over node:sqlite, unsigned jose.
// Run from verite-app/:  NODE_PATH=docs/changes/buyer-protection/evidence/shims tsx docs/changes/buyer-protection/evidence/v5-route-smoke.ts
import assert from 'node:assert/strict';
import { readFileSync, rmSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';

const A = path.resolve(__dirname, '../../../..');
const DB = '/tmp/claude-0/v5smoke.db';
const IMG = '/tmp/claude-0';
for (const f of [DB, `${DB}-wal`, `${DB}-shm`]) rmSync(f, { force: true });
rmSync('/tmp/claude-0/v5uploads', { recursive: true, force: true });
process.env.DATABASE_FILE = DB;
process.env.UPLOAD_DIR = '/tmp/claude-0/v5uploads';
process.env.OCR_SERVICE_URL = 'http://127.0.0.1:8765';
process.env.SCAN_WARNING_THRESHOLD_UNIT = '3';
process.env.SCAN_DISTINCT_SOURCE_THRESHOLD = '2';
process.env.SCAN_RATE_LIMIT_PER_MINUTE = '100';
(process.env as any).NODE_ENV = 'development';
delete process.env.GEMINI_API_KEY;

const results: string[] = [];
const step = async (name: string, fn: () => Promise<void>) => {
  try { await fn(); results.push(`PASS  ${name}`); } catch (e) { results.push(`FAIL  ${name}\n      ${(e as Error).message.split('\n').slice(0, 6).join('\n      ')}`); }
};

async function main() {
  const { NextRequest } = require('next/server');
  const db = (await import(`${A}/lib/db`)).default;
  const { signToken } = await import(`${A}/lib/auth-edge`);
  const { submitBusinessProfile, decideEntity } = await import(`${A}/lib/identity/onboarding`);
  const { MockRegistryAdapter } = await import(`${A}/lib/identity/registry`);
  const { issueIdentifiers } = await import(`${A}/lib/trace/service`);
  const products = await import(`${A}/app/api/products/route`);
  const product = await import(`${A}/app/api/products/[id]/route`);
  const listing = await import(`${A}/app/api/products/[id]/listing/route`);
  const labelCheck = await import(`${A}/app/api/products/[id]/label-check/route`);
  const labelReview = await import(`${A}/app/api/label-checks/[id]/route`);
  const sellerProducts = await import(`${A}/app/api/seller/products/route`);
  const cart = await import(`${A}/app/api/cart/route`);
  const orders = await import(`${A}/app/api/orders/route`);
  const recalls = await import(`${A}/app/api/recalls/route`);
  const recallOne = await import(`${A}/app/api/recalls/[id]/route`);
  const buyerNotes = await import(`${A}/app/api/buyer/notifications/route`);
  const adminProt = await import(`${A}/app/api/admin/protection/route`);
  const mrpReview = await import(`${A}/app/api/admin/products/[id]/mrp-review/route`);
  const scan = await import(`${A}/app/api/scan/route`);
  const assistant = await import(`${A}/app/api/seller/assistant/route`);
  const uploads = await import(`${A}/app/api/uploads/route`);
  const files = await import(`${A}/app/api/files/[name]/route`);

  const users: [string, string, string][] = [['u_seller', 'SELLER', 'seller@verite.app'], ['u_seller2', 'SELLER', 's2@verite.app'], ['u_buyer', 'BUYER', 'buyer@verite.app'], ['u_buyer2', 'BUYER', 'b2@verite.app'], ['u_admin', 'ADMIN', 'admin@verite.app']];
  for (const [id, role, email] of users) db.prepare('INSERT INTO users (id,name,email,password_hash,role) VALUES (?,?,?,?,?)').run(id, id, email, 'x', role);
  const tok: Record<string, string> = {};
  for (const [id, role, email] of users) tok[id] = await signToken({ id, email, role: role as any });
  const H = (who?: string, extra: Record<string, string> = {}) => ({ ...(who ? { cookie: `verite_session=${tok[who]}` } : {}), ...extra });
  const req = (url: string, who?: string, body?: unknown, method = 'POST', extra: Record<string, string> = {}) =>
    new NextRequest(`http://localhost:3000${url}`, { method, headers: H(who, { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...extra }), body: body === undefined ? undefined : JSON.stringify(body) });
  const form = (url: string, who: string | undefined, f: Record<string, [string, string]>) => {
    const fd = new FormData();
    for (const [k, [p, type]] of Object.entries(f)) fd.append(k, new File([readFileSync(p)], path.basename(p), { type }));
    return new NextRequest(`http://localhost:3000${url}`, { method: 'POST', headers: H(who), body: fd });
  };
  const call = async (r: Promise<Response> | Response) => { const res = await r; const ct = res.headers.get('content-type') || ''; return { status: res.status, res, json: ct.includes('json') ? (await res.json()) as any : null }; };
  const P = (id: string) => ({ params: { id } });
  const dbStatus = () => execFileSync('tsx', [`${A}/scripts/db-status.ts`], { cwd: A, env: { ...process.env }, encoding: 'utf8' });

  const base = {
    name: 'Chashi Chinigura Rice 1kg', brand: 'Chashi', batchNumber: 'LOT-241A', manufacturingDate: '2026-01-15', expiryDate: '2027-01-14',
    stock: 20, images: [], productNameBn: 'চাষী চিনিগুড়া চাল', manufacturer: { mode: 'CLAIM', name: 'প্রাণ এগ্রো লিমিটেড' },
  };

  /* ------------------------- persistence ------------------------- */
  let pid = '';
  await step('seller creates a product with MRP; it is saved in the database file and listed in "My products" as a draft', async () => {
    const r = await call(products.POST(req('/api/products', 'u_seller', { ...base, barcode: '8901234500001', mrp: '১৫০ টাকা', price: '145' })));
    assert.equal(r.status, 201, JSON.stringify(r.json));
    pid = r.json.data.id;
    const row = db.prepare('SELECT price, mrp_paisa, mrp_source, status FROM products WHERE id = ?').get(pid) as any;
    assert.deepEqual({ ...row }, { price: 145, mrp_paisa: 15000, mrp_source: 'SELLER_ENTERED', status: 'DRAFT' });
    const pub = await call(product.PATCH(req('', 'u_seller', undefined, 'PATCH'), P(pid)));
    assert.equal(pub.status, 409, 'seller not approved yet -> stays a draft');
    const mine = await call(sellerProducts.GET(req('/api/seller/products', 'u_seller', undefined, 'GET')));
    assert.equal(mine.json.data.length, 1);
    assert.equal(mine.json.data[0].status, 'DRAFT');
    assert.equal((await call(sellerProducts.GET(req('/api/seller/products', 'u_seller2', undefined, 'GET')))).json.data.length, 0, 'other sellers do not see it');
  });

  await step('"close and reopen": a separate process reading the same database file sees the saved product', async () => {
    const out = dbStatus();
    assert.match(out, /Products\s+: 1 \(published 0, drafts 1\)/);
    assert.match(out, /DRAFT\s+Chashi Chinigura Rice 1kg/);
    assert.match(out, new RegExp(`Database file : ${DB.replace(/\//g, '\\/')}`));
  });

  const ent = await submitBusinessProfile(db, { id: 'u_seller', role: 'SELLER' }, {
    legalName: 'GreenMart BD Ltd', displayName: 'GreenMart BD', entityType: 'ORGANIZATION', roles: ['SELLER'],
    licence: { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2026-0001', issuingAuthority: 'Demo City Corporation (fictitious)', claimSource: 'MANUAL_ENTRY' },
  }, { adapter: new MockRegistryAdapter(db) });
  decideEntity(db, { id: 'u_admin', role: 'ADMIN' }, ent.entity.id, { action: 'APPROVE' });

  await step('after approval the draft is published from "My products" and buyers see it in the marketplace', async () => {
    const pub = await call(product.PATCH(req('', 'u_seller', undefined, 'PATCH'), P(pid)));
    assert.equal(pub.status, 200, JSON.stringify(pub.json));
    const m = await call(products.GET(req('/api/products', undefined, undefined, 'GET')));
    assert.deepEqual(m.json.data.map((p: any) => p.id), [pid]);
    assert.match(dbStatus(), /Products\s+: 1 \(published 1, drafts 0\)/);
  });

  /* ------------------------- MRP guard ------------------------- */
  await step('MRP guard: create above MRP refused; price change above MRP refused; MRP/status fields cannot be mass-assigned', async () => {
    const above = await call(products.POST(req('/api/products', 'u_seller', { ...base, barcode: '8901234500002', mrp: '150', price: '150.01' })));
    assert.equal(above.status, 422);
    assert.equal(above.json.code, 'BLOCKED_ABOVE_MRP');
    assert.match(above.json.messageBn, /দেওয়া দাম \(৳১৫০\.০১\) নিবন্ধিত MRP \(৳১৫০\)-এর চেয়ে বেশি/);
    const noMrp = await call(products.POST(req('/api/products', 'u_seller', { ...base, barcode: '8901234500003', price: 150 })));
    assert.equal(noMrp.status, 422, 'new listings need an MRP');
    const up = await call(listing.PATCH(req('', 'u_seller', { price: 151 }, 'PATCH'), P(pid)));
    assert.equal(up.status, 409);
    assert.equal(up.json.blockers[0].code, 'ABOVE_MRP');
    const mass = await call(listing.PATCH(req('', 'u_seller', { price: 140, mrp_paisa: 99999, mrp_status: 'ADMIN_REVIEWED' }, 'PATCH'), P(pid)));
    assert.equal(mass.status, 422);
    const other = await call(listing.PATCH(req('', 'u_seller2', { price: 1 }, 'PATCH'), P(pid)));
    assert.equal(other.status, 404, 'another seller cannot change it');
    const ok = await call(listing.PATCH(req('', 'u_seller', { price: '149.50', stock: 30 }, 'PATCH'), P(pid)));
    assert.equal(ok.status, 200, JSON.stringify(ok.json));
    assert.deepEqual({ ...(db.prepare('SELECT price, stock, mrp_paisa, mrp_status FROM products WHERE id = ?').get(pid) as any) }, { price: 149.5, stock: 30, mrp_paisa: 15000, mrp_status: 'UNREVIEWED' });
    const actions = (db.prepare('SELECT action FROM protection_audit WHERE product_id = ? ORDER BY created_at, rowid').all(pid) as any[]).map((a) => a.action);
    assert.deepEqual(actions, ['PRICE_BLOCKED_ABOVE_MRP', 'LISTING_UPDATED']);
  });

  await step('admin corrects the MRP below the price: the listing is hidden automatically until the seller lowers the price', async () => {
    assert.equal((await call(mrpReview.POST(req('', 'u_seller', { mrp: 100 }), P(pid)))).status, 403);
    const r = await call(mrpReview.POST(req('', 'u_admin', { mrp: '140' }), P(pid)));
    assert.equal(r.status, 200);
    let m = await call(products.GET(req('/api/products', undefined, undefined, 'GET')));
    assert.equal(m.json.data.length, 0);
    await call(listing.PATCH(req('', 'u_seller', { price: 140 }, 'PATCH'), P(pid)));
    m = await call(products.GET(req('/api/products', undefined, undefined, 'GET')));
    assert.equal(m.json.data.length, 1);
    await call(mrpReview.POST(req('', 'u_admin', { mrp: '150' }), P(pid))); // back to the pack's real MRP for the label check below
  });

  /* ------------------------- cart ------------------------- */
  await step('cart is saved in the database per buyer; sellers and anonymous users cannot use it', async () => {
    assert.equal((await call(cart.POST(req('/api/cart', undefined, { productId: pid })))).status, 401);
    assert.equal((await call(cart.POST(req('/api/cart', 'u_seller', { productId: pid })))).status, 403);
    const a = await call(cart.POST(req('/api/cart', 'u_buyer', { productId: pid, quantity: 2 })));
    assert.equal(a.status, 201, JSON.stringify(a.json));
    const g = await call(cart.GET(req('/api/cart', 'u_buyer', undefined, 'GET')));
    assert.deepEqual(g.json.data.lines.map((l: any) => [l.productId, l.quantity, l.available]), [[pid, 2, true]]);
    assert.equal((await call(cart.GET(req('/api/cart', 'u_buyer2', undefined, 'GET')))).json.data.lines.length, 0);
    assert.match(dbStatus(), /Cart lines\s+: 1 \(buyers with a saved cart: 1\)/);
  });

  /* ------------------------- expiry ------------------------- */
  db.prepare(`INSERT INTO products (id, seller_id, name, barcode, batch_number, manufacturing_date, expiry_date, price, stock, status, mrp_paisa)
              VALUES ('old', 'u_seller', 'Instant Noodles Pack', '8909998887776', 'LOT-118B', '2026-04-01', '2026-10-01', 250, 6, 'PUBLISHED', 25000)`).run();
  await step('expired batch: hidden from marketplace, cannot be added to cart, cannot be ordered by direct API call, cannot be listed', async () => {
    const m = await call(products.GET(req('/api/products', undefined, undefined, 'GET')));
    assert.ok(!m.json.data.some((p: any) => p.id === 'old'));
    const c = await call(cart.POST(req('/api/cart', 'u_buyer', { productId: 'old' })));
    assert.equal(c.status, 409);
    assert.equal(c.json.blockers[0].code, 'EXPIRED');
    const o = await call(orders.POST(req('/api/orders', 'u_buyer', { items: [{ productId: 'old', quantity: 1 }], shippingAddress: { name: 'Test', phone: '01700000000', addressLine: 'House 1, Road 2' } })));
    assert.equal(o.status, 409);
    assert.match(o.json.messageBn, /মেয়াদ শেষ/);
    const g = await call(product.GET(req('', undefined, undefined, 'GET'), P('old')));
    assert.equal(g.json.data.protection.expiry.textBn, 'মেয়াদ শেষ');
    const create = await call(products.POST(req('/api/products', 'u_seller', { ...base, barcode: '8901234500009', mrp: 10, manufacturingDate: '2025-01-01', expiryDate: '2026-01-01' })));
    assert.equal(create.status, 422);
    assert.equal(create.json.code, 'EXPIRED');
  });

  /* ------------------------- checkout ------------------------- */
  await step('checkout: only buyers; order item stores the batch sold; bought items leave the saved cart', async () => {
    const body = { items: [{ productId: pid, quantity: 2 }], shippingAddress: { name: 'Test', phone: '01700000000', addressLine: 'House 1, Road 2' } };
    assert.equal((await call(orders.POST(req('/api/orders', 'u_seller', body)))).status, 403);
    const o = await call(orders.POST(req('/api/orders', 'u_buyer', body)));
    assert.equal(o.status, 200, JSON.stringify(o.json));
    const it = db.prepare('SELECT batch_number, expiry_date FROM order_items WHERE product_id = ?').get(pid) as any;
    assert.deepEqual({ ...it }, { batch_number: 'LOT-241A', expiry_date: '2027-01-14' });
    assert.equal((await call(cart.GET(req('/api/cart', 'u_buyer', undefined, 'GET')))).json.data.lines.length, 0);
  });

  /* ------------------------- buyer label check (real OCR) ------------------------- */
  let checkId = '';
  await step('label check, matching pack (real Bangla+English OCR): every compared field MATCH, nothing of the photo stored', async () => {
    const r = await call(labelCheck.POST(form(`/api/products/${pid}/label-check`, 'u_buyer', { front: [`${IMG}/genuine_front.jpg`, 'image/jpeg'], back: [`${IMG}/genuine_back.jpg`, 'image/jpeg'] }), P(pid)));
    assert.equal(r.status, 200, JSON.stringify(r.json));
    const by = Object.fromEntries(r.json.data.fields.map((f: any) => [f.field, f.result]));
    assert.deepEqual(by, { productName: 'MATCH', manufacturer: 'MATCH', batchNumber: 'MATCH', manufacturingDate: 'MATCH', expiryDate: 'MATCH', mrp: 'MATCH' }, JSON.stringify(r.json.data.fields));
    assert.equal(r.json.data.overall, 'MATCH');
    assert.equal(r.json.data.ocr.source, 'microservice');
    const row = db.prepare('SELECT * FROM label_checks WHERE id = ?').get(r.json.data.checkId) as any;
    assert.ok(!/চিনিগুড়া চাল\n|DEMO-CM-0002|লাইসেন্স/.test(row.fields_json), 'no raw OCR text stored, only compared values');
  });

  await step('label check, a different pack: MISMATCH_REVIEW with Bangla explanation, never "fake"; buyer sends it for review; admin sees it', async () => {
    const r = await call(labelCheck.POST(form(`/api/products/${pid}/label-check`, 'u_buyer', { front: [`${IMG}/genuine_front.jpg`, 'image/jpeg'], back: [`${IMG}/other_back.jpg`, 'image/jpeg'] }), P(pid)));
    assert.equal(r.status, 200);
    const by = Object.fromEntries(r.json.data.fields.map((f: any) => [f.field, f.result]));
    assert.equal(by.expiryDate, 'MISMATCH');
    assert.equal(by.mrp, 'MISMATCH');
    assert.notEqual(by.batchNumber, 'MATCH');
    assert.equal(r.json.data.overall, 'MISMATCH_REVIEW');
    assert.match(r.json.data.messageBn, /আরও যাচাই প্রয়োজন/);
    const verdicts = [r.json.data.messageEn, r.json.data.messageBn, ...r.json.data.fields.flatMap((f: any) => [f.reasonEn, f.reasonBn])].join(' ');
    assert.doesNotMatch(verdicts, /fake|counterfeit|নকল|জাল/i, 'no fraud verdict, only "does not match / needs checking"');
    checkId = r.json.data.checkId;
    assert.equal((await call(labelReview.POST(req('', 'u_buyer2', { action: 'REQUEST_REVIEW' }), P(checkId)))).status, 404, 'only the person who ran the check');
    assert.equal((await call(labelReview.POST(req('', 'u_buyer', { action: 'REQUEST_REVIEW' }), P(checkId)))).status, 200);
    const a = await call(adminProt.GET(req('/api/admin/protection', 'u_admin', undefined, 'GET')));
    assert.equal(a.json.data.reviews[0].id, checkId);
    assert.equal((await call(adminProt.GET(req('/api/admin/protection', 'u_seller', undefined, 'GET')))).status, 403);
  });

  await step('label check input validation: a non-image file with an image MIME type is refused', async () => {
    const fd = new FormData();
    fd.append('front', new File([Buffer.from('not really a jpeg')], 'x.jpg', { type: 'image/jpeg' }));
    const r = await call(labelCheck.POST(new NextRequest(`http://localhost:3000/api/products/${pid}/label-check`, { method: 'POST', headers: H('u_buyer2'), body: fd }), P(pid)));
    assert.equal(r.status, 422);
  });

  /* ------------------------- QR clone-risk ------------------------- */
  await step('QR clone-risk: real scans from several networks raise ONE cautious seller alert (at the threshold), with counts and no network data', async () => {
    const issued = issueIdentifiers(db, { productId: pid, scope: 'UNIT', quantity: 1, requestId: 'smoke-req-0001', actor: { id: 'u_seller', role: 'SELLER' } });
    const token = issued.identifiers[0].token;
    let last: any;
    for (const ip of ['10.0.1.5', '10.0.2.5', '10.0.3.5', '10.0.4.5']) {
      last = await call(scan.POST(new NextRequest('http://localhost:3000/api/scan', { method: 'POST', headers: { 'content-type': 'application/json', 'x-forwarded-for': ip }, body: JSON.stringify({ token }) })));
    }
    assert.equal(last.json.data.status, 'SUSPICIOUS_ACTIVITY');
    const n = db.prepare("SELECT * FROM seller_notifications WHERE kind = 'SCAN_RISK'").all() as any[];
    assert.equal(n.length, 1);
    assert.match(n[0].body_bn, /গত ১ দিনে এই ইউনিট কোড #১টি ৩টি নেটওয়ার্ক গ্রুপ থেকে ৩ বার স্ক্যান হয়েছে/, 'raised at the 3rd scan; the 4th scan the same day does not add a second alert');
    assert.doesNotMatch(n[0].body_en + n[0].data_json, /10\.0\./);
    const as = await call(assistant.GET(req('/api/seller/assistant', 'u_seller', undefined, 'GET')));
    assert.ok(as.json.data.notifications.some((x: any) => x.kind === 'SCAN_RISK'));
    assert.equal(db.prepare("SELECT status FROM trace_identifiers WHERE token = ?").get(token).status, 'ACTIVE', 'never revoked automatically');
  });

  /* ------------------------- recall ------------------------- */
  let recallId = '';
  await step('recall: other seller refused; owner recalls; buyer of that batch notified in-app; sales stop everywhere', async () => {
    assert.equal((await call(recalls.POST(req('/api/recalls', 'u_seller2', { productId: pid, reasonCode: 'QUALITY_ISSUE' })))).status, 404);
    assert.equal((await call(recalls.POST(req('/api/recalls', 'u_buyer', { productId: pid, reasonCode: 'QUALITY_ISSUE' })))).status, 403);
    const r = await call(recalls.POST(req('/api/recalls', 'u_seller', { productId: pid, reasonCode: 'QUALITY_ISSUE', publicMessage: 'Do not use; contact us for a refund.' })));
    assert.equal(r.status, 201, JSON.stringify(r.json));
    assert.equal(r.json.data.buyersNotified, 1);
    assert.equal(r.json.data.onChain, false);
    recallId = r.json.data.id;
    const again = await call(recalls.POST(req('/api/recalls', 'u_seller', { productId: pid, reasonCode: 'QUALITY_ISSUE' })));
    assert.equal(again.json.data.alreadyActive, true);
    const n = await call(buyerNotes.GET(req('', 'u_buyer', undefined, 'GET')));
    assert.equal(n.json.data.unread, 1);
    assert.match(n.json.data.notifications[0].bodyBn, /ব্যাচ LOT-241A প্রত্যাহার করা হয়েছে/);
    assert.equal((await call(buyerNotes.GET(req('', 'u_buyer2', undefined, 'GET')))).json.data.notifications.length, 0);
    assert.equal((await call(products.GET(req('/api/products', undefined, undefined, 'GET')))).json.data.length, 0);
    assert.equal((await call(cart.POST(req('/api/cart', 'u_buyer2', { productId: pid })))).json.blockers[0].code, 'RECALLED');
    const o = await call(orders.POST(req('/api/orders', 'u_buyer2', { items: [{ productId: pid, quantity: 1 }], shippingAddress: { name: 'Test', phone: '01700000000', addressLine: 'House 1' } })));
    assert.equal(o.status, 409);
    const g = await call(product.GET(req('', undefined, undefined, 'GET'), P(pid)));
    assert.equal(g.json.data.protection.recall.status, 'ACTIVE');
    const token = (db.prepare('SELECT token FROM trace_identifiers WHERE product_id = ?').get(pid) as any).token;
    const s = await call(scan.POST(new NextRequest('http://localhost:3000/api/scan', { method: 'POST', headers: { 'content-type': 'application/json', 'x-forwarded-for': '10.9.9.9' }, body: JSON.stringify({ token }) })));
    assert.equal(s.json.data.batchStatus.recalled, true);
    assert.equal(db.prepare('SELECT COUNT(*) AS c FROM orders').get().c, 1, 'order history kept');
  });

  await step('only an admin closes a recall; afterwards the listing is sellable again', async () => {
    assert.equal((await call(recallOne.POST(req('', 'u_seller', { action: 'CLOSE' }), P(recallId)))).status, 403);
    assert.equal((await call(recallOne.POST(req('', 'u_admin', { action: 'RESEND' }), P(recallId)))).json.data.added, 0, 'no duplicate notices');
    assert.equal((await call(recallOne.POST(req('', 'u_admin', { action: 'CLOSE', note: 'resolved' }), P(recallId)))).status, 200);
    assert.equal((await call(products.GET(req('/api/products', undefined, undefined, 'GET')))).json.data.length, 1);
  });

  /* ------------------------- uploads ------------------------- */
  await step('uploaded images are stored next to the database and served by /api/files (works in `next start` too)', async () => {
    const up = await call(uploads.POST(form('/api/uploads', 'u_seller', { file: [`${IMG}/genuine_front.jpg`, 'image/jpeg'] })));
    assert.equal(up.status, 201, JSON.stringify(up.json));
    const url: string = up.json.data.url;
    assert.match(url, /^\/api\/files\/img_[0-9a-f-]{36}\.jpg$/);
    const f = await files.GET(req(url, undefined, undefined, 'GET'), { params: { name: url.split('/').pop()! } });
    assert.equal(f.status, 200);
    assert.equal(f.headers.get('content-type'), 'image/jpeg');
    assert.equal(Buffer.from(await f.arrayBuffer()).length, readFileSync(`${IMG}/genuine_front.jpg`).length);
    assert.equal((await files.GET(req('', undefined, undefined, 'GET'), { params: { name: '..%2F..%2Fverite.db' } })).status, 404);
    const fake = new FormData();
    fake.append('file', new File([Buffer.from('<?php echo 1; ?>')], 'x.png', { type: 'image/png' }));
    assert.equal((await call(uploads.POST(new NextRequest('http://localhost:3000/api/uploads', { method: 'POST', headers: H('u_seller'), body: fake })))).status, 422);
  });

  console.log(results.join('\n'));
  const failed = results.filter((r) => r.startsWith('FAIL')).length;
  console.log(`\n${results.length - failed}/${results.length} steps passed`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
