# Buyer protection (v5): security, privacy and limitations

## Security and privacy controls
- **Authorisation on the server for every change:**
  - cart: buyer only, own rows;
  - listing update: owning seller only, with a strict schema (MRP, status, batch and dates cannot be mass-assigned);
  - recall: owning seller or admin, close by admin only (another seller gets the same 404 as "not found");
  - MRP review: admin only;
  - review requests: only the account that ran the check;
  - admin overview: admin only;
  - orders: buyer accounts only.
- A sign-in cookie for an account that is no longer in the database (for example after the database file was replaced) gets a clear "sign in again" message instead of a database error.
- **State-changing JSON routes** accept `application/json` only, with a 20 kB body limit. With SameSite=Lax cookies this blocks cross-site form posts.
- **Uploads:**
  - JPG/PNG/WEBP only, ≤10 MB;
  - the **file content (magic bytes) must match** the declared type;
  - files are served from a fixed folder by generated names only (no path traversal), with `X-Content-Type-Options: nosniff`.
- **Buyer photos:**
  - processed in memory and **never stored**;
  - sent only to this project's own OCR service, with a neutral file name;
  - **never sent to Gemini or any third party**;
  - `label_checks` stores only per-field results and the short compared values;
  - the OCR microservice keeps its own log of extracted label text (product text, not personal data), as in v2–v4;
  - rate-limited.
- **Scan data:**
  - no raw IPs are stored (a keyed hash of a coarse network prefix, from v2);
  - sellers see only counts, and only for their own codes;
  - events are pruned after 90 days.
- **Notifications:**
  - buyer notices are private to the buyer;
  - sellers and admins see only the number notified;
  - recall state and notices are written in **one transaction** and are unique per buyer and recall, so retries never duplicate them.
- **Audit (`protection_audit`)** records:
  - recall open, close and resend;
  - MRP review;
  - listing price/stock change;
  - blocked price changes and blocked publishes.

  Each row stores the actor, time, before/after and policy version. It contains no photos and no buyer contact data.
- **Money** uses integer paisa, and **dates** are date-only in Asia/Dhaka. Both are validated on the server.

## Limitations (be explicit about these in the defence)
1. **OCR accuracy on real packs is unmeasured.**
   - All OCR evidence uses synthetic rendered labels.
   - The batch number is the weakest field (v4 synthetic recall 0.60, and it was misread in the v5 smoke test too). That is why batch confusions give UNCERTAIN or BATCH_UNRESOLVED rather than MISMATCH.
   - The confidence threshold of 60 is provisional.
   - Run `ocr-service/scripts/evaluate.py` on 50–100 real photos before you claim any accuracy.
2. **A label check is not an authenticity test.** A counterfeiter can copy a label exactly, so a MATCH only means "the printed details agree with the registered batch".
3. **Registered data is seller-provided.**
   - MRP, batch and dates come from the seller, read from the label and confirmed by the seller.
   - An admin can mark an MRP reviewed, but nothing is checked against an official registry. No official BSTI or DNCRP data source is connected.
4. **Legal wording** is neutral and pending legal review (see POLICY_DECISIONS.md). The app does not say that selling above MRP or after expiry is an offence.
5. **No scheduler:**
   - expiry is enforced at request time;
   - `products.status` stays `PUBLISHED` after expiry and the listing is simply hidden;
   - seller alerts appear when the seller opens My Products or the Assistant, or when `npm run assistant:check` is run by a scheduler you set up.
6. **QR clone-risk is a heuristic.**
   - The thresholds are not calibrated, and no labelled dataset exists.
   - The network signal comes from the `X-Forwarded-For` header and can be spoofed unless a trusted proxy sets it.
   - Shared batch codes are scanned often for legitimate reasons.
7. **Recall reach is in-app only.**
   - No email, SMS or push provider is configured, so a buyer sees the notice only when they open Verité.
   - Buyers who bought **outside** Verité are not reached.
   - Simulated `SIM-` orders are excluded.
   - Pending, unpaid or shipped orders are not changed automatically (owner decision).
8. **Recall and listing status are off-chain.** The blockchain fingerprint, simulated unless `CHAIN_*` is set, covers the product data and identity at registration. It does not cover price, MRP, stock or recall status.
9. **One listing = one batch.**
   - A new batch of the same product must be listed as a new product.
   - Multi-batch inventory per listing is out of scope; the batch number is locked after publish so recall targeting stays exact.
10. **In-memory rate limits** reset on restart and are per server process (as in v2–v4).
11. **SQLite** is the single database file. That is fine for a single-instance deployment and the demo. A multi-instance or serverless deployment would need Postgres (see `lib/db.ts`).

## Remaining risks (priority)

| Priority | Risk | Mitigation / next step |
|---|---|---|
| High | Buyers over-trust a MATCH as "genuine" | The result text says it is not proof. Keep it in the defence and add it to the user guide. |
| High | OCR misreads cause false "does not match" results | UNCERTAIN rules, retake and review; real-photo evaluation needed. |
| Medium | Seller enters a wrong MRP to avoid the guard | Admin MRP review. A future buyer label check could flag MRP mismatches to the admin automatically. |
| Medium | Recall notice not seen | Add an SMS/email provider later; until then the in-app notice is the only channel. |
| Low | Spoofed network header affects clone-risk counts | Deploy behind a trusted proxy that sets the header. |
| Low | Database file deleted or a different folder used | `npm run db:status`; set an absolute `DATABASE_FILE`; back up `data/`. |
