# Buyer protection (v5): audit of the existing code

**Date:** 2026-10-29. **Base:** v4 (`verite-ocr-microservice-v4.zip`), unpacked unchanged. The base has no git history, so this audit is from reading files.
**Baseline tests:** `NODE_PATH=tests/shims tsx --test tests/trace/*.test.ts tests/identity/*.test.ts tests/ai/*.test.ts tests/assistant/*.test.ts` gave **133 pass, 0 fail**.

There is no `CLAUDE.md`, `docs/00_Baseline_State.md`, `01_Dependency_Map.md`, `02_Protected_Boundaries.md` or `REMEDIATION_PLAN.md` in the repository. The earlier change folders (`identifier-scan-protection`, `seller-licence-verification`, `ai-assistant-v4`) take their place.

Status key:
- **C** = confirmed in code.
- **M** = missing.
- **P** = partly present.

## 1. Answers to the required questions

### 1. Does OCR support Bangla and English together?
**C.**
- `ocr-service`: Tesseract `ben+eng` (`app/core/config.py` TESSERACT_LANG). The Docker image installs `tesseract-ocr-ben`.
- PaddleOCR has **no** Bengali model; it reads English only.
- The local fallback in `verite-app` is tesseract.js with `LOCAL_OCR_LANGS=eng+ben`. It downloads the data on first use.
- Tested in v4 on **synthetic** Bangla images only (`docs/changes/ai-assistant-v4/TEST_REPORT.md`). There is no real-photo evaluation yet.

### 2. Is there reliable product-to-batch resolution?
**C, with one important design fact.**
- There is **no separate batch table**. Each `products` row carries exactly one `batch_number`, `manufacturing_date` and `expiry_date` (`lib/db.ts`).
- A listing therefore *is* one batch.
- Buyers reach a listing through:
  - its product page (`/product/[id]`);
  - a QR identifier (`trace_identifiers.product_id`, with `batch_number` copied at issue time).

  Both resolve to exactly one batch, so no fuzzy batch matching is needed.

### 3. Which fields are product-level and which are batch-specific?
All label fields sit on the `products` row:
- name, brand, barcode, batch, MFG, EXP, price, stock;
- the Bangla name in `product_label_extractions.name_bn`;
- the manufacturer name in the identity tables (`lib/identity`).

Because one row is one batch, all of them are effectively batch-level.

### 4. Is MRP stored and connected to the listing price?
**M.**
- There is no MRP column.
- The seller studio (`app/seller/dashboard/page.tsx`) sends `price: Number(fields.mrp)`. The OCR-read MRP silently becomes the selling price.
- Stock is hard-coded to 50.
- There is no price-change endpoint at all.
- `product_label_extractions.fields_json` keeps a copy of `price`, but not as an MRP.

### 5. Are expiry dates reliable and unambiguous?
**P.**
- They are stored as `TEXT 'YYYY-MM-DD'`, date-only.
- The OCR parsers (`ocr-service/app/utils/dates.py`, `lib/ai/normalize.ts`) assume **DD/MM**, the Bangladesh label convention. They return ISO dates. Month-only dates become the last day of the month for expiry.
- The seller reviews every value before saving.
- Ambiguity such as `05/06/2027` is not flagged by the parsers. It must be handled at comparison time.

### 6. Is there scheduled processing?
**M.**
- There is no cron or worker.
- The seller assistant (`lib/assistant/alerts.ts` `runChecksIfDue`) runs **at request time**, at most once an hour per seller, when the seller opens the assistant.
- `scripts/assistant-check.ts` exists for manual or cron use.
- **Expiry is not enforced anywhere:**
  - `GET /api/products` lists expired products;
  - `POST /api/orders` sells them.

  The two seeded demo products (milk, noodles) are expired and still for sale.

### 7. Are scan events stored well enough for risk heuristics?
**C.**
- `scan_events` (`lib/trace/schema.ts`) stores the identifier, the outcome (`VALID`/`SUSPICIOUS`/`REVOKED`/`UNKNOWN`), a server-generated timestamp and `source_hash`.
- `source_hash` is a keyed HMAC of a **coarse** network prefix (IPv4 /24, IPv6 /48; `lib/trace/source.ts`). No raw IP is stored.
- Events are rate-limited per source and pruned after `SCAN_EVENT_RETENTION_DAYS` (90).
- Each page load of `/scan/v1/[token]` posts one scan. There is no separate "preview" event type, so previews by the seller count as scans.
- The buyer-facing warning (`evaluateScanPattern`) already exists.
- **M:** there is no seller-facing aggregation or alert.

### 8. Can an order item be traced to the purchased batch?
**C, indirectly.**
- `order_items.product_id` points to the listing, and the listing holds one batch.
- There is no code path that updates `products.batch_number` after creation. The only updates found are:
  - `status`;
  - `stock`;
  - `scripts/tamper.ts`, a demo that changes `expiry_date` on purpose to show a hash mismatch.

  The order-to-batch mapping is reliable today, but nothing enforces it.
- **M:**
  - no batch snapshot on the order item;
  - no lock on `batch_number`.

### 9. Are notifications available?
**P.**
- `seller_notifications` exists. It is in-app only, deduplicated per product, kind and Dhaka day.
- Its `kind` has a CHECK list that does not include scan-risk.
- There is **no buyer notification store** and no email, SMS or push provider.

### 10. What migration and compatibility risks exist?
- SQLite cannot `ALTER` a CHECK constraint. Adding a notification kind needs a table rebuild.
- New columns must be added with `ALTER TABLE ... ADD COLUMN`, guarded with `PRAGMA table_info`, because `lib/db.ts` uses `CREATE TABLE IF NOT EXISTS` on existing databases.
- `scripts/tamper.ts` must keep working: it edits `expiry_date`. A lock may therefore cover `batch_number` only.

### 11. What real tests can verify each flow?
- `node:test` + `node:sqlite` unit tests, in the existing pattern.
- Route-level smoke tests calling the real Next route handlers with real SQL, via the v4 shims.
- Real OCR through the sandbox HTTP wrapper of the real `read_photos`.

## 2. Persistence problem reported by the user
> "whenever as a buyer i add items … saved … after closing and reopening as that seller and also from buyer side i want the item added to the marketplace"

Findings:

| # | Finding | Evidence |
|---|---|---|
| P1 | The **cart is not in the database**. It lives in browser `localStorage` (`verite_cart`). It is lost with another browser or device, a cleared browser, or a changed Codespaces port URL. It is also shared between every account that uses the same browser. | `app/product/[id]/page.tsx` `addToCart`, `app/buyer/cart/page.tsx`, `app/buyer/checkout/page.tsx` |
| P2 | A seller has **no page listing their own products**. After a reload, a draft that failed to publish is unreachable: its id was only in React state. The marketplace shows only `PUBLISHED`, so such a product "disappears". | `app/seller/dashboard/page.tsx` (`productId` state), `GET /api/products` `WHERE status='PUBLISHED'` |
| P3 | Products **are** written to the SQLite database file `verite-app/data/verite.db` (real SQL, WAL mode). Published products survive restarts, as long as the same file is used and not deleted. | `lib/db.ts` |
| P4 | Uploaded images are written into `public/uploads`. `next dev` serves them, but **`next start` does not** serve files added to `public/` after the build, so images break in production mode. | `app/api/uploads/route.ts` |
| P5 | The seller cannot set the selling price or stock. The price equals the OCR MRP and stock is fixed at 50. | `app/seller/dashboard/page.tsx` |

## 3. Current sources of truth

| Data | Source of truth today |
|---|---|
| price | `products.price` (REAL, taka) |
| MRP | none |
| expiry, batch | `products.expiry_date`, `products.batch_number` |
| batch identity in QR | `trace_identifiers.batch_number` (copied from the product) |
| scans | `scan_events` |
| orders | `orders` + `order_items` (product, qty, unit price) |
| seller notifications | `seller_notifications` |
| buyer notifications | none |
| blockchain | `blockchain_records`: Keccak hash of product + identity snapshot (schema v2). Simulated unless `CHAIN_*` is set. Recall, price and stock are **not** part of the hash. |

## 4. Protected zones (must not change behaviour)
- The hash schemas v1 and v2 (`lib/blockchain.ts`, `lib/identity/hash.ts`): no new fields go into the preimage.
- The registration eligibility policy (`lib/identity/policy.ts`).
- Token format and the scan verdict rules (`lib/trace/service.ts`). Only new fields are *added* to the scan response.
- The OCR microservice API contract.
- `scripts/tamper.ts` demo behaviour.
