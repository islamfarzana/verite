# v5: buyer protection + saved data

**Start here.** Run instructions and the demo script are in [WORKFLOW.md](WORKFLOW.md).

## Documents in this folder

| File | Contents |
|---|---|
| [audit.md](audit.md) | What existed before (file evidence) and why products and carts seemed to "disappear" |
| [delta_spec.md](delta_spec.md) | The planned changes, written before coding |
| [POLICY_DECISIONS.md](POLICY_DECISIONS.md) | Every rule and threshold, and the legal-source check |
| [TEST_REPORT.md](TEST_REPORT.md) | Exact commands and real results, with logs in `evidence/` |
| [SECURITY_AND_LIMITATIONS.md](SECURITY_AND_LIMITATIONS.md) | What it does **not** prove, and the remaining risks |

## Summary

**Saved data.** Data was already stored in an SQLite database file. The losses came from three things:
- the cart was kept only in the browser;
- sellers had no page listing their own products, so a draft that failed to publish was lost from view after a reload;
- uploads were written to `public/`, which `next start` does not serve.

v5 fixes all three:
- the cart is stored in the database, per buyer account;
- sellers get **My Products**, which lists every listing including drafts;
- uploads go to `data/uploads`.

`npm run db:status` shows where everything is stored.

**Buyer protection features:**
1. **Check my pack:** Bangla and English OCR of the buyer's photo, compared field by field with the registered batch.
2. **MRP guard:** integer-paisa comparison, enforced on the server.
3. **Expiry protection:** enforced at request time; buyers see "মেয়াদ শেষ হতে X দিন বাকি".
4. **QR clone-risk alerts** for sellers, from real scan events.
5. **Batch recall** with in-app buyer notices.

**Tests:**
- 24 new unit tests and 133 regression tests pass.
- A 15-step route smoke test passes, including the real OCR pipeline.
- A database created by v4 upgrades cleanly.
- 40 OCR-service tests pass.
