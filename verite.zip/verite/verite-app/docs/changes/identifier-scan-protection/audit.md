# Audit: product identifiers and scan handling (before this change)

Scope: the code in `verite-app/` and `ocr-service/` as delivered in `verite-ocr-microservice.zip`, plus the
real-blockchain work added in the same session. The repository contains no `CLAUDE.md` or `docs/` baseline, so
this audit is based only on reading the code. Nothing below is assumed from the master prompt.

## Findings (each with evidence)

| # | Finding | Evidence |
|---|---|---|
| 1 | The only product-level identifier is the barcode: one `UNIQUE` value per product row. Every physical pack of that product shares it. | `lib/db.ts` `products.barcode TEXT UNIQUE NOT NULL`; `scripts/seed.ts` seeds one fixed EAN per product |
| 2 | Barcode "verification" looks the product up by barcode on the client and then calls the product verify endpoint. It checks the product RECORD against the ledger, not an individual pack. | `app/verify/page.tsx` (`list.find((p) => String(p.barcode) === barcode.trim())`), `app/api/products/[id]/verify/route.ts` |
| 3 | A copied barcode is indistinguishable from the original: nothing differs between a genuine and a cloned pack. This is the weakness the change addresses. | follows from 1 and 2 |
| 4 | No QR code, batch identifier, unit identifier, scan counter or scan log existed. `grep -ri "qrcode\|scan_event"` over `app lib scripts` matched nothing. | repository search |
| 5 | `verification_logs` records buyer clicks on "Verify" per product (result VERIFIED/FAILED). It is not a scan log of a physical pack. | `lib/db.ts` |
| 6 | A `products` row carries `batch_number` and `stock`, and publishing hashes `batch_number` into the product fingerprint. In practice one product row = one batch of one product. | `lib/blockchain.ts` `generateProductHash`, `app/api/products/[id]/route.ts` |
| 7 | Roles BUYER / SELLER / ADMIN are enforced in middleware for `/buyer`, `/seller`, `/admin`. `/scan` and `/api/scan` are not under those prefixes, so they are public, which a buyer without an account needs. | `middleware.ts` matcher |
| 8 | The ledger is a smart contract when configured (`CHAIN_*` variables) and a simulated local record otherwise. The commitment is PRODUCT-level (keyed by product id). It says nothing about an individual pack. | `lib/chain.ts`, `blockchain/contracts/ProductRegistry.sol` |
| 9 | Rate limiting, request-size limits and `scan` abuse controls did not exist for any public endpoint. | repository search |
| 10 | The database is SQLite via `better-sqlite3` (single instance). IDs are text with a prefix (`newId`). | `lib/db.ts`, `lib/ids.ts` |

## Decision on scope (batch vs unit)

The application can honestly issue and track BOTH:
- **BATCH**: one code per product row (= one batch). Fits the existing data model exactly.
- **UNIT**: N codes (serials 1..N) per product row, for sellers able to label every pack.

The application cannot know which physical pack received which printed label. That is an operational process
outside the software, stated in `SECURITY_AND_LIMITATIONS.md`. Clone warnings are far more meaningful for UNIT codes
(a unit code should be scanned a handful of times) than for BATCH codes (a shared label is scanned by everyone).

## Gaps this change closes / does not close

Closes: no per-pack or per-batch identifier; no scan record; no clone signal; no abuse limits on a public scan endpoint.
Does not close: a QR code can still be photographed and reprinted; the platform operator remains trusted;
the warning is a heuristic. See `SECURITY_AND_LIMITATIONS.md`.
