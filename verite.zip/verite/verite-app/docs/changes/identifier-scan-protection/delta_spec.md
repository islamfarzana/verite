# Delta specification: batch/unit identifiers with clone-warning

Additive only. No existing table, endpoint, role or page is changed in behaviour (see "Touched existing files").

## Data model (`lib/trace/schema.ts`, applied by `lib/db.ts`)

`trace_identifiers`: `id`, `token` (UNIQUE, public QR token), `scope` (UNIT|BATCH), `product_id` (FK), `batch_number`
(snapshot), `unit_serial` (UNIT only), `issue_group` (idempotency key), `status` (ACTIVE|REVOKED), `schema_version`,
`issued_by` (FK), `created_at`, `revoked_at/reason/by`.
- one BATCH identifier per product (partial unique index); `(product_id, unit_serial)` unique for UNIT;
- CHECK: UNIT needs a serial, BATCH must not have one;
- triggers: binding columns are immutable; REVOKED can never return to ACTIVE.

`scan_events`: `id`, `identifier_id` (nullable for unknown tokens), `outcome` (VALID|SUSPICIOUS|REVOKED|UNKNOWN),
`source_hash` (keyed HMAC of a coarse network prefix; never an IP), `reason`, `created_at`. Append-only by design
(no update/delete code path except retention pruning).

Migration: `CREATE ... IF NOT EXISTS`, no backfill, no change to existing rows. Rollback:
`DROP TABLE scan_events; DROP TABLE trace_identifiers;`.

## Token and payload
- 18 random bytes from `crypto.randomBytes` (144 bits) -> 24-char base64url. Not derived from product data, time or sequence.
- QR payload: `<PUBLIC_BASE_URL>/scan/v1/<token>`. Versioned, opaque, no product data. Base URL is configuration, never request input.
- The token is public by design (printed on the pack), so it is stored in plain text to allow label reprinting.
- Barcode and token are separate: a barcode never resolves an identifier (tested).

## Endpoints
| Endpoint | Auth | Purpose |
|---|---|---|
| `POST /api/scan` `{token}` | public | resolve + record scan + evaluate warning. 200 result; 429 rate limited; 413 too large; 503 unavailable |
| `POST /api/identifiers` | SELLER (own products) / ADMIN | issue BATCH or UNIT codes, idempotent by `requestId` |
| `GET /api/identifiers?productId=` | SELLER (own) / ADMIN | list codes with scan counts |
| `POST /api/identifiers/:id/revoke` | SELLER (own) / ADMIN | revoke with a reason |
Pages: `/scan/v1/[token]` (public), `/seller/codes` (seller).

## Result states (never overclaims)
VALID, SUSPICIOUS_ACTIVITY ("Possible cloned code / unusual scan activity"), REVOKED, UNKNOWN_IDENTIFIER; plus
UNAVAILABLE (503) and RATE_LIMITED (429) which are not product verdicts. A VALID result says "registered and active"
and states it is NOT proof of genuineness. Responses expose only name, brand, batch, dates and the product page path.

## Clone-warning heuristic (INITIAL, UNVALIDATED)
Within a rolling window, count VALID/SUSPICIOUS scans of the identifier (including the current one). Warn when
`count >= threshold(scope)` AND `distinct sources >= SCAN_DISTINCT_SOURCE_THRESHOLD`. Defaults: UNIT 3, BATCH 100,
window 1440 min, distinct sources 1 (count-only, so a one-laptop demo triggers it). Use 2 or more in real use.
No cool-down: the warning persists while the condition holds, then clears as scans age out. Scan evaluation and the
event insert run in one `BEGIN IMMEDIATE` transaction.

## Environment variables (all optional except PUBLIC_BASE_URL in production)
`PUBLIC_BASE_URL`, `SCAN_HASH_SECRET`, `SCAN_WARNING_THRESHOLD_UNIT`, `SCAN_WARNING_THRESHOLD_BATCH`,
`SCAN_WARNING_WINDOW_MINUTES`, `SCAN_DISTINCT_SOURCE_THRESHOLD`, `SCAN_RATE_LIMIT_PER_MINUTE`, `SCAN_EVENT_RETENTION_DAYS`.
Invalid values make the scan endpoint answer 503 UNAVAILABLE rather than guess.

## Touched existing files (minimal)
`lib/db.ts` (+2 lines: apply trace schema), `components/NavBar.tsx` (+1 seller link), `app/verify/page.tsx` (one sentence
explaining that a barcode is a product-type check), `package.json` (+qrcode, @types/qrcode, tsx, two scripts),
`.env.example`. Authentication, middleware, product publishing, checkout and the OCR service are unchanged.

## Retention
`scan_events` older than `SCAN_EVENT_RETENTION_DAYS` (default 90) are deleted: opportunistically every 500 scans and by
`npm run prune:scans`. The window may not exceed the retention period (validated).
