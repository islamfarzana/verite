# Security properties and honest limitations

## What the design protects against
- **Guessable identifiers**: 144-bit random tokens; no sequential or derivable values.
- **Barcode substitution**: barcodes cannot be used to look up or forge identifiers.
- **Database tampering of identifier binding**: immutable-binding and no-reactivation triggers.
- **Abuse of the public endpoint**: strict format check before any database access, 2 KB body limit, per-source rate limit, generic responses for unknown codes.
- **Privacy**: scan events hold a keyed hash of a coarse network prefix, never an IP or user agent; the scanned token is not stored for unknown codes and never logged.
- **Misleading output**: infrastructure failure returns UNAVAILABLE, never VALID; wording never claims genuineness.

## What it does NOT do (say this in the defense)
1. **A QR code can be copied.** A counterfeiter can photograph a real code and print it on fakes. The scan counter only raises a warning after repeated scans; it cannot stop the first fake scan, and if the counterfeiter scans a copy first, the genuine buyer may see the warning.
2. **The warning is a heuristic**, with uncalibrated defaults. Legitimate repeat scans (family, retailer, curious buyer) can trigger it; slow, well-spread cloning may not.
3. **Source signal is weak.** It relies on `X-Forwarded-For`, which a client can spoof unless a trusted proxy sets it. With carrier-grade NAT many buyers share one prefix.
4. **Labelling is outside the software.** The app issues unique codes; it cannot check that each code went on the right pack.
5. **Batch codes prove less** than unit codes: they identify a production batch, and repeated scans of a shared label are normal.
6. **The blockchain commitment is product-level.** It supports the integrity of product data, not the identity of one pack.
7. **Rate limiting is in-process memory**: per server instance and reset on restart. Multi-instance deployments need a shared store.
8. **The operator is trusted** for issuing codes and for scan-event integrity. Scan events are in the same database as everything else.
9. **Thresholds, window and scan counts are not validated** against real data. Calibrate before relying on them.
