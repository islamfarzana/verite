# Test report

## Command and result (real run)
```
npm run test:trace      # = tsx --test tests/trace/*.test.ts
ℹ tests 35
ℹ suites 0
ℹ pass 35
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
```
The suite runs on Node's built-in `node:sqlite` against an in-memory database built from the REAL `users`, `categories`
and `products` definitions in `lib/db.ts` plus the new trace schema. Needs a Node version where `node:sqlite` works without a flag (22.13 or newer). Run in this build on the Node version (v22.22.2).

## Tests executed
- ✔ separately issued identifiers are all distinct (unit and batch)
- ✔ unit serials continue after a second issuance; batch identifiers carry no serial
- ✔ issuance is idempotent: same requestId returns the same identifiers; second batch request reuses the batch code
- ✔ a token collision is retried and succeeds within the bound
- ✔ collisions that never resolve fail safely and roll back everything
- ✔ authorisation: other sellers and buyers cannot issue, list or revoke; admin can
- ✔ eligibility and input validation
- ✔ database enforces uniqueness, foreign keys and lifecycle rules, not just application code
- ✔ a revoked identifier can never be reactivated, even by direct SQL
- ✔ malformed tokens never touch the database
- ✔ unknown token: generic answer, event recorded without the token
- ✔ a product barcode is not an identifier: scanning it as a token never resolves
- ✔ resolution returns the right scope and approved product fields only
- ✔ messages never overclaim: any mention of genuine/counterfeit only appears inside a "does not prove" clause
- ✔ UNIT code: warning appears on the 3rd scan within the window and persists while the condition holds
- ✔ rolling window: old scans stop counting and the warning clears
- ✔ window boundary is inclusive of the window start
- ✔ distinct-source rule: same source alone stays VALID, two sources raise the warning
- ✔ BATCH code uses its own, much higher threshold and softer wording
- ✔ threshold is configurable and evaluateScanPattern is a pure rule
- ✔ revoked identifier: REVOKED result with no product data; event recorded
- ✔ identifier of an unpublished product does not pass as valid
- ✔ events store a keyed hash and a reason, never an IP address
- ✔ handler: infrastructure failure is UNAVAILABLE (503), never VALID, and never leaks the token
- ✔ handler: rate limiting returns 429 without writing events; oversized bodies are refused
- ✔ handler: a different network is limited independently; garbage JSON is a safe unknown result
- ✔ retention: pruning removes only events older than the cutoff
- ✔ a copied barcode (same EAN on many products) cannot be used to read identifiers
- ✔ token generation asks the secure random source for 18 bytes and encodes them to 24 URL-safe chars
- ✔ default generator yields distinct, valid tokens
- ✔ implementation path: lib/trace uses crypto.randomBytes and never Math.random
- ✔ token validation rejects wrong length, characters and types
- ✔ QR payload is versioned, opaque, built from the trusted base URL only
- ✔ source signal is a keyed hash of a coarse prefix: no raw IP, same /24 collapses
- ✔ config: defaults, overrides, and invalid values are rejected

## Corrections made while testing
Three tests failed on the first run. All three were mistakes in the TESTS, not in the service: (1) a check for "no token in the
stored event" matched the harmless reason text `unknown_token`; (2) the overclaim check matched the deliberately negated phrase
"does not prove ... genuine"; (3) the retention test used dates only 68 days apart against a 90-day cutoff. The tests were corrected
and the full suite then passed 35/35. No service behaviour was changed to make a test pass.

## What these tests do NOT prove
- **Next.js routes and pages were not executed.** Dependencies cannot be installed in the build sandbox, so `app/api/scan`, `app/api/identifiers/*`, `/scan/v1/[token]` and `/seller/codes` are syntax-checked (TypeScript transpile) only, and the service they call is type-checked with `tsc --strict`. The route-level login check (401 for buyers/anonymous) is therefore NOT covered by an automated test; seller ownership rules are covered at service level.
- **The `qrcode` library and QR rendering in a browser** were not run.
- **`better-sqlite3`** (the production driver) was not used; tests use `node:sqlite`, which has the same SQL engine and a compatible API but is a different driver.
- **No browser, mobile-camera or end-to-end test** of the printed-QR flow.
- **Heuristic accuracy**: the tests check the rule is applied as specified, not that it detects real cloning.
- The smart contract tests (`blockchain/test`) and the Amoy deployment were not run here.

## Manual verification to do on your machine
1. `npm install`, `npm run test:trace` (expect 35 passing).
2. `npm run dev`; sign in as seller; open "QR Codes"; issue 1 batch code and 5 unit codes; print preview.
3. Open a unit code URL 3 times: third view shows "Possible cloned code / unusual scan activity".
4. Revoke a code; open it: "Revoked code".
5. Open `/scan/v1/aaaaaaaaaaaaaaaaaaaaaaaa`: "Code not recognised".
