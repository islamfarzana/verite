module.exports={hash:async(s)=>'h:'+s,compare:async(a,b)=>b==='h:'+a};module.exports.default=module.exports;
