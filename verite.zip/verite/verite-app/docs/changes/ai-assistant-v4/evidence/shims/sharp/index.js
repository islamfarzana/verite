module.exports=()=>{throw new Error('sharp not installed in sandbox')};module.exports.default=module.exports;
