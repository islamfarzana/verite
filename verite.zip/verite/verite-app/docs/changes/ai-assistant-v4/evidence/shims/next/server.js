// Sandbox-only minimal stand-in for next/server (route handlers only).
class NextRequest extends Request {
  constructor(url, init = {}) {
    super(url, init);
    this.nextUrl = new URL(url);
    const cookieHeader = init.headers && (init.headers.cookie || init.headers.Cookie) || '';
    const jar = Object.fromEntries(cookieHeader.split(';').filter(Boolean).map((c) => c.trim().split('=')));
    this.cookies = { get: (n) => (jar[n] ? { value: jar[n] } : undefined) };
  }
}
class NextResponse extends Response {
  static json(body, init = {}) { return new NextResponse(JSON.stringify(body), { status: init.status || 200, headers: { 'content-type': 'application/json', ...(init.headers || {}) } }); }
}
module.exports = { NextRequest, NextResponse };
