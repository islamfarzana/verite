// Sandbox-only stand-in for jose: an UNSIGNED token, enough to drive role checks in a smoke test.
class SignJWT { constructor(p) { this.p = p; } setProtectedHeader() { return this; } setIssuedAt() { return this; } setExpirationTime() { return this; }
  async sign() { return Buffer.from(JSON.stringify(this.p)).toString('base64url'); } }
async function jwtVerify(t) { return { payload: JSON.parse(Buffer.from(t, 'base64url').toString()) }; }
module.exports = { SignJWT, jwtVerify };
