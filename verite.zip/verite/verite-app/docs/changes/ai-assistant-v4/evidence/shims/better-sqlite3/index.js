// Sandbox-only stand-in: better-sqlite3 API over node:sqlite.
const { DatabaseSync } = require('node:sqlite');
class Database {
  constructor(file) { this.d = new DatabaseSync(file); }
  prepare(sql) { return this.d.prepare(sql); }
  exec(sql) { this.d.exec(sql); return this; }
  pragma(p) { this.d.exec(`PRAGMA ${p}`); }
}
module.exports = Database; module.exports.default = Database;
