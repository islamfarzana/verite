exports.createWorker=async()=>{throw new Error('tesseract.js not installed in sandbox')};
