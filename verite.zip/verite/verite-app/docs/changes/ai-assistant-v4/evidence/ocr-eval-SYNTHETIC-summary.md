# OCR evaluation (SYNTHETIC — not real-world accuracy)

Packs: 20

Recall per field (precision in brackets):

| Field | baseline-eng | ben+eng-plain | ben+eng-full-bestvariant | ben+eng-full-voting |
|---|---|---|---|---|
| productName | 0.00 (0.00) | 1.00 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| productNameBn | 0.00 (—) | 1.00 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| manufacturer | 0.00 (—) | 0.35 (0.88) | 0.85 (1.00) | 0.85 (1.00) |
| batchNumber | 1.00 (1.00) | 0.90 (0.95) | 0.55 (0.61) | 0.60 (0.60) |
| manufacturingDate | 0.00 (—) | 0.90 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| expiryDate | 0.00 (—) | 0.90 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| mrp | 0.00 (0.00) | 1.00 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| weight | 0.00 (—) | 1.00 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| licenceNumber | 0.00 (—) | 0.80 (0.84) | 0.85 (0.85) | 0.90 (0.90) |
| seconds per pack | 0.99 | 1.2 | 3.9 | 3.79 |
