import assert from 'node:assert/strict';
import http from 'node:http';
import { readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

process.env.DATABASE_FILE = '/tmp/v4smoke.db';
(process.env as any).NODE_ENV = 'development';
process.env.OCR_SERVICE_URL = 'http://127.0.0.1:8765';
process.env.GEMINI_BASE_URL = 'http://127.0.0.1:8766';
const A = '/tmp/proj/v2/verite-app';
const results: string[] = [];
const step = async (name: string, fn: () => Promise<void>) => { await fn(); results.push(`PASS  ${name}`); };

// ---- fake Gemini (records requests) ----
const geminiCalls: any[] = [];
let geminiMode: 'ok' | 'invent' | '429' = 'ok';
const LABEL = { productName: 'Chashi Chinigura Rice', productNameBn: 'চাষী চিনিগুড়া চাল', brand: null, manufacturer: 'প্রাণ এগ্রো লিমিটেড',
  batchNumber: 'LOT-241A', manufacturingDate: '১৫/০১/২০২৬', expiryDate: '১৪/০১/২০২৭', mrp: '১৫০ টাকা', weight: '১ কেজি', barcode: null,
  licenceNumber: 'DEMO-CM-0002', countryOfOrigin: null, languagesSeen: ['bn', 'en'], legibilityProblems: null };
const gemini = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', () => {
    const j = JSON.parse(body);
    geminiCalls.push({ url: req.url, key: req.headers['x-goog-api-key'], body: j });
    if (geminiMode === '429') { res.writeHead(429); res.end('{}'); return; }
    const sys = j.system_instruction?.parts?.[0]?.text || '';
    let text: string;
    if (sys.includes('consumer product packages')) text = JSON.stringify(LABEL);
    else if (sys.includes('weekly business summary')) {
      const facts = JSON.parse(j.contents[0].parts[0].text.split('Facts (JSON):\n')[1]);
      text = geminiMode === 'invent'
        ? `You sold ${facts.thisWeek.units} units. Next week you will earn 99999 taka.`
        : `This week you sold ${facts.thisWeek.units} units in ${facts.thisWeek.orders} orders.`;
    } else text = JSON.stringify({ intent: 'top_products', period: '30d', metric: 'units', productQuery: null });
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ candidates: [{ content: { parts: [{ text }] }, finishReason: 'STOP' }] }));
  });
});

async function main() {
  await new Promise<void>((r) => gemini.listen(8766, '127.0.0.1', () => r()));
  const { NextRequest } = require('next/server');
  const db = (await import(`${A}/lib/db`)).default;
  const { signToken } = await import(`${A}/lib/auth-edge`);
  const { submitBusinessProfile, decideEntity } = await import(`${A}/lib/identity/onboarding`);
  const { MockRegistryAdapter } = await import(`${A}/lib/identity/registry`);
  const extract = await import(`${A}/app/api/ocr/extract/route`);
  const cover = await import(`${A}/app/api/ocr/cover/route`);
  const products = await import(`${A}/app/api/products/route`);
  const product = await import(`${A}/app/api/products/[id]/route`);
  const assistant = await import(`${A}/app/api/seller/assistant/route`);
  const summary = await import(`${A}/app/api/seller/assistant/summary/route`);
  const ask = await import(`${A}/app/api/seller/assistant/ask/route`);
  const notif = await import(`${A}/app/api/seller/assistant/notifications/route`);

  for (const [id, role, email] of [['u_seller', 'SELLER', 'seller@verite.app'], ['u_buyer', 'BUYER', 'buyer@verite.app'], ['u_admin', 'ADMIN', 'admin@verite.app']]) {
    db.prepare('INSERT INTO users (id,name,email,password_hash,role) VALUES (?,?,?,?,?)').run(id, id, email, 'x', role);
  }
  const tok: Record<string, string> = {};
  for (const [id, role, email] of [['u_seller', 'SELLER', 'seller@verite.app'], ['u_buyer', 'BUYER', 'buyer@verite.app']]) tok[role] = await signToken({ id, email, role: role as any });
  const cookie = (who?: string) => (who ? { cookie: `verite_session=${tok[who]}` } : {});
  const formReq = (path: string, who: string | undefined, files: Record<string, string>) => {
    const fd = new FormData();
    for (const [k, p] of Object.entries(files)) fd.append(k, new File([readFileSync(p)], p.split('/').pop()!, { type: 'image/jpeg' }));
    return new NextRequest(`http://localhost:3000${path}`, { method: 'POST', headers: cookie(who), body: fd });
  };
  const jsonReq = (path: string, who: string, body?: unknown, method = 'POST') =>
    new NextRequest(`http://localhost:3000${path}`, { method, headers: { ...cookie(who), ...(body !== undefined ? { 'content-type': 'application/json' } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
  const call = async (r: Promise<Response> | Response) => { const res = await r; const ct = res.headers.get('content-type') || ''; return { status: res.status, res, json: ct.includes('json') ? await res.json() as any : null }; };

  await step('label extraction requires a seller session (anonymous/buyer -> 401)', async () => {
    assert.equal((await call(extract.POST(formReq('/api/ocr/extract', undefined, { labelImage: '/tmp/smoke_front.jpg' })))).status, 401);
    assert.equal((await call(extract.POST(formReq('/api/ocr/extract', 'BUYER', { labelImage: '/tmp/smoke_front.jpg' })))).status, 401);
  });

  let extracted: any;
  await step('front + back WITHOUT an AI key: real Bangla OCR through the route, every field marked OCR_ONLY/NOT_FOUND', async () => {
    delete process.env.GEMINI_API_KEY;
    const r = await call(extract.POST(formReq('/api/ocr/extract', 'SELLER', { labelImage: '/tmp/smoke_front.jpg', backImage: '/tmp/smoke_back.jpg' })));
    assert.equal(r.status, 200, JSON.stringify(r.json));
    const d = r.json.data;
    assert.equal(d.productNameBn, 'চাষী চিনিগুড়া চাল');
    assert.equal(d.expiryDate, '2027-01-14');
    assert.equal(d.mrp, 150);
    assert.equal(d.ai.used, false);
    assert.equal(d.ai.reason, 'NOT_CONFIGURED');
    assert.deepEqual(d.ocr.languages, ['bn', 'en']);
    assert.equal(d.ocr.sides[1].perspectiveCorrected, true);
    assert.ok(Object.values(d.fieldStatus).every((s: any) => s.status === 'OCR_ONLY' || s.status === 'NOT_FOUND'));
    assert.equal(geminiCalls.length, 0, 'no AI call without a key');
  });

  await step('front + back WITH the AI key (fake Gemini): fields merged with statuses; key sent only in the header', async () => {
    process.env.GEMINI_API_KEY = 'sandbox-test-key';
    const r = await call(extract.POST(formReq('/api/ocr/extract', 'SELLER', { labelImage: '/tmp/smoke_front.jpg', backImage: '/tmp/smoke_back.jpg' })));
    assert.equal(r.status, 200, JSON.stringify(r.json));
    const d = r.json.data;
    extracted = d;
    assert.equal(d.ai.used, true);
    assert.equal(d.fieldStatus.expiryDate.status, 'AGREED');
    assert.equal(d.fieldStatus.productNameBn.status, 'AGREED');
    assert.equal(d.fieldStatus.licenceNumber.status, 'AGREED');
    assert.equal(d.weight, '1 KG');
    const call0 = geminiCalls[0];
    assert.equal(call0.key, 'sandbox-test-key');
    assert.ok(!call0.url.includes('sandbox-test-key'));
    const imgs = call0.body.contents[0].parts.filter((p: any) => p.inline_data);
    assert.equal(imgs.length, 2, 'both photos sent');
  });

  await step('AI quota exhausted (429): extraction still succeeds with OCR only, reason RATE_LIMITED', async () => {
    geminiMode = '429';
    const r = await call(extract.POST(formReq('/api/ocr/extract', 'SELLER', { labelImage: '/tmp/smoke_front.jpg' })));
    assert.equal(r.status, 200);
    assert.equal(r.json.data.ai.used, false);
    assert.equal(r.json.data.ai.reason, 'RATE_LIMITED');
    geminiMode = 'ok';
  });

  await step('enhanced cover: JPEG from the real cover pipeline (background removed)', async () => {
    const r = await call(cover.POST(formReq('/api/ocr/cover', 'SELLER', { image: '/tmp/smoke_packet.jpg' })));
    assert.equal(r.status, 200);
    assert.equal(r.res.headers.get('content-type'), 'image/jpeg');
    assert.equal(r.res.headers.get('x-cover-method'), 'grabcut');
    assert.equal((await call(cover.POST(formReq('/api/ocr/cover', 'BUYER', { image: '/tmp/smoke_packet.jpg' })))).status, 401);
  });

  let pid = '';
  await step('product saved with Bangla name, extraction audit and an enhanced-image label; GET shows them', async () => {
    const r = await call(products.POST(jsonReq('/api/products', 'SELLER', {
      name: extracted.productName, brand: 'Chashi', barcode: '8901234567890', batchNumber: extracted.batchNumber,
      manufacturingDate: extracted.manufacturingDate, expiryDate: extracted.expiryDate, price: extracted.mrp, stock: 9,
      images: ['/uploads/enhanced.jpg', '/uploads/original.jpg'], enhancedImageUrls: ['/uploads/enhanced.jpg', '/uploads/not-mine.jpg'],
      productNameBn: extracted.productNameBn, labelExtraction: { fieldStatus: extracted.fieldStatus, aiProvider: 'gemini', aiModel: 'm', ocrSource: 'microservice' },
      manufacturer: { mode: 'CLAIM', name: extracted.manufacturer },
    })));
    assert.equal(r.status, 201, JSON.stringify(r.json));
    pid = r.json.data.id;
    const g = await call(product.GET(jsonReq('', 'BUYER', undefined, 'GET'), { params: { id: pid } }));
    assert.equal(g.json.data.nameBn, 'চাষী চিনিগুড়া চাল');
    assert.deepEqual(g.json.data.imageLabels, { '/uploads/enhanced.jpg': 'ENHANCED_FROM_SELLER_PHOTO' }, 'only the product\'s own images can be labelled');
    const audit = db.prepare('SELECT field_status_json, ai_provider FROM product_label_extractions WHERE product_id = ?').get(pid) as any;
    assert.equal(JSON.parse(audit.field_status_json).expiryDate.status, 'AGREED');
  });

  // publish the product so it counts in the assistant (approve the seller first)
  const ent = await submitBusinessProfile(db, { id: 'u_seller', role: 'SELLER' }, {
    legalName: 'GreenMart BD Ltd', displayName: 'GreenMart BD', entityType: 'ORGANIZATION', roles: ['SELLER'],
    licence: { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2026-0001', issuingAuthority: 'Demo City Corporation (fictitious)', claimSource: 'MANUAL_ENTRY' },
  }, { adapter: new MockRegistryAdapter(db) });
  decideEntity(db, { id: 'u_admin', role: 'ADMIN' }, ent.entity.id, { action: 'APPROVE' });
  const pub = await call(product.PATCH(jsonReq('', 'SELLER', undefined, 'PATCH'), { params: { id: pid } }));
  assert.equal(pub.status, 200, JSON.stringify(pub.json));
  // an expired product, still listed (as in the seed data)
  db.prepare(`INSERT INTO products (id, seller_id, name, barcode, batch_number, manufacturing_date, expiry_date, price, stock, status)
              VALUES ('old', 'u_seller', 'Instant Noodles Pack', '8909998887776', 'LOT-118B', '2026-04-01', '2026-10-01', 250, 6, 'PUBLISHED')`).run();

  await step('simulated sales script creates labelled SIM- orders', async () => {
    const out = execFileSync('tsx', [`${A}/scripts/simulate-sales.ts`, '--days', '30'], { env: { ...process.env, NODE_PATH: process.env.NODE_PATH }, encoding: 'utf8' });
    assert.match(out, /Created \d+ SIMULATED orders/);
  });

  await step('assistant dashboard: alerts created (expired still listed, stock-out), facts and simulated count', async () => {
    const r = await call(assistant.GET(jsonReq('/api/seller/assistant', 'SELLER', undefined, 'GET')));
    assert.equal(r.status, 200, JSON.stringify(r.json));
    const d = r.json.data;
    const kinds = d.notifications.map((n: any) => n.kind);
    assert.ok(kinds.includes('EXPIRED_LISTED'), kinds.join(','));
    assert.ok(d.simulatedOrders > 0);
    assert.ok(d.top.length > 0);
    assert.equal(d.series.length, 28);
    assert.equal((await call(assistant.GET(jsonReq('/api/seller/assistant', 'BUYER', undefined, 'GET')))).status, 403);
  });

  await step('mark all notifications read', async () => {
    const r = await call(notif.POST(jsonReq('', 'SELLER', { all: true })));
    assert.ok(r.json.data.updated >= 1);
  });

  await step('weekly summary: AI text accepted when its numbers match; replaced by template when AI invents a number', async () => {
    const ok = await call(summary.POST(jsonReq('', 'SELLER', { lang: 'en' })));
    assert.equal(ok.json.data.source, 'AI', JSON.stringify(ok.json));
    geminiMode = 'invent';
    const bad = await call(summary.POST(jsonReq('', 'SELLER', { lang: 'bn' })));
    assert.equal(bad.json.data.source, 'TEMPLATE');
    assert.match(bad.json.data.fallbackReason, /99999/);
    assert.match(bad.json.data.text, /গত ৭ দিনে/);
    geminiMode = 'ok';
  });

  await step('ask your shop (Bangla): AI classifies, the server answers from the seller\'s data', async () => {
    const r = await call(ask.POST(jsonReq('', 'SELLER', { question: 'এই মাসে কোন পণ্য সবচেয়ে বেশি বিক্রি হয়েছে?' })));
    assert.equal(r.status, 200);
    assert.equal(r.json.data.interpretation.via, 'AI');
    assert.match(r.json.data.answer, /গত ৩০ দিনে সবচেয়ে বেশি বিক্রি হয়েছে/);
    assert.equal((await call(ask.POST(jsonReq('', 'SELLER', { question: 'x' })))).status, 422);
  });

  console.log(results.join('\n'));
  console.log(`\n${results.length} v4 route-level steps passed`);
  gemini.close();
}
main().catch((e) => { console.log(results.join('\n')); console.error('FAIL', e); process.exit(1); });
