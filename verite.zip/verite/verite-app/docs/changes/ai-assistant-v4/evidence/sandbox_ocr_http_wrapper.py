"""SANDBOX-ONLY stand-in for the FastAPI app: serves the REAL v4 OCR pipeline code
(app.services.extraction.read_photos, app.services.cover.make_cover) over HTTP with the
same request/response shape as /api/v1/ocr/extract and /api/v1/ocr/cover.
FastAPI itself cannot be installed in this sandbox."""
import json, sys, cv2
from email.parser import BytesParser
from email.policy import default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, '/tmp/proj/v2/ocr-service')
from app.core.config import settings
settings.OCR_ENGINE = 'tesseract'
from app.services.ocr_engine import ocr_engine
from app.services.extraction import read_photos
from app.services.cover import make_cover
from app.services.parser import detect_languages
ocr_engine.load()

def parts(handler):
    n = int(handler.headers['Content-Length'])
    body = handler.rfile.read(n)
    msg = BytesParser(policy=default).parsebytes(b'Content-Type: ' + handler.headers['Content-Type'].encode() + b'\r\n\r\n' + body)
    return {p.get_param('name', header='content-disposition'): p.get_payload(decode=True) for p in msg.iter_parts()}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        f = parts(self)
        if self.path == '/api/v1/ocr/extract':
            r = read_photos(ocr_engine, f['image'], f.get('backImage'))
            text = '\n'.join(x.text for x in r.regions)
            out = {'success': True, 'processingTime': 0, 'quality': r.sides[0].quality.quality,
                   'fields': {k: {'value': v.value, 'confidence': v.confidence} for k, v in r.fields.items()},
                   'rawText': text, 'languages': detect_languages(text), 'engine': ocr_engine.engine_name,
                   'sides': [{'side': s.side, 'quality': s.quality.quality, 'warnings': s.quality.warnings, 'variant': s.variant,
                              'perspectiveCorrected': s.perspective_corrected, 'rotatedDegrees': s.rotated_degrees} for s in r.sides]}
            b = json.dumps(out, ensure_ascii=False).encode()
            self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
        elif self.path == '/api/v1/ocr/cover':
            res = make_cover(f['image'])
            b = cv2.imencode('.jpg', res.image)[1].tobytes()
            self.send_response(200); self.send_header('Content-Type', 'image/jpeg'); self.send_header('X-Cover-Method', res.method); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
        else:
            self.send_response(404); self.end_headers()

ThreadingHTTPServer(('127.0.0.1', 8765), H).serve_forever()
