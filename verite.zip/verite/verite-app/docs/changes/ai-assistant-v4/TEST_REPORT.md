# Test report (v4)

**Date:** 2026-10-28. **Environment:** build sandbox (Linux, Node 22.23, Python 3.13, OpenCV 5.0, Tesseract 5 with `eng`, `osd` and the official `ben` model from tesseract-ocr/tessdata_fast, Noto Sans Bengali font). **Real Gemini API contacted: no** (no key in the sandbox; all AI tests use fake responses or a local fake Gemini server). **Real licence registry / blockchain contacted: no.**

Dependencies such as `next`, `better-sqlite3`, `ethers`, `fastapi`, `paddleocr` cannot be installed here (package registries blocked). Where needed, narrow stand-ins are used and listed below; they are not part of the application.

## Results

| # | What | Command | Result |
|---|---|---|---|
| 1 | AI layer (Gemini client, normalisation, label merge/grounding) | `tsx --test tests/ai/*.test.ts` | **17/17 pass** |
| 2 | Seller assistant (analytics, alerts, summary number check, ask) | `tsx --test tests/assistant/*.test.ts` | **20/20 pass** |
| 3 | Regression: v3 identity + QR traceability suites | `tsx --test tests/identity/*.test.ts tests/trace/*.test.ts` | **96/96 pass** |
| 4 | OCR service unit + end-to-end (synthetic Bangla images) | `pytest tests` (minus the FastAPI-only files) | **40 pass, 1 skipped** (`test_api_v4.py` needs FastAPI; runs in the Docker image) |
| 5 | Strict type-check of all new/changed TS (routes, libs, pages, scripts, tests) | `tsc --strict` with stubs | **0 errors** |
| 6 | v4 route-level smoke: real Next route handlers + **real OCR pipeline** (served over HTTP by a sandbox wrapper) + fake Gemini server + real SQL | `evidence/v4-route-smoke.ts` | **11/11 steps pass** |
| 7 | v3 route-level smoke (regression) | v3 `route-smoke.ts` | **18/18 steps pass** |
| 8 | Synthetic OCR evaluation (ablation) | `python scripts/evaluate.py --synthetic 20` | see below |

Logs: `evidence/*.log`.

### What the end-to-end OCR tests show (synthetic images)
On rendered Bangla+English labels, the pipeline reads product names in both scripts, manufacturer, MFG/EXP dates in Bengali digits, MRP in টাকা, weight in কেজি/গ্রাম and the BSTI licence number — on a flat label, a photo **taken at an angle** (perspective flattened), a **sideways** photo (auto-rotated) and a **dark** photo.

### Synthetic evaluation (20 packs, random conditions) — NOT real-world accuracy
Recall (precision):

| Field | v3-like English only | ben+eng, no extras | ben+eng + preprocessing, best variant | **ben+eng + preprocessing + voting (v4)** |
|---|---|---|---|---|
| productName | 0.00 (0.00) | 1.00 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| productNameBn | 0.00 | 1.00 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| manufacturer | 0.00 | 0.35 (0.88) | 0.85 (1.00) | 0.85 (1.00) |
| batchNumber | 1.00 (1.00) | 0.90 (0.95) | 0.55 (0.61) | 0.60 (0.60) |
| manufacturingDate | 0.00 | 0.90 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| expiryDate | 0.00 | 0.90 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| mrp | 0.00 | 1.00 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| weight | 0.00 | 1.00 (1.00) | 1.00 (1.00) | 1.00 (1.00) |
| licenceNumber | 0.00 | 0.80 (0.84) | 0.85 (0.85) | 0.90 (0.90) |
| seconds / pack | 0.99 | 1.2 | 3.9 | 3.8 |

Reading: English-only OCR cannot read Bangla labels at all; adding Bengali makes the fields readable; preprocessing + voting fixes the angled/rotated/dark cases for dates and licence numbers, but **hurts the batch number** on clean images (a measured trade-off, see DESIGN_AND_LIMITATIONS). The images are clean, single-font renderings, so absolute numbers are optimistic. **For the thesis, run the same script on 50–100 real labelled photos** (instructions at the top of `ocr-service/scripts/evaluate.py`) and add a column for "OCR + Gemini" by recording the merged values from the app.

## Stand-ins used only for testing
- `tests/shims/ethers` (Keccak-256 validated against published vectors) — unit tests only.
- `evidence/shims/*`: `next/server`, `better-sqlite3` over `node:sqlite`, an **unsigned** `jose`, `bcryptjs`, and throwing `sharp`/`tesseract.js` (the smoke test uses the OCR service path, not the local fallback).
- `evidence/sandbox_ocr_http_wrapper.py`: serves the real `read_photos` / `make_cover` functions over HTTP with the same request/response shape as the FastAPI endpoints (FastAPI could not be installed). The FastAPI route itself is covered by `ocr-service/tests/test_api_v4.py`, which was **not run** here.
- A `pydantic_settings` stand-in for the Python tests.

## Not tested here
- **Real Gemini calls** (model name, free-tier limits, real answer quality on Bangla photos). Request/response format follows Google's documented `generateContent` REST API; if a model name is rejected, the app falls back to OCR-only and shows the reason. First thing to check after adding your key: upload one label and see "AI reading: on".
- PaddleOCR in hybrid mode (not installable here; unchanged code path from v2).
- `next build` and the pages in a browser (type-checked only).
- The local tesseract.js fallback with `eng+ben` (needs the package and an internet download of the Bengali data).
- Real phone photos of real packs.
