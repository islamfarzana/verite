# Design decisions and limitations (v4)

## Why the OCR could not read Bangla before
PaddleOCR (the v2/v3 main engine) has no Bengali recognition model (its multilingual list covers Hindi, Marathi, Nepali, Tamil, Telugu, Urdu and others, not Bengali). The old Tesseract fallback ran English only and returned single words, so line-based rules ("MFG: …") failed. v4:
- adds Tesseract's LSTM Bengali model (`ben`) next to English, and keeps PaddleOCR for English (`OCR_ENGINE=hybrid`);
- groups Tesseract words back into lines;
- adds Bangla keyword rules (উৎপাদনের তারিখ, মেয়াদ উত্তীর্ণের তারিখ, ব্যাচ নং, সর্বোচ্চ খুচরা মূল্য, নিট ওজন, প্রস্তুতকারক, বিএসটিআই লাইসেন্স …), tolerant of common OCR confusions (ি/ী, ু/ূ, ৎ/ত্, য় composed or decomposed, "ঃ" used as a colon), Bengali digits and Bengali month names;
- extracts the product name in both scripts (`productName`, `productNameBn`).

## Robustness ("every state of image")
Perspective flattening (when the packet outline is a clear quadrilateral), 90/180/270° auto-rotation, upscaling small photos, three preprocessed variants and field-level voting. **Limits:** strong glare, heavy motion blur, text on tightly curved surfaces (bottles, crumpled sachets) and very small print can still fail. No OCR system reads every photo; the seller is shown "unable to read — retake or type" instead of a guess.

A measured trade-off (synthetic evaluation, see TEST_REPORT): the variant pipeline improved dates, manufacturer and licence numbers but made the **batch number worse** on clean images (the binarised/plain variants misread "LOT" as "107"). This is reported, not hidden; the AI cross-check is the intended remedy, and real-label evaluation must confirm the overall effect.

## AI (Gemini) — what it does and does not do
- **Provider:** Google Gemini API, free tier (Flash models are free of charge with rate limits; on the free tier Google states that content may be used to improve its products — acceptable here because packaging text is public). Default model `gemini-3.8-flash`, configurable. The key is server-side only (`GEMINI_API_KEY`, sent in the `x-goog-api-key` header; never in URLs, the browser or logs).
- **Label reading:** the model reads both photos and returns each field *exactly as printed*. We normalise dates/prices/weights ourselves, so the same rules apply to OCR and AI output.
- **Grounding check:** a value counts as confirmed only when OCR read the same value, or the AI's printed text appears in the independently OCR'd text (prices only on a price line). Otherwise it is flagged *AI only — please check* or *OCR and AI disagree — check*. Vision models can produce plausible but wrong values; in a product-authenticity system an invented expiry date is the worst failure, so the seller reviews every field before publishing (human-in-the-loop). The statuses are saved with the product (`product_label_extractions`) for audit.
- **Weekly summary:** numbers come from SQL. The AI only writes the sentences, and every number in its text is checked against the facts; if it invents or changes a number, the deterministic template is used instead.
- **Ask your shop:** the AI only classifies the question into one of six fixed intents. It never sees the database, writes SQL or produces the numbers; the server runs a fixed query on the seller's **own** products. Without a key, a Bangla/English keyword matcher is used.
- **Fail-safe:** no key, quota exhausted (429), timeout, network error or a malformed answer → OCR-only results / template text; nothing breaks. Per-user and per-day limits protect the free quota (`AI_REQUESTS_PER_MINUTE_PER_USER`, `AI_REQUESTS_PER_DAY`).
- **Not done:** the AI is never allowed to approve sellers, verify licences or decide authenticity.

## Enhanced cover photo — why not generative AI
Generative image models redraw packaging and routinely change text (Bangla especially), logos, weights and colours. On a platform whose purpose is "what you see is genuine", the cover must show the real packet. v4 therefore uses classic computer vision on the seller's real photo: GrabCut segmentation (seeded from the border colour when the background is plain), largest-region cleanup, perspective flattening, and placement on a white square. **No colour or tone changes** — an automatic white balance tried during development shifted brand colours and was removed. The image is labelled "Enhanced from the seller's photo" for buyers and the original stays in the gallery. Limits: busy or similar-coloured backgrounds may give "crop-only" (no background removal).

## Seller assistant — rules, not guesses
Velocity = units in the last 28 days ÷ 28 (or the product's age, minimum 7 days). Days of cover = stock ÷ velocity. Expiry risk = stock − velocity × days to expiry. Thresholds are configurable (`ASSISTANT_*`). Alerts are stored once per product, kind and Dhaka calendar day. Checks run when the assistant opens (at most hourly) and by `npm run assistant:check` (schedule it with cron / Windows Task Scheduler / a hosting cron). **Limits:** a moving average is not a seasonal forecast; with little sales history the numbers are rough. Demo sales are **simulated** (`SIM-` orders, shown as simulated in the UI) and must be presented as such.

## Privacy and security
- Label photos go to Google only when `GEMINI_API_KEY` is set; sellers' private data (emails, licence numbers on file, other sellers' sales) is never sent.
- All new seller endpoints require a seller session and only read/write the seller's own data (tested). `/api/ocr/extract` now requires a seller session (it previously had none) because it spends AI quota.
- State-changing assistant endpoints accept JSON only (CSRF guard, same as v3).

## What is unchanged
Auth, buyer flows, cart/checkout/orders/payments, blockchain contract and hashing, v3 identity/licence workflow, QR traceability. The `ocr-service` API is backwards compatible: `backImage` is optional and new response fields are additions.
