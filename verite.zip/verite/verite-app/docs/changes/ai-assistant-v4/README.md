# v4: Bangla + English label reading, AI cross-check, enhanced cover photo, seller assistant

Date: 2026-10-28. Builds on v3 (seller onboarding and licence verification), which is unchanged.

## What was added

| Feature | Where | AI? |
|---|---|---|
| **Bangla + English OCR** from the **front and back** photos | `ocr-service`: Tesseract `ben+eng` (PaddleOCR has no Bengali model), Bangla keyword rules, Bengali digits and month names | No (classic OCR) |
| **Robust photo handling** | `ocr-service/app/services/preprocessing.py`: perspective flattening (four-point transform), auto-rotation (Tesseract OSD), 2x upscaling of small photos, 3 preprocessed variants with **field-level voting** | No |
| **AI label reading + grounding check** | `verite-app/lib/ai/*`, `app/api/ocr/extract`: Gemini reads both photos; every field gets a status: *OCR + AI agree*, *AI, confirmed by OCR text*, *OCR only*, *AI only — please check*, *OCR and AI disagree — check* | Gemini (free tier) |
| **Enhanced cover photo** from the real front photo | `ocr-service/app/services/cover.py` (GrabCut background removal, perspective flatten, white square), `app/api/ocr/cover`; labelled "Enhanced from the seller's photo"; original kept in the gallery | No (deliberately not generative) |
| **Seller Assistant** | `verite-app/lib/assistant/*`, `/seller/assistant`: stock-out forecast, low/out-of-stock, expired-but-listed, expiring soon, expiry risk (stock likely to expire unsold), best sellers, slow movers, 28-day chart, weekly summary (EN/বাংলা), "ask your shop" | Gemini writes the summary (numbers checked) and classifies questions; all numbers come from the database |
| **OCR evaluation tool** | `ocr-service/scripts/evaluate.py`: field-level precision/recall on labelled photos, with ablations | No |

## Run it

### 1. OCR service (Codespace / Docker) — rebuild, the image changed
```bash
cd ocr-service
docker compose build ocr-api          # installs tesseract-ocr-ben (Bengali)
docker compose up -d --no-deps ocr-api
```
(If you use the SQLite `docker-compose.override.yml` from before, keep it.) New settings, all optional, in `ocr-service/.env`:
`OCR_ENGINE=hybrid` (default: PaddleOCR + Tesseract ben+eng), `TESSERACT_LANG=ben+eng`, `OCR_TRY_VARIANTS=true`, `OCR_PERSPECTIVE_CORRECTION=true`, `OCR_AUTO_ORIENT=true`.

### 2. Website
Add to `verite-app/.env` (see `.env.example`):
```
GEMINI_API_KEY=your-key-from-aistudio.google.com     # optional; without it everything still works, without AI
GEMINI_MODEL=gemini-3.8-flash
OCR_SERVICE_URL=https://<your-codespace>-8000.app.github.dev
OCR_SERVICE_TIMEOUT_MS=60000
```
Then:
```bash
npm install
npm run seed                 # unchanged demo data (+ pending demo business from v3)
npm run simulate:sales       # SIMULATED order history (SIM- orders) so the assistant has data
npm run dev
```
Remove the simulated orders again with `npm run simulate:sales -- --clear`.

### 3. Demo path (about 5 minutes)
1. Admin → Seller Reviews → approve **GreenMart BD** (v3 step).
2. Seller → **Seller Studio** → *Upload Label (front of pack)* → *Add back of pack*. Watch the chips next to each field; open a field marked *AI only — please check* and compare with the pack.
3. *Make enhanced cover photo* → the cover slot gets the cleaned photo with the label "Enhanced from your photo"; the original goes into the gallery.
4. Publish → product page shows the Bangla name and the enhanced-photo caption.
5. Seller → **Assistant**: alerts (the seeded noodles and milk are past their expiry date but still listed — a real-world problem the assistant catches), best sellers, stock table, *Write summary* in বাংলা, ask "কোন পণ্যের স্টক শেষ হয়ে যাচ্ছে?".

### 4. Tests
```bash
cd verite-app && npm run test:ai && npm run test:assistant && npm run test:identity && npm run test:trace
cd ocr-service && pytest            # needs tesseract with the 'ben' language (inside the Docker image)
python scripts/evaluate.py --images <folder> --truth <folder>/truth.csv --out results/   # real-label evaluation
```

See `DESIGN_AND_LIMITATIONS.md` and `TEST_REPORT.md`.
