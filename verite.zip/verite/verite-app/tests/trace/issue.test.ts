import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, addProduct, addUser, seller1, seller2, admin1, buyer1 } from './helpers';
import { issueIdentifiers, revokeIdentifier, listIdentifiers, TraceError, MAX_UNITS_PER_REQUEST } from '../../lib/trace/service';

const req = (n: number) => `req-${String(n).padStart(8, '0')}`;

test('separately issued identifiers are all distinct (unit and batch)', () => {
  const db = fixture();
  addProduct(db, 'prod2', 'seller1', 'PUBLISHED', '8900000000002');
  const units = issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 50, requestId: req(1), actor: seller1 });
  const batch = issueIdentifiers(db, { productId: 'prod2', scope: 'BATCH', requestId: req(2), actor: seller1 });
  const tokens = new Set([...units.identifiers, ...batch.identifiers].map((i) => i.token));
  assert.equal(tokens.size, 51);
  assert.deepEqual(units.identifiers.map((i) => i.unitSerial), Array.from({ length: 50 }, (_, i) => i + 1));
});

test('unit serials continue after a second issuance; batch identifiers carry no serial', () => {
  const db = fixture();
  issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 3, requestId: req(1), actor: seller1 });
  const more = issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 2, requestId: req(2), actor: seller1 });
  assert.deepEqual(more.identifiers.map((i) => i.unitSerial), [4, 5]);
  const b = issueIdentifiers(db, { productId: 'prod1', scope: 'BATCH', requestId: req(3), actor: seller1 });
  assert.equal(b.identifiers[0].unitSerial, null);
});

test('issuance is idempotent: same requestId returns the same identifiers; second batch request reuses the batch code', () => {
  const db = fixture();
  const a = issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 4, requestId: req(1), actor: seller1 });
  const b = issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 4, requestId: req(1), actor: seller1 });
  assert.equal(b.created, false);
  assert.deepEqual(b.identifiers.map((i) => i.token), a.identifiers.map((i) => i.token));
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM trace_identifiers').get().n, 4);
  const b1 = issueIdentifiers(db, { productId: 'prod1', scope: 'BATCH', requestId: req(2), actor: seller1 });
  const b2 = issueIdentifiers(db, { productId: 'prod1', scope: 'BATCH', requestId: req(3), actor: seller1 });
  assert.equal(b2.created, false);
  assert.equal(b2.identifiers[0].token, b1.identifiers[0].token);
});

test('a token collision is retried and succeeds within the bound', () => {
  const db = fixture();
  const first = issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 1, requestId: req(1), actor: seller1 }, { randomBytesFn: (n) => Buffer.alloc(n, 7) });
  let calls = 0;
  const colliding = (n: number) => { calls++; return calls <= 2 ? Buffer.alloc(n, 7) : Buffer.alloc(n, 9); };
  const second = issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 1, requestId: req(2), actor: seller1 }, { randomBytesFn: colliding });
  assert.equal(calls, 3);
  assert.notEqual(second.identifiers[0].token, first.identifiers[0].token);
});

test('collisions that never resolve fail safely and roll back everything', () => {
  const db = fixture();
  issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 1, requestId: req(1), actor: seller1 }, { randomBytesFn: (n) => Buffer.alloc(n, 7) });
  assert.throws(
    () => issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 3, requestId: req(2), actor: seller1 }, { randomBytesFn: (n) => Buffer.alloc(n, 7) }),
    (e: unknown) => e instanceof TraceError && e.code === 'COLLISION_EXHAUSTED'
  );
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM trace_identifiers').get().n, 1);
});

test('authorisation: other sellers and buyers cannot issue, list or revoke; admin can', () => {
  const db = fixture();
  const code = (fn: () => unknown) => { try { fn(); return 'ok'; } catch (e) { return (e as TraceError).code; } };
  assert.equal(code(() => issueIdentifiers(db, { productId: 'prod1', scope: 'BATCH', requestId: req(1), actor: seller2 })), 'FORBIDDEN');
  assert.equal(code(() => issueIdentifiers(db, { productId: 'prod1', scope: 'BATCH', requestId: req(1), actor: buyer1 })), 'FORBIDDEN');
  assert.equal(code(() => issueIdentifiers(db, { productId: 'prod1', scope: 'BATCH', requestId: req(1), actor: admin1 })), 'ok');
  const id = listIdentifiers(db, 'prod1', seller1)[0].id;
  assert.equal(code(() => listIdentifiers(db, 'prod1', seller2)), 'FORBIDDEN');
  assert.equal(code(() => revokeIdentifier(db, { identifierId: id, reason: 'attempt', actor: seller2 })), 'FORBIDDEN');
  assert.equal(code(() => revokeIdentifier(db, { identifierId: id, reason: 'lost label batch', actor: seller1 })), 'ok');
});

test('eligibility and input validation', () => {
  const db = fixture();
  addProduct(db, 'draft1', 'seller1', 'DRAFT', '8900000000003');
  const code = (fn: () => unknown) => { try { fn(); return 'ok'; } catch (e) { return (e as TraceError).code; } };
  assert.equal(code(() => issueIdentifiers(db, { productId: 'draft1', scope: 'BATCH', requestId: req(1), actor: seller1 })), 'NOT_ELIGIBLE');
  assert.equal(code(() => issueIdentifiers(db, { productId: 'nope', scope: 'BATCH', requestId: req(1), actor: seller1 })), 'NOT_FOUND');
  assert.equal(code(() => issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: MAX_UNITS_PER_REQUEST + 1, requestId: req(1), actor: seller1 })), 'INVALID');
  assert.equal(code(() => issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 0, requestId: req(1), actor: seller1 })), 'INVALID');
  assert.equal(code(() => issueIdentifiers(db, { productId: 'prod1', scope: 'WHATEVER' as any, requestId: req(1), actor: seller1 })), 'INVALID');
  assert.equal(code(() => issueIdentifiers(db, { productId: 'prod1', scope: 'BATCH', requestId: 'bad id!', actor: seller1 })), 'INVALID');
});

test('database enforces uniqueness, foreign keys and lifecycle rules, not just application code', () => {
  const db = fixture();
  const [u] = issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 1, requestId: req(1), actor: seller1 }).identifiers;
  const ins = (id: string, token: string, scope: string, pid: string, serial: number | null) =>
    db.prepare("INSERT INTO trace_identifiers (id, token, scope, product_id, unit_serial, issue_group, issued_by, created_at) VALUES (?,?,?,?,?,'g','seller1','2026-01-01T00:00:00.000Z')").run(id, token, scope, pid, serial);
  assert.throws(() => ins('x1', u.token, 'UNIT', 'prod1', 99), /UNIQUE constraint failed: trace_identifiers\.token/);
  assert.throws(() => ins('x2', 'T'.repeat(24), 'UNIT', 'prod1', 1), /UNIQUE/);                // duplicate (product, serial)
  assert.throws(() => ins('x3', 'U'.repeat(24), 'UNIT', 'no_such_product', 5), /FOREIGN KEY/);
  assert.throws(() => ins('x4', 'V'.repeat(24), 'UNIT', 'prod1', null), /CHECK/);              // unit needs a serial
  ins('b1', 'W'.repeat(24), 'BATCH', 'prod1', null);
  assert.throws(() => ins('b2', 'X'.repeat(24), 'BATCH', 'prod1', null), /UNIQUE/);            // one batch code per product
  assert.throws(() => db.prepare("UPDATE trace_identifiers SET product_id = 'other' WHERE id = ?").run(u.id), /immutable/);
  assert.throws(() => db.prepare("UPDATE trace_identifiers SET token = 'Z' WHERE id = ?").run(u.id), /immutable/);
});

test('a revoked identifier can never be reactivated, even by direct SQL', () => {
  const db = fixture();
  const [u] = issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 1, requestId: req(1), actor: seller1 }).identifiers;
  assert.equal(revokeIdentifier(db, { identifierId: u.id, reason: 'label lost in transit', actor: seller1 }).changed, true);
  assert.equal(revokeIdentifier(db, { identifierId: u.id, reason: 'label lost in transit', actor: seller1 }).changed, false);
  assert.throws(() => db.prepare("UPDATE trace_identifiers SET status = 'ACTIVE' WHERE id = ?").run(u.id), /cannot be reactivated/);
  assert.throws(() => revokeIdentifier(db, { identifierId: u.id, reason: 'x', actor: seller1 }), (e: unknown) => (e as TraceError).code === 'INVALID');
});
