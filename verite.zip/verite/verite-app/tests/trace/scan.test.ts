import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, addProduct, seller1, cfg, at } from './helpers';
import { issueIdentifiers, revokeIdentifier, processScan, handleScanRequest, pruneScanEvents, evaluateScanPattern, MESSAGES } from '../../lib/trace/service';
import { FixedWindowLimiter } from '../../lib/trace/ratelimit';
import { generateToken } from '../../lib/trace/token';

const T0 = '2026-03-01T10:00:00.000Z';
const plus = (min: number) => at(new Date(Date.parse(T0) + min * 60_000).toISOString());
const issueUnit = (db: any) => issueIdentifiers(db, { productId: 'prod1', scope: 'UNIT', quantity: 1, requestId: 'req-00000001', actor: seller1 }).identifiers[0];
const issueBatch = (db: any, pid = 'prod1') => issueIdentifiers(db, { productId: pid, scope: 'BATCH', requestId: 'req-00000002', actor: seller1 }).identifiers[0];
const scan = (db: any, token: unknown, src: string | null, now: Date, c = cfg()) => processScan(db, { token, sourceHash: src, now }, c);
const events = (db: any) => db.prepare('SELECT * FROM scan_events ORDER BY created_at, rowid').all();

test('malformed tokens never touch the database', () => {
  const exploding: any = { prepare() { throw new Error('database must not be used'); }, exec() { throw new Error('database must not be used'); } };
  for (const bad of ['', 'short', 'x'.repeat(40), "'; DROP TABLE users;--", null, undefined, 123]) {
    const r = scan(exploding, bad, 'a', at(T0));
    assert.equal(r.status, 'UNKNOWN_IDENTIFIER');
  }
});

test('unknown token: generic answer, event recorded without the token', () => {
  const db = fixture();
  const unknown = generateToken();
  const r = scan(db, unknown, 'src1', at(T0));
  assert.equal(r.status, 'UNKNOWN_IDENTIFIER');
  assert.equal(r.product, undefined);
  const ev = events(db);
  assert.equal(ev.length, 1);
  assert.equal(ev[0].identifier_id, null);
  assert.ok(!JSON.stringify(ev).includes(unknown), 'the scanned token must not be stored');
});

test('a product barcode is not an identifier: scanning it as a token never resolves', () => {
  const db = fixture();
  issueBatch(db);
  const r = scan(db, '8901234567890', 'a', at(T0));
  assert.equal(r.status, 'UNKNOWN_IDENTIFIER');
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM scan_events WHERE identifier_id IS NOT NULL").get().n, 0);
});

test('resolution returns the right scope and approved product fields only', () => {
  const db = fixture();
  const u = issueUnit(db);
  const r = scan(db, u.token, 's', at(T0));
  assert.equal(r.status, 'VALID'); assert.equal(r.scope, 'UNIT'); assert.equal(r.warning, false);
  assert.equal(r.product?.name, 'Demo Rice 5kg'); assert.equal(r.product?.batchNumber, 'LOT-DEMO-1');
  assert.equal(r.product?.productPath, '/product/prod1');
  const json = JSON.stringify(r);
  for (const leaked of ['seller1', 'example.test', 'password', 'issued_by', 'source_hash', u.id, u.token]) assert.ok(!json.includes(leaked), `response must not contain ${leaked}`);
});

test('messages never overclaim: any mention of genuine/counterfeit only appears inside a "does not prove" clause', () => {
  for (const text of Object.values(MESSAGES)) {
    const withoutNegatedClaims = text.replace(/does not prove[^.]*\./gi, '');
    assert.ok(!/genuine|authentic|verified|counterfeit|\bfake\b/i.test(withoutNegatedClaims), `overclaiming wording in: ${text}`);
  }
  assert.match(MESSAGES.validUnit, /does not prove/);
  assert.match(MESSAGES.validBatch, /batch, not an individual/);
  assert.match(MESSAGES.suspicious, /does not prove counterfeiting/);
});

test('UNIT code: warning appears on the 3rd scan within the window and persists while the condition holds', () => {
  const db = fixture(); const u = issueUnit(db);
  assert.equal(scan(db, u.token, 'a', plus(0)).status, 'VALID');
  assert.equal(scan(db, u.token, 'a', plus(10)).status, 'VALID');
  const third = scan(db, u.token, 'a', plus(20));
  assert.equal(third.status, 'SUSPICIOUS_ACTIVITY'); assert.equal(third.warning, true); assert.ok(third.guidance);
  assert.equal(scan(db, u.token, 'a', plus(30)).status, 'SUSPICIOUS_ACTIVITY');            // no cool-down
  assert.deepEqual(events(db).map((e: any) => e.outcome), ['VALID', 'VALID', 'SUSPICIOUS', 'SUSPICIOUS']);
});

test('rolling window: old scans stop counting and the warning clears', () => {
  const db = fixture(); const u = issueUnit(db);
  scan(db, u.token, 'a', plus(0)); scan(db, u.token, 'a', plus(10));
  assert.equal(scan(db, u.token, 'a', plus(1500)).status, 'VALID');       // first two are > 1440 min old
  assert.equal(scan(db, u.token, 'a', plus(1501)).status, 'VALID');
  assert.equal(scan(db, u.token, 'a', plus(1502)).status, 'SUSPICIOUS_ACTIVITY');
});

test('window boundary is inclusive of the window start', () => {
  const db = fixture(); const u = issueUnit(db);
  scan(db, u.token, 'a', plus(0)); scan(db, u.token, 'a', plus(1));
  assert.equal(scan(db, u.token, 'a', plus(1440)).status, 'SUSPICIOUS_ACTIVITY'); // scan at +0 is exactly at the window start
  const db2 = fixture(); const u2 = issueUnit(db2);
  scan(db2, u2.token, 'a', plus(0)); scan(db2, u2.token, 'a', plus(1));
  assert.equal(scan(db2, u2.token, 'a', plus(1441)).status, 'VALID');
});

test('distinct-source rule: same source alone stays VALID, two sources raise the warning', () => {
  const c = cfg({ distinctSourceThreshold: 2 });
  const db = fixture(); const u = issueUnit(db);
  for (let i = 0; i < 5; i++) assert.equal(scan(db, u.token, 'same', plus(i), c).status, 'VALID');
  const db2 = fixture(); const u2 = issueUnit(db2);
  scan(db2, u2.token, 'a', plus(0), c); scan(db2, u2.token, 'a', plus(1), c);
  assert.equal(scan(db2, u2.token, 'b', plus(2), c).status, 'SUSPICIOUS_ACTIVITY');
});

test('BATCH code uses its own, much higher threshold and softer wording', () => {
  const db = fixture(); const b = issueBatch(db);
  for (let i = 0; i < 99; i++) assert.equal(scan(db, b.token, 'a', plus(i % 1000)).status, 'VALID');
  const r = scan(db, b.token, 'a', plus(100));
  assert.equal(r.status, 'SUSPICIOUS_ACTIVITY'); assert.match(r.message, /batch, not an individual/);
});

test('threshold is configurable and evaluateScanPattern is a pure rule', () => {
  assert.equal(evaluateScanPattern('UNIT', 4, 1, cfg({ thresholdUnit: 5 })).suspicious, false);
  assert.equal(evaluateScanPattern('UNIT', 5, 1, cfg({ thresholdUnit: 5 })).suspicious, true);
  assert.equal(evaluateScanPattern('UNIT', 9, 1, cfg({ distinctSourceThreshold: 2 })).suspicious, false);
});

test('revoked identifier: REVOKED result with no product data; event recorded', () => {
  const db = fixture(); const u = issueUnit(db);
  revokeIdentifier(db, { identifierId: u.id, reason: 'label printed wrongly', actor: seller1 });
  const r = scan(db, u.token, 'a', at(T0));
  assert.equal(r.status, 'REVOKED'); assert.equal(r.product, undefined);
  assert.equal(events(db)[0].outcome, 'REVOKED');
});

test('identifier of an unpublished product does not pass as valid', () => {
  const db = fixture(); const u = issueUnit(db);
  db.prepare("UPDATE products SET status = 'DRAFT' WHERE id = 'prod1'").run();
  assert.equal(scan(db, u.token, 'a', at(T0)).status, 'UNKNOWN_IDENTIFIER');
  assert.equal(events(db)[0].reason, 'product_not_published');
});

test('events store a keyed hash and a reason, never an IP address', () => {
  const db = fixture(); const u = issueUnit(db);
  scan(db, u.token, 'a1b2c3d4e5f60718293a4b5c6d7e8f90', at(T0));
  const ev = events(db)[0];
  assert.deepEqual(Object.keys(ev).sort(), ['created_at', 'id', 'identifier_id', 'outcome', 'reason', 'source_hash']);
  assert.doesNotMatch(JSON.stringify(ev), /\b\d{1,3}(\.\d{1,3}){3}\b/);
});

test('handler: infrastructure failure is UNAVAILABLE (503), never VALID, and never leaks the token', () => {
  const broken: any = { prepare() { throw new Error('disk I/O error'); }, exec() { throw new Error('disk I/O error'); } };
  const secret = 'test-secret';
  const logged: string[] = []; const origErr = console.error; console.error = (...a: unknown[]) => logged.push(a.join(' '));
  try {
    const token = generateToken();
    const res = handleScanRequest({ db: broken, config: cfg(), secret, limiter: new FixedWindowLimiter(10) }, { rawBody: JSON.stringify({ token }), ip: '203.0.113.9' });
    assert.equal(res.status, 503);
    assert.equal((res.body as any).data.status, 'UNAVAILABLE');
    assert.ok(!JSON.stringify(res.body).includes(token));
    assert.ok(!logged.join(' ').includes(token));
  } finally { console.error = origErr; }
});

test('handler: rate limiting returns 429 without writing events; oversized bodies are refused', () => {
  const db = fixture(); const u = issueUnit(db);
  const deps = { db, config: cfg(), secret: 's', limiter: new FixedWindowLimiter(3), now: at(T0) };
  const call = () => handleScanRequest(deps, { rawBody: JSON.stringify({ token: u.token }), ip: '198.51.100.20' });
  assert.deepEqual([call().status, call().status, call().status, call().status], [200, 200, 200, 429]);
  assert.equal(events(db).length, 3);
  assert.equal(handleScanRequest(deps, { rawBody: 'x'.repeat(5000), ip: '198.51.100.21' }).status, 413);
});

test('handler: a different network is limited independently; garbage JSON is a safe unknown result', () => {
  const db = fixture();
  const deps = { db, config: cfg(), secret: 's', limiter: new FixedWindowLimiter(1), now: at(T0) };
  assert.equal(handleScanRequest(deps, { rawBody: '{}', ip: '203.0.113.1' }).status, 200);
  assert.equal(handleScanRequest(deps, { rawBody: '{}', ip: '203.0.113.1' }).status, 429);
  const other = handleScanRequest(deps, { rawBody: '{not json', ip: '192.0.2.1' });
  assert.equal(other.status, 200); assert.equal((other.body as any).data.status, 'UNKNOWN_IDENTIFIER');
});

test('retention: pruning removes only events older than the cutoff', () => {
  const db = fixture(); const u = issueUnit(db);
  scan(db, u.token, 'a', at('2025-10-01T00:00:00.000Z')); scan(db, u.token, 'a', at('2026-03-01T00:00:00.000Z'));
  assert.equal(pruneScanEvents(db, at('2026-03-10T00:00:00.000Z'), 90), 1);
  assert.equal(events(db).length, 1);
});

test('a copied barcode (same EAN on many products) cannot be used to read identifiers', () => {
  const db = fixture(); addProduct(db, 'prod9', 'seller1', 'PUBLISHED', '8900000000009');
  const b = issueBatch(db);
  assert.equal(scan(db, b.token, 'a', at(T0)).scope, 'BATCH');
  assert.equal(scan(db, '8900000000009', 'a', at(T0)).status, 'UNKNOWN_IDENTIFIER');
});
