import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { TRACE_SCHEMA_SQL } from '../../lib/trace/schema';
import { DEFAULT_SCAN_CONFIG, type ScanConfig } from '../../lib/trace/config';
import type { Db } from '../../lib/trace/types';

// Build a test database from the REAL table definitions in lib/db.ts (users, categories,
// products), so the fixture cannot drift from the application schema.
function realTable(name: string): string {
  const src = readFileSync(join(__dirname, '../../lib/db.ts'), 'utf8');
  const m = src.match(new RegExp(`CREATE TABLE IF NOT EXISTS ${name} \\([\\s\\S]*?\\n\\);`));
  if (!m) throw new Error(`table ${name} not found in lib/db.ts`);
  return m[0];
}

export function makeDb(): Db {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  for (const t of ['users', 'categories', 'products']) db.exec(realTable(t));
  db.exec(TRACE_SCHEMA_SQL);
  return db as unknown as Db;
}

export function addUser(db: Db, id: string, role: 'BUYER' | 'SELLER' | 'ADMIN' = 'SELLER') {
  db.prepare('INSERT INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)').run(id, id, `${id}@example.test`, 'x', role);
}

export function addProduct(db: Db, id: string, sellerId: string, status: 'DRAFT' | 'PUBLISHED' = 'PUBLISHED', barcode = '8901234567890') {
  db.prepare(
    `INSERT INTO products (id, seller_id, name, brand, barcode, batch_number, manufacturing_date, expiry_date, price, stock, status)
     VALUES (?, ?, 'Demo Rice 5kg', 'DemoBrand', ?, 'LOT-DEMO-1', '2026-01-01', '2027-01-01', 100, 10, ?)`
  ).run(id, sellerId, barcode, status);
}

export function fixture() {
  const db = makeDb();
  addUser(db, 'seller1'); addUser(db, 'seller2'); addUser(db, 'admin1', 'ADMIN'); addUser(db, 'buyer1', 'BUYER');
  addProduct(db, 'prod1', 'seller1');
  return db;
}

export const seller1 = { id: 'seller1', role: 'SELLER' as const };
export const seller2 = { id: 'seller2', role: 'SELLER' as const };
export const admin1 = { id: 'admin1', role: 'ADMIN' as const };
export const buyer1 = { id: 'buyer1', role: 'BUYER' as const };
export const cfg = (over: Partial<ScanConfig> = {}): ScanConfig => ({ ...DEFAULT_SCAN_CONFIG, ...over });
export const at = (iso: string) => new Date(iso);
