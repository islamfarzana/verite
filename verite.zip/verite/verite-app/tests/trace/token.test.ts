import test from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { generateToken, isValidToken, buildScanUrl, TOKEN_BYTES } from '../../lib/trace/token';
import { loadScanConfig, getPublicBaseUrl } from '../../lib/trace/config';
import { coarseSource, sourceHash } from '../../lib/trace/source';

test('token generation asks the secure random source for 18 bytes and encodes them to 24 URL-safe chars', () => {
  let asked = 0;
  const token = generateToken((n) => { asked = n; return Buffer.alloc(n, 0xab); });
  assert.equal(asked, TOKEN_BYTES);
  assert.equal(TOKEN_BYTES, 18);
  assert.equal(token.length, 24);
  assert.ok(isValidToken(token));
});

test('default generator yields distinct, valid tokens', () => {
  const seen = new Set<string>();
  for (let i = 0; i < 500; i++) { const t = generateToken(); assert.ok(isValidToken(t)); seen.add(t); }
  assert.equal(seen.size, 500);
});

test('implementation path: lib/trace uses crypto.randomBytes and never Math.random', () => {
  const dir = join(__dirname, '../../lib/trace');
  for (const f of readdirSync(dir)) assert.ok(!/Math\.random/.test(readFileSync(join(dir, f), 'utf8').replace(/\/\/.*|\/\*[\s\S]*?\*\//g, '')), `${f} must not use Math.random`);
  assert.match(readFileSync(join(dir, 'token.ts'), 'utf8'), /from 'crypto'/);
});

test('token validation rejects wrong length, characters and types', () => {
  for (const bad of ['', 'short', 'x'.repeat(23), 'x'.repeat(25), 'a'.repeat(23) + '!', '8901234567890', null, undefined, 42, {}, ['a'.repeat(24)]]) {
    assert.equal(isValidToken(bad as unknown), false);
  }
});

test('QR payload is versioned, opaque, built from the trusted base URL only', () => {
  const t = generateToken();
  assert.equal(buildScanUrl('https://shop.example.invalid/some/path?x=1', t), `https://shop.example.invalid/scan/v1/${t}`);
  assert.throws(() => buildScanUrl('javascript:alert(1)', t));
  assert.throws(() => buildScanUrl('https://shop.example.invalid', 'not-a-token'));
});

test('source signal is a keyed hash of a coarse prefix: no raw IP, same /24 collapses', () => {
  assert.equal(coarseSource('203.0.113.77'), '203.0.113.0/24');
  const a = sourceHash('203.0.113.5', 'k1'), b = sourceHash('203.0.113.200', 'k1'), c = sourceHash('198.51.100.5', 'k1');
  assert.equal(a, b); assert.notEqual(a, c); assert.notEqual(a, sourceHash('203.0.113.5', 'k2'));
  assert.ok(!a.includes('203') || /^[0-9a-f]{32}$/.test(a));
  assert.match(a, /^[0-9a-f]{32}$/);
});

test('config: defaults, overrides, and invalid values are rejected', () => {
  assert.equal(loadScanConfig({}).thresholdUnit, 3);
  assert.equal(loadScanConfig({ SCAN_WARNING_THRESHOLD_UNIT: '5' }).thresholdUnit, 5);
  assert.throws(() => loadScanConfig({ SCAN_WARNING_THRESHOLD_UNIT: '0' }));
  assert.throws(() => loadScanConfig({ SCAN_WARNING_WINDOW_MINUTES: 'abc' }));
  assert.throws(() => loadScanConfig({ SCAN_WARNING_WINDOW_MINUTES: '200000', SCAN_EVENT_RETENTION_DAYS: '10' }));
  assert.equal(getPublicBaseUrl({}), 'http://localhost:3000');
  assert.throws(() => getPublicBaseUrl({ NODE_ENV: 'production' }));
});
