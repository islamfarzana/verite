import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AiError, generateJson, loadGeminiConfig, type FetchLike } from '../../lib/ai/gemini';

const cfg = { apiKey: 'test-key-123', model: 'gemini-test', baseUrl: 'https://example.test', timeoutMs: 50 };

function fake(responses: { status: number; body?: unknown; throws?: Error }[], seen: any[] = []): FetchLike {
  return async (url, init) => {
    seen.push({ url, init, body: JSON.parse(init.body) });
    const r = responses.length > 1 ? responses.shift()! : responses[0];
    if (r.throws) throw r.throws;
    return { status: r.status, json: async () => r.body };
  };
}
const ok = (text: string) => ({ status: 200, body: { candidates: [{ content: { parts: [{ text }] }, finishReason: 'STOP' }] } });

async function rejectsWith(p: Promise<unknown>, category: string) {
  await assert.rejects(p, (e: unknown) => e instanceof AiError && e.category === category);
}

test('config: no key -> AI off; key -> defaults; AI_PROVIDER=off disables', () => {
  assert.equal(loadGeminiConfig({}), null);
  const c = loadGeminiConfig({ GEMINI_API_KEY: 'k' })!;
  assert.equal(c.model, 'gemini-3.8-flash');
  assert.equal(c.baseUrl, 'https://generativelanguage.googleapis.com');
  assert.equal(loadGeminiConfig({ GEMINI_API_KEY: 'k', AI_PROVIDER: 'off' }), null);
  assert.equal(loadGeminiConfig({ GEMINI_API_KEY: 'k', GEMINI_MODEL: 'gemini-3.5-flash-lite' })!.model, 'gemini-3.5-flash-lite');
});

test('request: key only in the x-goog-api-key header, JSON mode + schema, inline image data', async () => {
  const seen: any[] = [];
  const out = await generateJson<{ a: number }>(cfg, {
    parts: [{ text: 'hi' }, { inline_data: { mime_type: 'image/jpeg', data: 'QUJD' } }], schema: { type: 'OBJECT' }, system: 'sys',
  }, fake([ok('{"a":1}')], seen));
  assert.deepEqual(out, { a: 1 });
  assert.equal(seen[0].url, 'https://example.test/v1beta/models/gemini-test:generateContent');
  assert.ok(!seen[0].url.includes('test-key-123'), 'key never in the URL');
  assert.equal(seen[0].init.headers['x-goog-api-key'], 'test-key-123');
  assert.equal(seen[0].body.generation_config.response_mime_type, 'application/json');
  assert.deepEqual(seen[0].body.generation_config.response_schema, { type: 'OBJECT' });
  assert.equal(seen[0].body.generation_config.temperature, 0);
  assert.equal(seen[0].body.contents[0].parts[1].inline_data.mime_type, 'image/jpeg');
  assert.equal(seen[0].body.system_instruction.parts[0].text, 'sys');
});

test('a 400 (schema not accepted) is retried once without the schema', async () => {
  const seen: any[] = [];
  const out = await generateJson(cfg, { parts: [{ text: 'x' }], schema: { type: 'OBJECT' } }, fake([{ status: 400, body: {} }, ok('{"b":2}')], seen));
  assert.deepEqual(out, { b: 2 });
  assert.equal(seen.length, 2);
  assert.equal(seen[1].body.generation_config.response_schema, undefined);
  assert.equal(seen[1].body.generation_config.response_mime_type, 'application/json');
});

test('JSON wrapped in a code fence is accepted', async () => {
  assert.deepEqual(await generateJson(cfg, { parts: [{ text: 'x' }] }, fake([ok('```json\n{"c":3}\n```')])), { c: 3 });
});

test('failures map to safe categories', async () => {
  await rejectsWith(generateJson(null, { parts: [] }), 'NOT_CONFIGURED');
  await rejectsWith(generateJson(cfg, { parts: [] }, fake([{ status: 429, body: {} }])), 'RATE_LIMITED');
  await rejectsWith(generateJson(cfg, { parts: [] }, fake([{ status: 403, body: {} }])), 'AUTH');
  await rejectsWith(generateJson(cfg, { parts: [] }, fake([{ status: 404, body: {} }])), 'BAD_REQUEST');
  await rejectsWith(generateJson(cfg, { parts: [] }, fake([{ status: 503, body: {} }])), 'SERVER');
  await rejectsWith(generateJson(cfg, { parts: [] }, fake([{ status: 200, throws: new TypeError('fetch failed') }])), 'NETWORK');
  await rejectsWith(generateJson(cfg, { parts: [] }, fake([{ status: 200, body: { promptFeedback: { blockReason: 'SAFETY' } } }])), 'BLOCKED');
  await rejectsWith(generateJson(cfg, { parts: [] }, fake([{ status: 200, body: { candidates: [] } }])), 'MALFORMED');
  await rejectsWith(generateJson(cfg, { parts: [] }, fake([ok('not json at all')])), 'MALFORMED');
});

test('a hung request times out (bounded wait)', async () => {
  const hang: FetchLike = (_u, init) => new Promise((_r, rej) => init.signal.addEventListener('abort', () => rej(Object.assign(new Error('x'), { name: 'AbortError' }))));
  await rejectsWith(generateJson(cfg, { parts: [] }, hang), 'TIMEOUT');
});
