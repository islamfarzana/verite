import { test } from 'node:test';
import assert from 'node:assert/strict';
import { aiReadLabel, groundedInOcr, LABEL_FIELDS, LABEL_SYSTEM_PROMPT, mergeOcrAndAi, type AiLabelResult } from '../../lib/ai/label-extract';
import type { FetchLike } from '../../lib/ai/gemini';

const cfg = { apiKey: 'k', model: 'm', baseUrl: 'https://example.test', timeoutMs: 1000 };
const answer = (obj: unknown): FetchLike => async () => ({ status: 200, json: async () => ({ candidates: [{ content: { parts: [{ text: JSON.stringify(obj) }] } }] }) });

const OCR_TEXT = [
  'চাষী চিনিগুড়া চাল', 'Chashi Chinigura Rice', 'প্রস্তুতকারক: প্রাণ এগ্রো লিমিটেড', 'ব্যাচ নং:107-241/',
  'উৎপাদনের তারিখ: ১৫/০১/২০২৬', 'মেয়াদ উত্তীর্ণের তারিখ: ১৪/০১/২০২৭', 'সর্বোচ্চ খুচরা মুল্য: ১৫০ টাকা',
].join('\n');

function ai(printed: Partial<Record<string, string | null>>): AiLabelResult {
  return { printed: printed as AiLabelResult['printed'], languagesSeen: ['bn', 'en'], legibilityProblems: null };
}

test('prompt forbids guessing and asks for values exactly as printed', () => {
  assert.match(LABEL_SYSTEM_PROMPT, /Never guess/);
  assert.match(LABEL_SYSTEM_PROMPT, /return null/);
  assert.match(LABEL_SYSTEM_PROMPT, /exactly as printed/);
});

test('aiReadLabel sends both photos with side captions and cleans "null"-like strings', async () => {
  let body: any;
  const f: FetchLike = async (_u, init) => {
    body = JSON.parse(init.body);
    return { status: 200, json: async () => ({ candidates: [{ content: { parts: [{ text: JSON.stringify({ productName: 'Rice', expiryDate: 'N/A', mrp: '  ', languagesSeen: ['bn'] }) }] } }] }) };
  };
  const r = await aiReadLabel(cfg, [{ side: 'front', mimeType: 'image/jpeg', base64: 'AA' }, { side: 'back', mimeType: 'image/png', base64: 'BB' }], f);
  const parts = body.contents[0].parts;
  assert.match(parts[0].text, /FRONT/);
  assert.equal(parts[1].inline_data.data, 'AA');
  assert.match(parts[2].text, /BACK/);
  assert.equal(parts[3].inline_data.mime_type, 'image/png');
  assert.equal(r.printed.productName, 'Rice');
  assert.equal(r.printed.expiryDate, null);
  assert.equal(r.printed.mrp, null);
  assert.deepEqual(r.languagesSeen, ['bn']);
});

test('merge: every status, and nothing appears that neither OCR nor AI read', () => {
  const ocr = { productName: 'Chashi Chinigura Rice', batchNumber: '107-241', mrp: null, expiryDate: '2027-01-14', weight: '1 KG', brand: null };
  const m = mergeOcrAndAi(ocr, ai({
    productName: 'Chashi Chinigura Rice', // same as OCR
    batchNumber: 'LOT-241A', // differs from OCR, not in OCR text -> conflict
    mrp: '১৫০ টাকা', // OCR parser missed it, but "150" is in the OCR text -> confirmed
    expiryDate: '১৪/০১/২০২৭', // normalises to the OCR value -> agreed
    manufacturer: 'প্রাণ এগ্রো লিমিটেড', // OCR field null, words present in OCR text -> confirmed
    licenceNumber: 'BSTI-9999', // only AI, not in text -> check
    weight: null, // AI found nothing -> OCR only
  }), OCR_TEXT);
  assert.equal(m.productName.status, 'AGREED');
  assert.equal(m.batchNumber.status, 'CONFLICT');
  assert.equal(m.batchNumber.value, 'LOT-241A');
  assert.equal(m.batchNumber.ocrValue, '107-241');
  assert.equal(m.mrp.status, 'AI_CONFIRMED_BY_TEXT');
  assert.equal(m.mrp.value, 150);
  assert.equal(m.expiryDate.status, 'AGREED');
  assert.equal(m.expiryDate.value, '2027-01-14');
  assert.equal(m.manufacturer.status, 'AI_CONFIRMED_BY_TEXT');
  assert.equal(m.licenceNumber.status, 'AI_ONLY_CHECK');
  assert.equal(m.weight.status, 'OCR_ONLY');
  assert.equal(m.brand.status, 'NOT_FOUND');
  assert.equal(m.brand.value, null);
  assert.equal(m.countryOfOrigin.value, null);
});

test('without AI the result is exactly the OCR result', () => {
  const ocr = { productName: 'X', mrp: 10 };
  const m = mergeOcrAndAi(ocr, null, 'X 10');
  assert.equal(m.productName.value, 'X');
  assert.equal(m.productName.status, 'OCR_ONLY');
  assert.equal(m.mrp.value, 10);
  for (const f of LABEL_FIELDS) if (!(f in ocr)) assert.equal(m[f].status, 'NOT_FOUND');
});

test('AI dates are normalised by us (not trusted as ISO) and invalid ones dropped', () => {
  const m = mergeOcrAndAi({}, ai({ manufacturingDate: '০৩/২০২৬', expiryDate: '31/02/2027', barcode: '890 1234 567890' }), '');
  assert.equal(m.manufacturingDate.value, '2026-03-01');
  assert.equal(m.expiryDate.value, '2027-02-28', 'day clamped to the month, as for OCR');
  assert.equal(m.barcode.value, '8901234567890');
  assert.equal(m.manufacturingDate.status, 'AI_ONLY_CHECK', 'no OCR text: the seller must check');
});

test('grounding: Bengali digits, short values and names', () => {
  assert.equal(groundedInOcr('expiryDate', '14/01/2027', '2027-01-14', OCR_TEXT), true);
  assert.equal(groundedInOcr('mrp', '150', 150, OCR_TEXT), true);
  assert.equal(groundedInOcr('mrp', '15', 15, OCR_TEXT), false, '15 must not match inside 150');
  assert.equal(groundedInOcr('productNameBn', 'চাষী চিনিগুড়া চাল', 'চাষী চিনিগুড়া চাল', OCR_TEXT), true);
  assert.equal(groundedInOcr('productName', 'Famous Brand Biscuits', 'Famous Brand Biscuits', OCR_TEXT), false);
  assert.equal(groundedInOcr('batchNumber', 'LOT-241A', 'LOT-241A', OCR_TEXT), false);
});

test('end to end with a fake Gemini answer', async () => {
  const r = await aiReadLabel(cfg, [{ side: 'front', mimeType: 'image/jpeg', base64: 'AA' }], answer({ productNameBn: 'চাষী চিনিগুড়া চাল', mrp: '৳১৫০' }));
  const m = mergeOcrAndAi({ productNameBn: 'চাষী চিনিগুড়া চাল' }, r, OCR_TEXT);
  assert.equal(m.productNameBn.status, 'AGREED');
  assert.equal(m.mrp.value, 150);
});
