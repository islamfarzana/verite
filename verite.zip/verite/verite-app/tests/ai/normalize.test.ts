import { test } from 'node:test';
import assert from 'node:assert/strict';
import { comparable, normalizeDate, normalizePrice, normalizeWeight, toAsciiDigits } from '../../lib/ai/normalize';

test('Bengali digits become ASCII digits', () => {
  assert.equal(toAsciiDigits('১৫/০১/২০২৬'), '15/01/2026');
});

test('dates: Bangla and English formats, month-only rule for expiry vs manufacturing', () => {
  const e = { endOfMonth: true };
  const m = { endOfMonth: false };
  assert.equal(normalizeDate('১৫/০১/২০২৬', m), '2026-01-15');
  assert.equal(normalizeDate('১৫ জানুয়ারি ২০২৬', m), '2026-01-15');
  assert.equal(normalizeDate('০৮/২০২৭', e), '2027-08-31');
  assert.equal(normalizeDate('০৮/২০২৭', m), '2027-08-01');
  assert.equal(normalizeDate('AUG 2026', e), '2026-08-31');
  assert.equal(normalizeDate('15-Jan-26', m), '2026-01-15');
  assert.equal(normalizeDate('2028-02', e), '2028-02-29');
  assert.equal(normalizeDate('31.08.2027', e), '2027-08-31');
  assert.equal(normalizeDate('মেয়াদ', e), null, '"মে" inside "মেয়াদ" is not May');
  assert.equal(normalizeDate('not a date', e), null);
  assert.equal(normalizeDate('13/2026', e), null, 'invalid month');
});

test('prices and weights', () => {
  assert.equal(normalizePrice('৳ ১৫০'), 150);
  assert.equal(normalizePrice('Tk. 1,250.50'), 1250.5);
  assert.equal(normalizePrice('১৫০ টাকা'), 150);
  assert.equal(normalizePrice('free'), null);
  assert.equal(normalizeWeight('৫০০ গ্রাম'), '500 G');
  assert.equal(normalizeWeight('১ কেজি'), '1 KG');
  assert.equal(normalizeWeight('500gm'), '500 G');
  assert.equal(normalizeWeight('1.5 L'), '1.5 L');
  assert.equal(normalizeWeight('a lot'), null);
});

test('comparable() ignores spaces, punctuation, case and digit script', () => {
  assert.equal(comparable('LOT-241A'), comparable('lot 241a'));
  assert.equal(comparable('১৫/০১/২০২৬'), comparable('15-01-2026'));
});
