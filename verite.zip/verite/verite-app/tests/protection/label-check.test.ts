import test from 'node:test';
import assert from 'node:assert/strict';
import { compareDates, compareLabel, nameSimilarity, overallResult, type RegisteredRecord } from '../../lib/protection/label-check';

const REG: RegisteredRecord = {
  productName: 'Chashi Chinigura Rice 1kg', productNameBn: 'চাষী চিনিগুড়া চাল ১ কেজি', manufacturer: 'Pran Agro Ltd',
  batchNumber: 'LOT-241A', manufacturingDate: '2026-01-15', expiryDate: '2027-01-14', mrpPaisa: 15000,
};
const by = (fields: ReturnType<typeof compareLabel>) => Object.fromEntries(fields.map((f) => [f.field, f.result]));

test('all fields match (English OCR, ISO dates, numeric MRP) -> MATCH, wording is not an authenticity claim', () => {
  const f = compareLabel(REG, { fields: { productName: 'CHASHI Chinigura Rice', manufacturer: 'PRAN AGRO LIMITED', batchNumber: 'lot 241a', manufacturingDate: '2026-01-15', expiryDate: '2027-01-14', mrp: 150 } }, 60);
  assert.deepEqual(by(f), { productName: 'MATCH', manufacturer: 'MATCH', batchNumber: 'MATCH', manufacturingDate: 'MATCH', expiryDate: 'MATCH', mrp: 'MATCH' });
  const o = overallResult(f, true);
  assert.equal(o.overall, 'MATCH');
  assert.match(o.bn, /প্রমাণ নয়/);
});

test('Bangla label: Bangla name, Bangla digits in MRP and dates', () => {
  const f = compareLabel(REG, { fields: { productNameBn: 'চাষী চিনিগুড়া চাল', batchNumber: 'LOT-241A', manufacturingDate: '১৫/০১/২০২৬', expiryDate: '১৪ জানুয়ারি ২০২৭', mrp: '১৫০ টাকা' } }, 60);
  assert.deepEqual(by(f), { productName: 'MATCH', manufacturer: 'NOT_FOUND_ON_LABEL', batchNumber: 'MATCH', manufacturingDate: 'MATCH', expiryDate: 'MATCH', mrp: 'MATCH' });
  assert.equal(overallResult(f, true).overall, 'MATCH');
});

test('each field mismatch is reported, and the overall result asks for review without saying counterfeit', () => {
  const f = compareLabel(REG, { fields: { productName: 'Golden Basmati Premium', manufacturer: 'Acme Foods', batchNumber: 'XYZ-999', manufacturingDate: '2025-03-01', expiryDate: '2026-06-30', mrp: '175' } }, 60);
  assert.deepEqual(by(f), { productName: 'MISMATCH', manufacturer: 'MISMATCH', batchNumber: 'MISMATCH', manufacturingDate: 'MISMATCH', expiryDate: 'MISMATCH', mrp: 'MISMATCH' });
  const o = overallResult(f, true);
  assert.equal(o.overall, 'MISMATCH_REVIEW');
  assert.equal(f.find((x) => x.field === 'expiryDate')!.reasonBn, 'আপনার প্যাকেটের মেয়াদোত্তীর্ণের তারিখ নিবন্ধিত ব্যাচের তথ্যের সঙ্গে মিলছে না। ছবিটি আবার পরীক্ষা করুন বা যাচাইয়ের জন্য পাঠান।');
  for (const text of [o.en, o.bn, ...f.flatMap((x) => [x.reasonEn, x.reasonBn])]) {
    assert.doesNotMatch(text, /counterfeit(?! —)|is fake|নকল পণ্য|জাল/i);
  }
});

test('dates: day/month ambiguity is UNCERTAIN, never MISMATCH; month-only labels match at month precision', () => {
  assert.equal(compareDates('expiryDate', '2027-06-05', '2027-05-06').result, 'UNCERTAIN');
  assert.equal(compareDates('expiryDate', '2027-06-05', '2027-06-05').result, 'MATCH');
  assert.equal(compareDates('expiryDate', '2027-08-31', '2027-08-31').result, 'MATCH');
  assert.equal(compareDates('expiryDate', '2027-08-20', '2027-08-31').result, 'MATCH', 'EXP 08/2027 printed month-only');
  assert.equal(compareDates('manufacturingDate', '2026-02-14', '2026-02-01').result, 'MATCH', 'MFG 02/2026');
  assert.equal(compareDates('expiryDate', '2027-08-20', '2027-08-10').result, 'UNCERTAIN', 'same month, different day');
  assert.equal(compareDates('expiryDate', '2027-08-20', '2028-08-20').result, 'MISMATCH');
  assert.equal(compareDates('expiryDate', '2027-06-25', '2027-25-06' as any).result, 'MISMATCH', 'impossible swap stays a plain comparison');
  const f = compareLabel(REG, { fields: { batchNumber: 'LOT-241A', expiryDate: 'garbled 99/99', mrp: 150 } }, 60);
  assert.equal(f.find((x) => x.field === 'expiryDate')!.result, 'UNCERTAIN');
});

test('batch: OCR letter/digit confusion is UNCERTAIN; missing batch -> BATCH_UNRESOLVED (never compared to another batch)', () => {
  const conf = compareLabel(REG, { fields: { batchNumber: 'L0T-24IA', expiryDate: '2027-01-14', mrp: 150 } }, 60);
  assert.equal(by(conf).batchNumber, 'UNCERTAIN');
  assert.equal(overallResult(conf, true).overall, 'BATCH_UNRESOLVED');
  const missing = compareLabel(REG, { fields: { productName: 'Chashi Chinigura Rice', expiryDate: '2027-01-14', mrp: 150 } }, 60);
  assert.equal(by(missing).batchNumber, 'NOT_FOUND_ON_LABEL');
  assert.match(missing.find((x) => x.field === 'batchNumber')!.reasonBn, /ব্যাচ নম্বরটি স্পষ্টভাবে পড়া যায়নি/);
  assert.equal(overallResult(missing, true).overall, 'BATCH_UNRESOLVED');
});

test('low OCR confidence turns a mismatch into UNCERTAIN; MRP format differences are not mismatches', () => {
  const f = compareLabel(REG, { fields: { batchNumber: 'LOT-241A', mrp: '157', expiryDate: '2027-01-14' }, confidence: { mrp: 41, batchNumber: 95 } }, 60);
  assert.equal(by(f).mrp, 'UNCERTAIN');
  assert.equal(f.find((x) => x.field === 'mrp')!.confidence, 41);
  for (const m of ['150', '150.00', 'Tk. 150', '৳১৫০', 'MRP: 150/-']) {
    assert.equal(by(compareLabel(REG, { fields: { mrp: m } }, 60)).mrp, 'MATCH', m);
  }
});

test('missing registered data is NOT_REGISTERED, not a mismatch; too little text is INSUFFICIENT_IMAGE; unpublished is NOT_REGISTERED', () => {
  const reg = { ...REG, manufacturer: null, mrpPaisa: null };
  const f = compareLabel(reg, { fields: { manufacturer: 'Pran', mrp: 150 } }, 60);
  assert.equal(by(f).manufacturer, 'NOT_REGISTERED');
  assert.equal(by(f).mrp, 'NOT_REGISTERED');
  assert.equal(by(compareLabel(reg, { fields: {} }, 60)).mrp, 'NOT_APPLICABLE');
  assert.equal(overallResult(compareLabel(REG, { fields: { mrp: 150 } }, 60), true).overall, 'INSUFFICIENT_IMAGE');
  const nr = overallResult(compareLabel(REG, { fields: { mrp: 150, batchNumber: 'LOT-241A' } }, 60), false);
  assert.equal(nr.overall, 'NOT_REGISTERED');
  assert.equal(nr.bn, 'এই ব্যাচের নিবন্ধিত তথ্য পাওয়া যায়নি। এর মানে পণ্যটি নকল—এমন সিদ্ধান্ত শুধু এই ফলাফল থেকে দেওয়া যায় না।');
});

test('name similarity', () => {
  assert.equal(nameSimilarity('Basmati Rice 5kg', 'BASMATI RICE 5 KG'), 1);
  assert.ok(nameSimilarity('Basmati Rice 5kg', 'Rice') <= 0.6);
  assert.equal(nameSimilarity('Basmati Rice', 'Olive Oil'), 0);
});
