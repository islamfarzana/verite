import test from 'node:test';
import assert from 'node:assert/strict';
import { NOW, makeDb, product } from './helpers';
import { findScanRisks, runScanRiskCheck } from '../../lib/protection/scan-risk';
import { DEFAULT_SCAN_CONFIG } from '../../lib/trace/config';
import type { Db } from '../../lib/trace/types';

const cfg = { ...DEFAULT_SCAN_CONFIG, thresholdUnit: 5, thresholdBatch: 50, windowMinutes: 120, distinctSourceThreshold: 3 };

function code(db: Db, id: string, productId: string, scope: 'UNIT' | 'BATCH', serial: number | null) {
  db.prepare(`INSERT INTO trace_identifiers (id, token, scope, product_id, batch_number, unit_serial, issue_group, issued_by, created_at)
              VALUES (?, ?, ?, ?, 'LOT-X', ?, 'g1', 's1', '2026-10-01T00:00:00Z')`).run(id, `tok_${id}`.padEnd(24, 'x'), scope, productId, serial);
}
let k = 0;
function scans(db: Db, identifierId: string, n: number, sources: string[], minutesAgo: number, outcome = 'VALID') {
  for (let i = 0; i < n; i++) {
    db.prepare('INSERT INTO scan_events (id, identifier_id, outcome, source_hash, reason, created_at) VALUES (?, ?, ?, ?, ?, ?)')
      .run(`e${k++}`, identifierId, outcome, sources[i % sources.length], 'test', new Date(NOW.getTime() - minutesAgo * 60_000).toISOString());
  }
}

test('threshold not reached / reached; old events, UNKNOWN/REVOKED outcomes and single-source floods do not count', () => {
  const db = makeDb();
  product(db, 'p1');
  code(db, 'u1', 'p1', 'UNIT', 1);
  code(db, 'u2', 'p1', 'UNIT', 2);
  code(db, 'u3', 'p1', 'UNIT', 3);
  scans(db, 'u1', 4, ['n1', 'n2', 'n3'], 10); // 4 < 5
  scans(db, 'u2', 9, ['n1', 'n2', 'n3', 'n4'], 30); // 9 scans, 4 networks -> flagged
  scans(db, 'u3', 10, ['n1'], 10); // many scans from ONE network group -> not flagged (distinct 1 < 3)
  scans(db, 'u1', 10, ['n5', 'n6', 'n7'], 500); // outside the 2-hour window
  scans(db, 'u1', 10, ['n5', 'n6', 'n7'], 5, 'UNKNOWN');
  const f = findScanRisks(db, 's1', NOW, cfg);
  assert.deepEqual(f.map((x) => [x.identifierId, x.scans, x.distinctNetworkGroups]), [['u2', 9, 4]]);
});

test('alert wording is cautious, uses the computed numbers, and exposes no network identifiers; deduplicated per day', () => {
  const db = makeDb();
  product(db, 'p1');
  code(db, 'u2', 'p1', 'UNIT', 2);
  scans(db, 'u2', 9, ['hash-aaaa', 'hash-bbbb', 'hash-cccc', 'hash-dddd'], 30);
  assert.deepEqual(runScanRiskCheck(db, 's1', NOW, cfg), { findings: 1, created: 1 });
  assert.deepEqual(runScanRiskCheck(db, 's1', NOW, cfg), { findings: 1, created: 0 }, 'same code same day: no spam');
  const n = db.prepare("SELECT * FROM seller_notifications WHERE kind = 'SCAN_RISK'").get() as any;
  assert.match(n.body_bn, /গত ২ ঘণ্টায় এই ইউনিট কোড #২টি ৪টি নেটওয়ার্ক গ্রুপ থেকে ৯ বার স্ক্যান হয়েছে/);
  assert.match(n.body_bn, /শুধু স্ক্যানের সংখ্যা দিয়ে নকল প্রমাণ হয় না/);
  assert.match(n.body_en, /does not prove|do not prove/);
  assert.doesNotMatch(n.body_en + n.body_bn + n.data_json, /hash-|\d+\.\d+\.\d+/, 'no hashes or IPs');
});

test('sellers only get alerts for their own codes; missing network signal degrades to one group', () => {
  const db = makeDb();
  product(db, 'p1', { seller: 's1' });
  product(db, 'p2', { seller: 's2' });
  code(db, 'a', 'p1', 'UNIT', 1);
  code(db, 'b', 'p2', 'UNIT', 1);
  scans(db, 'b', 9, ['n1', 'n2', 'n3', 'n4'], 5);
  scans(db, 'a', 9, ['unknown'], 5);
  assert.equal(findScanRisks(db, 's1', NOW, cfg).length, 0);
  assert.equal(findScanRisks(db, 's2', NOW, cfg).length, 1);
  assert.equal(findScanRisks(db, 's1', NOW, { ...cfg, distinctSourceThreshold: 1 }).length, 1, 'count-only rule when distinct threshold is 1');
});

test('a batch code needs its (much higher) batch threshold', () => {
  const db = makeDb();
  product(db, 'p1');
  code(db, 'bt', 'p1', 'BATCH', null);
  scans(db, 'bt', 49, ['n1', 'n2', 'n3'], 5);
  assert.equal(findScanRisks(db, 's1', NOW, cfg).length, 0);
  scans(db, 'bt', 1, ['n4'], 5);
  const f = findScanRisks(db, 's1', NOW, cfg);
  assert.equal(f[0].scope, 'BATCH');
});
