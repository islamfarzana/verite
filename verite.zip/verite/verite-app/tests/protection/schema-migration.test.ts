import test from 'node:test';
import assert from 'node:assert/strict';
import { baseDb } from './helpers';
import { TRACE_SCHEMA_SQL } from '../../lib/trace/schema';
import { applyProtectionSchema, migrateNotificationKinds } from '../../lib/protection/schema';

// The v4 seller_notifications table, exactly as v4 created it (old CHECK list).
const V4_NOTIFICATIONS = `CREATE TABLE seller_notifications (
  id TEXT PRIMARY KEY, seller_id TEXT NOT NULL REFERENCES users(id), product_id TEXT REFERENCES products(id),
  kind TEXT NOT NULL CHECK (kind IN ('OUT_OF_STOCK','STOCKOUT_SOON','LOW_STOCK','EXPIRED_LISTED','EXPIRING_SOON','EXPIRY_RISK')),
  severity TEXT NOT NULL CHECK (severity IN ('INFO','WARNING','CRITICAL')), title_en TEXT NOT NULL, body_en TEXT NOT NULL,
  title_bn TEXT NOT NULL, body_bn TEXT NOT NULL, data_json TEXT, dedupe_key TEXT NOT NULL, created_at TEXT NOT NULL, read_at TEXT,
  UNIQUE (seller_id, dedupe_key));`;

test('upgrading a v4 database keeps every row, adds the new columns/tables, and is idempotent', () => {
  const db = baseDb();
  db.exec(TRACE_SCHEMA_SQL);
  db.exec(V4_NOTIFICATIONS);
  db.prepare("INSERT INTO users (id, name, email, password_hash, role) VALUES ('s1','s','s@x','x','SELLER'), ('b1','b','b@x','x','BUYER')").run();
  db.prepare(`INSERT INTO products (id, seller_id, name, barcode, batch_number, expiry_date, price, stock, status)
              VALUES ('p1','s1','Milk','123456','L1','2027-01-01',120,5,'PUBLISHED')`).run();
  db.prepare("INSERT INTO orders (id, buyer_id, order_number, total) VALUES ('o1','b1','ORD-1',120)").run();
  db.prepare("INSERT INTO order_items (id, order_id, product_id, quantity, price) VALUES ('i1','o1','p1',1,120)").run();
  db.prepare(`INSERT INTO seller_notifications (id, seller_id, product_id, kind, severity, title_en, body_en, title_bn, body_bn, dedupe_key, created_at, read_at)
              VALUES ('n1','s1','p1','LOW_STOCK','INFO','t','b','t','b','k1','2026-10-01','2026-10-02')`).run();
  assert.throws(() => db.prepare(`INSERT INTO seller_notifications (id, seller_id, kind, severity, title_en, body_en, title_bn, body_bn, dedupe_key, created_at)
              VALUES ('n2','s1','SCAN_RISK','WARNING','t','b','t','b','k2','2026-10-01')`).run(), /CHECK/);

  applyProtectionSchema(db);
  applyProtectionSchema(db); // second start-up: nothing changes, nothing fails
  assert.equal(migrateNotificationKinds(db), false);

  const n1 = db.prepare("SELECT * FROM seller_notifications WHERE id = 'n1'").get() as any;
  assert.equal(n1.kind, 'LOW_STOCK');
  assert.equal(n1.read_at, '2026-10-02');
  db.prepare(`INSERT INTO seller_notifications (id, seller_id, kind, severity, title_en, body_en, title_bn, body_bn, dedupe_key, created_at)
              VALUES ('n2','s1','SCAN_RISK','WARNING','t','b','t','b','k2','2026-10-01')`).run();
  const p = db.prepare("SELECT mrp_paisa, mrp_source, mrp_status, price FROM products WHERE id = 'p1'").get() as any;
  assert.deepEqual({ ...p }, { mrp_paisa: null, mrp_source: null, mrp_status: null, price: 120 });
  const it = db.prepare("SELECT batch_number, expiry_date FROM order_items WHERE id = 'i1'").get() as any;
  assert.deepEqual({ ...it }, { batch_number: null, expiry_date: null });
  for (const t of ['cart_items', 'label_checks', 'batch_recalls', 'buyer_notifications', 'protection_audit']) {
    assert.ok(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?").get(t), t);
  }
  assert.throws(() => db.prepare("UPDATE products SET mrp_paisa = 0 WHERE id = 'p1'").run(), /CHECK/);
});
