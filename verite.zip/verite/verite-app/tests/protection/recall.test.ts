import test from 'node:test';
import assert from 'node:assert/strict';
import { CFG, NOW, makeDb, order, product } from './helpers';
import { affectedBuyers, buyerUnreadCount, closeRecall, listBuyerNotifications, listRecalls, markBuyerNotificationsRead, openRecall, resendRecallNotices } from '../../lib/protection/recall';
import { protectionFor } from '../../lib/protection/sellability';

const seller = { id: 's1', role: 'SELLER' as const };
const other = { id: 's2', role: 'SELLER' as const };
const admin = { id: 'a1', role: 'ADMIN' as const };

test('authorisation: own seller or admin may recall; other sellers and buyers may not; drafts cannot be recalled', () => {
  const db = makeDb();
  product(db, 'p1');
  product(db, 'd1', { status: 'DRAFT' });
  assert.throws(() => openRecall(db, { id: 'b1', role: 'BUYER' }, { productId: 'p1', reasonCode: 'QUALITY_ISSUE' }, NOW, CFG), (e: any) => e.code === 'FORBIDDEN');
  assert.throws(() => openRecall(db, other, { productId: 'p1', reasonCode: 'QUALITY_ISSUE' }, NOW, CFG), (e: any) => e.code === 'NOT_FOUND', 'another seller cannot even learn it exists');
  assert.throws(() => openRecall(db, seller, { productId: 'p1', reasonCode: 'BAD' }, NOW, CFG), (e: any) => e.code === 'INVALID');
  assert.throws(() => openRecall(db, seller, { productId: 'p1', reasonCode: 'OTHER', publicMessage: 'x'.repeat(301) }, NOW, CFG), (e: any) => e.code === 'INVALID');
  assert.throws(() => openRecall(db, seller, { productId: 'd1', reasonCode: 'OTHER' }, NOW, CFG), (e: any) => e.code === 'INVALID');
  assert.equal(openRecall(db, seller, { productId: 'p1', reasonCode: 'QUALITY_ISSUE' }, NOW, CFG).alreadyActive, false);
  assert.throws(() => closeRecall(db, seller, (listRecalls(db, seller)[0] as any).id, null, NOW), (e: any) => e.code === 'FORBIDDEN', 'only an admin closes');
  assert.deepEqual(listRecalls(db, other), [], 'sellers only see their own recalls');
});

test('targets only buyers of this listing+batch, deduplicated, excludes cancelled and simulated orders; history kept', () => {
  const db = makeDb();
  product(db, 'p1', { batch: 'LOT-A' });
  product(db, 'p2', { batch: 'LOT-B' });
  order(db, 'b1', 'p1', 1, { batch: 'LOT-A' });
  order(db, 'b1', 'p1', 2, { batch: 'LOT-A' }); // repeat order: still one notice
  order(db, 'b2', 'p1', 1); // legacy order item without batch snapshot -> listing batch
  order(db, 'b3', 'p2', 1); // other listing
  order(db, 'b3', 'p1', 1, { status: 'CANCELLED' });
  order(db, 'b3', 'p1', 1, { sim: true });
  assert.deepEqual(affectedBuyers(db, 'p1', 'LOT-A', false), { buyerIds: ['b1', 'b2'], simulatedOrdersSkipped: 1 });
  assert.deepEqual(affectedBuyers(db, 'p1', 'LOT-A', true).buyerIds, ['b1', 'b2', 'b3']);

  const ordersBefore = db.prepare('SELECT COUNT(*) AS c FROM order_items').get() as any;
  const r = openRecall(db, admin, { productId: 'p1', reasonCode: 'SAFETY_RISK', publicMessage: 'Stop using this batch.' }, NOW, CFG);
  assert.equal(r.buyersNotified, 2);
  assert.equal(r.simulatedOrdersSkipped, 1);
  assert.equal(listBuyerNotifications(db, 'b3').length, 0);
  const n = listBuyerNotifications(db, 'b1') as any[];
  assert.equal(n.length, 1);
  assert.match(n[0].bodyBn, /সতর্কতা: আপনার কেনা পণ্যের ব্যাচ LOT-A প্রত্যাহার করা হয়েছে/);
  assert.equal(n[0].channel, 'IN_APP');
  assert.equal(n[0].deliveryStatus, 'DELIVERED_IN_APP');
  assert.doesNotMatch(JSON.stringify(n), /b2@|b2\b/, 'no other buyer is mentioned');
  assert.deepEqual(db.prepare('SELECT COUNT(*) AS c FROM order_items').get(), ordersBefore, 'orders are never deleted');

  // admin recall tells the seller (count only)
  const sn = db.prepare("SELECT kind, body_en FROM seller_notifications WHERE seller_id = 's1'").all() as any[];
  assert.equal(sn[0].kind, 'RECALL_ISSUED');
  assert.match(sn[0].body_en, /2 buyer\(s\)/);
  assert.doesNotMatch(sn[0].body_en, /b1|b2/);

  // stops sales of this batch only
  assert.equal(protectionFor(db, 'p1', NOW, CFG)!.blockers[0].code, 'RECALLED');
  assert.equal(protectionFor(db, 'p2', NOW, CFG)!.sellable, true);
});

test('idempotent: repeating, resending and retries never duplicate notices; closing restores sellability', () => {
  const db = makeDb();
  product(db, 'p1');
  order(db, 'b1', 'p1');
  const first = openRecall(db, seller, { productId: 'p1', reasonCode: 'QUALITY_ISSUE' }, NOW, CFG);
  const again = openRecall(db, seller, { productId: 'p1', reasonCode: 'QUALITY_ISSUE' }, NOW, CFG);
  assert.equal(again.alreadyActive, true);
  assert.equal(again.recall.id, first.recall.id);
  assert.deepEqual(resendRecallNotices(db, admin, first.recall.id, NOW, CFG), { added: 0, total: 1 });
  order(db, 'b2', 'p1'); // e.g. an order recorded late
  assert.deepEqual(resendRecallNotices(db, admin, first.recall.id, NOW, CFG), { added: 1, total: 2 });
  assert.equal(listBuyerNotifications(db, 'b1').length, 1);
  assert.equal(buyerUnreadCount(db, 'b1'), 1);
  assert.equal(markBuyerNotificationsRead(db, 'b2', 'all', NOW), 1);
  assert.equal(buyerUnreadCount(db, 'b1'), 1, 'marking is per buyer');
  assert.equal(closeRecall(db, admin, first.recall.id, 'resolved', NOW).closed, true);
  assert.equal(closeRecall(db, admin, first.recall.id, 'resolved', NOW).alreadyClosed, true);
  assert.equal(protectionFor(db, 'p1', NOW, CFG)!.sellable, true);
  const audits = (db.prepare('SELECT action FROM protection_audit ORDER BY created_at, rowid').all() as any[]).map((a) => a.action);
  assert.deepEqual(audits, ['RECALL_OPENED', 'RECALL_NOTICES_RESENT', 'RECALL_NOTICES_RESENT', 'RECALL_CLOSED']);
});

test('the batch number of a published listing is locked (exact recall targeting stays valid)', () => {
  const db = makeDb();
  product(db, 'p1', { batch: 'LOT-A' });
  product(db, 'd1', { batch: 'LOT-D', status: 'DRAFT' });
  assert.throws(() => db.prepare("UPDATE products SET batch_number = 'LOT-Z' WHERE id = 'p1'").run(), /locked after publish/);
  db.prepare("UPDATE products SET batch_number = 'LOT-E' WHERE id = 'd1'").run();
  db.prepare("UPDATE products SET expiry_date = '2030-01-01' WHERE id = 'p1'").run(); // scripts/tamper.ts demo still works
});
