import test from 'node:test';
import assert from 'node:assert/strict';
import { formatPaisa, parseTakaToPaisa, dbTakaToPaisa } from '../../lib/protection/money';
import { evaluatePrice } from '../../lib/protection/pricing';
import { expiryInfo, isValidIsoDate } from '../../lib/protection/expiry';

test('money: taka text -> integer paisa without float rounding, Bangla digits, rejects >2 decimals', () => {
  assert.equal(parseTakaToPaisa('120'), 12000);
  assert.equal(parseTakaToPaisa('120.5'), 12050);
  assert.equal(parseTakaToPaisa('120.05'), 12005);
  assert.equal(parseTakaToPaisa('1,250.00'), 125000);
  assert.equal(parseTakaToPaisa('৳ ১২০'), 12000);
  assert.equal(parseTakaToPaisa('১৫০ টাকা'), 15000);
  assert.equal(parseTakaToPaisa('MRP: Tk 99.99'), 9999);
  assert.equal(parseTakaToPaisa('Tk 120/-'), 12000);
  assert.equal(parseTakaToPaisa(120.5), 12050);
  assert.equal(parseTakaToPaisa(0.1 + 0.2), null, 'float noise is rejected, not rounded');
  assert.equal(parseTakaToPaisa('12.345'), null);
  assert.equal(parseTakaToPaisa('-5'), null);
  assert.equal(parseTakaToPaisa('abc'), null);
  assert.equal(parseTakaToPaisa(1e21), null);
  assert.equal(dbTakaToPaisa(19.99), 1999, '19.99*100 is 1998.9999… in floats; rounding to the nearest paisa fixes it');
  assert.equal(formatPaisa(12050), '120.50');
  assert.equal(formatPaisa(12000), '120');
});

test('pricing: below / equal / above MRP, missing MRP under both policies', () => {
  assert.equal(evaluatePrice(11999, 12000, { mrpMissingPolicy: 'allow' }).decision, 'ALLOWED');
  assert.equal(evaluatePrice(12000, 12000, { mrpMissingPolicy: 'allow' }).decision, 'ALLOWED');
  const above = evaluatePrice(12001, 12000, { mrpMissingPolicy: 'allow' });
  assert.equal(above.decision, 'BLOCKED_ABOVE_MRP');
  assert.equal(above.allowed, false);
  assert.match(above.bn, /নিবন্ধিত MRP/);
  assert.doesNotMatch(above.en + above.bn, /offence|illegal|অপরাধ|আইন/, 'neutral wording, no legal verdict');
  assert.equal(evaluatePrice(12000, null, { mrpMissingPolicy: 'allow' }).decision, 'ALLOWED_MRP_NOT_REGISTERED');
  assert.equal(evaluatePrice(12000, null, { mrpMissingPolicy: 'block' }).decision, 'BLOCKED_MRP_MISSING');
});

test('expiry: Dhaka calendar day, sellable through the expiry day, day counts, invalid dates', () => {
  const at = (iso: string) => new Date(iso);
  // 2026-10-29 17:59Z is 23:59 on 29 Oct in Dhaka; 18:00Z is already 30 Oct in Dhaka.
  assert.equal(expiryInfo('2026-10-29', at('2026-10-29T17:59:00Z'), 60).state, 'EXPIRES_TODAY');
  assert.equal(expiryInfo('2026-10-29', at('2026-10-29T17:59:00Z'), 60).sellable, true);
  assert.equal(expiryInfo('2026-10-29', at('2026-10-29T18:00:00Z'), 60).state, 'EXPIRED');
  assert.equal(expiryInfo('2026-10-29', at('2026-10-29T18:00:00Z'), 60).sellable, false);
  const one = expiryInfo('2026-10-30', at('2026-10-29T06:00:00Z'), 60);
  assert.deepEqual([one.state, one.daysRemaining, one.textBn], ['NEAR_EXPIRY', 1, 'মেয়াদ শেষ হতে ১ দিন বাকি']);
  assert.equal(expiryInfo('2026-12-28', at('2026-10-29T06:00:00Z'), 60).state, 'NEAR_EXPIRY', '60 days = at the threshold');
  assert.equal(expiryInfo('2026-12-29', at('2026-10-29T06:00:00Z'), 60).state, 'OK', '61 days = beyond it');
  assert.equal(expiryInfo('2028-02-29', at('2028-02-28T06:00:00Z'), 60).daysRemaining, 1, 'leap day');
  for (const bad of [null, '', '2027-02-29', '2026-13-01', '31/08/2027', '2026-8-1']) {
    const e = expiryInfo(bad as any, at('2026-10-29T06:00:00Z'), 60);
    assert.equal(e.state, 'UNKNOWN', String(bad));
    assert.equal(e.daysRemaining, null, 'no guessed countdown');
    assert.equal(e.sellable, false);
    assert.equal(e.textBn, 'মেয়াদ যাচাই করা যায়নি');
  }
  assert.equal(isValidIsoDate('2024-02-29'), true);
});
