import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { ASSISTANT_SCHEMA_SQL } from '../../lib/assistant/schema';
import { TRACE_SCHEMA_SQL } from '../../lib/trace/schema';
import { applyProtectionSchema } from '../../lib/protection/schema';
import { DEFAULT_PROTECTION_CONFIG } from '../../lib/protection/config';
import type { Db } from '../../lib/trace/types';

// Real table definitions (copied out of lib/db.ts at test time) + the real v5 migration.
export function realTable(name: string): string {
  const src = readFileSync(join(__dirname, '../../lib/db.ts'), 'utf8');
  const m = src.match(new RegExp(`CREATE TABLE IF NOT EXISTS ${name} \\([\\s\\S]*?\\n\\);`));
  if (!m) throw new Error(`table ${name} not found in lib/db.ts`);
  return m[0];
}

export const CFG = { ...DEFAULT_PROTECTION_CONFIG };
export const NOW = new Date('2026-10-29T06:00:00.000Z'); // 12:00 in Dhaka, 29 Oct 2026

export function baseDb(): Db {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  for (const t of ['users', 'categories', 'products', 'orders', 'order_items', 'product_images']) db.exec(realTable(t));
  return db as unknown as Db;
}

export function makeDb(): Db {
  const d = baseDb();
  d.exec(TRACE_SCHEMA_SQL);
  d.exec(ASSISTANT_SCHEMA_SQL);
  applyProtectionSchema(d);
  for (const [id, role] of [['s1', 'SELLER'], ['s2', 'SELLER'], ['b1', 'BUYER'], ['b2', 'BUYER'], ['b3', 'BUYER'], ['a1', 'ADMIN']]) {
    d.prepare('INSERT INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)').run(id, id, `${id}@x.test`, 'x', role);
  }
  return d;
}

let barcode = 1000;
export function product(db: Db, id: string, o: { seller?: string; stock?: number; price?: number; mrpPaisa?: number | null; expiry?: string | null; status?: string; batch?: string } = {}) {
  db.prepare(
    `INSERT INTO products (id, seller_id, name, brand, barcode, batch_number, manufacturing_date, expiry_date, price, stock, status, mrp_paisa, mrp_source, mrp_status)
     VALUES (?, ?, ?, 'B', ?, ?, '2026-01-01', ?, ?, ?, ?, ?, 'SELLER_ENTERED', 'UNREVIEWED')`
  ).run(id, o.seller ?? 's1', `Product ${id}`, String(890000000 + barcode++), o.batch ?? `LOT-${id}`, o.expiry === undefined ? '2027-12-31' : o.expiry,
    o.price ?? 100, o.stock ?? 50, o.status ?? 'PUBLISHED', o.mrpPaisa === undefined ? 12000 : o.mrpPaisa);
}

let n = 0;
export function order(db: Db, buyer: string, productId: string, qty = 1, o: { sim?: boolean; status?: string; batch?: string | null } = {}) {
  n += 1;
  const id = `o${n}`;
  db.prepare("INSERT INTO orders (id, buyer_id, order_number, total, status, created_at) VALUES (?, ?, ?, 100, ?, '2026-10-01 10:00:00')")
    .run(id, buyer, `${o.sim ? 'SIM' : 'ORD'}-${n}`, o.status ?? 'CONFIRMED');
  db.prepare('INSERT INTO order_items (id, order_id, product_id, quantity, price, batch_number) VALUES (?, ?, ?, ?, 100, ?)')
    .run(`oi${n}`, id, productId, qty, o.batch === undefined ? null : o.batch);
  return id;
}
