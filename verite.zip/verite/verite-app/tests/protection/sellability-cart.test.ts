import test from 'node:test';
import assert from 'node:assert/strict';
import { CFG, NOW, makeDb, product } from './helpers';
import { protectionFor, sellableSqlFilter } from '../../lib/protection/sellability';
import { addToCart, getCart, mergeCart, removeFromCart, setCartQuantity } from '../../lib/protection/cart';
import { openRecall } from '../../lib/protection/recall';
import { dhakaToday } from '../../lib/protection/expiry';
import { ProtectionError } from '../../lib/protection/errors';

test('sellability precedence: recalled > expired > not published > above MRP > stock; all reasons reported', () => {
  const db = makeDb();
  product(db, 'ok');
  product(db, 'exp', { expiry: '2026-10-28' });
  product(db, 'draft', { status: 'DRAFT' });
  product(db, 'above', { price: 130, mrpPaisa: 12000 });
  product(db, 'empty', { stock: 0 });
  product(db, 'all', { expiry: '2026-01-01', price: 200, stock: 0 });
  openRecall(db, { id: 's1', role: 'SELLER' }, { productId: 'all', reasonCode: 'QUALITY_ISSUE' }, NOW, CFG);
  const codes = (id: string) => protectionFor(db, id, NOW, CFG)!.blockers.map((b) => b.code);
  assert.deepEqual(codes('ok'), []);
  assert.deepEqual(codes('exp'), ['EXPIRED']);
  assert.deepEqual(codes('draft'), ['NOT_PUBLISHED']);
  assert.deepEqual(codes('above'), ['ABOVE_MRP']);
  assert.deepEqual(codes('empty'), ['OUT_OF_STOCK']);
  assert.deepEqual(codes('all'), ['RECALLED', 'EXPIRED', 'ABOVE_MRP', 'OUT_OF_STOCK']);
  assert.deepEqual(protectionFor(db, 'ok', NOW, CFG, 51)!.blockers.map((b) => b.code), ['INSUFFICIENT_STOCK']);
});

test('marketplace SQL filter hides recalled, expired, undated, draft and above-MRP listings', () => {
  const db = makeDb();
  product(db, 'ok');
  product(db, 'legacyNoMrp', { mrpPaisa: null });
  product(db, 'exp', { expiry: '2026-10-28' });
  product(db, 'today', { expiry: '2026-10-29' });
  product(db, 'nodate', { expiry: null });
  product(db, 'draft', { status: 'DRAFT' });
  product(db, 'above', { price: 120.01, mrpPaisa: 12000 });
  product(db, 'rec');
  openRecall(db, { id: 'a1', role: 'ADMIN' }, { productId: 'rec', reasonCode: 'SAFETY_RISK' }, NOW, CFG);
  const ids = (cfg: typeof CFG) => (db.prepare(`SELECT p.id FROM products p WHERE ${sellableSqlFilter('p', cfg, dhakaToday(NOW))} ORDER BY p.id`).all() as any[]).map((r) => r.id);
  assert.deepEqual(ids(CFG), ['legacyNoMrp', 'ok', 'today']);
  assert.deepEqual(ids({ ...CFG, mrpMissingPolicy: 'block' }), ['ok', 'today']);
  assert.throws(() => sellableSqlFilter('p', CFG, "2026-01-01' OR 1=1 --"));
});

test('cart is stored per buyer, re-checks sellability on add and on view, and survives a reload', () => {
  const db = makeDb();
  product(db, 'p1', { stock: 3 });
  product(db, 'p2');
  product(db, 'exp', { expiry: '2026-01-01' });
  assert.equal(addToCart(db, 'b1', 'p1', 2, NOW, CFG), 2);
  assert.equal(addToCart(db, 'b1', 'p1', 1, NOW, CFG), 3, 'adds to the existing line');
  assert.throws(() => addToCart(db, 'b1', 'p1', 1, NOW, CFG), (e: any) => e instanceof ProtectionError && e.blockers[0].code === 'INSUFFICIENT_STOCK');
  assert.throws(() => addToCart(db, 'b1', 'exp', 1, NOW, CFG), (e: any) => e.code === 'NOT_SELLABLE' && e.blockers[0].code === 'EXPIRED' && /মেয়াদ শেষ/.test(e.messageBn));
  assert.throws(() => addToCart(db, 'b1', 'nope', 1, NOW, CFG), (e: any) => e.code === 'NOT_FOUND');
  assert.throws(() => addToCart(db, 'b1', 'p2', 0, NOW, CFG), (e: any) => e.code === 'INVALID');
  assert.throws(() => addToCart(db, 'b1', 'p2', 1.5, NOW, CFG), (e: any) => e.code === 'INVALID');
  addToCart(db, 'b1', 'p2', 1, NOW, CFG);
  addToCart(db, 'b2', 'p2', 5, NOW, CFG);

  // "close the browser and come back": a new read of the same database returns the same cart
  const c = getCart(db, 'b1', NOW, CFG);
  assert.deepEqual(c.lines.map((l) => [l.productId, l.quantity, l.available]), [['p1', 3, true], ['p2', 1, true]]);
  assert.equal(c.subtotal, 400);
  assert.equal(getCart(db, 'b2', NOW, CFG).lines[0].quantity, 5, 'buyers never see each other’s carts');

  // after a recall the line stays but is marked unavailable and drops out of the subtotal
  openRecall(db, { id: 's1', role: 'SELLER' }, { productId: 'p2', reasonCode: 'LABELLING_ERROR' }, NOW, CFG);
  const c2 = getCart(db, 'b1', NOW, CFG);
  assert.deepEqual(c2.lines.map((l) => [l.productId, l.available]), [['p1', true], ['p2', false]]);
  assert.equal(c2.lines[1].reasons[0].code, 'RECALLED');
  assert.equal(c2.subtotal, 300);
  assert.equal(c2.unavailableCount, 1);

  assert.equal(setCartQuantity(db, 'b1', 'p1', 1, NOW, CFG), 1, 'lowering is always allowed');
  assert.equal(setCartQuantity(db, 'b1', 'p2', 1, NOW, CFG), 1, 'lowering a recalled line is allowed too');
  assert.throws(() => setCartQuantity(db, 'b1', 'p2', 2, NOW, CFG), (e: any) => e.blockers[0].code === 'RECALLED');
  assert.equal(removeFromCart(db, 'b1', 'p2'), 1);
  assert.equal(removeFromCart(db, 'b1', null), 1);
  assert.equal(getCart(db, 'b1', NOW, CFG).lines.length, 0);
});

test('importing an old browser cart skips items that cannot be sold', () => {
  const db = makeDb();
  product(db, 'p1');
  product(db, 'exp', { expiry: '2026-01-01' });
  const r = mergeCart(db, 'b1', [{ productId: 'p1', quantity: 2 }, { productId: 'exp', quantity: 1 }, { productId: 42, quantity: 1 }, { productId: 'gone', quantity: 1 }], NOW, CFG);
  assert.deepEqual(r, { added: 1, skipped: 3 });
  assert.equal(getCart(db, 'b1', NOW, CFG).lines[0].quantity, 2);
});
