import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { ASSISTANT_SCHEMA_SQL } from '../../lib/assistant/schema';
import type { Db } from '../../lib/trace/types';

function realTable(name: string): string {
  const src = readFileSync(join(__dirname, '../../lib/db.ts'), 'utf8');
  const m = src.match(new RegExp(`CREATE TABLE IF NOT EXISTS ${name} \\([\\s\\S]*?\\n\\);`));
  if (!m) throw new Error(`table ${name} not found in lib/db.ts`);
  return m[0];
}

export const NOW = new Date('2026-10-28T06:00:00.000Z'); // 12:00 in Dhaka
export const daysAgo = (d: number, h = 0) => new Date(NOW.getTime() - d * 86_400_000 + h * 3_600_000);
const sql = (d: Date) => d.toISOString().slice(0, 19).replace('T', ' ');

export function makeDb(): Db {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  for (const t of ['users', 'categories', 'products', 'orders', 'order_items']) db.exec(realTable(t));
  db.exec(ASSISTANT_SCHEMA_SQL);
  const d = db as unknown as Db;
  for (const [id, role] of [['s1', 'SELLER'], ['s2', 'SELLER'], ['b1', 'BUYER']]) {
    d.prepare('INSERT INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)').run(id, id, `${id}@x.test`, 'x', role);
  }
  return d;
}

let barcode = 1000;
export function product(db: Db, id: string, o: { seller?: string; stock?: number; price?: number; expiry?: string; createdDaysAgo?: number; status?: string } = {}) {
  db.prepare(
    `INSERT INTO products (id, seller_id, name, brand, barcode, batch_number, manufacturing_date, expiry_date, price, stock, status, created_at)
     VALUES (?, ?, ?, 'B', ?, 'L1', '2026-01-01', ?, ?, ?, ?, ?)`
  ).run(id, o.seller ?? 's1', `Product ${id}`, String(890000000 + barcode++), o.expiry ?? '2027-12-31', o.price ?? 100, o.stock ?? 50, o.status ?? 'PUBLISHED', sql(daysAgo(o.createdDaysAgo ?? 60)));
}

let n = 0;
export function sale(db: Db, productId: string, qty: number, when: Date, o: { price?: number; status?: string } = {}) {
  const id = `o${n++}`;
  db.prepare(
    `INSERT INTO orders (id, buyer_id, order_number, total, status, created_at) VALUES (?, 'b1', ?, ?, ?, ?)`
  ).run(id, `ORD-${n}`, qty * (o.price ?? 100), o.status ?? 'CONFIRMED', sql(when));
  db.prepare('INSERT INTO order_items (id, order_id, product_id, quantity, price) VALUES (?, ?, ?, ?, ?)').run(`i${n}`, id, productId, qty, o.price ?? 100);
}
