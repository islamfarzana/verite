import { test } from 'node:test';
import assert from 'node:assert/strict';
import { dailySeries, productStats, slowMovers, topProducts, weeklyFacts } from '../../lib/assistant/analytics';
import { NOW, daysAgo, makeDb, product, sale } from './helpers';

test('velocity, days of cover and stock-out date', () => {
  const db = makeDb();
  product(db, 'p1', { stock: 20 });
  for (let d = 1; d <= 28; d++) sale(db, 'p1', 2, daysAgo(d)); // 56 units in 28 days = 2/day
  const s = productStats(db, 's1', NOW).find((x) => x.id === 'p1')!;
  assert.equal(s.units28, 56);
  assert.equal(s.dailyVelocity, 2);
  assert.equal(s.daysOfCover, 10);
  assert.equal(s.stockoutDate, '2026-11-07');
});

test('a young product uses its own age (min 7 days) as the window, not 28 days', () => {
  const db = makeDb();
  product(db, 'new', { stock: 30, createdDaysAgo: 10 });
  for (let d = 1; d <= 10; d++) sale(db, 'new', 1, daysAgo(d));
  const s = productStats(db, 's1', NOW).find((x) => x.id === 'new')!;
  assert.equal(s.windowDays, 10);
  assert.equal(s.dailyVelocity, 1);
  assert.equal(s.daysOfCover, 30);
});

test('nothing selling = no velocity and no stock-out date (not divide by zero)', () => {
  const db = makeDb();
  product(db, 'p', { stock: 5 });
  const s = productStats(db, 's1', NOW)[0];
  assert.equal(s.dailyVelocity, 0);
  assert.equal(s.daysOfCover, null);
  assert.equal(s.stockoutDate, null);
});

test('expiry: days to expiry on the Dhaka calendar, and units projected unsold at expiry', () => {
  const db = makeDb();
  product(db, 'p', { stock: 100, expiry: '2026-11-27' }); // 30 days from 2026-10-28
  for (let d = 1; d <= 28; d++) sale(db, 'p', 1, daysAgo(d)); // 1/day
  const s = productStats(db, 's1', NOW)[0];
  assert.equal(s.daysToExpiry, 30);
  assert.equal(s.projectedUnsoldAtExpiry, 70);
});

test('cancelled orders and other sellers are excluded; periods are respected', () => {
  const db = makeDb();
  product(db, 'a'); product(db, 'b'); product(db, 'other', { seller: 's2' });
  sale(db, 'a', 5, daysAgo(2));
  sale(db, 'a', 50, daysAgo(3), { status: 'CANCELLED' });
  sale(db, 'b', 3, daysAgo(2), { price: 500 });
  sale(db, 'b', 10, daysAgo(40));
  sale(db, 'other', 99, daysAgo(1));
  assert.deepEqual(topProducts(db, 's1', NOW, '7d', 'units').map((t) => [t.id, t.units]), [['a', 5], ['b', 3]]);
  assert.deepEqual(topProducts(db, 's1', NOW, '7d', 'revenue').map((t) => [t.id, t.revenue]), [['b', 1500], ['a', 500]]);
  assert.deepEqual(topProducts(db, 's1', NOW, '90d', 'units').map((t) => [t.id, t.units]), [['b', 13], ['a', 5]]);
  assert.ok(!topProducts(db, 's1', NOW, '90d').some((t) => t.id === 'other'));
});

test('slow movers: in stock, published, no sale in 14 days', () => {
  const db = makeDb();
  product(db, 'sells'); product(db, 'slow'); product(db, 'empty', { stock: 0 }); product(db, 'draft', { status: 'DRAFT' });
  sale(db, 'sells', 1, daysAgo(3));
  sale(db, 'slow', 1, daysAgo(20));
  assert.deepEqual(slowMovers(productStats(db, 's1', NOW), NOW).map((s) => s.id), ['slow']);
});

test('daily series has one entry per Dhaka day, zeros included', () => {
  const db = makeDb();
  product(db, 'p');
  sale(db, 'p', 4, daysAgo(1));
  const series = dailySeries(db, 's1', NOW, 7);
  assert.equal(series.length, 7);
  assert.equal(series.reduce((a, d) => a + d.units, 0), 4);
  assert.equal(series[series.length - 1].day, '2026-10-28');
});

test('weekly facts: this week vs last week, change percent, flagged lists', () => {
  const db = makeDb();
  product(db, 'p', { stock: 3, price: 100 }); product(db, 'old', { expiry: '2026-10-01', stock: 4 });
  sale(db, 'p', 2, daysAgo(10)); // last week: 200
  sale(db, 'p', 3, daysAgo(2)); // this week: 300
  const f = weeklyFacts(db, 's1', NOW);
  assert.equal(f.thisWeek.revenue, 300);
  assert.equal(f.lastWeek.revenue, 200);
  assert.equal(f.revenueChangePercent, 50);
  assert.deepEqual(f.expiredStillListed.map((x) => x.name), ['Product old']);
  assert.equal(f.simulatedOrdersIncluded, 0);
});
