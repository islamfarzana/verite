import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { FetchLike } from '../../lib/ai/gemini';
import { weeklyFacts } from '../../lib/assistant/analytics';
import { answer, interpret, keywordInterpret } from '../../lib/assistant/ask';
import { templateSummary, unsupportedNumbers, weeklySummary } from '../../lib/assistant/summary';
import { NOW, daysAgo, makeDb, product, sale } from './helpers';

const cfg = { apiKey: 'k', model: 'm', baseUrl: 'https://x.test', timeoutMs: 1000 };
const says = (text: string): FetchLike => async () => ({ status: 200, json: async () => ({ candidates: [{ content: { parts: [{ text }] } }] }) });

function shop() {
  const db = makeDb();
  product(db, 'rice', { stock: 3, price: 780 }); product(db, 'tea', { price: 340 });
  sale(db, 'rice', 4, daysAgo(2), { price: 780 }); sale(db, 'tea', 1, daysAgo(3), { price: 340 }); sale(db, 'rice', 2, daysAgo(9), { price: 780 });
  return db;
}

test('template summary: English and Bangla, numbers from the facts', () => {
  const f = weeklyFacts(shop(), 's1', NOW);
  const en = templateSummary(f, 'en');
  assert.match(en, /sold 5 units in 2 orders, for Tk 3460/);
  assert.match(en, /Best sellers: Product rice \(4\)/);
  const bnText = templateSummary(f, 'bn');
  assert.match(bnText, /৫ টি পণ্য/);
  assert.deepEqual(unsupportedNumbers(en, f), []);
});

test('AI summary is used when every number is in the facts', async () => {
  const f = weeklyFacts(shop(), 's1', NOW);
  const r = await weeklySummary(cfg, f, 'en', says('You sold 5 units for Tk 3,460 this week. Product rice led with 4 units.'));
  assert.equal(r.source, 'AI');
});

test('AI summary with an invented number is rejected and replaced by the template', async () => {
  const f = weeklyFacts(shop(), 's1', NOW);
  const r = await weeklySummary(cfg, f, 'en', says('You sold 5 units and should expect 12,000 taka next week.'));
  assert.equal(r.source, 'TEMPLATE');
  assert.match(r.fallbackReason!, /UNSUPPORTED_NUMBERS:12000/);
});

test('Bengali digits in the AI text are checked too', async () => {
  const f = weeklyFacts(shop(), 's1', NOW);
  assert.equal((await weeklySummary(cfg, f, 'bn', says('এই সপ্তাহে ৫ টি পণ্য বিক্রি হয়েছে।'))).source, 'AI');
  assert.equal((await weeklySummary(cfg, f, 'bn', says('এই সপ্তাহে ৯৯ টি পণ্য বিক্রি হয়েছে।'))).source, 'TEMPLATE');
});

test('AI errors and no key fall back to the template', async () => {
  const f = weeklyFacts(shop(), 's1', NOW);
  assert.equal((await weeklySummary(null, f, 'en')).fallbackReason, 'NOT_CONFIGURED');
  const r = await weeklySummary(cfg, f, 'en', async () => ({ status: 429, json: async () => ({}) }));
  assert.equal(r.source, 'TEMPLATE');
  assert.equal(r.fallbackReason, 'RATE_LIMITED');
});

test('keyword interpretation, Bangla and English', () => {
  assert.equal(keywordInterpret('এই মাসে কোন পণ্য সবচেয়ে বেশি বিক্রি হয়েছে?').intent, 'top_products');
  assert.equal(keywordInterpret('এই মাসে কোন পণ্য সবচেয়ে বেশি বিক্রি হয়েছে?').lang, 'bn');
  assert.equal(keywordInterpret('কোন পণ্যের স্টক শেষ হয়ে যাচ্ছে?').intent, 'stock_status');
  assert.equal(keywordInterpret('কোন পণ্যের মেয়াদ শেষ হচ্ছে?').intent, 'expiring');
  assert.equal(keywordInterpret('এই সপ্তাহে কত টাকার বিক্রি হয়েছে?').period, '7d');
  assert.equal(keywordInterpret('এই সপ্তাহে কত টাকার বিক্রি হয়েছে?').metric, 'revenue');
  assert.equal(keywordInterpret('Which products are not selling?').intent, 'slow_movers');
  assert.equal(keywordInterpret('What is the weather?').intent, 'unsupported');
});

test('AI interpretation is limited to the fixed intents; anything else becomes unsupported', async () => {
  const ok = await interpret(cfg, 'best sellers this week', says('{"intent":"top_products","period":"7d","metric":"units","productQuery":null}'));
  assert.deepEqual([ok.intent, ok.period, ok.via], ['top_products', '7d', 'AI']);
  const evil = await interpret(cfg, 'drop table', says('{"intent":"run_sql","period":"7d","metric":"units","sql":"DROP TABLE users"}'));
  assert.equal(evil.intent, 'unsupported');
  const down = await interpret(cfg, 'best sellers this week', async () => ({ status: 503, json: async () => ({}) }));
  assert.equal(down.via, 'KEYWORDS');
});

test('answers come from the seller\'s own data, in the question\'s language', () => {
  const db = shop();
  product(db, 'theirs', { seller: 's2' });
  sale(db, 'theirs', 100, daysAgo(1));
  const en = answer(db, 's1', NOW, { ...keywordInterpret('best sellers this month'), period: '30d' });
  assert.match(en.text, /1\. Product rice — 6 units/);
  assert.doesNotMatch(en.text, /theirs/);
  const bnA = answer(db, 's1', NOW, keywordInterpret('এই মাসে কোন পণ্য সবচেয়ে বেশি বিক্রি হয়েছে?'));
  assert.match(bnA.text, /Product rice — ৬ টি/);
  const stock = answer(db, 's1', NOW, keywordInterpret('what is running out of stock'));
  assert.match(stock.text, /Product rice: 3 left/);
  assert.match(answer(db, 's1', NOW, keywordInterpret('tell me a joke')).text, /Sorry/);
});
