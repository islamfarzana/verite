import { test } from 'node:test';
import assert from 'node:assert/strict';
import { evaluateAlerts, listNotifications, markRead, runChecksIfDue, saveAlerts, unreadCount } from '../../lib/assistant/alerts';
import { productStats } from '../../lib/assistant/analytics';
import { NOW, daysAgo, makeDb, product, sale } from './helpers';

function kinds(db: any) {
  return Object.fromEntries(evaluateAlerts(productStats(db, 's1', NOW)).map((a) => [a.productId, a.kind]));
}

test('each alert kind fires on the right condition', () => {
  const db = makeDb();
  product(db, 'oos', { stock: 0 });
  product(db, 'soon', { stock: 6 }); for (let d = 1; d <= 28; d++) sale(db, 'soon', 1, daysAgo(d)); // 6 days of cover
  product(db, 'low', { stock: 3 });
  product(db, 'expired', { expiry: '2026-10-01' });
  product(db, 'expiring', { expiry: '2026-11-10', stock: 40 });
  product(db, 'risk', { expiry: '2026-12-27', stock: 200 }); for (let d = 1; d <= 28; d++) sale(db, 'risk', 1, daysAgo(d));
  product(db, 'fine', { stock: 100 }); for (let d = 1; d <= 28; d++) sale(db, 'fine', 1, daysAgo(d));
  product(db, 'draft', { stock: 0, status: 'DRAFT' });
  const k = kinds(db);
  assert.equal(k.oos, 'OUT_OF_STOCK');
  assert.equal(k.soon, 'STOCKOUT_SOON');
  assert.equal(k.low, 'LOW_STOCK');
  assert.equal(k.expired, 'EXPIRED_LISTED');
  assert.equal(k.expiring, 'EXPIRING_SOON');
  assert.equal(k.risk, 'EXPIRY_RISK');
  assert.equal(k.fine, undefined);
  assert.equal(k.draft, undefined, 'drafts are not listed, so no alerts');
});

test('stock-out alert suggests a restock quantity from the sales rate, in English and Bangla', () => {
  const db = makeDb();
  product(db, 'soon', { stock: 6 }); for (let d = 1; d <= 28; d++) sale(db, 'soon', 1, daysAgo(d));
  const a = evaluateAlerts(productStats(db, 's1', NOW))[0];
  assert.equal(a.data.restock, 8); // 14 days x 1/day - 6 in stock
  assert.match(a.bodyEn, /Restock about 8 units/);
  assert.match(a.bodyBn, /৮ টি মজুত করুন/);
  assert.match(a.titleBn, /[০-৯]/, 'Bangla text uses Bengali digits');
});

test('alerts are stored once per product, kind and day; the check is throttled', () => {
  const db = makeDb();
  product(db, 'oos', { stock: 0 });
  assert.deepEqual(runChecksIfDue(db, 's1', NOW), { ran: true, created: 1 });
  assert.deepEqual(runChecksIfDue(db, 's1', new Date(NOW.getTime() + 10 * 60_000)), { ran: false, created: 0 });
  assert.deepEqual(runChecksIfDue(db, 's1', new Date(NOW.getTime() + 2 * 3_600_000)), { ran: true, created: 0 }, 'same day: no duplicate');
  assert.equal(runChecksIfDue(db, 's1', new Date(NOW.getTime() + 24 * 3_600_000)).created, 1, 'next day: alerted again');
  assert.equal(unreadCount(db, 's1'), 2);
});

test('sellers only see and change their own notifications', () => {
  const db = makeDb();
  product(db, 'a', { stock: 0 }); product(db, 'b', { stock: 0, seller: 's2' });
  saveAlerts(db, 's1', evaluateAlerts(productStats(db, 's1', NOW)), NOW);
  saveAlerts(db, 's2', evaluateAlerts(productStats(db, 's2', NOW)), NOW);
  const mine = listNotifications(db, 's1') as any[];
  const theirs = listNotifications(db, 's2') as any[];
  assert.equal(mine.length, 1);
  assert.equal(markRead(db, 's1', [theirs[0].id], NOW), 0, 'cannot mark another seller\'s notification');
  assert.equal(markRead(db, 's1', 'all', NOW), 1);
  assert.equal(unreadCount(db, 's2'), 1);
});
