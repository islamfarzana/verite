import { test } from 'node:test';
import assert from 'node:assert/strict';
import { evaluateEligibility, ELIGIBILITY_MESSAGES } from '../../lib/identity/policy';
import { policy } from './helpers';

const NOW = new Date('2026-10-28T06:00:00Z');
const fresh = '2026-10-28T05:00:00.000Z';
const L = (over: Record<string, unknown> = {}) => ({
  id: 'l1', check_result: 'VALID', verification_method: 'REAL_REGISTRY_API', checked_at: fresh,
  registry_expiry_date: '2027-12-31', claimed_expiry_date: null, superseded_at: null, ...over,
}) as any;
const approved = { status: 'APPROVED' as const };
const ev = (entity: any, licences: any[], over = {}) => evaluateEligibility(entity, licences, policy(NOW, over));

test('the documented matrix: entity states', () => {
  assert.equal(ev(null, [L()]).code, 'NO_BUSINESS_PROFILE');
  for (const s of ['PENDING', 'REJECTED', 'SUSPENDED'] as const) {
    const e = ev({ status: s }, [L()]);
    assert.equal(e.canRegister, false, s);
    assert.equal(e.canSaveDraft, true);
    assert.equal(e.code, `ENTITY_${s}`);
  }
  assert.equal(ev(approved, []).code, 'NO_LICENCE');
});

test('suspended entity cannot register even with a previously VALID real registry result', () => {
  assert.equal(ev({ status: 'SUSPENDED' }, [L()]).canRegister, false);
});

test('the documented matrix: licence outcomes for an APPROVED entity', () => {
  const cases: [Record<string, unknown>, string, boolean][] = [
    [{}, 'ELIGIBLE_REAL_REGISTRY', true],
    [{ check_result: 'NOT_CHECKED', verification_method: 'UNVERIFIED_CLAIM', checked_at: null }, 'LICENCE_UNVERIFIED', false],
    [{ check_result: 'EXPIRED' }, 'LICENCE_EXPIRED', false],
    [{ check_result: 'REVOKED' }, 'LICENCE_REVOKED', false],
    [{ check_result: 'SUSPENDED' }, 'LICENCE_SUSPENDED', false],
    [{ check_result: 'INVALID' }, 'LICENCE_INVALID', false],
    [{ check_result: 'NOT_FOUND' }, 'LICENCE_NOT_FOUND', false],
    [{ check_result: 'UNAVAILABLE', checked_at: null }, 'REGISTRY_UNAVAILABLE', false],
    [{ check_result: 'ERROR', checked_at: null }, 'REGISTRY_UNAVAILABLE', false],
    [{ check_result: 'UNSUPPORTED', checked_at: null }, 'VERIFICATION_UNSUPPORTED', false],
  ];
  for (const [over, code, ok] of cases) {
    const e = ev(approved, [L(over)]);
    assert.equal(e.code, code, JSON.stringify(over));
    assert.equal(e.canRegister, ok, code);
    assert.equal(e.message, ELIGIBILITY_MESSAGES[e.code]);
  }
});

test('unavailable is neither valid nor invalid', () => {
  const e = ev(approved, [L({ check_result: 'UNAVAILABLE', checked_at: null })]);
  assert.equal(e.canRegister, false);
  assert.notEqual(e.code, 'LICENCE_INVALID');
});

test('a VALID result whose expiry date has passed (Dhaka calendar) is expired', () => {
  assert.equal(ev(approved, [L({ registry_expiry_date: '2026-10-27' })]).code, 'LICENCE_EXPIRED');
  assert.equal(ev(approved, [L({ registry_expiry_date: '2026-10-28' })]).code, 'ELIGIBLE_REAL_REGISTRY', 'expires today: still valid today');
  assert.equal(ev(approved, [L({ registry_expiry_date: null, claimed_expiry_date: '2026-01-01' })]).code, 'LICENCE_EXPIRED', 'claimed expiry is used when the registry gives none');
});

test('a VALID registry result older than the TTL does not count until re-checked', () => {
  assert.equal(ev(approved, [L({ checked_at: '2026-10-26T00:00:00.000Z' })]).code, 'REGISTRY_UNAVAILABLE');
  assert.equal(ev(approved, [L({ checked_at: '2026-10-26T00:00:00.000Z' })], { resultTtlHours: 100 }).canRegister, true);
});

test('mock VALID: allowed only in demo mode and labelled DEMO ONLY; never treated as a real registry result', () => {
  const mock = L({ verification_method: 'MOCK_REGISTRY' });
  const demo = ev(approved, [mock], { mockAllowed: true });
  assert.equal(demo.canRegister, true);
  assert.equal(demo.basis, 'MOCK_REGISTRY_DEMO');
  assert.match(demo.message, /DEMO MODE ONLY/);
  const prod = ev(approved, [mock], { mockAllowed: false });
  assert.equal(prod.canRegister, false);
  assert.equal(prod.code, 'MOCK_NOT_ALLOWED');
  // a mock REVOKED doesn't count outside demo either (neither way)
  assert.equal(ev(approved, [L({ verification_method: 'MOCK_REGISTRY', check_result: 'REVOKED' })], { mockAllowed: false }).code, 'MOCK_NOT_ALLOWED');
});

test('manual review counts only when the deployment explicitly accepts it', () => {
  const manual = L({ verification_method: 'AUTHORIZED_MANUAL_REVIEW', checked_at: '2025-01-01T00:00:00.000Z' });
  assert.equal(ev(approved, [manual]).code, 'MANUAL_REVIEW_NOT_ACCEPTED');
  const ok = ev(approved, [manual], { acceptManualReview: true });
  assert.equal(ok.canRegister, true);
  assert.equal(ok.basis, 'MANUAL_LICENCE_REVIEW');
});

test('a revoked or suspended licence blocks even if another licence is valid; real outranks demo', () => {
  assert.equal(ev(approved, [L({ id: 'a' }), L({ id: 'b', check_result: 'REVOKED' })]).code, 'LICENCE_REVOKED');
  const both = ev(approved, [L({ id: 'mock', verification_method: 'MOCK_REGISTRY' }), L({ id: 'real' })]);
  assert.equal(both.basis, 'REAL_REGISTRY');
  assert.equal(both.qualifyingLicenceId, 'real');
  assert.equal(ev(approved, [L({ superseded_at: '2026-01-01' })]).code, 'NO_LICENCE', 'superseded licences are ignored');
});
