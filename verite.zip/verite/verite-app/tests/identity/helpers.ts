import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { IDENTITY_SCHEMA_SQL } from '../../lib/identity/schema';
import type { RegistryAdapter, RegistryQuery, RegistryResult } from '../../lib/identity/registry';
import type { PolicyContext } from '../../lib/identity/policy';
import type { Actor, Db } from '../../lib/identity/types';

// Test database built from the REAL table definitions in lib/db.ts plus the real identity schema,
// so the fixture cannot drift from the application.
function realTable(name: string): string {
  const src = readFileSync(join(__dirname, '../../lib/db.ts'), 'utf8');
  const m = src.match(new RegExp(`CREATE TABLE IF NOT EXISTS ${name} \\([\\s\\S]*?\\n\\);`));
  if (!m) throw new Error(`table ${name} not found in lib/db.ts`);
  return m[0];
}

export function makeDb(): Db {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  for (const t of ['users', 'categories', 'products', 'blockchain_records']) db.exec(realTable(t));
  db.exec(IDENTITY_SCHEMA_SQL);
  return db as unknown as Db;
}

export function addUser(db: Db, id: string, role: 'BUYER' | 'SELLER' | 'ADMIN' = 'SELLER', email = `${id}@example.test`) {
  db.prepare('INSERT INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)').run(id, `${id} name`, email, 'x', role);
}

export function addProduct(db: Db, id: string, sellerId: string, barcode = `89000000${Math.floor(Math.random() * 1e5)}`) {
  db.prepare(
    `INSERT INTO products (id, seller_id, name, brand, barcode, batch_number, manufacturing_date, expiry_date, price, stock, status)
     VALUES (?, ?, 'Demo Rice 5kg', 'DemoBrand', ?, 'LOT-DEMO-1', '2026-01-01', '2027-01-01', 100, 10, 'DRAFT')`
  ).run(id, sellerId, barcode);
}

export const seller1: Actor = { id: 'seller1', role: 'SELLER' };
export const seller2: Actor = { id: 'seller2', role: 'SELLER' };
export const admin1: Actor = { id: 'admin1', role: 'ADMIN' };
export const buyer1: Actor = { id: 'buyer1', role: 'BUYER' };

export function fixture() {
  const db = makeDb();
  addUser(db, 'seller1'); addUser(db, 'seller2'); addUser(db, 'admin1', 'ADMIN'); addUser(db, 'buyer1', 'BUYER');
  return db;
}

/** A clock frozen at a given instant (and advanceable). */
export function clock(iso = '2026-10-28T06:00:00.000Z') {
  let t = new Date(iso).getTime();
  const now = () => new Date(t);
  return Object.assign(now, { advanceHours: (h: number) => { t += h * 3_600_000; } });
}

export const policy = (now: Date, over: Partial<PolicyContext> = {}): PolicyContext => ({
  mockAllowed: true, acceptManualReview: false, resultTtlHours: 24, now, ...over,
});

/** Scripted adapter: returns queued results (or a function's result) and records every query. */
export function scriptedAdapter(mode: 'MOCK' | 'REAL' | 'NONE', results: (Partial<RegistryResult> | Error)[]) {
  const calls: RegistryQuery[] = [];
  const adapter: RegistryAdapter & { calls: RegistryQuery[] } = {
    name: 'scripted', mode, sourceLabel: mode === 'REAL' ? 'Test Registry (fake)' : 'scripted', calls,
    async check(q) {
      calls.push(q);
      const next = results.length > 1 ? results.shift()! : results[0];
      if (next instanceof Error) throw next;
      return {
        outcome: 'VALID', mode, method: mode === 'REAL' ? 'REAL_REGISTRY_API' : mode === 'MOCK' ? 'MOCK_REGISTRY' : 'UNVERIFIED_CLAIM',
        environment: mode === 'REAL' ? 'PRODUCTION' : mode === 'MOCK' ? 'DEMO' : null, sourceLabel: adapter.sourceLabel,
        checkedAt: '2026-10-28T06:00:00.000Z', reference: 'REF-1', expiryDate: '2027-12-31', errorCategory: null, ...next,
      } as RegistryResult;
    },
  };
  return adapter;
}

export const goodProfile = (over: Record<string, unknown> = {}) => ({
  legalName: 'Demo Foods Limited',
  displayName: 'Demo Foods',
  entityType: 'ORGANIZATION' as const,
  roles: ['SELLER', 'MANUFACTURER'] as ('SELLER' | 'MANUFACTURER' | 'BRAND_OWNER')[],
  contactEmail: 'contact@demo-foods.example',
  licence: {
    licenceType: 'TRADE_LICENCE' as const,
    licenceNumber: 'DEMO-TL-2026-0001',
    issuingAuthority: 'Demo City Corporation (fictitious)',
    claimedExpiryDate: '2027-06-30',
    claimSource: 'MANUAL_ENTRY' as const,
  },
  ...over,
});
