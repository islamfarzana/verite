import { test } from 'node:test';
import assert from 'node:assert/strict';
import { loadIdentityConfig } from '../../lib/identity/config';
import { MOCK_LABEL } from '../../lib/identity/labels';
import { MOCK_REGISTRY_RECORDS } from '../../lib/identity/mock-registry-data';
import {
  HttpRegistryAdapter, MockRegistryAdapter, UnconfiguredRegistryAdapter, normalizeLicenceNumber, selectRegistryAdapter, type FetchLike,
} from '../../lib/identity/registry';
import { clock, makeDb } from './helpers';

const q = (licenceNumber: string, licenceType = 'TRADE_LICENCE') => ({ licenceType, licenceNumber, issuingAuthority: 'Anything' });

// ---------------------------------------------------------------------------------------------- mock
test('mock registry: every result is labelled MOCK/DEMO and never claims to be official', async () => {
  const a = new MockRegistryAdapter(makeDb(), clock());
  for (const r of MOCK_REGISTRY_RECORDS) {
    const res = await a.check(q(r.licenceNumber, r.licenceType));
    assert.equal(res.mode, 'MOCK');
    assert.equal(res.method, 'MOCK_REGISTRY');
    assert.equal(res.environment, 'DEMO');
    assert.equal(res.sourceLabel, MOCK_LABEL);
    assert.match(res.sourceLabel, /NOT OFFICIAL/);
    assert.doesNotMatch(res.sourceLabel, /BSTI verified|government verified/i);
  }
});

test('mock registry: valid, expired (by date), revoked, suspended, invalid, not found, outage, unsupported', async () => {
  const a = new MockRegistryAdapter(makeDb(), clock('2026-10-28T06:00:00Z'));
  assert.equal((await a.check(q('DEMO-TL-2026-0001'))).outcome, 'VALID');
  assert.equal((await a.check(q(' demo-tl-2026-0001 '))).outcome, 'VALID', 'number is normalised');
  assert.equal((await a.check(q('DEMO-TL-2024-0003'))).outcome, 'EXPIRED', 'ACTIVE in registry but expiry date has passed');
  assert.equal((await a.check(q('DEMO-TL-2025-0004'))).outcome, 'REVOKED');
  assert.equal((await a.check(q('DEMO-CM-2025-0005', 'BSTI_CM_LICENCE'))).outcome, 'SUSPENDED');
  assert.equal((await a.check(q('DEMO-TL-2025-0006'))).outcome, 'INVALID');
  assert.equal((await a.check(q('DEMO-TL-9999-9999'))).outcome, 'NOT_FOUND');
  const outage = await a.check(q('DEMO-TL-0000-OUTAGE'));
  assert.equal(outage.outcome, 'UNAVAILABLE');
  assert.equal(outage.checkedAt, null, 'no check time when nothing was checked');
  const unsupported = await a.check(q('X-1', 'DGDA_LICENCE'));
  assert.equal(unsupported.outcome, 'UNSUPPORTED');
  assert.equal(unsupported.checkedAt, null);
});

test('mock fixtures are synthetic: every number starts with DEMO- and every holder is marked fictitious', () => {
  for (const r of MOCK_REGISTRY_RECORDS) {
    assert.match(r.licenceNumber, /^DEMO-/);
    assert.match(r.holderName, /fictitious/i);
  }
});

test('expiry uses the Bangladesh calendar day: a licence expiring "today" in Dhaka is still valid', async () => {
  // 2025-06-30T20:00Z is already 2025-07-01 02:00 in Dhaka (UTC+6): expired. 2025-06-30T17:00Z is 23:00 on the 30th: valid.
  const db = makeDb();
  assert.equal((await new MockRegistryAdapter(db, clock('2025-06-30T17:00:00Z')).check(q('DEMO-TL-2024-0003'))).outcome, 'VALID');
  assert.equal((await new MockRegistryAdapter(db, clock('2025-06-30T20:00:00Z')).check(q('DEMO-TL-2024-0003'))).outcome, 'EXPIRED');
});

// ---------------------------------------------------------------------------------------------- real (fake HTTP)
const realCfg = { baseUrl: 'https://registry.example.test/api', apiKey: 'secret-key', sourceLabel: 'Example Registry (test)', supportedTypes: ['TRADE_LICENCE'], timeoutMs: 50 };

function fakeFetch(status: number, body: unknown | (() => Promise<unknown>), seen: { url?: string; headers?: Record<string, string> } = {}): FetchLike {
  return async (url, init) => {
    seen.url = url; seen.headers = init.headers;
    return { status, json: async () => (typeof body === 'function' ? (body as () => Promise<unknown>)() : body) };
  };
}

test('real adapter: a controlled 200 ACTIVE response is VALID with REAL provenance and an actual check time', async () => {
  const seen: { url?: string; headers?: Record<string, string> } = {};
  const a = new HttpRegistryAdapter(realCfg, fakeFetch(200, { status: 'ACTIVE', expiryDate: '2027-12-31', reference: 'R-77' }, seen), clock());
  const r = await a.check(q('tl 123'));
  assert.equal(r.outcome, 'VALID');
  assert.equal(r.mode, 'REAL');
  assert.equal(r.method, 'REAL_REGISTRY_API');
  assert.equal(r.sourceLabel, 'Example Registry (test)');
  assert.equal(r.checkedAt, '2026-10-28T06:00:00.000Z');
  assert.equal(r.reference, 'R-77');
  assert.ok(seen.url!.startsWith('https://registry.example.test/api/licences/lookup?'), 'URL comes only from server config');
  assert.ok(seen.url!.includes('number=TL123'));
  assert.equal(seen.headers!.Authorization, 'Bearer secret-key');
});

test('real adapter: registry outcomes map one-to-one', async () => {
  for (const s of ['EXPIRED', 'REVOKED', 'SUSPENDED', 'INVALID', 'NOT_FOUND'] as const) {
    const r = await new HttpRegistryAdapter(realCfg, fakeFetch(200, { status: s }), clock()).check(q('TL1'));
    assert.equal(r.outcome, s);
    assert.ok(r.checkedAt, `${s} is a real answer, so it has a check time`);
  }
  const past = await new HttpRegistryAdapter(realCfg, fakeFetch(200, { status: 'ACTIVE', expiryDate: '2020-01-01' }), clock()).check(q('TL1'));
  assert.equal(past.outcome, 'EXPIRED', 'ACTIVE with a past expiry date is expired');
  assert.equal((await new HttpRegistryAdapter(realCfg, fakeFetch(404, {}), clock()).check(q('TL1'))).outcome, 'NOT_FOUND');
});

test('real adapter: failures are never VALID and carry no check time', async () => {
  const cases: [FetchLike, string, string][] = [
    [fakeFetch(401, {}), 'ERROR', 'AUTH_401'],
    [fakeFetch(403, {}), 'ERROR', 'AUTH_403'],
    [fakeFetch(429, {}), 'UNAVAILABLE', 'RATE_LIMITED'],
    [fakeFetch(500, {}), 'UNAVAILABLE', 'HTTP_500'],
    [fakeFetch(503, {}), 'UNAVAILABLE', 'HTTP_503'],
    [fakeFetch(418, {}), 'ERROR', 'HTTP_418'],
    [fakeFetch(200, async () => { throw new SyntaxError('bad json'); }), 'ERROR', 'MALFORMED_RESPONSE'],
    [fakeFetch(200, { nope: true }), 'ERROR', 'MALFORMED_RESPONSE'],
    [fakeFetch(200, { status: 'PROBABLY_FINE' }), 'ERROR', 'MALFORMED_RESPONSE'],
    [async () => { throw new TypeError('fetch failed'); }, 'UNAVAILABLE', 'NETWORK'],
  ];
  for (const [f, outcome, category] of cases) {
    const r = await new HttpRegistryAdapter(realCfg, f, clock()).check(q('TL1'));
    assert.equal(r.outcome, outcome, category);
    assert.equal(r.errorCategory, category);
    assert.equal(r.checkedAt, null, `${category}: no check time`);
  }
});

test('real adapter: a hung registry times out as UNAVAILABLE (bounded wait)', async () => {
  const hang: FetchLike = (_u, init) => new Promise((_res, rej) => init.signal.addEventListener('abort', () => rej(Object.assign(new Error('aborted'), { name: 'AbortError' }))));
  const started = Date.now();
  const r = await new HttpRegistryAdapter({ ...realCfg, timeoutMs: 30 }, hang, clock()).check(q('TL1'));
  assert.equal(r.outcome, 'UNAVAILABLE');
  assert.equal(r.errorCategory, 'TIMEOUT');
  assert.ok(Date.now() - started < 2000);
});

test('real adapter: unsupported licence type is not sent to the registry', async () => {
  let called = false;
  const r = await new HttpRegistryAdapter(realCfg, async () => { called = true; return { status: 200, json: async () => ({ status: 'ACTIVE' }) }; }, clock()).check(q('X', 'BSTI_CM_LICENCE'));
  assert.equal(r.outcome, 'UNSUPPORTED');
  assert.equal(called, false);
});

// ---------------------------------------------------------------------------------------------- selection
test('config: mock by default in development, OFF by default in production', () => {
  assert.equal(loadIdentityConfig({ NODE_ENV: 'development' }).registryMode, 'mock');
  assert.equal(loadIdentityConfig({ NODE_ENV: 'production' }).registryMode, 'off');
});

test('config: mock is refused in production unless the environment is explicitly marked demo', () => {
  const c = loadIdentityConfig({ NODE_ENV: 'production', LICENCE_REGISTRY_MODE: 'mock' });
  assert.equal(c.registryMode, 'off');
  assert.match(c.modeNote!, /disabled in production/);
  assert.equal(loadIdentityConfig({ NODE_ENV: 'production', LICENCE_REGISTRY_MODE: 'mock', APP_ENVIRONMENT: 'demo' }).registryMode, 'mock');
  assert.equal(loadIdentityConfig({ LICENCE_REGISTRY_MODE: 'banana' }).registryMode, 'off');
});

test('config: real mode with missing or non-https settings is unconfigured, and never falls back to mock', async () => {
  const db = makeDb();
  for (const env of [
    { LICENCE_REGISTRY_MODE: 'real' },
    { LICENCE_REGISTRY_MODE: 'real', LICENCE_REGISTRY_BASE_URL: 'http://plain.example', LICENCE_REGISTRY_API_KEY: 'k', LICENCE_REGISTRY_SOURCE_LABEL: 'L' },
  ]) {
    const cfg = loadIdentityConfig({ NODE_ENV: 'development', ...env });
    assert.ok(cfg.realConfigError);
    const a = selectRegistryAdapter(cfg, db);
    assert.ok(a instanceof UnconfiguredRegistryAdapter);
    const r = await a.check(q('DEMO-TL-2026-0001'));
    assert.equal(r.outcome, 'UNAVAILABLE', 'even a number the mock registry would accept');
    assert.notEqual(r.method, 'MOCK_REGISTRY');
  }
  const ok = loadIdentityConfig({ LICENCE_REGISTRY_MODE: 'real', LICENCE_REGISTRY_BASE_URL: 'https://r.example/', LICENCE_REGISTRY_API_KEY: 'k', LICENCE_REGISTRY_SOURCE_LABEL: 'R' });
  assert.ok(selectRegistryAdapter(ok, db) instanceof HttpRegistryAdapter);
  assert.equal(ok.real!.baseUrl, 'https://r.example');
});

test('mock registry table is only created when the mock adapter is used', () => {
  const db = makeDb();
  const exists = () => !!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='mock_licence_registry'").get();
  selectRegistryAdapter(loadIdentityConfig({ NODE_ENV: 'production' }), db);
  assert.equal(exists(), false);
  selectRegistryAdapter(loadIdentityConfig({ NODE_ENV: 'development' }), db);
  assert.equal(exists(), true);
});

test('licence numbers are normalised without changing their characters', () => {
  assert.equal(normalizeLicenceNumber(' demo-tl 2026/0001 '), 'DEMO-TL2026/0001');
  assert.equal(normalizeLicenceNumber('ＤＥＭＯ１'), 'DEMO1', 'full-width digits/letters fold to ASCII (NFKC)');
});
