import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MockRegistryAdapter } from '../../lib/identity/registry';
import {
  decideEntity, getEntityForUser, getLicences, recheckLicence, recordManualLicenceReview, submitBusinessProfile, submitLicence, listEntities,
} from '../../lib/identity/onboarding';
import { sellerOnboardingView, adminEntityView } from '../../lib/identity/views';
import { IdentityError } from '../../lib/identity/types';
import { admin1, buyer1, clock, fixture, goodProfile, policy, scriptedAdapter, seller1, seller2 } from './helpers';

const rejectsWith = async (p: Promise<unknown> | (() => unknown), code: string) => {
  try { await (typeof p === 'function' ? p() : p); } catch (e) { assert.ok(e instanceof IdentityError, String(e)); assert.equal(e.code, code, e.message); return; }
  assert.fail(`expected ${code}`);
};

async function submitted(db = fixture(), now = clock()) {
  const adapter = new MockRegistryAdapter(db, now);
  const r = await submitBusinessProfile(db, seller1, goodProfile(), { adapter, now });
  return { db, now, adapter, entityId: r.entity.id, licenceId: r.licence.id, r };
}

test('a new submission starts PENDING, records history, and checks the licence with provenance', async () => {
  const { db, r } = await submitted();
  assert.equal(r.entity.status, 'PENDING');
  assert.deepEqual(r.roles, ['MANUFACTURER', 'SELLER']);
  assert.equal(r.licence.check_result, 'VALID');
  assert.equal(r.licence.verification_method, 'MOCK_REGISTRY');
  assert.equal(r.licence.verification_environment, 'DEMO');
  assert.equal(r.licence.checked_at, '2026-10-28T06:00:00.000Z');
  const h = db.prepare('SELECT * FROM entity_status_history').all() as any[];
  assert.equal(h.length, 1);
  assert.equal(h[0].previous_status, null);
  assert.equal(h[0].new_status, 'PENDING');
  assert.equal(h[0].reason_code, 'SUBMITTED');
  assert.equal((db.prepare('SELECT COUNT(*) c FROM licence_check_events').get() as any).c, 1);
});

test('clients cannot mass-assign status, verification method or timestamps', async () => {
  const db = fixture();
  const sneaky: any = goodProfile({ status: 'APPROVED', checkResult: 'VALID', verificationMethod: 'REAL_REGISTRY_API' });
  sneaky.licence = { ...sneaky.licence, check_result: 'VALID', verification_method: 'REAL_REGISTRY_API', checked_at: '2020-01-01' };
  const r = await submitBusinessProfile(db, seller1, sneaky, { adapter: scriptedAdapter('NONE', [{ outcome: 'UNAVAILABLE', checkedAt: null, errorCategory: 'NOT_CONFIGURED' }]), now: clock() });
  assert.equal(r.entity.status, 'PENDING');
  assert.equal(r.licence.verification_method, 'UNVERIFIED_CLAIM');
  assert.equal(r.licence.check_result, 'UNAVAILABLE');
  assert.equal(r.licence.checked_at, null);
});

test('only sellers can submit; buyers and admins cannot', async () => {
  const db = fixture();
  const deps = { adapter: new MockRegistryAdapter(db), now: clock() };
  await rejectsWith(submitBusinessProfile(db, buyer1, goodProfile(), deps), 'FORBIDDEN');
  await rejectsWith(submitBusinessProfile(db, admin1, goodProfile(), deps), 'FORBIDDEN');
});

test('input validation rejects bad names, licence numbers and dates', async () => {
  const db = fixture();
  const deps = { adapter: new MockRegistryAdapter(db), now: clock() };
  await rejectsWith(submitBusinessProfile(db, seller1, goodProfile({ legalName: 'x' }), deps), 'INVALID');
  await rejectsWith(submitBusinessProfile(db, seller1, goodProfile({ licence: { ...goodProfile().licence, licenceNumber: '<script>' } }), deps), 'INVALID');
  await rejectsWith(submitBusinessProfile(db, seller1, goodProfile({ licence: { ...goodProfile().licence, claimedIssueDate: '2027-01-01', claimedExpiryDate: '2026-01-01' } }), deps), 'INVALID');
  await rejectsWith(submitBusinessProfile(db, seller1, goodProfile({ entityType: 'GOVERNMENT' }), deps), 'INVALID');
  await rejectsWith(submitBusinessProfile(db, seller1, goodProfile({ roles: ['ADMIN'] }), deps), 'INVALID');
  assert.equal(getEntityForUser(db, 'seller1'), undefined, 'nothing written');
});

test('admin transitions: approve, suspend, reinstate, reopen; invalid transitions refused', async () => {
  const { db, entityId, now } = await submitted();
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'SUSPEND', reasonCode: 'POLICY_VIOLATION' }, now), 'INVALID_TRANSITION');
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'REINSTATE', reasonCode: 'REVIEW_PASSED' }, now), 'INVALID_TRANSITION');
  assert.equal(decideEntity(db, admin1, entityId, { action: 'APPROVE' }, now).status, 'APPROVED');
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'APPROVE' }, now), 'INVALID_TRANSITION');
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'REJECT', reasonCode: 'OTHER', note: 'x' }, now), 'INVALID_TRANSITION');
  assert.equal(decideEntity(db, admin1, entityId, { action: 'SUSPEND', reasonCode: 'COMPLAINT_UNDER_REVIEW', note: 'buyer complaint #12' }, now).status, 'SUSPENDED');
  assert.equal(decideEntity(db, admin1, entityId, { action: 'REINSTATE', reasonCode: 'COMPLAINT_RESOLVED' }, now).status, 'APPROVED');
  decideEntity(db, admin1, entityId, { action: 'SUSPEND', reasonCode: 'LICENCE_EXPIRED' }, now);
  assert.equal(decideEntity(db, admin1, entityId, { action: 'REOPEN', reasonCode: 'NEW_EVIDENCE' }, now).status, 'PENDING');
  const h = db.prepare('SELECT previous_status p, new_status n, reason_code r, actor_role a FROM entity_status_history ORDER BY rowid').all() as any[];
  assert.deepEqual(h.map((x) => `${x.p}->${x.n}:${x.r}`), [
    'null->PENDING:SUBMITTED', 'PENDING->APPROVED:REVIEW_PASSED', 'APPROVED->SUSPENDED:COMPLAINT_UNDER_REVIEW',
    'SUSPENDED->APPROVED:COMPLAINT_RESOLVED', 'APPROVED->SUSPENDED:LICENCE_EXPIRED', 'SUSPENDED->PENDING:NEW_EVIDENCE',
  ]);
  assert.ok(h.slice(1).every((x) => x.a === 'ADMIN'));
});

test('rejection and suspension require an allowed reason; OTHER requires a note', async () => {
  const { db, entityId, now } = await submitted();
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'REJECT' }, now), 'INVALID');
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'REJECT', reasonCode: 'BECAUSE' }, now), 'INVALID');
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'REJECT', reasonCode: 'OTHER' }, now), 'INVALID');
  assert.equal(decideEntity(db, admin1, entityId, { action: 'REJECT', reasonCode: 'DOCUMENTS_INCOMPLETE', publicNote: 'Please upload a clearer licence.', note: 'internal: blurry' }, now).status, 'REJECTED');
});

test('sellers and buyers cannot approve, reject or suspend; an admin cannot review a business their own account manages', async () => {
  const { db, entityId, now } = await submitted();
  await rejectsWith(() => decideEntity(db, seller1, entityId, { action: 'APPROVE' }, now), 'FORBIDDEN');
  await rejectsWith(() => decideEntity(db, seller2, entityId, { action: 'APPROVE' }, now), 'FORBIDDEN');
  await rejectsWith(() => decideEntity(db, buyer1, entityId, { action: 'APPROVE' }, now), 'FORBIDDEN');
  // Defence in depth: if an entity were ever linked to an admin account, that admin could not approve it.
  db.prepare("UPDATE business_entities SET managed_by_user_id = 'admin1' WHERE id = ?").run(entityId);
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'APPROVE' }, now), 'FORBIDDEN');
  await rejectsWith(() => listEntities(db, seller1), 'FORBIDDEN');
});

test('rejected application returns to PENDING only through the seller resubmitting', async () => {
  const { db, entityId, now, adapter } = await submitted();
  decideEntity(db, admin1, entityId, { action: 'REJECT', reasonCode: 'IDENTITY_MISMATCH' }, now);
  await rejectsWith(() => decideEntity(db, admin1, entityId, { action: 'REOPEN', reasonCode: 'NEW_EVIDENCE' }, now), 'INVALID_TRANSITION');
  const r = await submitBusinessProfile(db, seller1, goodProfile({ legalName: 'Demo Foods Ltd (corrected)' }), { adapter, now });
  assert.equal(r.entity.status, 'PENDING');
  assert.equal(r.entity.legal_name, 'Demo Foods Ltd (corrected)');
  const last = db.prepare('SELECT * FROM entity_status_history ORDER BY rowid DESC LIMIT 1').get() as any;
  assert.equal(last.reason_code, 'RESUBMITTED');
  assert.equal(last.previous_status, 'REJECTED');
});

test('approved or suspended profiles are locked against seller edits', async () => {
  const { db, entityId, now, adapter } = await submitted();
  decideEntity(db, admin1, entityId, { action: 'APPROVE' }, now);
  await rejectsWith(submitBusinessProfile(db, seller1, goodProfile({ legalName: 'Something Else Ltd' }), { adapter, now }), 'LOCKED');
});

test('history is append-only, enforced by the database', async () => {
  const { db } = await submitted();
  assert.throws(() => db.prepare("UPDATE entity_status_history SET reason_code = 'X'").run(), /append-only/);
  assert.throws(() => db.prepare('DELETE FROM entity_status_history').run(), /append-only/);
  assert.throws(() => db.prepare("UPDATE licence_check_events SET result = 'VALID'").run(), /append-only/);
  assert.throws(() => db.prepare('DELETE FROM licence_check_events').run(), /append-only/);
});

test('a licence number already claimed by another business is refused, not merged', async () => {
  const { db, adapter, now } = await submitted();
  await rejectsWith(submitBusinessProfile(db, seller2, goodProfile({ legalName: 'Other Co', displayName: 'Other' }), { adapter, now }), 'CONFLICT');
  assert.equal(getEntityForUser(db, 'seller2'), undefined, 'transaction rolled back');
  // and the database itself enforces it
  assert.throws(() => db.prepare(
    "INSERT INTO licence_records (id, entity_id, licence_type, licence_number, licence_number_normalized, issuing_authority, claim_source) SELECT 'x', id, 'TRADE_LICENCE', 'demo-tl-2026-0001', 'DEMO-TL-2026-0001', 'A', 'MANUAL_ENTRY' FROM business_entities LIMIT 1"
  ).run(), /UNIQUE/);
});

test('a renewal supersedes the old licence of the same type; the old one is kept', async () => {
  const { db, entityId, adapter, now } = await submitted();
  decideEntity(db, admin1, entityId, { action: 'APPROVE' }, now);
  const renewed = await submitLicence(db, seller1, { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2025-0004', issuingAuthority: 'Demo City Corporation (fictitious)', claimSource: 'OCR_EXTRACTED' }, { adapter, now });
  assert.equal(renewed.check_result, 'REVOKED');
  assert.equal(renewed.claim_source, 'OCR_EXTRACTED');
  assert.equal(getLicences(db, entityId).length, 1);
  assert.equal(getLicences(db, entityId, true).length, 2);
  assert.equal(getEntityForUser(db, 'seller1')!.status, 'APPROVED', 'adding a licence does not change the entity status');
});

test('a failed re-check keeps the earlier definitive answer and its original time; the attempt is recorded', async () => {
  const db = fixture(); const now = clock();
  const r = await submitBusinessProfile(db, seller1, goodProfile(), { adapter: scriptedAdapter('REAL', [{}]), now });
  assert.equal(r.licence.check_result, 'VALID');
  now.advanceHours(30);
  const after = await recheckLicence(db, seller1, r.licence.id, { adapter: scriptedAdapter('REAL', [{ outcome: 'UNAVAILABLE', checkedAt: null, errorCategory: 'TIMEOUT' }]), now });
  assert.equal(after.check_result, 'VALID');
  assert.equal(after.checked_at, '2026-10-28T06:00:00.000Z', 'not rewritten to the time of the failed attempt');
  assert.equal(after.last_attempt_at, '2026-10-29T12:00:00.000Z');
  assert.equal(after.error_category, 'TIMEOUT');
  const ev = db.prepare('SELECT result, checked_at FROM licence_check_events ORDER BY rowid').all() as any[];
  assert.deepEqual(ev.map((e) => [e.result, e.checked_at]), [['VALID', '2026-10-28T06:00:00.000Z'], ['UNAVAILABLE', null]]);
});

test('an adapter that throws is recorded as ERROR, never VALID', async () => {
  const db = fixture();
  const r = await submitBusinessProfile(db, seller1, goodProfile(), { adapter: scriptedAdapter('REAL', [new Error('boom')]), now: clock() });
  assert.equal(r.licence.check_result, 'ERROR');
  assert.equal(r.licence.error_category, 'ADAPTER_EXCEPTION');
  assert.equal(r.licence.checked_at, null);
});

test('re-check authorisation: owner or admin only; another seller sees "not found"', async () => {
  const { db, licenceId, adapter, now } = await submitted();
  await rejectsWith(recheckLicence(db, seller2, licenceId, { adapter, now }), 'NOT_FOUND');
  await rejectsWith(recheckLicence(db, buyer1, licenceId, { adapter, now }), 'FORBIDDEN');
  assert.equal((await recheckLicence(db, admin1, licenceId, { adapter, now })).check_result, 'VALID');
  const last = db.prepare('SELECT trigger_reason FROM licence_check_events ORDER BY rowid DESC LIMIT 1').get() as any;
  assert.equal(last.trigger_reason, 'ADMIN_RECHECK');
});

test('manual licence review is admin-only, labelled as a manual review and timestamped when it happened', async () => {
  const { db, licenceId, now } = await submitted();
  await rejectsWith(() => recordManualLicenceReview(db, seller1, licenceId, { result: 'VALID' }, now), 'FORBIDDEN');
  now.advanceHours(2);
  const l = recordManualLicenceReview(db, admin1, licenceId, { result: 'VALID' }, now);
  assert.equal(l.verification_method, 'AUTHORIZED_MANUAL_REVIEW');
  assert.equal(l.checked_at, '2026-10-28T08:00:00.000Z');
  assert.match(l.source_label!, /not a registry lookup/);
});

test('seller view hides internal notes and reviewer identity; admin view shows them', async () => {
  const { db, entityId, now } = await submitted();
  decideEntity(db, admin1, entityId, { action: 'REJECT', reasonCode: 'DOCUMENTS_INCOMPLETE', note: 'INTERNAL-SECRET-NOTE', publicNote: 'Upload a clearer licence.' }, now);
  const sv = JSON.stringify(sellerOnboardingView(db, seller1, policy(now()), { mode: 'mock', label: 'x', note: null }));
  assert.ok(!sv.includes('INTERNAL-SECRET-NOTE'));
  assert.ok(!sv.includes('admin1'));
  assert.ok(sv.includes('Upload a clearer licence.'));
  const av = JSON.stringify(adminEntityView(db, admin1, entityId, policy(now())));
  assert.ok(av.includes('INTERNAL-SECRET-NOTE'));
  assert.throws(() => adminEntityView(db, seller1, entityId, policy(now())), IdentityError);
});
