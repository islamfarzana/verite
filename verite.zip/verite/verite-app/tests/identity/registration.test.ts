import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateProductHash, simulateChainWrite } from '../../lib/blockchain';
import { decideEntity, recheckLicence, submitBusinessProfile, submitLicence } from '../../lib/identity/onboarding';
import { publicIdentityFor } from '../../lib/identity/public';
import { MockRegistryAdapter, UnconfiguredRegistryAdapter, type RegistryAdapter } from '../../lib/identity/registry';
import {
  finalizeRegistration, getProductIdentity, prepareRegistration, recordProductIdentity, verificationHash,
} from '../../lib/identity/registration';
import { IdentityError, type Db } from '../../lib/identity/types';
import { addProduct, addUser, admin1, clock, fixture, goodProfile, scriptedAdapter, seller1, seller2 } from './helpers';

const policyCfg = { mockAllowed: true, acceptManualReview: false, resultTtlHours: 24 };

/** The same steps the PATCH /api/products/[id] route performs (minus the optional real chain call). */
async function publish(db: Db, productId: string, adapter: RegistryAdapter, now: () => Date, policy = policyCfg) {
  const prepared = await prepareRegistration(db, seller1, productId, { adapter, policy, now });
  if (!prepared.ok) return prepared;
  const { txHash, blockNumber } = simulateChainWrite(prepared.hash);
  finalizeRegistration(db, productId, prepared, () => {
    db.prepare(
      `INSERT INTO blockchain_records (id, product_id, keccak_hash, tx_hash, block_number, network) VALUES (?, ?, ?, ?, ?, 'polygon-amoy-simulated')
       ON CONFLICT(product_id) DO UPDATE SET keccak_hash = excluded.keccak_hash`
    ).run(`bcr_${productId}`, productId, prepared.hash, txHash, blockNumber);
    db.prepare("UPDATE products SET status='PUBLISHED', verification_status='VERIFIED' WHERE id = ?").run(productId);
  });
  return prepared;
}

const productRow = (db: Db, id: string) =>
  db.prepare('SELECT p.*, u.email AS seller_email FROM products p LEFT JOIN users u ON u.id = p.seller_id WHERE p.id = ?').get(id) as Record<string, any>;
const status = (db: Db, id: string) => (db.prepare('SELECT status FROM products WHERE id = ?').get(id) as any).status;

async function approvedSeller(profile = goodProfile()) {
  const db = fixture(); const now = clock();
  const adapter = new MockRegistryAdapter(db, now);
  const r = await submitBusinessProfile(db, seller1, profile, { adapter, now });
  decideEntity(db, admin1, r.entity.id, { action: 'APPROVE' }, now);
  return { db, now, adapter, entityId: r.entity.id };
}

test('pending, rejected and suspended sellers cannot publish; the product stays a draft', async () => {
  const db = fixture(); const now = clock(); const adapter = new MockRegistryAdapter(db, now);
  addProduct(db, 'p0', 'seller1');
  let r = await publish(db, 'p0', adapter, now);
  assert.equal(r.ok, false); assert.equal((r as any).code, 'NO_BUSINESS_PROFILE');

  const sub = await submitBusinessProfile(db, seller1, goodProfile(), { adapter, now });
  r = await publish(db, 'p0', adapter, now);
  assert.equal((r as any).code, 'ENTITY_PENDING');

  decideEntity(db, admin1, sub.entity.id, { action: 'REJECT', reasonCode: 'DOCUMENTS_INCOMPLETE' }, now);
  assert.equal(((await publish(db, 'p0', adapter, now)) as any).code, 'ENTITY_REJECTED');

  await submitBusinessProfile(db, seller1, goodProfile(), { adapter, now });
  decideEntity(db, admin1, sub.entity.id, { action: 'APPROVE' }, now);
  decideEntity(db, admin1, sub.entity.id, { action: 'SUSPEND', reasonCode: 'POLICY_VIOLATION' }, now);
  assert.equal(((await publish(db, 'p0', adapter, now)) as any).code, 'ENTITY_SUSPENDED');

  assert.equal(status(db, 'p0'), 'DRAFT');
  assert.equal(db.prepare('SELECT COUNT(*) c FROM blockchain_records').get()!.c, 0);
});

test('approved seller with a demo-registry VALID licence can publish in demo mode only, recorded as demo basis', async () => {
  const { db, now, adapter } = await approvedSeller();
  addProduct(db, 'p1', 'seller1');
  const off = await publish(db, 'p1', adapter, now, { ...policyCfg, mockAllowed: false });
  assert.equal((off as any).code, 'MOCK_NOT_ALLOWED');
  const r = await publish(db, 'p1', adapter, now);
  assert.equal(r.ok, true);
  assert.equal(status(db, 'p1'), 'PUBLISHED');
  const pi = getProductIdentity(db, 'p1')!;
  assert.equal(pi.registration_basis, 'MOCK_REGISTRY_DEMO');
  assert.equal(pi.hash_schema_version, 2);
});

test('approved seller whose licence is expired, revoked, suspended, not found, unsupported or unavailable cannot publish', async () => {
  const cases: [string, string, string][] = [
    ['DEMO-TL-2024-0003', 'TRADE_LICENCE', 'LICENCE_EXPIRED'],
    ['DEMO-TL-2025-0004', 'TRADE_LICENCE', 'LICENCE_REVOKED'],
    ['DEMO-CM-2025-0005', 'BSTI_CM_LICENCE', 'LICENCE_SUSPENDED'],
    ['DEMO-TL-2025-0006', 'TRADE_LICENCE', 'LICENCE_INVALID'],
    ['DEMO-TL-7777-0000', 'TRADE_LICENCE', 'LICENCE_NOT_FOUND'],
    ['DEMO-TL-0000-OUTAGE', 'TRADE_LICENCE', 'REGISTRY_UNAVAILABLE'],
    ['DEMO-DG-0001', 'DGDA_LICENCE', 'VERIFICATION_UNSUPPORTED'],
  ];
  for (const [num, type, code] of cases) {
    const { db, now, adapter } = await approvedSeller(goodProfile({ licence: { ...goodProfile().licence, licenceNumber: num, licenceType: type } }));
    addProduct(db, 'px', 'seller1');
    const r = await publish(db, 'px', adapter, now);
    assert.equal((r as any).code, code, num);
    assert.equal(status(db, 'px'), 'DRAFT', num);
  }
});

test('no registry configured (production default): approved seller cannot publish; nothing is silently approved', async () => {
  const db = fixture(); const now = clock(); const adapter = new UnconfiguredRegistryAdapter();
  const r = await submitBusinessProfile(db, seller1, goodProfile(), { adapter, now });
  decideEntity(db, admin1, r.entity.id, { action: 'APPROVE' }, now);
  addProduct(db, 'p1', 'seller1');
  const p = await publish(db, 'p1', adapter, now, { ...policyCfg, mockAllowed: false });
  assert.equal((p as any).code, 'REGISTRY_UNAVAILABLE');
});

test('real registry VALID (fake HTTP via scripted adapter): publishable, basis REAL_REGISTRY; stale result is re-checked first', async () => {
  const db = fixture(); const now = clock();
  const r = await submitBusinessProfile(db, seller1, goodProfile(), { adapter: scriptedAdapter('REAL', [{}]), now });
  decideEntity(db, admin1, r.entity.id, { action: 'APPROVE' }, now);
  addProduct(db, 'p1', 'seller1');
  now.advanceHours(48); // result is now older than the 24 h TTL
  const later = scriptedAdapter('REAL', [{ outcome: 'REVOKED', checkedAt: '2026-10-30T06:00:00.000Z' }]);
  const p = await publish(db, 'p1', later, now);
  assert.equal(later.calls.length, 1, 'a pre-registration re-check happened');
  assert.equal((p as any).code, 'LICENCE_REVOKED', 'the fresh revocation blocks registration immediately');
  // A revoked result is sticky: publishing again does not quietly re-ask the registry...
  const idle = scriptedAdapter('REAL', [{}]);
  assert.equal(((await publish(db, 'p1', idle, now)) as any).code, 'LICENCE_REVOKED');
  assert.equal(idle.calls.length, 0);
  // ...only an explicit re-check (seller or admin) can change it.
  const again = scriptedAdapter('REAL', [{ checkedAt: '2026-10-30T06:00:00.000Z' }]);
  const lic = db.prepare('SELECT id FROM licence_records').get() as any;
  await recheckLicence(db, seller1, lic.id, { adapter: again, now });
  const ok = await publish(db, 'p1', again, now);
  assert.equal(ok.ok, true);
  assert.equal(getProductIdentity(db, 'p1')!.registration_basis, 'REAL_REGISTRY');
});

test('identity separation: the manufacturer is never the seller email; seller and manufacturer can differ', async () => {
  const { db, now, adapter, entityId } = await approvedSeller(goodProfile({ roles: ['SELLER'] }));
  addProduct(db, 'claim', 'seller1');
  addProduct(db, 'unknown', 'seller1');
  // a reseller cannot claim to be the manufacturer
  assert.throws(() => recordProductIdentity(db, seller1, 'claim', { manufacturer: { mode: 'SELF' } }, now), IdentityError);
  recordProductIdentity(db, seller1, 'claim', { manufacturer: { mode: 'CLAIM', name: 'Acme Mills Ltd' }, labelLicenceClaim: 'BSTI CM 1234' }, now);
  await publish(db, 'claim', adapter, now);
  await publish(db, 'unknown', adapter, now);

  const c = getProductIdentity(db, 'claim')!;
  assert.equal(c.manufacturer_identity, 'UNVERIFIED_CLAIM');
  assert.equal(c.manufacturer_entity_id, null);
  assert.equal(c.seller_entity_id, entityId);
  const u = getProductIdentity(db, 'unknown')!;
  assert.equal(u.manufacturer_identity, 'UNKNOWN', 'unknown manufacturer stays unknown, not copied from the seller');

  for (const id of ['claim', 'unknown']) {
    const snap = getProductIdentity(db, id)!.identity_snapshot_json!;
    assert.doesNotMatch(snap, /@/, 'no email anywhere in the snapshot');
  }
  // the database refuses a "verified" manufacturer reference without an entity
  assert.throws(() => db.prepare("INSERT INTO product_identity (product_id, manufacturer_identity) VALUES ('unknown2', 'ENTITY_REFERENCE')").run(), /CHECK|FOREIGN/);
});

test('SELF manufacturer is the seller’s own reviewed entity (by ID), and other sellers cannot touch the product', async () => {
  const { db, now, adapter, entityId } = await approvedSeller();
  addProduct(db, 'p1', 'seller1');
  assert.throws(() => recordProductIdentity(db, seller2, 'p1', { manufacturer: { mode: 'SELF' } }, now), IdentityError);
  assert.throws(() => recordProductIdentity(db, seller1, 'p1', { manufacturer: { mode: 'ENTITY', entityId } }, now), /administrator/);
  recordProductIdentity(db, seller1, 'p1', { manufacturer: { mode: 'SELF' } }, now);
  await publish(db, 'p1', adapter, now);
  const pi = getProductIdentity(db, 'p1')!;
  assert.equal(pi.manufacturer_entity_id, entityId);
  await assert.rejects(prepareRegistration(db, seller2, 'p1', { adapter, policy: policyCfg, now }), IdentityError);
});

test('changing the seller account email does not change the manufacturer reference or the v2 hash', async () => {
  const { db, now, adapter } = await approvedSeller();
  addProduct(db, 'p1', 'seller1');
  recordProductIdentity(db, seller1, 'p1', { manufacturer: { mode: 'SELF' } }, now);
  const pub = await publish(db, 'p1', adapter, now);
  assert.ok(pub.ok);
  const before = verificationHash(db, productRow(db, 'p1'));
  db.prepare("UPDATE users SET email = 'renamed@example.test' WHERE id = 'seller1'").run();
  const after = verificationHash(db, productRow(db, 'p1'));
  assert.equal(after.version, 2);
  assert.equal(after.hash, before.hash);
  assert.equal(after.hash, (db.prepare("SELECT keccak_hash FROM blockchain_records WHERE product_id='p1'").get() as any).keccak_hash);
});

test('renaming or suspending the entity later keeps the registered attribution and hash; the snapshot is frozen', async () => {
  const { db, now, adapter, entityId } = await approvedSeller();
  addProduct(db, 'p1', 'seller1');
  recordProductIdentity(db, seller1, 'p1', { manufacturer: { mode: 'SELF' } }, now);
  await publish(db, 'p1', adapter, now);
  const anchored = (db.prepare("SELECT keccak_hash FROM blockchain_records WHERE product_id='p1'").get() as any).keccak_hash;
  db.prepare("UPDATE business_entities SET display_name = 'New Name Ltd' WHERE id = ?").run(entityId);
  decideEntity(db, admin1, entityId, { action: 'SUSPEND', reasonCode: 'COMPLAINT_UNDER_REVIEW' }, now);
  assert.equal(verificationHash(db, productRow(db, 'p1')).hash, anchored);
  const pub = publicIdentityFor(db, 'p1') as any;
  assert.equal(pub.seller.name, 'Demo Foods', 'name as registered');
  assert.equal(pub.seller.currentStatus, 'SUSPENDED');
  assert.ok(pub.warnings.includes('SELLER_SUSPENDED_AFTER_REGISTRATION'));
  assert.throws(() => db.prepare("UPDATE product_identity SET manufacturer_claim_name = 'x' WHERE product_id = 'p1'").run(), /frozen/);
});

test('tampering with product data or with the stored identity snapshot is detected', async () => {
  const { db, now, adapter } = await approvedSeller();
  addProduct(db, 'p1', 'seller1');
  await publish(db, 'p1', adapter, now);
  const anchored = (db.prepare("SELECT keccak_hash FROM blockchain_records WHERE product_id='p1'").get() as any).keccak_hash;
  db.prepare("UPDATE products SET expiry_date = '2030-01-01' WHERE id = 'p1'").run();
  assert.notEqual(verificationHash(db, productRow(db, 'p1')).hash, anchored);
  db.prepare("UPDATE products SET expiry_date = '2027-01-01' WHERE id = 'p1'").run();
  assert.equal(verificationHash(db, productRow(db, 'p1')).hash, anchored);
  // bypass the freeze trigger the way an attacker with raw DB access would
  db.exec('DROP TRIGGER trg_product_identity_frozen');
  const snap = JSON.parse(getProductIdentity(db, 'p1')!.identity_snapshot_json!);
  snap.refs.manufacturer = { identity: 'ENTITY_REFERENCE', entityId: 'ent_fake', name: 'Famous Brand Ltd' };
  db.prepare('UPDATE product_identity SET identity_snapshot_json = ? WHERE product_id = ?').run(JSON.stringify(snap), 'p1');
  assert.notEqual(verificationHash(db, productRow(db, 'p1')).hash, anchored);
});

test('legacy (v1) records keep verifying exactly as before and are never promoted', () => {
  const db = fixture();
  addUser(db, 'legacySeller', 'SELLER', 'seller@verite.app');
  addProduct(db, 'old', 'legacySeller', '8901234567890');
  const row = productRow(db, 'old');
  const v1 = generateProductHash({
    productId: 'old', brand: 'DemoBrand', productName: 'Demo Rice 5kg', barcode: '8901234567890', batchNumber: 'LOT-DEMO-1',
    manufacturingDate: '2026-01-01', expiryDate: '2027-01-01', manufacturer: 'seller@verite.app',
  });
  db.prepare("INSERT INTO blockchain_records (id, product_id, keccak_hash, tx_hash, block_number) VALUES ('b', 'old', ?, '0x1', 1)").run(v1);
  const vh = verificationHash(db, row);
  assert.equal(vh.version, 1);
  assert.equal(vh.hash, v1);
  const pub = publicIdentityFor(db, 'old') as any;
  assert.equal(pub.legacy, true);
  assert.equal(pub.manufacturer.identity, 'NOT_RECORDED_LEGACY');
  assert.equal(getProductIdentity(db, 'old'), undefined, 'no identity row is invented for a legacy product');
});

test('re-publishing a legacy product never overwrites its v1 commitment', async () => {
  const { db, now, adapter } = await approvedSeller();
  addProduct(db, 'old', 'seller1');
  db.prepare("INSERT INTO blockchain_records (id, product_id, keccak_hash, tx_hash, block_number) VALUES ('b', 'old', '0xlegacy', '0x1', 1)").run();
  const r = await publish(db, 'old', adapter, now);
  assert.equal((r as any).code, 'LEGACY_RECORD_EXISTS');
  assert.equal((db.prepare("SELECT keccak_hash FROM blockchain_records WHERE product_id='old'").get() as any).keccak_hash, '0xlegacy');
});

test('publish retry after a registration reuses the frozen snapshot and yields the same hash', async () => {
  const { db, now, adapter } = await approvedSeller();
  addProduct(db, 'p1', 'seller1');
  const first = await publish(db, 'p1', adapter, now);
  now.advanceHours(1);
  const second = await prepareRegistration(db, seller1, 'p1', { adapter, policy: policyCfg, now });
  assert.ok(first.ok && second.ok);
  assert.equal(second.alreadyRegistered, true);
  assert.equal(second.hash, first.hash);
});

test('public identity summary: no emails, IDs, licence numbers or internal notes; mock is clearly labelled', async () => {
  const { db, now, adapter, entityId } = await approvedSeller();
  addProduct(db, 'p1', 'seller1');
  recordProductIdentity(db, seller1, 'p1', { manufacturer: { mode: 'SELF' } }, now);
  await publish(db, 'p1', adapter, now);
  const pub = publicIdentityFor(db, 'p1') as any;
  const s = JSON.stringify(pub);
  for (const secret of ['@', entityId, 'seller1', 'DEMO-TL-2026-0001', 'MOCK-REF-0001', 'lic_', 'ent_']) assert.ok(!s.includes(secret), `leaked ${secret}`);
  assert.equal(pub.licence.isMock, true);
  assert.equal(pub.licence.isRegistryResult, false);
  assert.match(pub.licence.sourceLabel, /MOCK\/DEMO REGISTRY — NOT OFFICIAL VERIFICATION/);
  assert.ok(pub.warnings.includes('DEMO_REGISTRY_RESULT'));
  assert.equal(pub.manufacturer.identity, 'SAME_ENTITY_AS_SELLER');
  assert.equal(pub.seller.identityReview, 'ADMIN_REVIEWED');
});

test('a later revocation shows on the public summary without rewriting the registration record', async () => {
  const { db, now, adapter } = await approvedSeller();
  addProduct(db, 'p1', 'seller1');
  await publish(db, 'p1', adapter, now);
  const lic = db.prepare('SELECT id FROM licence_records').get() as any;
  // simulate the registry later reporting the licence as revoked
  const { runLicenceCheck } = await import('../../lib/identity/onboarding');
  await runLicenceCheck(db, lic.id, scriptedAdapter('MOCK', [{ outcome: 'REVOKED' }]), 'ADMIN_RECHECK', admin1, now);
  const pub = publicIdentityFor(db, 'p1') as any;
  assert.equal(pub.licence.resultAtRegistration, 'VALID');
  assert.equal(pub.licence.currentResult, 'REVOKED');
  assert.ok(pub.warnings.includes('LICENCE_STATUS_CHANGED_AFTER_REGISTRATION'));
  // and new products are blocked immediately
  addProduct(db, 'p2', 'seller1');
  assert.equal(((await publish(db, 'p2', adapter, now)) as any).code, 'LICENCE_REVOKED');
  // renewing with a new licence supersedes it and allows registration again
  await submitLicence(db, seller1, { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2026-0001X', issuingAuthority: 'Demo City Corporation (fictitious)', claimSource: 'MANUAL_ENTRY' }, { adapter: scriptedAdapter('MOCK', [{}]), now });
  assert.equal((await publish(db, 'p2', adapter, now)).ok, true);
});
