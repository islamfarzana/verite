import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { canonicalizeV2, computeProductHashV2, type IdentitySnapshotRefs, type ProductFieldsV2 } from '../../lib/identity/hash';
import { keccakUtf8 } from '../../lib/identity/keccak';
import { canonicalize, generateProductHash } from '../../lib/blockchain';
import { keccak256Bytes } from './keccak';

const enc = (s: string) => new TextEncoder().encode(s);

test('Keccak-256 matches published test vectors (Ethereum Keccak, not SHA3-256)', () => {
  assert.equal(keccak256Bytes(enc('')), '0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470');
  assert.equal(keccak256Bytes(enc('abc')), '0x4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45');
  assert.equal(keccak256Bytes(enc('The quick brown fox jumps over the lazy dog')), '0x4d741b6f1eb29cb2a9b9911c82f56fa8d73b04959d3d9d222895df6c0b28aa15');
  // whichever ethers is loaded (real package or the offline test shim) must agree
  assert.equal(keccakUtf8('abc'), '0x4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45');
});

const P: ProductFieldsV2 = {
  productId: 'prod_1', productName: 'Demo Rice 5kg', brand: 'DemoBrand', barcode: '8901234567890', batchNumber: 'LOT-1',
  manufacturingDate: '2026-01-01', expiryDate: '2027-01-01',
};
const R: IdentitySnapshotRefs = {
  seller: { entityId: 'ent_a', displayName: 'Demo Foods' },
  manufacturer: { identity: 'ENTITY_REFERENCE', entityId: 'ent_a', name: 'Demo Foods' },
  brandOwner: { entityId: null, name: null },
};

test('canonical form is deterministic: key order, Unicode composition and surrounding spaces do not matter', () => {
  const a = canonicalizeV2({ b: 1, a: { y: 'Café', x: null } });
  const b = canonicalizeV2({ a: { x: undefined, y: ' Café ' }, b: 1 });
  assert.equal(a, b);
  assert.equal(a, '{"a":{"x":null,"y":"Café"},"b":1}');
  assert.throws(() => canonicalizeV2({ price: 1.5 }), /only integers/);
});

test('v2 hash is stable for identical input and declares its schema version in the preimage', () => {
  assert.equal(computeProductHashV2(P, R, keccakUtf8), computeProductHashV2({ ...P }, JSON.parse(JSON.stringify(R)), keccakUtf8));
  const s = canonicalizeV2({ schemaVersion: 2 });
  assert.ok(s.includes('"schemaVersion":2'));
});

test('identity changes that MUST change the hash do; distinct entities never collide', () => {
  const base = computeProductHashV2(P, R, keccakUtf8);
  const variants: IdentitySnapshotRefs[] = [
    { ...R, seller: { entityId: 'ent_b', displayName: 'Demo Foods' } },
    { ...R, manufacturer: { identity: 'UNVERIFIED_CLAIM', entityId: null, name: 'Demo Foods' } },
    { ...R, manufacturer: { identity: 'ENTITY_REFERENCE', entityId: 'ent_c', name: 'Demo Foods' } },
    { ...R, brandOwner: { entityId: 'ent_a', name: 'Demo Foods' } },
    { ...R, seller: { entityId: 'ent_a', displayName: 'Demo Foods 2' } },
  ];
  const hashes = new Set([base, ...variants.map((v) => computeProductHashV2(P, v, keccakUtf8))]);
  assert.equal(hashes.size, variants.length + 1);
  // Moving text between fields must not collide either (structured JSON, not concatenation).
  const x = computeProductHashV2(P, { ...R, manufacturer: { identity: 'UNVERIFIED_CLAIM', entityId: null, name: 'AB' } }, keccakUtf8);
  const y = computeProductHashV2({ ...P, brand: P.brand + 'A' }, { ...R, manufacturer: { identity: 'UNVERIFIED_CLAIM', entityId: null, name: 'B' } }, keccakUtf8);
  assert.notEqual(x, y);
});

test('v2 preimage contains no email address and no licence data', () => {
  const pre = canonicalizeV2({ schemaVersion: 2, ...P, ...R });
  assert.doesNotMatch(pre, /@/);
  assert.doesNotMatch(pre, /licen/i);
});

test('v1 (legacy) rule is unchanged: the same 8 flat fields with the seller email, as before this change', () => {
  // Pin the v1 canonical form, so legacy hashes already on-chain keep verifying.
  const v1 = { productId: 'prod_1', brand: 'DemoBrand', productName: 'Demo Rice 5kg', barcode: '8901234567890', batchNumber: 'LOT-1', manufacturingDate: '2026-01-01', expiryDate: '2027-01-01', manufacturer: 'seller@verite.app' };
  assert.equal(canonicalize(v1), '{"barcode":"8901234567890","batchNumber":"LOT-1","brand":"DemoBrand","expiryDate":"2027-01-01","manufacturer":"seller@verite.app","manufacturingDate":"2026-01-01","productId":"prod_1","productName":"Demo Rice 5kg"}');
  assert.equal(generateProductHash(v1), keccakUtf8(canonicalize(v1)));
  // lib/blockchain.ts itself was not modified by this change
  const src = readFileSync(join(__dirname, '../../lib/blockchain.ts'), 'utf8');
  assert.match(src, /manufacturer: string;/);
});
