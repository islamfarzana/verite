// TEST-ONLY stand-in for the `ethers` package, used ONLY when ethers is not installed (offline sandbox).
// Activated by NODE_PATH=tests/shims; when node_modules/ethers exists, Node resolves the real package first.
// It provides just the two functions lib/blockchain.ts and lib/identity/keccak.ts use.
const { keccak256Bytes } = require('../../identity/keccak.ts');
exports.toUtf8Bytes = (s) => new TextEncoder().encode(s);
exports.keccak256 = (bytes) => keccak256Bytes(bytes);
exports.__isTestShim = true;
