// Shared label-text -> structured-fields extraction.
//
// This mirrors the regex approach already used by app/api/ocr/upload/route.ts
// (that file is left completely untouched) and is used by the new
// app/api/ocr/extract/route.ts, which feeds it real OCR'd text instead of
// user-typed/sample text. Extended with productName, brand, and weight,
// which the image-upload flow needs but the original text-paste endpoint
// never extracted. Every field is null when not found in the text — no
// value is ever fabricated.

// v5: dates keep the printed DAY (the old helper always returned day 01, which made a correct expiry
// like 31/08/2027 look like 2027-08-01). Month-only dates: expiry -> last day, manufacture -> first day.
// Same parser as the AI/grounding layer (lib/ai/normalize.ts), which follows ocr-service/app/utils/dates.py.
import { normalizeDate as normalizeLabelDate } from './ai/normalize';

export interface ExtractedOcrFields {
  productName: string | null;
  brand: string | null;
  batchNumber: string | null;
  barcode: string | null;
  manufacturingDate: string | null;
  expiryDate: string | null;
  mrp: number | null;
  weight: string | null;
}

export function extractFieldsFromOcrText(text: string): ExtractedOcrFields {
  const batchNumber = text.match(/(?:BATCH\s*(?:NO\.?|NUMBER)?|LOT\s*(?:NO\.?)?)\s*:?\s*([A-Z0-9-]+)/i)?.[1] || null;
  const mrpRaw = text.match(/(?:MRP|M\.?R\.?P\.?|TK|BDT|₹|RS\.?)\s*:?\s*(\d+(?:\.\d+)?)/i)?.[1] || null;
  const barcode = text.match(/\b(\d{8,13})\b/)?.[1] || null;
  const mfgRaw = text.match(/(?:MFG|MFD|MANUFACTURING DATE|PACKED ON|PKD|PACKING DATE|PROD(?:UCTION)? DATE)\s*:?\s*([\d/-]+)/i)?.[1] || null;
  const expRaw = text.match(/(?:EXP|EXPIRY|EXPIRY DATE|BEST BEFORE|B\.?B\.?|USE BY)\s*:?\s*([\d/-]+)/i)?.[1] || null;
  const brand = text.match(/(?:BRAND)\s*:?\s*([A-Za-z0-9&' -]+)/i)?.[1]?.trim() || null;
  const productName = text.match(/(?:PRODUCT NAME|PRODUCT|NAME)\s*:?\s*([A-Za-z0-9&' -]+)/i)?.[1]?.trim() || null;
  const weight = text.match(/(?:NET\s*(?:WT|WEIGHT)\.?|NW|WEIGHT|WT\.?)\s*:?\s*(\d+(?:\.\d+)?\s?(?:G|GM|GRAMS?|KG|ML|L))\b/i)?.[1]?.trim() || null;

  return {
    productName,
    brand,
    batchNumber,
    barcode,
    manufacturingDate: mfgRaw ? normalizeLabelDate(mfgRaw, { endOfMonth: false }) : null,
    expiryDate: expRaw ? normalizeLabelDate(expRaw, { endOfMonth: true }) : null,
    mrp: mrpRaw ? Number(mrpRaw) : null,
    weight,
  };
}
