import { NextRequest } from 'next/server';
import { verifyToken, AUTH_COOKIE, JwtPayload } from '@/lib/auth-edge';

export async function getSession(req: NextRequest): Promise<JwtPayload | null> {
  const cookieToken = req.cookies.get(AUTH_COOKIE)?.value;
  // Also accept a Bearer header for API/CLI convenience, but cookies are the
  // primary mechanism the browser app uses (per the spec: JWT in a secure
  // cookie, not localStorage).
  const headerToken = req.headers.get('authorization')?.replace('Bearer ', '');
  const token = cookieToken || headerToken;
  if (!token) return null;
  return verifyToken(token);
}
