import bcrypt from 'bcryptjs';

// Node-only helpers (bcrypt needs real Node crypto). Regular API routes run
// in the Node runtime, so this is fine to import there. Re-exports the
// edge-safe JWT helpers too, so most files only need one import line.
export * from '@/lib/auth-edge';

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}
