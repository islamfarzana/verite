import sharp from 'sharp';

// Fallback enhanced cover (no background removal): trim the uniform border, centre on a white
// 1000x1000 square. Packet colours are not changed.
export async function localCover(input: Buffer): Promise<Buffer> {
  const trimmed = await sharp(input).rotate().trim({ threshold: 25 }).toBuffer().catch(() => sharp(input).rotate().toBuffer());
  const inner = await sharp(trimmed).resize(840, 840, { fit: 'inside' }).toBuffer();
  const meta = await sharp(inner).metadata();
  const w = meta.width || 840;
  const h = meta.height || 840;
  return sharp({ create: { width: 1000, height: 1000, channels: 3, background: { r: 255, g: 255, b: 255 } } })
    .composite([{ input: inner, left: Math.round((1000 - w) / 2), top: Math.round((1000 - h) / 2) }])
    .jpeg({ quality: 90 })
    .toBuffer();
}
