import { FixedWindowLimiter } from '../trace/ratelimit';

// Protects the Gemini free-tier quota from one user (or a bug) using it all up.
// In-memory, per server process (same limitation as lib/trace/ratelimit.ts).
const perMinute = new FixedWindowLimiter(Number(process.env.AI_REQUESTS_PER_MINUTE_PER_USER || 6));
const perDay = new FixedWindowLimiter(Number(process.env.AI_REQUESTS_PER_DAY || 200), 24 * 60 * 60 * 1000);

/** True when this user may make another AI call now. */
export function allowAiCall(userId: string, nowMs = Date.now()): boolean {
  return perMinute.allow(`ai:${userId}`, nowMs) && perDay.allow('ai:all', nowMs);
}
