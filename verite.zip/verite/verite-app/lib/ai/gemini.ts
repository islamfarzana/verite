// Minimal Google Gemini API client (REST, models.generateContent) — server-side only.
//
// The API key lives only in the server environment (GEMINI_API_KEY) and is sent in the
// x-goog-api-key header. It is never sent to the browser and never logged.
// Free tier: Google's Flash models are free of charge on the Gemini API free tier, with rate
// limits; on the free tier Google states that content may be used to improve its products.
//
// Every failure becomes an AiError with a non-sensitive category, so callers can fall back to
// OCR-only results instead of breaking the seller's flow.

export type AiErrorCategory =
  | 'NOT_CONFIGURED' | 'TIMEOUT' | 'NETWORK' | 'RATE_LIMITED' | 'AUTH' | 'BAD_REQUEST' | 'BLOCKED' | 'MALFORMED' | 'SERVER';

export class AiError extends Error {
  constructor(public category: AiErrorCategory, message: string) {
    super(message);
  }
}

export interface GeminiConfig {
  apiKey: string;
  model: string;
  baseUrl: string;
  timeoutMs: number;
}

export function loadGeminiConfig(env: Record<string, string | undefined> = process.env): GeminiConfig | null {
  const apiKey = (env.GEMINI_API_KEY || '').trim();
  if (!apiKey || (env.AI_PROVIDER || 'gemini').toLowerCase() === 'off') return null;
  const timeout = Number(env.GEMINI_TIMEOUT_MS || 30000);
  return {
    apiKey,
    // A Flash model listed as free of charge on the Gemini API free tier (checked 2026-10-28).
    // If the daily free limit is too low, try a Flash-Lite model, e.g. GEMINI_MODEL=gemini-3.5-flash-lite.
    model: (env.GEMINI_MODEL || 'gemini-3.8-flash').trim(),
    baseUrl: (env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com').replace(/\/$/, ''),
    timeoutMs: Number.isFinite(timeout) && timeout > 0 && timeout <= 120_000 ? timeout : 30000,
  };
}

export type GeminiPart = { text: string } | { inline_data: { mime_type: string; data: string } };

export type FetchLike = (url: string, init: { method: string; headers: Record<string, string>; body: string; signal: AbortSignal }) => Promise<{
  status: number;
  json(): Promise<unknown>;
}>;

export interface GenerateOptions {
  parts: GeminiPart[];
  system?: string;
  /** OpenAPI-style response schema (types OBJECT/STRING/...). Omit for free text. */
  schema?: Record<string, unknown>;
  json?: boolean;
  temperature?: number;
}

function stripFences(s: string): string {
  const t = s.trim();
  const m = t.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return m ? m[1] : t;
}

async function callOnce(cfg: GeminiConfig, opts: GenerateOptions, withSchema: boolean, fetchImpl: FetchLike) {
  const body: Record<string, unknown> = {
    contents: [{ role: 'user', parts: opts.parts }],
    generation_config: {
      temperature: opts.temperature ?? 0,
      ...(opts.json || opts.schema ? { response_mime_type: 'application/json' } : {}),
      ...(withSchema && opts.schema ? { response_schema: opts.schema } : {}),
    },
  };
  if (opts.system) body.system_instruction = { parts: [{ text: opts.system }] };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), cfg.timeoutMs);
  let res: { status: number; json(): Promise<unknown> };
  try {
    res = await fetchImpl(`${cfg.baseUrl}/v1beta/models/${encodeURIComponent(cfg.model)}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': cfg.apiKey },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (err) {
    const aborted = controller.signal.aborted || (err as Error)?.name === 'AbortError';
    throw new AiError(aborted ? 'TIMEOUT' : 'NETWORK', aborted ? 'The AI service did not answer in time.' : 'The AI service could not be reached.');
  } finally {
    clearTimeout(timer);
  }
  return res;
}

/** Call Gemini and return the model's text output (raw). */
export async function generate(cfg: GeminiConfig | null, opts: GenerateOptions, fetchImpl: FetchLike = fetch as unknown as FetchLike): Promise<string> {
  if (!cfg) throw new AiError('NOT_CONFIGURED', 'No AI provider is configured (GEMINI_API_KEY is not set).');
  let res = await callOnce(cfg, opts, true, fetchImpl);
  // A 400 can mean the response schema uses a feature this model/API version rejects:
  // retry once with JSON mode only (the prompt also describes the expected fields).
  if (res.status === 400 && opts.schema) res = await callOnce(cfg, opts, false, fetchImpl);

  if (res.status === 429) throw new AiError('RATE_LIMITED', 'The AI free-tier limit was reached. Try again later.');
  if (res.status === 401 || res.status === 403) throw new AiError('AUTH', 'The AI API key was rejected.');
  if (res.status === 400 || res.status === 404) throw new AiError('BAD_REQUEST', `The AI service rejected the request (HTTP ${res.status}). Check GEMINI_MODEL.`);
  if (res.status >= 500) throw new AiError('SERVER', `The AI service failed (HTTP ${res.status}).`);
  if (res.status !== 200) throw new AiError('SERVER', `Unexpected AI response (HTTP ${res.status}).`);

  let payload: any;
  try { payload = await res.json(); } catch { throw new AiError('MALFORMED', 'The AI service returned an unreadable response.'); }
  if (payload?.promptFeedback?.blockReason) throw new AiError('BLOCKED', 'The AI service declined to process this request.');
  const cand = payload?.candidates?.[0];
  if (!cand) throw new AiError('MALFORMED', 'The AI service returned no answer.');
  if (cand.finishReason === 'SAFETY' || cand.finishReason === 'PROHIBITED_CONTENT') throw new AiError('BLOCKED', 'The AI service declined to process this request.');
  const text = (cand.content?.parts || []).map((p: any) => (typeof p?.text === 'string' ? p.text : '')).join('');
  if (!text.trim()) throw new AiError('MALFORMED', 'The AI service returned an empty answer.');
  return text;
}

/** Call Gemini in JSON mode and parse the result. */
export async function generateJson<T>(cfg: GeminiConfig | null, opts: GenerateOptions, fetchImpl?: FetchLike): Promise<T> {
  const text = await generate(cfg, { ...opts, json: true }, fetchImpl);
  try {
    return JSON.parse(stripFences(text)) as T;
  } catch {
    throw new AiError('MALFORMED', 'The AI answer was not valid JSON.');
  }
}
