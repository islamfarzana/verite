// Normalisation shared by the AI extraction and the grounding check.
// Mirrors ocr-service/app/utils/dates.py so OCR and AI values are compared on the same terms.

const BN_DIGITS = '০১২৩৪৫৬৭৮৯';

export function toAsciiDigits(s: string): string {
  return s.replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
}

const MONTHS: Record<string, number> = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };

// Bengali month names (with spelling variants) -> English 3-letter month. Longest first.
const BN_MONTHS: [string, string][] = ([
  ['জানুয়ারি', 'JAN'], ['জানুয়ারী', 'JAN'], ['জানু', 'JAN'], ['ফেব্রুয়ারি', 'FEB'], ['ফেব্রুয়ারী', 'FEB'], ['ফেব্রু', 'FEB'],
  ['মার্চ', 'MAR'], ['এপ্রিল', 'APR'], ['মে', 'MAY'], ['জুন', 'JUN'], ['জুলাই', 'JUL'], ['আগস্ট', 'AUG'], ['আগষ্ট', 'AUG'],
  ['সেপ্টেম্বর', 'SEP'], ['সেপ্টে', 'SEP'], ['অক্টোবর', 'OCT'], ['অক্টো', 'OCT'], ['নভেম্বর', 'NOV'], ['নভে', 'NOV'],
  ['ডিসেম্বর', 'DEC'], ['ডিসে', 'DEC'],
] as [string, string][]).map(([bn, en]) => [bn.normalize('NFC'), en] as [string, string]).sort((a, b) => b[0].length - a[0].length);

function daysInMonth(y: number, m: number) {
  return new Date(Date.UTC(y, m, 0)).getUTCDate();
}

function iso(y: number, m: number, d: number) {
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

/**
 * Printed date -> YYYY-MM-DD, or null. Month-only dates use the LAST day for expiry and the
 * FIRST day for manufacturing (how FMCG labels are meant). Only reformats what is present.
 */
export function normalizeDate(raw: string | null | undefined, opts: { endOfMonth: boolean }): string | null {
  if (!raw) return null;
  let t = toAsciiDigits(raw.normalize('NFC'));
  for (const [bn, en] of BN_MONTHS) {
    t = t.replace(new RegExp(`(?<![\\u0980-\\u09FF])${bn}(?![\\u0980-\\u09FF])`, 'g'), ` ${en} `);
  }
  t = t.replace(/ইং|সাল/g, ' ').replace(/\s+/g, ' ').trim().replace(/^[\s.,:-]+|[\s.,:-]+$/g, '');

  const finish = (y: number, m: number | undefined, d: number | null): string | null => {
    if (!m || m < 1 || m > 12) return null;
    if (y < 100) y += 2000;
    if (y < 1990 || y > 2100) return null;
    const max = daysInMonth(y, m);
    if (d === null) d = opts.endOfMonth ? max : 1;
    if (d < 1 || d > 31) return null;
    return iso(y, m, Math.min(d, max));
  };
  const tries: [RegExp, (m: RegExpMatchArray) => string | null][] = [
    [/(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})/, (m) => finish(+m[1], +m[2], +m[3])],
    [/(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})/, (m) => finish(+m[3], +m[2], +m[1])],
    [/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2})$/, (m) => finish(2000 + +m[3], +m[2], +m[1])],
    [/(\d{1,2})[\s\-.]*([A-Za-z]{3,9})[\s\-.,]*(\d{4}|\d{2})\b/, (m) => finish(m[3].length === 2 ? 2000 + +m[3] : +m[3], MONTHS[m[2].slice(0, 3).toLowerCase()], +m[1])],
    [/^(\d{4})[/\-.](\d{1,2})$/, (m) => finish(+m[1], +m[2], null)],
    [/^(\d{1,2})[/\-.](\d{4})$/, (m) => finish(+m[2], +m[1], null)],
    [/^(\d{1,2})\/(\d{2})$/, (m) => finish(2000 + +m[2], +m[1], null)],
    [/([A-Za-z]{3,9})[\s\-.]?(\d{2,4})/, (m) => finish(m[2].length === 2 ? 2000 + +m[2] : +m[2], MONTHS[m[1].slice(0, 3).toLowerCase()], null)],
    [/^(\d{2})(\d{4})$/, (m) => finish(+m[2], +m[1], null)],
  ];
  for (const [rx, f] of tries) {
    const m = t.match(rx);
    if (!m) continue;
    const out = f(m);
    if (out) return out;
  }
  return null;
}

/** "৳ ১৫০" / "Tk. 150.00" / "150 টাকা" -> 150. Null if no number. */
export function normalizePrice(raw: string | number | null | undefined): number | null {
  if (raw === null || raw === undefined) return null;
  const m = toAsciiDigits(String(raw)).replace(/,/g, '').match(/\d+(?:\.\d{1,2})?/);
  return m ? Number(m[0]) : null;
}

const UNITS: [RegExp, string][] = [
  [/^(?:kg|kgs|কেজি|কে\.?জি\.?)$/i, 'KG'], [/^(?:g|gm|gms|gram|grams|গ্রাম|গ্রা\.?)$/i, 'G'], [/^(?:mg)$/i, 'MG'],
  [/^(?:ml|মিলি|মিলিলিটার|মি\.?লি\.?)$/i, 'ML'], [/^(?:l|ltr|litre|liter|লিটার|লি\.?)$/i, 'L'],
];

/** "৫০০ গ্রাম" / "500gm" -> "500 G". Null when there is no number + known unit. */
export function normalizeWeight(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const m = toAsciiDigits(raw.normalize('NFC')).match(/(\d+(?:\.\d+)?)\s*([A-Za-zঀ-৿.]+)/);
  if (!m) return null;
  const unit = UNITS.find(([rx]) => rx.test(m[2].trim()))?.[1];
  return unit ? `${m[1]} ${unit}` : null;
}

/** For comparisons: NFC, ASCII digits, case-folded, without spaces and punctuation. */
export function comparable(s: string | number | null | undefined): string {
  if (s === null || s === undefined) return '';
  return toAsciiDigits(String(s).normalize('NFC'))
    .toLowerCase()
    .replace(/[‌‍]/g, '')
    .replace(/[\s.,:;|/\\'"`()\-–—_৳]/g, '');
}
