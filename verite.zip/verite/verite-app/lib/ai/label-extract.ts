import { AiError, generateJson, type FetchLike, type GeminiConfig, type GeminiPart } from './gemini';
import { comparable, normalizeDate, normalizePrice, normalizeWeight, toAsciiDigits } from './normalize';

// AI label reading (Gemini vision) + grounding against OCR.
//
// The vision model reads the FRONT and BACK photos together and returns each field exactly as
// printed. We then normalise it ourselves (dates, prices, weights) and check it against the OCR
// text: a value the AI read that also appears in the independently OCR'd text is "confirmed";
// a value only the AI produced is shown to the seller as "AI read this — please check".
// Vision models can produce plausible but wrong values; a product authenticity system must
// never silently publish an invented expiry date. The seller still reviews every field.

export const LABEL_FIELDS = [
  'productName', 'productNameBn', 'brand', 'manufacturer', 'batchNumber', 'manufacturingDate', 'expiryDate',
  'mrp', 'weight', 'barcode', 'licenceNumber', 'countryOfOrigin',
] as const;
export type LabelField = (typeof LABEL_FIELDS)[number];

export type FieldStatus =
  | 'AGREED' // OCR and AI read the same value
  | 'AI_CONFIRMED_BY_TEXT' // AI's value appears in the OCR text (OCR's parser missed or mis-assigned it)
  | 'OCR_ONLY' // only OCR found it (AI not used or found nothing)
  | 'AI_ONLY_CHECK' // only the AI read it; not found in OCR text -> seller must check
  | 'CONFLICT' // both found different values and the AI's is not in the OCR text -> seller must check
  | 'NOT_FOUND';

export interface FieldOutcome {
  value: string | number | null;
  status: FieldStatus;
  ocrValue: string | number | null;
  aiValue: string | number | null;
  aiPrinted: string | null; // what the AI says is printed, before normalisation
}

const DESCRIPTIONS: Record<LabelField, string> = {
  productName: 'Product name in English/Latin script, as printed (e.g. "Chashi Chinigura Rice")',
  productNameBn: 'Product name in Bengali script, as printed (e.g. "চাষী চিনিগুড়া চাল")',
  brand: 'Brand name, as printed',
  manufacturer: 'Company that manufactured the product (after "Manufactured by" / "প্রস্তুতকারক" / "উৎপাদনকারী"), as printed',
  batchNumber: 'Batch or lot number (after "Batch"/"Lot"/"ব্যাচ নং"), exactly as printed',
  manufacturingDate: 'Manufacturing / packing date exactly as printed (after MFG / উৎপাদনের তারিখ), keep the printed format and digits',
  expiryDate: 'Expiry / best-before date exactly as printed (after EXP / মেয়াদ উত্তীর্ণের তারিখ), keep the printed format and digits',
  mrp: 'Maximum retail price (MRP / সর্বোচ্চ খুচরা মূল্য) as printed, including currency text if present',
  weight: 'Net weight or volume as printed, with unit (e.g. "500 g", "১ কেজি", "1 L")',
  barcode: 'Barcode number printed under the barcode (digits only), if legible',
  licenceNumber: 'BSTI / licence / registration number as printed',
  countryOfOrigin: 'Country of origin / made in, as printed',
};

export const LABEL_SCHEMA = {
  type: 'OBJECT',
  properties: {
    ...Object.fromEntries(LABEL_FIELDS.map((f) => [f, { type: 'STRING', nullable: true, description: DESCRIPTIONS[f] }])),
    languagesSeen: { type: 'ARRAY', items: { type: 'STRING' }, description: 'Scripts seen on the pack: "bn" and/or "en"' },
    legibilityProblems: { type: 'STRING', nullable: true, description: 'Short note if parts are blurred, cut off or covered' },
  },
  required: [...LABEL_FIELDS],
};

export const LABEL_SYSTEM_PROMPT = [
  'You read photos of consumer product packages sold in Bangladesh. Text can be Bengali (Bangla), English, or both.',
  'Return ONLY information that is actually printed and legible on the package.',
  'If a field is not visible, not legible, or you are not sure, return null for it. Never guess, infer, or fill in typical values.',
  'Copy values exactly as printed (keep Bengali digits and the printed date format); do not translate or reformat.',
  'Do not confuse the manufacturing date with the expiry date, or the MRP with other numbers.',
].join(' ');

export interface AiLabelResult {
  printed: Partial<Record<LabelField, string | null>>;
  languagesSeen: string[];
  legibilityProblems: string | null;
}

export async function aiReadLabel(
  cfg: GeminiConfig | null,
  images: { mimeType: string; base64: string; side: 'front' | 'back' }[],
  fetchImpl?: FetchLike
): Promise<AiLabelResult> {
  const parts: GeminiPart[] = [];
  for (const img of images) {
    parts.push({ text: `Photo of the ${img.side.toUpperCase()} of the package:` });
    parts.push({ inline_data: { mime_type: img.mimeType, data: img.base64 } });
  }
  parts.push({ text: `Extract these fields as JSON (null when not printed): ${LABEL_FIELDS.join(', ')}, languagesSeen, legibilityProblems.` });
  const raw = await generateJson<Record<string, unknown>>(cfg, { system: LABEL_SYSTEM_PROMPT, parts, schema: LABEL_SCHEMA }, fetchImpl);
  if (!raw || typeof raw !== 'object') throw new AiError('MALFORMED', 'The AI answer had an unexpected shape.');
  const printed: AiLabelResult['printed'] = {};
  for (const f of LABEL_FIELDS) {
    const v = raw[f];
    printed[f] = typeof v === 'string' && v.trim() && !/^(null|n\/a|none|unknown|not visible)$/i.test(v.trim()) ? v.trim().slice(0, 200) : null;
  }
  return {
    printed,
    languagesSeen: Array.isArray(raw.languagesSeen) ? raw.languagesSeen.filter((x): x is string => typeof x === 'string').slice(0, 4) : [],
    legibilityProblems: typeof raw.legibilityProblems === 'string' ? raw.legibilityProblems.slice(0, 300) : null,
  };
}

/** Convert a printed value to the form the product form uses. */
export function normalizeField(field: LabelField, printed: string | null): string | number | null {
  if (!printed) return null;
  switch (field) {
    case 'manufacturingDate': return normalizeDate(printed, { endOfMonth: false });
    case 'expiryDate': return normalizeDate(printed, { endOfMonth: true });
    case 'mrp': return normalizePrice(printed);
    case 'weight': return normalizeWeight(printed) ?? printed;
    case 'barcode': {
      const d = toAsciiDigits(printed).replace(/\D/g, '');
      return d.length >= 8 && d.length <= 14 ? d : null;
    }
    case 'batchNumber': return toAsciiDigits(printed).toUpperCase();
    default: return printed;
  }
}

const PRICE_LINE = /(m\.?r\.?p|price|tk|৳|টাকা|মূল্য|মুল্য|দাম)/i;

/** True when the AI's printed text (or its normalised value) is found in the OCR text. */
export function groundedInOcr(field: LabelField, printed: string | null, value: string | number | null, ocrText: string): boolean {
  if (!printed && value === null) return false;
  const hay = comparable(ocrText);
  if (!hay) return false;
  const candidates = [printed, value].filter((x) => x !== null && x !== undefined).map((x) => comparable(x as string | number));
  if (field === 'mrp') {
    // A price is only "confirmed" when the number appears on a line that is about price
    // (MRP / মূল্য / ৳ / টাকা / Tk) — "15" in a date like 15/01/2026 does not count.
    if (value === null) return false;
    const num = new RegExp(`(^|[^\\d.])${String(value).replace('.', '\\.')}(\\.0+)?([^\\d]|$)`);
    return toAsciiDigits(ocrText.normalize('NFC')).split('\n').some((line) => PRICE_LINE.test(line) && num.test(line));
  }
  if (candidates.some((c) => c.length >= 3 && hay.includes(c))) return true;
  // Long free-text fields (names): most of their words must appear in the OCR text.
  if (printed && ['productName', 'productNameBn', 'brand', 'manufacturer', 'countryOfOrigin'].includes(field)) {
    const words = printed.normalize('NFC').split(/\s+/).map(comparable).filter((w) => w.length >= 2);
    if (words.length >= 2) return words.filter((w) => hay.includes(w)).length / words.length >= 0.75;
  }
  return false;
}

function same(field: LabelField, a: string | number | null, b: string | number | null) {
  if (a === null || b === null) return false;
  if (field === 'mrp') return Number(a) === Number(b);
  return comparable(a) === comparable(b);
}

/** Merge OCR fields and the AI reading into one value per field, with a status the seller sees. */
export function mergeOcrAndAi(
  ocr: Partial<Record<string, string | number | null>>,
  ai: AiLabelResult | null,
  ocrText: string
): Record<LabelField, FieldOutcome> {
  const out = {} as Record<LabelField, FieldOutcome>;
  for (const f of LABEL_FIELDS) {
    const ocrValue = (ocr[f] ?? null) as string | number | null;
    const aiPrinted = ai?.printed[f] ?? null;
    const aiValue = ai ? normalizeField(f, aiPrinted) : null;
    let value: string | number | null;
    let status: FieldStatus;
    if (aiValue === null && ocrValue === null) { value = null; status = 'NOT_FOUND'; }
    else if (aiValue === null) { value = ocrValue; status = 'OCR_ONLY'; }
    else if (same(f, aiValue, ocrValue)) { value = aiValue; status = 'AGREED'; }
    else if (groundedInOcr(f, aiPrinted, aiValue, ocrText)) { value = aiValue; status = 'AI_CONFIRMED_BY_TEXT'; }
    else if (ocrValue === null) { value = aiValue; status = 'AI_ONLY_CHECK'; }
    else { value = aiValue; status = 'CONFLICT'; }
    out[f] = { value, status, ocrValue, aiValue, aiPrinted };
  }
  return out;
}
