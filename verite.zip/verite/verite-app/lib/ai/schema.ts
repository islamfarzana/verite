// v4 AI-assisted listing data. Additive tables only (no existing table is altered).
// Rollback: DROP TABLE product_image_meta; DROP TABLE product_label_extractions;
export const AI_SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS product_label_extractions (
  product_id TEXT PRIMARY KEY REFERENCES products(id),
  name_bn TEXT,
  -- what the seller confirmed, and how each value was obtained (OCR / AI / both), for audit
  fields_json TEXT NOT NULL,
  field_status_json TEXT,
  ai_provider TEXT,
  ai_model TEXT,
  ocr_source TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS product_image_meta (
  image_url TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  kind TEXT NOT NULL CHECK (kind IN ('ENHANCED_FROM_SELLER_PHOTO')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_image_meta_product ON product_image_meta(product_id);
`;
