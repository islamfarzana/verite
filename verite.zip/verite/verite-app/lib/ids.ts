import crypto from 'crypto';

export function newId(prefix: string): string {
  return `${prefix}_${crypto.randomUUID()}`;
}

export function newOrderNumber(): string {
  return `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
}
