import { NextRequest, NextResponse } from 'next/server';
import db from '../db';
import { getSession } from '../session';
import { IdentityError } from '../identity/types';
import { ProtectionError } from './errors';

// Route helpers for the buyer-protection API.

export async function requireRole(req: NextRequest, roles: ('BUYER' | 'SELLER' | 'ADMIN')[]) {
  const s = await getSession(req);
  if (!s) throw new ProtectionError('UNAUTHENTICATED', 'Please sign in first.');
  if (!roles.includes(s.role)) throw new ProtectionError('FORBIDDEN', `This action needs a ${roles.join(' or ').toLowerCase()} account.`);
  // A sign-in cookie can outlive its account (e.g. the database file was deleted and re-seeded):
  // ask the user to sign in again instead of failing later on a foreign key.
  if (!db.prepare('SELECT 1 FROM users WHERE id = ?').get(s.id)) {
    throw new ProtectionError('UNAUTHENTICATED', 'Your account was not found in this database. Please sign out and sign in again.');
  }
  return { id: s.id, role: s.role as 'BUYER' | 'SELLER' | 'ADMIN' };
}

/** JSON-only bodies (with SameSite=Lax cookies this blocks cross-site form posts), size-limited. */
export async function readJson(req: NextRequest): Promise<any> {
  if (!(req.headers.get('content-type') || '').toLowerCase().startsWith('application/json')) {
    throw new ProtectionError('INVALID', 'Requests must be sent as JSON.');
  }
  const text = await req.text();
  if (text.length > 20_000) throw new ProtectionError('INVALID', 'Request is too large.');
  try { return JSON.parse(text || '{}'); } catch { throw new ProtectionError('INVALID', 'Malformed JSON.'); }
}

export function protectionErrorResponse(err: unknown) {
  if (err instanceof ProtectionError) return NextResponse.json(err.toBody(), { status: err.status });
  if (err instanceof IdentityError) {
    const status: Record<string, number> = { UNAUTHENTICATED: 401, FORBIDDEN: 403, NOT_FOUND: 404, INVALID: 422, RATE_LIMITED: 429 };
    return NextResponse.json({ success: false, code: err.code, message: err.message }, { status: status[err.code] ?? 409 });
  }
  console.error('Unexpected buyer-protection error:', (err as Error)?.name || 'unknown', (err as Error)?.message?.slice(0, 120));
  return NextResponse.json({ success: false, message: 'Something went wrong. Please try again.' }, { status: 500 });
}
