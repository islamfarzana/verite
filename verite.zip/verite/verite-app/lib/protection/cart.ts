import type { Db } from '../trace/types';
import type { ProtectionConfig } from './config';
import { ProtectionError } from './errors';
import { activeRecall, evaluateProtection, loadProduct } from './sellability';

// Server-side cart: one row per (buyer, product) in the database, so the cart survives closing the
// browser, signing in on another device, and server restarts. Every add re-checks sellability.

export const MAX_LINE_QTY = 99;

export interface CartLine {
  productId: string;
  name: string;
  emoji: string | null;
  coverImageUrl: string | null;
  price: number;
  quantity: number;
  lineTotal: number;
  available: boolean;
  reasons: { code: string; en: string; bn: string }[];
  expiry: { state: string; textEn: string | null; textBn: string | null };
}

export function getCart(db: Db, buyerId: string, now: Date, cfg: ProtectionConfig) {
  const rows = db.prepare(
    `SELECT ci.product_id, ci.quantity, p.name, p.image_emoji,
            (SELECT image_url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS cover_image_url
     FROM cart_items ci JOIN products p ON p.id = ci.product_id
     WHERE ci.buyer_id = ? ORDER BY ci.added_at, ci.product_id`
  ).all(buyerId) as { product_id: string; quantity: number; name: string; image_emoji: string | null; cover_image_url: string | null }[];

  const lines: CartLine[] = rows.map((r) => {
    const p = loadProduct(db, r.product_id)!;
    const prot = evaluateProtection(p, activeRecall(db, p.id), now, cfg, Number(r.quantity));
    const pricePaisa = prot.pricing.pricePaisa;
    return {
      productId: r.product_id, name: r.name, emoji: r.image_emoji, coverImageUrl: r.cover_image_url,
      price: p.price, quantity: Number(r.quantity), lineTotal: (pricePaisa * Number(r.quantity)) / 100,
      available: prot.sellable, reasons: prot.blockers.map(({ code, en, bn }) => ({ code, en, bn })),
      expiry: { state: prot.expiry.state, textEn: prot.expiry.textEn, textBn: prot.expiry.textBn },
    };
  });
  const subtotalPaisa = lines.filter((l) => l.available).reduce((s, l) => s + Math.round(l.price * 100) * l.quantity, 0);
  return { lines, subtotal: subtotalPaisa / 100, itemCount: lines.reduce((s, l) => s + l.quantity, 0), unavailableCount: lines.filter((l) => !l.available).length };
}

function assertQty(q: unknown): number {
  const n = Number(q);
  if (!Number.isInteger(n) || n < 1 || n > MAX_LINE_QTY) throw new ProtectionError('INVALID', `Quantity must be a whole number from 1 to ${MAX_LINE_QTY}.`);
  return n;
}

/** Add `quantity` to the buyer's line for this product (creating it). Refused when the product can't be sold. */
export function addToCart(db: Db, buyerId: string, productId: string, quantity: unknown, now: Date, cfg: ProtectionConfig) {
  const add = assertQty(quantity);
  const p = loadProduct(db, productId);
  if (!p) throw new ProtectionError('NOT_FOUND', 'Product not found.');
  const existing = db.prepare('SELECT quantity FROM cart_items WHERE buyer_id = ? AND product_id = ?').get(buyerId, productId) as { quantity: number } | undefined;
  const target = Math.min(MAX_LINE_QTY, (existing ? Number(existing.quantity) : 0) + add);
  const prot = evaluateProtection(p, activeRecall(db, productId), now, cfg, target);
  if (!prot.sellable) throw new ProtectionError('NOT_SELLABLE', prot.blockers[0].en, prot.blockers, prot.blockers[0].bn);
  const ts = now.toISOString();
  db.prepare(
    `INSERT INTO cart_items (buyer_id, product_id, quantity, added_at, updated_at) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(buyer_id, product_id) DO UPDATE SET quantity = excluded.quantity, updated_at = excluded.updated_at`
  ).run(buyerId, productId, target, ts, ts);
  return target;
}

/** Set the line to an exact quantity (the cart page's +/- buttons). Lowering is always allowed. */
export function setCartQuantity(db: Db, buyerId: string, productId: string, quantity: unknown, now: Date, cfg: ProtectionConfig) {
  const q = assertQty(quantity);
  const existing = db.prepare('SELECT quantity FROM cart_items WHERE buyer_id = ? AND product_id = ?').get(buyerId, productId) as { quantity: number } | undefined;
  if (!existing) throw new ProtectionError('NOT_FOUND', 'This item is not in your cart.');
  if (q > Number(existing.quantity)) {
    const p = loadProduct(db, productId)!;
    const prot = evaluateProtection(p, activeRecall(db, productId), now, cfg, q);
    if (!prot.sellable) throw new ProtectionError('NOT_SELLABLE', prot.blockers[0].en, prot.blockers, prot.blockers[0].bn);
  }
  db.prepare('UPDATE cart_items SET quantity = ?, updated_at = ? WHERE buyer_id = ? AND product_id = ?').run(q, now.toISOString(), buyerId, productId);
  return q;
}

export function removeFromCart(db: Db, buyerId: string, productId: string | null) {
  if (productId === null) return Number(db.prepare('DELETE FROM cart_items WHERE buyer_id = ?').run(buyerId).changes);
  return Number(db.prepare('DELETE FROM cart_items WHERE buyer_id = ? AND product_id = ?').run(buyerId, productId).changes);
}

/** One-time import of an old browser (localStorage) cart. Items that can't be sold are skipped and counted. */
export function mergeCart(db: Db, buyerId: string, items: { productId: unknown; quantity: unknown }[], now: Date, cfg: ProtectionConfig) {
  let added = 0;
  let skipped = 0;
  for (const it of items.slice(0, 50)) {
    try {
      if (typeof it.productId !== 'string') throw new Error('bad id');
      addToCart(db, buyerId, it.productId, Math.min(MAX_LINE_QTY, Math.max(1, Math.trunc(Number(it.quantity)) || 1)), now, cfg);
      added += 1;
    } catch {
      skipped += 1;
    }
  }
  return { added, skipped };
}
