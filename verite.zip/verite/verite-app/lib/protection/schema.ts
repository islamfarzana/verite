import type { Db } from '../trace/types';
import { sellerNotificationsTableSql } from '../assistant/schema';

// v5 buyer protection + persistence. Applied by lib/db.ts after the older schemas, and by the tests,
// so both use the same definitions. Everything is additive and idempotent:
//   - new tables use CREATE ... IF NOT EXISTS;
//   - new columns are added only when PRAGMA table_info says they are missing;
//   - the seller_notifications rebuild (new CHECK values) runs only when the old CHECK is detected,
//     inside one transaction, copying every row.
// Rollback: DROP the new tables and trigger; the added columns are nullable and ignored by v4 code.

export const PROTECTION_TABLES_SQL = `
CREATE TABLE IF NOT EXISTS cart_items (
  buyer_id TEXT NOT NULL REFERENCES users(id),
  product_id TEXT NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 99),
  added_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (buyer_id, product_id)
);

-- Buyer label checks. Stores the comparison outcome and the short observed values of the compared
-- fields only: never the photo and never the full OCR text.
CREATE TABLE IF NOT EXISTS label_checks (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  checker_user_id TEXT REFERENCES users(id),
  overall TEXT NOT NULL,
  fields_json TEXT NOT NULL,
  ocr_source TEXT,
  policy_version TEXT NOT NULL,
  review_requested_at TEXT,
  reviewed_at TEXT,
  reviewed_by TEXT REFERENCES users(id),
  review_note TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_label_checks_product ON label_checks(product_id, created_at);
CREATE INDEX IF NOT EXISTS ix_label_checks_review ON label_checks(review_requested_at);

CREATE TABLE IF NOT EXISTS batch_recalls (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  batch_number TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','CLOSED')),
  reason_code TEXT NOT NULL CHECK (reason_code IN ('QUALITY_ISSUE','SAFETY_RISK','LABELLING_ERROR','REGULATOR_INSTRUCTION','MANUFACTURER_REQUEST','OTHER')),
  public_message TEXT,
  initiated_by TEXT NOT NULL REFERENCES users(id),
  initiated_role TEXT NOT NULL CHECK (initiated_role IN ('SELLER','ADMIN')),
  buyers_notified INTEGER NOT NULL DEFAULT 0,
  simulated_orders_skipped INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  closed_by TEXT REFERENCES users(id),
  closed_at TEXT,
  close_note TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_one_active_recall ON batch_recalls(product_id) WHERE status = 'ACTIVE';

CREATE TABLE IF NOT EXISTS buyer_notifications (
  id TEXT PRIMARY KEY,
  buyer_id TEXT NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL CHECK (kind IN ('BATCH_RECALL')),
  recall_id TEXT REFERENCES batch_recalls(id),
  product_id TEXT REFERENCES products(id),
  title_en TEXT NOT NULL,
  body_en TEXT NOT NULL,
  title_bn TEXT NOT NULL,
  body_bn TEXT NOT NULL,
  channel TEXT NOT NULL DEFAULT 'IN_APP' CHECK (channel IN ('IN_APP')),
  delivery_status TEXT NOT NULL DEFAULT 'DELIVERED_IN_APP' CHECK (delivery_status IN ('DELIVERED_IN_APP')),
  dedupe_key TEXT NOT NULL,
  created_at TEXT NOT NULL,
  read_at TEXT,
  UNIQUE (buyer_id, dedupe_key)
);
CREATE INDEX IF NOT EXISTS ix_buyer_notifications ON buyer_notifications(buyer_id, created_at);

CREATE TABLE IF NOT EXISTS protection_audit (
  id TEXT PRIMARY KEY,
  actor_id TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  product_id TEXT,
  ref_id TEXT,
  before_json TEXT,
  after_json TEXT,
  policy_version TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_protection_audit_product ON protection_audit(product_id, created_at);
`;

const BATCH_LOCK_TRIGGER = `
CREATE TRIGGER IF NOT EXISTS trg_products_batch_locked
BEFORE UPDATE OF batch_number ON products
WHEN OLD.status = 'PUBLISHED' AND NEW.batch_number IS NOT OLD.batch_number
BEGIN SELECT RAISE(ABORT, 'batch number is locked after publish'); END;
`;

function columns(db: Db, table: string): Set<string> {
  return new Set((db.prepare(`PRAGMA table_info(${table})`).all() as { name: string }[]).map((r) => r.name));
}

function addColumnIfMissing(db: Db, table: string, column: string, decl: string) {
  if (!columns(db, table).has(column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${decl}`);
}

/** Rebuild seller_notifications once if its CHECK predates the v5 kinds. Keeps every row. Returns true if rebuilt. */
export function migrateNotificationKinds(db: Db): boolean {
  const row = db.prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'seller_notifications'").get() as { sql: string } | undefined;
  if (!row || row.sql.includes('SCAN_RISK')) return false;
  db.exec('BEGIN IMMEDIATE');
  try {
    db.exec(sellerNotificationsTableSql('seller_notifications_v5'));
    db.exec(`INSERT INTO seller_notifications_v5 (id, seller_id, product_id, kind, severity, title_en, body_en, title_bn, body_bn, data_json, dedupe_key, created_at, read_at)
             SELECT id, seller_id, product_id, kind, severity, title_en, body_en, title_bn, body_bn, data_json, dedupe_key, created_at, read_at FROM seller_notifications`);
    db.exec('DROP TABLE seller_notifications');
    db.exec('ALTER TABLE seller_notifications_v5 RENAME TO seller_notifications');
    db.exec('CREATE INDEX IF NOT EXISTS ix_notifications_seller ON seller_notifications(seller_id, created_at)');
    db.exec('COMMIT');
    return true;
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch { /* nothing to roll back */ }
    throw err;
  }
}

export function applyProtectionSchema(db: Db) {
  db.exec(PROTECTION_TABLES_SQL);
  addColumnIfMissing(db, 'products', 'mrp_paisa', 'INTEGER CHECK (mrp_paisa IS NULL OR mrp_paisa > 0)');
  addColumnIfMissing(db, 'products', 'mrp_source', 'TEXT');
  addColumnIfMissing(db, 'products', 'mrp_status', 'TEXT');
  addColumnIfMissing(db, 'order_items', 'batch_number', 'TEXT');
  addColumnIfMissing(db, 'order_items', 'expiry_date', 'TEXT');
  db.exec(BATCH_LOCK_TRIGGER);
  migrateNotificationKinds(db);
}
