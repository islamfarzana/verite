import { toAsciiDigits } from '../ai/normalize';

// Money for price/MRP decisions is held as INTEGER PAISA (1 taka = 100 paisa) and parsed from the
// decimal TEXT, so comparisons never depend on binary floating point.
// products.price stays a REAL column in taka (legacy schema); it is converted here before comparing.

const MAX_PAISA = 100_000_000_00; // 10 crore taka: anything above is treated as a typo

/**
 * "120", "120.5", "1,250.00", "৳ ১২০", "Tk 120/-", 120.5  ->  paisa (integer), or null when the input is
 * not a plain non-negative amount with at most 2 decimals. Never rounds silently.
 */
export function parseTakaToPaisa(input: string | number | null | undefined): number | null {
  if (input === null || input === undefined) return null;
  let s: string;
  if (typeof input === 'number') {
    if (!Number.isFinite(input) || input < 0) return null;
    // Number -> shortest round-trip text ("120.5"); more than 2 decimals is rejected below, not rounded.
    s = String(input);
    if (/e/i.test(s)) return null;
  } else {
    s = toAsciiDigits(input.normalize('NFC'))
      .replace(/৳|tk\.?|taka|bdt|টাকা|mrp|এমআরপি|সর্বোচ্চ খুচরা মূল্য|মূল্য|[:\s]/gi, '')
      .replace(/\/-$/, '')
      .replace(/,/g, '');
  }
  const m = s.match(/^(\d{1,12})(?:\.(\d{1,2}))?$/);
  if (!m) return null;
  const paisa = Number(m[1]) * 100 + Number((m[2] || '').padEnd(2, '0'));
  return paisa <= MAX_PAISA ? paisa : null;
}

/** A REAL taka value from the database -> paisa. Rounds to the nearest paisa (stored prices have ≤ 2 decimals). */
export function dbTakaToPaisa(price: number | null | undefined): number | null {
  if (price === null || price === undefined || !Number.isFinite(Number(price))) return null;
  return Math.round(Number(price) * 100);
}

/** paisa -> "120" or "120.50" (no float arithmetic). */
export function formatPaisa(paisa: number | null | undefined): string | null {
  if (paisa === null || paisa === undefined) return null;
  const taka = Math.trunc(paisa / 100);
  const rest = paisa % 100;
  return rest === 0 ? String(taka) : `${taka}.${String(rest).padStart(2, '0')}`;
}

/** paisa -> taka number for the legacy REAL column (exact for 2-decimal values). */
export function paisaToTakaNumber(paisa: number): number {
  return Number(formatPaisa(paisa));
}

export const bnDigits = (x: number | string) => String(x).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[Number(d)]);
