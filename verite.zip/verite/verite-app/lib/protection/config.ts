// Buyer-protection configuration. Every number is a documented, PROVISIONAL policy value (see
// docs/changes/buyer-protection/POLICY_DECISIONS.md), not a validated or legal threshold.

export const POLICY_VERSION = 'buyer-protection-1';

export interface ProtectionConfig {
  /** What to do with a listing that has no registered MRP (legacy listings). New listings always need one. */
  mrpMissingPolicy: 'allow' | 'block';
  /** Show "expires in X days" to buyers when X is at most this. */
  expiryDisplayDays: number;
  /** A microservice field confidence (0-100) below this turns a would-be MISMATCH into UNCERTAIN. */
  buyerCheckMinConfidence: number;
  /** Buyer label checks per minute per user / network source. */
  buyerCheckPerMinute: number;
  /** Include simulated demo orders (order number SIM-...) when targeting recall notices. */
  recallIncludeSimulatedOrders: boolean;
}

export const DEFAULT_PROTECTION_CONFIG: ProtectionConfig = {
  mrpMissingPolicy: 'allow',
  expiryDisplayDays: 60,
  buyerCheckMinConfidence: 60,
  buyerCheckPerMinute: 5,
  recallIncludeSimulatedOrders: false,
};

export function loadProtectionConfig(env: Record<string, string | undefined> = process.env): ProtectionConfig {
  const int = (v: string | undefined, d: number, min: number, max: number) => {
    if (v === undefined || v === '') return d;
    const n = Number(v);
    return Number.isInteger(n) && n >= min && n <= max ? n : d;
  };
  return {
    mrpMissingPolicy: env.MRP_MISSING_POLICY === 'block' ? 'block' : 'allow',
    expiryDisplayDays: int(env.EXPIRY_DISPLAY_DAYS, 60, 0, 3650),
    buyerCheckMinConfidence: int(env.BUYER_CHECK_MIN_CONFIDENCE, 60, 0, 100),
    buyerCheckPerMinute: int(env.BUYER_CHECK_PER_MINUTE, 5, 1, 1000),
    recallIncludeSimulatedOrders: env.RECALL_INCLUDE_SIMULATED_ORDERS === 'true',
  };
}
