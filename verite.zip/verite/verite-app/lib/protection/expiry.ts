import { dhakaDate } from '../assistant/analytics';
import { bnDigits } from './money';

// Expiry policy (documented in POLICY_DECISIONS.md):
// - expiry is a DATE-ONLY value 'YYYY-MM-DD' (a printed month-only date was stored as the month's last day);
// - "today" is the calendar date in Asia/Dhaka (UTC+6, no daylight saving);
// - a batch is sellable through the END of its expiry day, and expired from the next day;
// - daysRemaining = expiry date - today (0 on the expiry day). Never estimated when the date is invalid.

export type ExpiryState = 'OK' | 'NEAR_EXPIRY' | 'EXPIRES_TODAY' | 'EXPIRED' | 'UNKNOWN';

export interface ExpiryInfo {
  state: ExpiryState;
  expiryDate: string | null;
  daysRemaining: number | null;
  sellable: boolean;
  textEn: string | null;
  textBn: string | null;
}

/** True only for a real calendar date in strict YYYY-MM-DD form (rejects 2026-02-30, 2027-02-29). */
export function isValidIsoDate(s: unknown): s is string {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export function dhakaToday(now: Date): string {
  return dhakaDate(now);
}

export function daysBetweenIso(from: string, to: string): number {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000);
}

export function expiryInfo(expiryDate: string | null | undefined, now: Date, displayDays: number): ExpiryInfo {
  if (!isValidIsoDate(expiryDate)) {
    return { state: 'UNKNOWN', expiryDate: expiryDate ?? null, daysRemaining: null, sellable: false,
      textEn: 'Expiry date could not be verified', textBn: 'মেয়াদ যাচাই করা যায়নি' };
  }
  const days = daysBetweenIso(dhakaToday(now), expiryDate);
  if (days < 0) {
    return { state: 'EXPIRED', expiryDate, daysRemaining: days, sellable: false, textEn: 'Expired', textBn: 'মেয়াদ শেষ' };
  }
  if (days === 0) {
    return { state: 'EXPIRES_TODAY', expiryDate, daysRemaining: 0, sellable: true, textEn: 'Expires today', textBn: 'আজ মেয়াদ শেষ হবে' };
  }
  if (days <= displayDays) {
    return { state: 'NEAR_EXPIRY', expiryDate, daysRemaining: days, sellable: true,
      textEn: `Expires in ${days} day${days === 1 ? '' : 's'}`, textBn: `মেয়াদ শেষ হতে ${bnDigits(days)} দিন বাকি` };
  }
  return { state: 'OK', expiryDate, daysRemaining: days, sellable: true, textEn: null, textBn: null };
}
