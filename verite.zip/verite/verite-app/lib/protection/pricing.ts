import { bnDigits, formatPaisa } from './money';
import type { ProtectionConfig } from './config';

// Price-above-MRP guard. The comparison is the listing's per-pack item price against the MRP registered
// for that same listing (one listing = one pack size and batch). Delivery charge and VAT are separate
// order lines and are not part of this comparison. All amounts are integer paisa.
//
// Wording is deliberately neutral. Bangladesh's Consumer Rights Protection Act 2009 s.40 concerns prices
// "fixed under any Act or rules"; whether a printed MRP is such a price was not verified for this project,
// so the app states the fact ("price is above the registered MRP") and not a legal verdict.

export type PriceDecision = 'ALLOWED' | 'BLOCKED_ABOVE_MRP' | 'ALLOWED_MRP_NOT_REGISTERED' | 'BLOCKED_MRP_MISSING';

export interface PriceEvaluation {
  decision: PriceDecision;
  allowed: boolean;
  pricePaisa: number;
  mrpPaisa: number | null;
  price: string;
  mrp: string | null;
  en: string;
  bn: string;
}

export function evaluatePrice(pricePaisa: number, mrpPaisa: number | null, cfg: Pick<ProtectionConfig, 'mrpMissingPolicy'>): PriceEvaluation {
  const price = formatPaisa(pricePaisa)!;
  const mrp = formatPaisa(mrpPaisa);
  if (mrpPaisa === null) {
    const block = cfg.mrpMissingPolicy === 'block';
    return {
      decision: block ? 'BLOCKED_MRP_MISSING' : 'ALLOWED_MRP_NOT_REGISTERED', allowed: !block, pricePaisa, mrpPaisa, price, mrp,
      en: block ? 'No MRP is registered for this listing. Add the MRP printed on the pack before selling it.' : 'No MRP is registered for this listing, so the price could not be checked against it.',
      bn: block ? 'এই পণ্যের কোনো MRP নিবন্ধিত নেই। বিক্রির আগে প্যাকেটে ছাপা MRP যোগ করুন।' : 'এই পণ্যের MRP নিবন্ধিত নেই, তাই দাম MRP-এর সঙ্গে মেলানো যায়নি।',
    };
  }
  if (pricePaisa > mrpPaisa) {
    return {
      decision: 'BLOCKED_ABOVE_MRP', allowed: false, pricePaisa, mrpPaisa, price, mrp,
      en: `The price (৳${price}) is higher than the registered MRP (৳${mrp}). Check the MRP and the pack size.`,
      bn: `দেওয়া দাম (৳${bnDigits(price)}) নিবন্ধিত MRP (৳${bnDigits(mrp!)})-এর চেয়ে বেশি। MRP ও প্যাকের আকার যাচাই করুন।`,
    };
  }
  return {
    decision: 'ALLOWED', allowed: true, pricePaisa, mrpPaisa, price, mrp,
    en: pricePaisa === mrpPaisa ? `Price equals the registered MRP (৳${mrp}).` : `Price is below the registered MRP (৳${mrp}).`,
    bn: pricePaisa === mrpPaisa ? `দাম নিবন্ধিত MRP (৳${bnDigits(mrp!)})-এর সমান।` : `দাম নিবন্ধিত MRP (৳${bnDigits(mrp!)})-এর চেয়ে কম।`,
  };
}
