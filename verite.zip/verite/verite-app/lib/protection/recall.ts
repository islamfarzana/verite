import { newId } from '../ids';
import { tx } from '../identity/onboarding';
import type { Db } from '../trace/types';
import type { ProtectionConfig } from './config';
import { ProtectionError } from './errors';
import { bnDigits } from './money';
import { audit } from './sellability';

// Batch recall. One listing = one batch (audit.md §1.2), so a recall targets one listing's batch.
// - A seller may recall their OWN listing; an admin may recall any listing. Only an admin closes a recall.
// - Effect: the listing is unsellable at every guard immediately (sellability.ts). Orders are never edited.
// - Affected buyers: distinct buyers of non-cancelled orders whose order item is for this listing and
//   batch (the batch snapshot on the order item, or the listing's batch for older rows, which is reliable
//   because the batch number cannot change after publish). Simulated demo orders are excluded by default.
// - Delivery: one in-app notification per buyer and recall, written in the SAME transaction as the recall
//   (UNIQUE dedupe key), so recall state and notices cannot diverge and retries never duplicate.
//   No email/SMS/push provider exists in this project; nothing else is claimed.
// - Off-chain: the on-chain fingerprint is not changed by a recall.

export const RECALL_REASONS = {
  QUALITY_ISSUE: { en: 'a quality issue', bn: 'মানগত সমস্যা' },
  SAFETY_RISK: { en: 'a possible safety risk', bn: 'সম্ভাব্য নিরাপত্তা ঝুঁকি' },
  LABELLING_ERROR: { en: 'a labelling error', bn: 'লেবেলে ভুল' },
  REGULATOR_INSTRUCTION: { en: 'an instruction from a regulator', bn: 'নিয়ন্ত্রক সংস্থার নির্দেশনা' },
  MANUFACTURER_REQUEST: { en: 'a request from the manufacturer', bn: 'প্রস্তুতকারকের অনুরোধ' },
  OTHER: { en: 'another reason', bn: 'অন্য কারণ' },
} as const;
export type RecallReason = keyof typeof RECALL_REASONS;

export interface RecallActor { id: string; role: 'SELLER' | 'ADMIN' | 'BUYER' }

export function affectedBuyers(db: Db, productId: string, batchNumber: string, includeSimulated: boolean) {
  const rows = db.prepare(
    `SELECT o.buyer_id, o.order_number
     FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN products p ON p.id = oi.product_id
     WHERE oi.product_id = ? AND COALESCE(oi.batch_number, p.batch_number) = ? AND o.status <> 'CANCELLED'`
  ).all(productId, batchNumber) as { buyer_id: string; order_number: string }[];
  const simulated = rows.filter((r) => String(r.order_number).startsWith('SIM-'));
  const counted = includeSimulated ? rows : rows.filter((r) => !String(r.order_number).startsWith('SIM-'));
  return {
    buyerIds: [...new Set(counted.map((r) => r.buyer_id))].sort(),
    simulatedOrdersSkipped: includeSimulated ? 0 : simulated.length,
  };
}

function cleanMessage(m: unknown): string | null {
  if (m === undefined || m === null || m === '') return null;
  if (typeof m !== 'string') throw new ProtectionError('INVALID', 'The message must be text.');
  const t = m.replace(/[\u0000-\u001f\u007f]/g, ' ').trim();
  if (t.length > 300) throw new ProtectionError('INVALID', 'The message can be at most 300 characters.');
  return t || null;
}

function notifyBuyers(db: Db, recall: { id: string; product_id: string; batch_number: string; reason_code: RecallReason; public_message: string | null; created_at: string },
  productName: string, buyerIds: string[]): number {
  const reason = RECALL_REASONS[recall.reason_code];
  const date = recall.created_at.slice(0, 10);
  const msgEn = recall.public_message ? ` Message from the recall owner: “${recall.public_message}”` : '';
  const msgBn = recall.public_message ? ` প্রত্যাহারকারীর বার্তা: “${recall.public_message}”` : '';
  const ins = db.prepare(
    `INSERT OR IGNORE INTO buyer_notifications (id, buyer_id, kind, recall_id, product_id, title_en, body_en, title_bn, body_bn, dedupe_key, created_at)
     VALUES (?, ?, 'BATCH_RECALL', ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  let n = 0;
  for (const buyerId of buyerIds) {
    n += Number(ins.run(newId('bnt'), buyerId, recall.id, recall.product_id,
      `Recall: ${productName}, batch ${recall.batch_number}`,
      `The batch ${recall.batch_number} of ${productName} that you bought was recalled on ${date} because of ${reason.en}. Please contact the seller or the support channel for guidance before using or reselling it.${msgEn}`,
      `সতর্কতা: ${productName}, ব্যাচ ${recall.batch_number} প্রত্যাহার`,
      `সতর্কতা: আপনার কেনা পণ্যের ব্যাচ ${recall.batch_number} প্রত্যাহার করা হয়েছে (${productName}; তারিখ: ${bnDigits(date)}; কারণ: ${reason.bn})। আপাতত পণ্যটি ব্যবহার/বিক্রি সম্পর্কে নির্দেশনার জন্য বিক্রেতা বা নির্ধারিত সহায়তা চ্যানেলের সঙ্গে যোগাযোগ করুন।${msgBn}`,
      `RECALL:${recall.id}`, recall.created_at).changes);
  }
  return n;
}

export function openRecall(db: Db, actor: RecallActor, input: { productId: unknown; reasonCode: unknown; publicMessage?: unknown }, now: Date, cfg: ProtectionConfig) {
  if (actor.role !== 'SELLER' && actor.role !== 'ADMIN') throw new ProtectionError('FORBIDDEN', 'Only the seller or an administrator can recall a batch.');
  if (typeof input.productId !== 'string') throw new ProtectionError('INVALID', 'productId is required.');
  if (typeof input.reasonCode !== 'string' || !(input.reasonCode in RECALL_REASONS)) throw new ProtectionError('INVALID', 'Choose a recall reason.');
  const message = cleanMessage(input.publicMessage);
  const p = db.prepare('SELECT id, seller_id, name, status, batch_number FROM products WHERE id = ?').get(input.productId) as
    { id: string; seller_id: string; name: string; status: string; batch_number: string | null } | undefined;
  // Same response for "not found" and "not yours": sellers cannot probe other sellers' listings.
  if (!p || (actor.role === 'SELLER' && p.seller_id !== actor.id)) throw new ProtectionError('NOT_FOUND', 'Product not found.');
  if (p.status !== 'PUBLISHED') throw new ProtectionError('INVALID', 'Only a published listing can be recalled (a draft was never sold).');
  if (!p.batch_number) throw new ProtectionError('INVALID', 'This listing has no batch number, so a batch recall cannot be scoped.');

  return tx(db, () => {
    const existing = db.prepare("SELECT * FROM batch_recalls WHERE product_id = ? AND status = 'ACTIVE'").get(p.id) as any;
    if (existing) return { recall: existing, alreadyActive: true, buyersNotified: Number(existing.buyers_notified), simulatedOrdersSkipped: Number(existing.simulated_orders_skipped) };

    const recall = {
      id: newId('rcl'), product_id: p.id, batch_number: p.batch_number!, status: 'ACTIVE', reason_code: input.reasonCode as RecallReason,
      public_message: message, initiated_by: actor.id, initiated_role: actor.role, created_at: now.toISOString(),
    };
    db.prepare(
      `INSERT INTO batch_recalls (id, product_id, batch_number, status, reason_code, public_message, initiated_by, initiated_role, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(recall.id, recall.product_id, recall.batch_number, recall.status, recall.reason_code, recall.public_message, recall.initiated_by, recall.initiated_role, recall.created_at);

    const target = affectedBuyers(db, p.id, p.batch_number!, cfg.recallIncludeSimulatedOrders);
    const notified = notifyBuyers(db, recall, p.name, target.buyerIds);
    db.prepare('UPDATE batch_recalls SET buyers_notified = ?, simulated_orders_skipped = ? WHERE id = ?').run(notified, target.simulatedOrdersSkipped, recall.id);

    // The listing's seller is told when an admin recalls their batch (count only, never buyer identities).
    if (actor.role === 'ADMIN') {
      db.prepare(
        `INSERT OR IGNORE INTO seller_notifications (id, seller_id, product_id, kind, severity, title_en, body_en, title_bn, body_bn, data_json, dedupe_key, created_at)
         VALUES (?, ?, ?, 'RECALL_ISSUED', 'CRITICAL', ?, ?, ?, ?, ?, ?, ?)`
      ).run(newId('ntf'), p.seller_id, p.id,
        `An administrator recalled ${p.name}, batch ${p.batch_number}`,
        `Sales of this batch are stopped. ${notified} buyer(s) with matching orders were notified in the app.`,
        `প্রশাসক ${p.name}, ব্যাচ ${p.batch_number} প্রত্যাহার করেছেন`,
        `এই ব্যাচের বিক্রি বন্ধ। মিল থাকা অর্ডারের ${bnDigits(notified)} জন ক্রেতাকে অ্যাপে জানানো হয়েছে।`,
        JSON.stringify({ recallId: recall.id, buyersNotified: notified }), `RECALL_ISSUED:${recall.id}`, recall.created_at);
    }
    audit(db, { actorId: actor.id, actorRole: actor.role, action: 'RECALL_OPENED', productId: p.id, refId: recall.id,
      after: { batch: p.batch_number, reasonCode: recall.reason_code, buyersNotified: notified, simulatedOrdersSkipped: target.simulatedOrdersSkipped } }, now);
    return { recall: { ...recall, buyers_notified: notified, simulated_orders_skipped: target.simulatedOrdersSkipped }, alreadyActive: false, buyersNotified: notified, simulatedOrdersSkipped: target.simulatedOrdersSkipped };
  });
}

/** Re-run targeting for an ACTIVE recall (e.g. after a buyer account was linked). Idempotent: never duplicates. */
export function resendRecallNotices(db: Db, actor: RecallActor, recallId: string, now: Date, cfg: ProtectionConfig) {
  if (actor.role !== 'ADMIN') throw new ProtectionError('FORBIDDEN', 'Administrator access required.');
  const r = db.prepare('SELECT r.*, p.name FROM batch_recalls r JOIN products p ON p.id = r.product_id WHERE r.id = ?').get(recallId) as any;
  if (!r) throw new ProtectionError('NOT_FOUND', 'Recall not found.');
  if (r.status !== 'ACTIVE') throw new ProtectionError('CONFLICT', 'This recall is closed.');
  return tx(db, () => {
    const target = affectedBuyers(db, r.product_id, r.batch_number, cfg.recallIncludeSimulatedOrders);
    const added = notifyBuyers(db, r, r.name, target.buyerIds);
    const total = Number((db.prepare('SELECT COUNT(*) AS c FROM buyer_notifications WHERE recall_id = ?').get(recallId) as { c: number }).c);
    db.prepare('UPDATE batch_recalls SET buyers_notified = ? WHERE id = ?').run(total, recallId);
    audit(db, { actorId: actor.id, actorRole: actor.role, action: 'RECALL_NOTICES_RESENT', productId: r.product_id, refId: recallId, after: { added, total } }, now);
    return { added, total };
  });
}

export function closeRecall(db: Db, actor: RecallActor, recallId: string, note: unknown, now: Date) {
  if (actor.role !== 'ADMIN') throw new ProtectionError('FORBIDDEN', 'Only an administrator can close a recall.');
  const n = cleanMessage(note);
  return tx(db, () => {
    const r = db.prepare('SELECT * FROM batch_recalls WHERE id = ?').get(recallId) as any;
    if (!r) throw new ProtectionError('NOT_FOUND', 'Recall not found.');
    if (r.status === 'CLOSED') return { closed: false, alreadyClosed: true };
    db.prepare("UPDATE batch_recalls SET status = 'CLOSED', closed_by = ?, closed_at = ?, close_note = ? WHERE id = ?").run(actor.id, now.toISOString(), n, recallId);
    audit(db, { actorId: actor.id, actorRole: actor.role, action: 'RECALL_CLOSED', productId: r.product_id, refId: recallId, before: { status: 'ACTIVE' }, after: { status: 'CLOSED', note: n } }, now);
    return { closed: true, alreadyClosed: false };
  });
}

/** Recalls visible to the actor: admin sees all, seller sees their own listings'. Counts only, no buyer identities. */
export function listRecalls(db: Db, actor: RecallActor) {
  if (actor.role !== 'SELLER' && actor.role !== 'ADMIN') throw new ProtectionError('FORBIDDEN', 'Not allowed.');
  const where = actor.role === 'SELLER' ? 'WHERE p.seller_id = ?' : '';
  return db.prepare(
    `SELECT r.id, r.product_id AS productId, p.name AS productName, r.batch_number AS batchNumber, r.status, r.reason_code AS reasonCode,
            r.public_message AS publicMessage, r.initiated_role AS initiatedRole, r.buyers_notified AS buyersNotified,
            r.simulated_orders_skipped AS simulatedOrdersSkipped, r.created_at AS createdAt, r.closed_at AS closedAt
     FROM batch_recalls r JOIN products p ON p.id = r.product_id ${where} ORDER BY r.created_at DESC LIMIT 200`
  ).all(...(actor.role === 'SELLER' ? [actor.id] : []));
}

export function listBuyerNotifications(db: Db, buyerId: string, limit = 50) {
  return db.prepare(
    `SELECT id, kind, product_id AS productId, title_en AS titleEn, body_en AS bodyEn, title_bn AS titleBn, body_bn AS bodyBn,
            channel, delivery_status AS deliveryStatus, created_at AS createdAt, read_at AS readAt
     FROM buyer_notifications WHERE buyer_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?`
  ).all(buyerId, limit);
}

export function buyerUnreadCount(db: Db, buyerId: string): number {
  return Number((db.prepare('SELECT COUNT(*) AS c FROM buyer_notifications WHERE buyer_id = ? AND read_at IS NULL').get(buyerId) as { c: number }).c);
}

export function markBuyerNotificationsRead(db: Db, buyerId: string, ids: string[] | 'all', now: Date): number {
  if (ids === 'all') return Number(db.prepare('UPDATE buyer_notifications SET read_at = ? WHERE buyer_id = ? AND read_at IS NULL').run(now.toISOString(), buyerId).changes);
  const st = db.prepare('UPDATE buyer_notifications SET read_at = ? WHERE id = ? AND buyer_id = ? AND read_at IS NULL');
  return ids.slice(0, 200).reduce((n, id) => n + Number(st.run(now.toISOString(), id, buyerId).changes), 0);
}
