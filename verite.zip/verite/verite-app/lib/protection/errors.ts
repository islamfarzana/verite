// Errors raised by buyer-protection rules. `blockers` carries the reasons (English + Bangla) so the
// UI can show exactly why something was refused.

export interface Blocker {
  code: 'RECALLED' | 'EXPIRED' | 'EXPIRY_UNKNOWN' | 'NOT_PUBLISHED' | 'ABOVE_MRP' | 'MRP_MISSING' | 'OUT_OF_STOCK' | 'INSUFFICIENT_STOCK' | 'NOT_FOUND';
  en: string;
  bn: string;
}

export type ProtectionErrorCode = 'UNAUTHENTICATED' | 'FORBIDDEN' | 'NOT_FOUND' | 'INVALID' | 'CONFLICT' | 'NOT_SELLABLE' | 'RATE_LIMITED';

const STATUS: Record<ProtectionErrorCode, number> = {
  UNAUTHENTICATED: 401, FORBIDDEN: 403, NOT_FOUND: 404, INVALID: 422, CONFLICT: 409, NOT_SELLABLE: 409, RATE_LIMITED: 429,
};

export class ProtectionError extends Error {
  constructor(public code: ProtectionErrorCode, message: string, public blockers: Blocker[] = [], public messageBn?: string) {
    super(message);
  }
  get status() {
    return STATUS[this.code];
  }
  toBody() {
    return { success: false, code: this.code, message: this.message, ...(this.messageBn ? { messageBn: this.messageBn } : {}), ...(this.blockers.length ? { blockers: this.blockers } : {}) };
  }
}
