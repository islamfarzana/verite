import { comparable, normalizeDate, toAsciiDigits } from '../ai/normalize';
import { isValidIsoDate } from './expiry';
import { formatPaisa, parseTakaToPaisa } from './money';

// Buyer physical-label check: compare what OCR read from the buyer's photo with the REGISTERED record of
// the listing (= one batch). Pure functions, so every rule is unit-tested.
//
// Principles (POLICY_DECISIONS.md):
// - OCR is evidence, not proof. A difference becomes MISMATCH only when the reading is clear; anything that
//   OCR commonly confuses (O/0, I/1, DD/MM vs MM/DD, low confidence) becomes UNCERTAIN.
// - Nothing here says "counterfeit". The strongest outcome is "does not match — needs review".

export type FieldResult = 'MATCH' | 'MISMATCH' | 'UNCERTAIN' | 'NOT_FOUND_ON_LABEL' | 'NOT_REGISTERED' | 'NOT_APPLICABLE';
export type OverallResult = 'MATCH' | 'MISMATCH_REVIEW' | 'UNCERTAIN' | 'BATCH_UNRESOLVED' | 'INSUFFICIENT_IMAGE' | 'NOT_REGISTERED';

export const CHECK_FIELDS = ['productName', 'manufacturer', 'batchNumber', 'manufacturingDate', 'expiryDate', 'mrp'] as const;
export type CheckField = (typeof CHECK_FIELDS)[number];

export const FIELD_LABELS: Record<CheckField, { en: string; bn: string }> = {
  productName: { en: 'Product name', bn: 'পণ্যের নাম' },
  manufacturer: { en: 'Manufacturer', bn: 'প্রস্তুতকারক' },
  batchNumber: { en: 'Batch number', bn: 'ব্যাচ নম্বর' },
  manufacturingDate: { en: 'Manufacturing date', bn: 'উৎপাদনের তারিখ' },
  expiryDate: { en: 'Expiry date', bn: 'মেয়াদোত্তীর্ণের তারিখ' },
  mrp: { en: 'MRP', bn: 'MRP' },
};

export interface RegisteredRecord {
  productName: string;
  productNameBn: string | null;
  manufacturer: string | null;
  batchNumber: string | null;
  manufacturingDate: string | null;
  expiryDate: string | null;
  mrpPaisa: number | null;
}

export interface ObservedLabel {
  fields: Record<string, string | number | null | undefined>;
  /** Per-field OCR confidence 0-100 when the OCR engine reports it (the microservice does). */
  confidence?: Record<string, number> | null;
}

export interface FieldComparison {
  field: CheckField;
  result: FieldResult;
  registered: string | null;
  observed: string | null;
  confidence: number | null;
  reasonEn: string;
  reasonBn: string;
}

const str = (v: unknown) => (v === null || v === undefined ? null : String(v).trim() || null);

/* ------------------------------ names ------------------------------ */

function tokens(s: string): string[] {
  return toAsciiDigits(s.normalize('NFC')).toLowerCase().replace(/[‌‍]/g, '')
    .split(/[^a-z0-9ঀ-৿]+/).filter((t) => t.length >= 2);
}

/**
 * 0..1. The larger of: Dice coefficient over word tokens, and — when one name contains the other once
 * spaces/punctuation are removed — the length ratio (so "Rice" inside "Basmati Rice 5kg" scores low).
 */
export function nameSimilarity(a: string, b: string): number {
  const ca = comparable(a);
  const cb = comparable(b);
  if (!ca || !cb) return 0;
  if (ca === cb) return 1;
  const [short, long] = ca.length <= cb.length ? [ca, cb] : [cb, ca];
  const containment = long.includes(short) ? short.length / long.length : 0;
  const ta = new Set(tokens(a));
  const tb = new Set(tokens(b));
  let dice = 0;
  if (ta.size && tb.size) {
    let inter = 0;
    for (const t of ta) if (tb.has(t)) inter += 1;
    dice = (2 * inter) / (ta.size + tb.size);
  }
  return Math.max(dice, containment);
}

/* ------------------------------ batch ------------------------------ */

const CONFUSABLE: Record<string, string> = { O: '0', Q: '0', D: '0', I: '1', L: '1', S: '5', B: '8', Z: '2', G: '6' };
export const batchKey = (s: string) => toAsciiDigits(s).toUpperCase().replace(/[^A-Z0-9]/g, '');
const confusableKey = (s: string) => batchKey(s).replace(/[OQDILSBZG]/g, (c) => CONFUSABLE[c]);

/* ------------------------------ dates ------------------------------ */

function lastDay(y: number, m: number) {
  return new Date(Date.UTC(y, m, 0)).getUTCDate();
}

export function compareDates(field: 'manufacturingDate' | 'expiryDate', registered: string, observed: string): { result: FieldResult; en: string; bn: string } {
  if (registered === observed) return { result: 'MATCH', en: 'Same date.', bn: 'তারিখ মিলেছে।' };
  const [ry, rm, rd] = registered.split('-').map(Number);
  const [oy, om, od] = observed.split('-').map(Number);
  // The printed date could be read either way round (e.g. 05/06/2027): the swapped reading matches.
  if (od <= 12 && om <= 12 && od !== om && oy === ry && od === rm && om === rd) {
    return { result: 'UNCERTAIN', en: 'The printed date can be read as day/month or month/day; one reading matches. Check it on the pack.', bn: 'ছাপা তারিখটি দিন/মাস বা মাস/দিন দুইভাবেই পড়া যায়; একভাবে পড়লে মেলে। প্যাকেটে দেখে নিশ্চিত হোন।' };
  }
  if (oy === ry && om === rm) {
    // Month-only printing ("EXP 08/2027") is stored as the last day (expiry) or first day (manufacture).
    const monthDefault = field === 'expiryDate' ? lastDay(oy, om) : 1;
    if (od === monthDefault || rd === monthDefault) {
      return { result: 'MATCH', en: 'Same month and year (the label prints the month only).', bn: 'মাস ও বছর মিলেছে (লেবেলে শুধু মাস ছাপা)।' };
    }
    return { result: 'UNCERTAIN', en: 'Same month and year, different day. OCR may have misread the day.', bn: 'মাস ও বছর মিলেছে, কিন্তু দিন আলাদা। OCR দিনটি ভুল পড়তে পারে।' };
  }
  return { result: 'MISMATCH', en: 'The date on the pack differs from the registered date.', bn: 'প্যাকেটের তারিখ নিবন্ধিত তারিখের সঙ্গে মিলছে না।' };
}

function observedIsoDate(field: 'manufacturingDate' | 'expiryDate', raw: string | null): string | null {
  if (!raw) return null;
  if (isValidIsoDate(raw)) return raw;
  return normalizeDate(raw, { endOfMonth: field === 'expiryDate' });
}

/* ------------------------------ compare ------------------------------ */

export function compareLabel(reg: RegisteredRecord, obs: ObservedLabel, minConfidence: number): FieldComparison[] {
  const conf = (k: string) => (obs.confidence && typeof obs.confidence[k] === 'number' ? Math.round(obs.confidence[k]) : null);
  const lowConf = (k: string) => { const c = conf(k); return c !== null && c < minConfidence; };
  const soften = (k: string, r: FieldResult): FieldResult => (r === 'MISMATCH' && lowConf(k) ? 'UNCERTAIN' : r);
  const out: FieldComparison[] = [];
  const push = (field: CheckField, result: FieldResult, registered: string | null, observed: string | null, en: string, bn: string, confKey: string = field) =>
    out.push({ field, result, registered, observed, confidence: conf(confKey), reasonEn: en, reasonBn: bn });

  // product name: English or Bangla reading against the registered name(s); best score wins.
  {
    const oEn = str(obs.fields.productName);
    const oBn = str(obs.fields.productNameBn);
    const regNames = [reg.productName, reg.productNameBn].filter((x): x is string => !!x);
    if (!oEn && !oBn) push('productName', 'NOT_FOUND_ON_LABEL', reg.productName, null, 'No product name was read from the photo.', 'ছবি থেকে পণ্যের নাম পড়া যায়নি।');
    else {
      let best = 0; let bestObs = oEn || oBn; let bestKey = oEn ? 'productName' : 'productNameBn';
      for (const [o, key] of [[oEn, 'productName'], [oBn, 'productNameBn']] as const) {
        if (!o) continue;
        for (const r of regNames) { const s = nameSimilarity(r, o); if (s > best) { best = s; bestObs = o; bestKey = key; } }
      }
      const r: FieldResult = best >= 0.6 ? 'MATCH' : best >= 0.3 ? 'UNCERTAIN' : 'MISMATCH';
      const res = soften(bestKey, r);
      push('productName', res, reg.productNameBn ? `${reg.productName} / ${reg.productNameBn}` : reg.productName, bestObs,
        res === 'MATCH' ? 'The name on the pack matches the registered name.' : res === 'UNCERTAIN' ? 'The name only partly matches. OCR may have misread it.' : 'The name on the pack differs from the registered name.',
        res === 'MATCH' ? 'প্যাকেটের নাম নিবন্ধিত নামের সঙ্গে মিলেছে।' : res === 'UNCERTAIN' ? 'নাম আংশিক মিলেছে। OCR ভুল পড়তে পারে।' : 'প্যাকেটের নাম নিবন্ধিত নামের সঙ্গে মিলছে না।', bestKey);
    }
  }

  // manufacturer
  {
    const o = str(obs.fields.manufacturer) || str(obs.fields.brand);
    if (!reg.manufacturer) push('manufacturer', o ? 'NOT_REGISTERED' : 'NOT_APPLICABLE', null, o, 'No manufacturer is registered for this listing, so it cannot be compared.', 'এই পণ্যের প্রস্তুতকারক নিবন্ধিত নেই, তাই মেলানো যায়নি।');
    else if (!o) push('manufacturer', 'NOT_FOUND_ON_LABEL', reg.manufacturer, null, 'No manufacturer was read from the photo.', 'ছবি থেকে প্রস্তুতকারকের নাম পড়া যায়নি।');
    else {
      const s = nameSimilarity(reg.manufacturer, o);
      const res = soften('manufacturer', s >= 0.6 ? 'MATCH' : s >= 0.3 ? 'UNCERTAIN' : 'MISMATCH');
      push('manufacturer', res, reg.manufacturer, o,
        res === 'MATCH' ? 'Manufacturer matches.' : res === 'UNCERTAIN' ? 'Manufacturer only partly matches.' : 'Manufacturer on the pack differs from the registered one.',
        res === 'MATCH' ? 'প্রস্তুতকারক মিলেছে।' : res === 'UNCERTAIN' ? 'প্রস্তুতকারক আংশিক মিলেছে।' : 'প্যাকেটের প্রস্তুতকারক নিবন্ধিত তথ্যের সঙ্গে মিলছে না।');
    }
  }

  // batch
  {
    const o = str(obs.fields.batchNumber);
    if (!reg.batchNumber) push('batchNumber', o ? 'NOT_REGISTERED' : 'NOT_APPLICABLE', null, o, 'No batch number is registered.', 'ব্যাচ নম্বর নিবন্ধিত নেই।');
    else if (!o) push('batchNumber', 'NOT_FOUND_ON_LABEL', reg.batchNumber, null, 'The batch number could not be read. Take a clearer photo of the batch number.', 'ব্যাচ নম্বরটি স্পষ্টভাবে পড়া যায়নি। অনুগ্রহ করে প্যাকেটের ব্যাচ নম্বরের আরও পরিষ্কার ছবি তুলুন।');
    else if (batchKey(o) === batchKey(reg.batchNumber)) push('batchNumber', 'MATCH', reg.batchNumber, o, 'Batch number matches.', 'ব্যাচ নম্বর মিলেছে।');
    else if (confusableKey(o) === confusableKey(reg.batchNumber) || batchKey(o).includes(batchKey(reg.batchNumber))) {
      push('batchNumber', 'UNCERTAIN', reg.batchNumber, o, 'Almost the same; OCR often confuses letters like O/0 or I/1. Check it on the pack.', 'প্রায় একই; OCR অনেক সময় O/0 বা I/1 গুলিয়ে ফেলে। প্যাকেটে দেখে নিশ্চিত হোন।');
    } else {
      const res = soften('batchNumber', 'MISMATCH');
      push('batchNumber', res, reg.batchNumber, o,
        res === 'MISMATCH' ? 'The batch number on the pack differs from the registered batch.' : 'The batch number differs, but OCR was not confident. Take a clearer photo.',
        res === 'MISMATCH' ? 'প্যাকেটের ব্যাচ নম্বর নিবন্ধিত ব্যাচের সঙ্গে মিলছে না।' : 'ব্যাচ নম্বর আলাদা, তবে OCR নিশ্চিত নয়। আরও পরিষ্কার ছবি তুলুন।');
    }
  }

  // dates
  for (const field of ['manufacturingDate', 'expiryDate'] as const) {
    const regDate = reg[field];
    const raw = str(obs.fields[field]);
    const o = observedIsoDate(field, raw);
    const label = FIELD_LABELS[field];
    if (!regDate || !isValidIsoDate(regDate)) push(field, raw ? 'NOT_REGISTERED' : 'NOT_APPLICABLE', regDate ?? null, raw, `No valid ${label.en.toLowerCase()} is registered.`, `${label.bn} নিবন্ধিত নেই।`);
    else if (!raw) push(field, 'NOT_FOUND_ON_LABEL', regDate, null, `The ${label.en.toLowerCase()} could not be read.`, `${label.bn} পড়া যায়নি।`);
    else if (!o) push(field, 'UNCERTAIN', regDate, raw, 'A date was read but could not be understood.', 'একটি তারিখ পড়া গেছে, কিন্তু বোঝা যায়নি।');
    else {
      const c = compareDates(field, regDate, o);
      const res = soften(field, c.result);
      push(field, res, regDate, o,
        res === c.result ? c.en : 'The date differs, but OCR was not confident. Take a clearer photo.',
        res === c.result ? (field === 'expiryDate' && res === 'MISMATCH' ? 'আপনার প্যাকেটের মেয়াদোত্তীর্ণের তারিখ নিবন্ধিত ব্যাচের তথ্যের সঙ্গে মিলছে না। ছবিটি আবার পরীক্ষা করুন বা যাচাইয়ের জন্য পাঠান।' : c.bn) : 'তারিখ আলাদা, তবে OCR নিশ্চিত নয়। আরও পরিষ্কার ছবি তুলুন।');
    }
  }

  // MRP (integer paisa, so "120", "120.00" and "১২০ টাকা" are equal)
  {
    const raw = str(obs.fields.mrp);
    const o = raw === null ? null : parseTakaToPaisa(typeof obs.fields.mrp === 'number' ? obs.fields.mrp : raw);
    if (reg.mrpPaisa === null) push('mrp', raw ? 'NOT_REGISTERED' : 'NOT_APPLICABLE', null, raw, 'No MRP is registered for this listing.', 'এই পণ্যের MRP নিবন্ধিত নেই।');
    else if (!raw) push('mrp', 'NOT_FOUND_ON_LABEL', formatPaisa(reg.mrpPaisa), null, 'The MRP could not be read.', 'MRP পড়া যায়নি।');
    else if (o === null) push('mrp', 'UNCERTAIN', formatPaisa(reg.mrpPaisa), raw, 'An amount was read but could not be understood.', 'একটি দাম পড়া গেছে, কিন্তু বোঝা যায়নি।');
    else if (o === reg.mrpPaisa) push('mrp', 'MATCH', formatPaisa(reg.mrpPaisa), formatPaisa(o), 'MRP matches.', 'প্যাকেটের MRP নিবন্ধিত তথ্যের সঙ্গে মিলেছে।');
    else {
      const res = soften('mrp', 'MISMATCH');
      push('mrp', res, formatPaisa(reg.mrpPaisa), formatPaisa(o),
        res === 'MISMATCH' ? 'The MRP on the pack differs from the registered MRP.' : 'The MRP differs, but OCR was not confident.',
        res === 'MISMATCH' ? 'প্যাকেটের MRP নিবন্ধিত MRP-এর সঙ্গে মিলছে না।' : 'MRP আলাদা, তবে OCR নিশ্চিত নয়।');
    }
  }
  return out;
}

const READ_RESULTS: FieldResult[] = ['MATCH', 'MISMATCH', 'UNCERTAIN'];

export function overallResult(fields: FieldComparison[], listingPublished: boolean): { overall: OverallResult; en: string; bn: string } {
  if (!listingPublished) {
    return { overall: 'NOT_REGISTERED', en: 'No registered record was found for this batch. This alone does not mean the product is fake.', bn: 'এই ব্যাচের নিবন্ধিত তথ্য পাওয়া যায়নি। এর মানে পণ্যটি নকল—এমন সিদ্ধান্ত শুধু এই ফলাফল থেকে দেওয়া যায় না।' };
  }
  const read = fields.filter((f) => READ_RESULTS.includes(f.result));
  if (read.length < 2) {
    return { overall: 'INSUFFICIENT_IMAGE', en: 'Too little text could be read from the photo. Take a clearer, well-lit photo of the label (front and back).', bn: 'ছবি থেকে যথেষ্ট লেখা পড়া যায়নি। আলোতে লেবেলের সামনে ও পেছনের পরিষ্কার ছবি তুলুন।' };
  }
  if (fields.some((f) => f.result === 'MISMATCH')) {
    return { overall: 'MISMATCH_REVIEW', en: 'Some details do not match. This can be an OCR error, a mistake in the registered data, or a real difference in the pack. Further checking is needed — you can send this result for review.', bn: 'কিছু তথ্য মিলছে না। এটি OCR-এর ভুল, নিবন্ধিত তথ্যের ভুল, অথবা প্যাকেটের পার্থক্যের কারণে হতে পারে। আরও যাচাই প্রয়োজন।' };
  }
  const batch = fields.find((f) => f.field === 'batchNumber');
  if (batch && batch.result !== 'MATCH' && batch.result !== 'NOT_APPLICABLE') {
    return { overall: 'BATCH_UNRESOLVED', en: 'The batch number could not be confirmed, so the pack cannot be matched to this batch. Take a clearer photo of the batch number.', bn: 'ব্যাচ নম্বর নিশ্চিত করা যায়নি, তাই প্যাকেটটিকে এই ব্যাচের সঙ্গে মেলানো যায়নি। ব্যাচ নম্বরের আরও পরিষ্কার ছবি তুলুন।' };
  }
  const matches = fields.filter((f) => f.result === 'MATCH').length;
  if (matches >= 3 && !fields.some((f) => f.result === 'UNCERTAIN')) {
    return { overall: 'MATCH', en: 'The details read from your pack match the registered batch. This is a label comparison, not proof that the item is genuine.', bn: 'আপনার প্যাকেট থেকে পড়া তথ্য নিবন্ধিত ব্যাচের সঙ্গে মিলেছে। এটি লেবেলের তুলনা মাত্র—পণ্যটি আসল তার প্রমাণ নয়।' };
  }
  return { overall: 'UNCERTAIN', en: 'Some details match and some could not be confirmed. Retake the photo, or send it for review.', bn: 'কিছু তথ্য মিলেছে, কিছু নিশ্চিত করা যায়নি। ছবিটি আবার তুলুন অথবা যাচাইয়ের জন্য পাঠান।' };
}
