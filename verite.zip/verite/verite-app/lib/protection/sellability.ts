import { newId } from '../ids';
import type { Db } from '../trace/types';
import { POLICY_VERSION, type ProtectionConfig } from './config';
import type { Blocker } from './errors';
import { expiryInfo, type ExpiryInfo } from './expiry';
import { dbTakaToPaisa, formatPaisa } from './money';
import { evaluatePrice, type PriceEvaluation } from './pricing';

// ONE place that decides whether a listing may be sold. Used by the marketplace query, add-to-cart,
// the cart view, checkout (inside the order transaction), publish and the price/stock update.
// Precedence (first blocker is the headline reason; all are reported):
//   1 RECALLED  2 EXPIRED / EXPIRY_UNKNOWN  3 NOT_PUBLISHED  4 ABOVE_MRP / MRP_MISSING  5 OUT_OF_STOCK / INSUFFICIENT_STOCK

export interface ProductRow {
  id: string;
  seller_id: string;
  name: string;
  status: string;
  stock: number;
  price: number;
  batch_number: string | null;
  expiry_date: string | null;
  mrp_paisa: number | null;
  mrp_source?: string | null;
  mrp_status?: string | null;
}

export interface RecallSummary {
  id: string;
  status: 'ACTIVE' | 'CLOSED';
  reasonCode: string;
  publicMessage: string | null;
  createdAt: string;
}

export interface Protection {
  sellable: boolean;
  blockers: Blocker[];
  expiry: ExpiryInfo;
  pricing: PriceEvaluation;
  mrp: { amount: string | null; source: string | null; status: string | null };
  recall: RecallSummary | null;
}

export function activeRecall(db: Db, productId: string): RecallSummary | null {
  const r = db.prepare(
    "SELECT id, status, reason_code, public_message, created_at FROM batch_recalls WHERE product_id = ? AND status = 'ACTIVE'"
  ).get(productId) as { id: string; status: 'ACTIVE'; reason_code: string; public_message: string | null; created_at: string } | undefined;
  return r ? { id: r.id, status: r.status, reasonCode: r.reason_code, publicMessage: r.public_message, createdAt: r.created_at } : null;
}

export function evaluateProtection(p: ProductRow, recall: RecallSummary | null, now: Date, cfg: ProtectionConfig, quantity = 1): Protection {
  const blockers: Blocker[] = [];
  if (recall) {
    blockers.push({ code: 'RECALLED', en: 'This batch has been recalled and cannot be sold.', bn: 'এই ব্যাচটি প্রত্যাহার করা হয়েছে, তাই বিক্রি করা যাবে না।' });
  }
  const expiry = expiryInfo(p.expiry_date, now, cfg.expiryDisplayDays);
  if (expiry.state === 'EXPIRED') {
    blockers.push({ code: 'EXPIRED', en: `This batch expired on ${p.expiry_date} and cannot be sold.`, bn: 'এই ব্যাচের মেয়াদ শেষ, তাই বিক্রি করা যাবে না।' });
  } else if (expiry.state === 'UNKNOWN') {
    blockers.push({ code: 'EXPIRY_UNKNOWN', en: 'The expiry date is missing or invalid, so this batch cannot be sold until it is corrected.', bn: 'মেয়াদ যাচাই করা যায়নি, তাই সংশোধন না হওয়া পর্যন্ত বিক্রি করা যাবে না।' });
  }
  if (p.status !== 'PUBLISHED') {
    blockers.push({ code: 'NOT_PUBLISHED', en: 'This listing is not published.', bn: 'এই পণ্যটি এখনো প্রকাশিত হয়নি।' });
  }
  const pricePaisa = dbTakaToPaisa(p.price) ?? 0;
  const mrpPaisa = p.mrp_paisa === null || p.mrp_paisa === undefined ? null : Number(p.mrp_paisa);
  const pricing = evaluatePrice(pricePaisa, mrpPaisa, cfg);
  if (pricing.decision === 'BLOCKED_ABOVE_MRP') blockers.push({ code: 'ABOVE_MRP', en: pricing.en, bn: pricing.bn });
  if (pricing.decision === 'BLOCKED_MRP_MISSING') blockers.push({ code: 'MRP_MISSING', en: pricing.en, bn: pricing.bn });
  if (p.stock <= 0) {
    blockers.push({ code: 'OUT_OF_STOCK', en: 'Out of stock.', bn: 'স্টকে নেই।' });
  } else if (quantity > p.stock) {
    blockers.push({ code: 'INSUFFICIENT_STOCK', en: `Only ${p.stock} left in stock.`, bn: `স্টকে মাত্র ${p.stock} টি আছে।` });
  }
  return {
    sellable: blockers.length === 0,
    blockers,
    expiry,
    pricing,
    mrp: { amount: formatPaisa(mrpPaisa), source: p.mrp_source ?? null, status: p.mrp_status ?? null },
    recall,
  };
}

export function loadProduct(db: Db, productId: string): ProductRow | undefined {
  return db.prepare(
    'SELECT id, seller_id, name, status, stock, price, batch_number, expiry_date, mrp_paisa, mrp_source, mrp_status FROM products WHERE id = ?'
  ).get(productId) as ProductRow | undefined;
}

export function protectionFor(db: Db, productId: string, now: Date, cfg: ProtectionConfig, quantity = 1): Protection | null {
  const p = loadProduct(db, productId);
  return p ? evaluateProtection(p, activeRecall(db, productId), now, cfg, quantity) : null;
}

/** Marketplace filter in SQL (mirrors the rules above, minus stock): used so hidden listings never reach buyers. */
export function sellableSqlFilter(alias: string, cfg: ProtectionConfig, today: string): string {
  // `today` comes from dhakaToday() and is checked here, so inlining it cannot inject SQL.
  if (!/^\d{4}-\d{2}-\d{2}$/.test(today)) throw new Error('invalid date');
  const a = alias;
  return [
    `${a}.status = 'PUBLISHED'`,
    `${a}.expiry_date IS NOT NULL AND ${a}.expiry_date >= '${today}'`,
    `NOT EXISTS (SELECT 1 FROM batch_recalls br WHERE br.product_id = ${a}.id AND br.status = 'ACTIVE')`,
    `(${a}.mrp_paisa IS NULL OR CAST(ROUND(${a}.price * 100) AS INTEGER) <= ${a}.mrp_paisa)`,
    ...(cfg.mrpMissingPolicy === 'block' ? [`${a}.mrp_paisa IS NOT NULL`] : []),
  ].join(' AND ');
}

export function audit(db: Db, e: { actorId: string | null; actorRole: string | null; action: string; productId?: string | null; refId?: string | null; before?: unknown; after?: unknown }, now: Date) {
  db.prepare(
    `INSERT INTO protection_audit (id, actor_id, actor_role, action, product_id, ref_id, before_json, after_json, policy_version, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(newId('pau'), e.actorId, e.actorRole, e.action, e.productId ?? null, e.refId ?? null,
    e.before === undefined ? null : JSON.stringify(e.before), e.after === undefined ? null : JSON.stringify(e.after), POLICY_VERSION, now.toISOString());
}
