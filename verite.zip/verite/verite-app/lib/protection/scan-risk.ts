import { newId } from '../ids';
import { dhakaDate } from '../assistant/analytics';
import type { ScanConfig } from '../trace/config';
import { evaluateScanPattern } from '../trace/service';
import type { Db } from '../trace/types';
import { bnDigits } from './money';

// Seller-facing QR clone-RISK alerts, built only from stored scan_events (real requests to /api/scan).
// The rule is the SAME one the buyer-facing scan warning uses (lib/trace/service.ts evaluateScanPattern
// with ScanConfig), so seller and buyer never disagree: within the window, the number of VALID or
// SUSPICIOUS scans of one code >= the scope threshold AND distinct network groups >= the distinct threshold.
// - "network group" = the stored keyed hash of a coarse network prefix (IPv4 /24, IPv6 /48). Only the COUNT
//   of distinct groups is shown; no IP, hash or buyer identity ever leaves this function.
// - UNKNOWN/REVOKED outcomes and rate-limited requests (never stored) are not counted.
// - It is a heuristic: thresholds are provisional, repeated scans can be legitimate, and the alert never
//   revokes a code or recalls a batch by itself.

export interface ScanRiskFinding {
  identifierId: string;
  productId: string;
  productName: string;
  scope: 'UNIT' | 'BATCH';
  batchNumber: string | null;
  unitSerial: number | null;
  scans: number;
  distinctNetworkGroups: number;
  threshold: number;
  windowMinutes: number;
}

export function windowText(minutes: number) {
  // bn is in the locative form used after "গত": "গত ২ ঘণ্টায়", "গত ১ দিনে".
  if (minutes % 1440 === 0) { const d = minutes / 1440; return { en: `${d} day${d === 1 ? '' : 's'}`, bn: `${bnDigits(d)} দিনে` }; }
  if (minutes % 60 === 0) { const h = minutes / 60; return { en: `${h} hour${h === 1 ? '' : 's'}`, bn: `${bnDigits(h)} ঘণ্টায়` }; }
  return { en: `${minutes} minutes`, bn: `${bnDigits(minutes)} মিনিটে` };
}

export function findScanRisks(db: Db, sellerId: string, now: Date, cfg: ScanConfig): ScanRiskFinding[] {
  const since = new Date(now.getTime() - cfg.windowMinutes * 60_000).toISOString();
  const rows = db.prepare(
    `SELECT ti.id, ti.scope, ti.product_id, ti.batch_number, ti.unit_serial, p.name,
            COUNT(*) AS n, COUNT(DISTINCT COALESCE(se.source_hash, 'unknown')) AS d
     FROM scan_events se
     JOIN trace_identifiers ti ON ti.id = se.identifier_id
     JOIN products p ON p.id = ti.product_id
     WHERE p.seller_id = ? AND se.created_at >= ? AND se.created_at <= ? AND se.outcome IN ('VALID','SUSPICIOUS')
     GROUP BY ti.id`
  ).all(sellerId, since, now.toISOString()) as any[];
  const out: ScanRiskFinding[] = [];
  for (const r of rows) {
    const scans = Number(r.n);
    const distinct = Number(r.d);
    if (!evaluateScanPattern(r.scope, scans, distinct, cfg).suspicious) continue;
    out.push({
      identifierId: r.id, productId: r.product_id, productName: r.name, scope: r.scope, batchNumber: r.batch_number ?? null,
      unitSerial: r.unit_serial === null || r.unit_serial === undefined ? null : Number(r.unit_serial),
      scans, distinctNetworkGroups: distinct, threshold: r.scope === 'UNIT' ? cfg.thresholdUnit : cfg.thresholdBatch, windowMinutes: cfg.windowMinutes,
    });
  }
  return out;
}

export function scanRiskText(f: ScanRiskFinding) {
  const w = windowText(f.windowMinutes);
  const which = f.scope === 'UNIT' ? `unit code #${f.unitSerial}` : 'batch code';
  const whichBn = f.scope === 'UNIT' ? `ইউনিট কোড #${bnDigits(f.unitSerial ?? '')}` : 'ব্যাচ কোড';
  const batchNote = f.scope === 'BATCH' ? ' A batch code is printed on many packs, so many scans can be normal.' : '';
  const batchNoteBn = f.scope === 'BATCH' ? ' ব্যাচ কোড অনেক প্যাকেটে ছাপা থাকে, তাই বেশি স্ক্যান স্বাভাবিকও হতে পারে।' : '';
  return {
    titleEn: `Unusual scan activity: ${f.productName} (${which})`,
    bodyEn: `In the last ${w.en}, this ${which} was scanned ${f.scans} times from ${f.distinctNetworkGroups} different network group(s) (rule: ${f.threshold}+ scans). The code may have been copied, but scan counts alone do not prove a counterfeit. Suggested: inspect packs of batch ${f.batchNumber ?? '—'}, check where you supplied them, and revoke the code on the QR Codes page only if you confirm a problem.${batchNote}`,
    titleBn: `অস্বাভাবিক স্ক্যান: ${f.productName} (${whichBn})`,
    bodyBn: `গত ${w.bn} এই ${whichBn}টি ${bnDigits(f.distinctNetworkGroups)}টি নেটওয়ার্ক গ্রুপ থেকে ${bnDigits(f.scans)} বার স্ক্যান হয়েছে (নিয়ম: ${bnDigits(f.threshold)}+ স্ক্যান)। কোডটি কপি হয়ে থাকতে পারে, তবে শুধু স্ক্যানের সংখ্যা দিয়ে নকল প্রমাণ হয় না। প্যাকেটগুলো পরীক্ষা করুন, আর সমস্যা নিশ্চিত হলে তবেই QR Codes পাতা থেকে কোডটি বাতিল করুন।${batchNoteBn}`,
  };
}

/** Store one SCAN_RISK notification per code per Dhaka day. Returns how many were created. */
export function saveScanRiskAlerts(db: Db, sellerId: string, findings: ScanRiskFinding[], now: Date): number {
  const ins = db.prepare(
    `INSERT OR IGNORE INTO seller_notifications (id, seller_id, product_id, kind, severity, title_en, body_en, title_bn, body_bn, data_json, dedupe_key, created_at)
     VALUES (?, ?, ?, 'SCAN_RISK', 'WARNING', ?, ?, ?, ?, ?, ?, ?)`
  );
  const day = dhakaDate(now);
  let created = 0;
  for (const f of findings) {
    const t = scanRiskText(f);
    const data = { scope: f.scope, unitSerial: f.unitSerial, scans: f.scans, distinctNetworkGroups: f.distinctNetworkGroups, threshold: f.threshold, windowMinutes: f.windowMinutes, rule: 'evaluateScanPattern' };
    created += Number(ins.run(newId('ntf'), sellerId, f.productId, t.titleEn, t.bodyEn, t.titleBn, t.bodyBn, JSON.stringify(data), `SCAN_RISK:${f.identifierId}:${day}`, now.toISOString()).changes);
  }
  return created;
}

export function runScanRiskCheck(db: Db, sellerId: string, now: Date, cfg: ScanConfig) {
  const findings = findScanRisks(db, sellerId, now, cfg);
  return { findings: findings.length, created: saveScanRiskAlerts(db, sellerId, findings, now) };
}
