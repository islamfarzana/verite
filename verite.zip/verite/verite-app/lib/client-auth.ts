'use client';
import { useEffect, useState } from 'react';

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  role: 'BUYER' | 'SELLER' | 'ADMIN';
}

// The JWT itself lives in a secure httpOnly cookie set by the server (never
// in localStorage — the browser JS can't read it, which is the point). This
// hook just asks the server "who am I?" via that cookie.
export function useSession() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/users/me')
      .then((r) => (r.ok ? r.json() : null))
      .then((res) => setUser(res?.data || null))
      .finally(() => setLoading(false));
  }, []);

  return { user, loading };
}

export async function logout() {
  await fetch('/api/auth/logout', { method: 'POST' });
  location.href = '/';
}

export function dashboardPathFor(role: SessionUser['role']): string {
  if (role === 'SELLER') return '/seller/dashboard';
  if (role === 'ADMIN') return '/admin/dashboard';
  return '/buyer/dashboard';
}
