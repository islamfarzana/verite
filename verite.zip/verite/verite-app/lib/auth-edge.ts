import { SignJWT, jwtVerify } from 'jose';

// Edge-runtime-safe: only jose (pure JS, no Node APIs). This is the file
// middleware.ts imports, so it must NEVER pull in bcryptjs (which uses
// Node's process.nextTick/setImmediate and breaks in the Edge runtime).
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || 'dev-secret-change-me-in-production');
export const AUTH_COOKIE = 'verite_session';

export interface JwtPayload {
  id: string;
  email: string;
  role: 'BUYER' | 'SELLER' | 'ADMIN';
}

export async function signToken(payload: JwtPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string): Promise<JwtPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as JwtPayload;
  } catch {
    return null;
  }
}

export function dashboardPathFor(role: JwtPayload['role']): string {
  if (role === 'SELLER') return '/seller/dashboard';
  if (role === 'ADMIN') return '/admin/dashboard';
  return '/buyer/dashboard';
}
