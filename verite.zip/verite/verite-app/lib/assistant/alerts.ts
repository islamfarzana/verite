import { newId } from '../ids';
import type { Db } from '../trace/types';
import { dhakaDate, productStats, sqlTime, type ProductStat } from './analytics';

// Rule-based seller alerts (stock and expiry). Deterministic: the same data always gives the same
// alerts, so they can be tested and explained. Text is written in English and Bangla.
// Each alert is stored once per product, kind and Dhaka calendar day (dedupe key), so running the
// check many times a day does not spam the seller.

export interface AlertConfig {
  stockoutWarnDays: number; // warn when stock will run out within this many days
  coverTargetDays: number; // suggested restock covers this many days of sales
  lowStockUnits: number; // "low stock" for slow sellers, in units
  expiryWarnDays: number; // "expiring soon"
  expiryRiskHorizonDays: number; // look this far ahead for stock that may expire unsold
}

export const DEFAULT_ALERT_CONFIG: AlertConfig = {
  stockoutWarnDays: 7, coverTargetDays: 14, lowStockUnits: 5, expiryWarnDays: 30, expiryRiskHorizonDays: 90,
};

export function loadAlertConfig(env: Record<string, string | undefined> = process.env): AlertConfig {
  const n = (v: string | undefined, d: number) => (v && Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : d);
  return {
    stockoutWarnDays: n(env.ASSISTANT_STOCKOUT_WARN_DAYS, 7),
    coverTargetDays: n(env.ASSISTANT_COVER_TARGET_DAYS, 14),
    lowStockUnits: n(env.ASSISTANT_LOW_STOCK_UNITS, 5),
    expiryWarnDays: n(env.ASSISTANT_EXPIRY_WARN_DAYS, 30),
    expiryRiskHorizonDays: n(env.ASSISTANT_EXPIRY_RISK_DAYS, 90),
  };
}

export const bn = (x: number | string) => String(x).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[Number(d)]);

export interface AlertDraft {
  kind: 'OUT_OF_STOCK' | 'STOCKOUT_SOON' | 'LOW_STOCK' | 'EXPIRED_LISTED' | 'EXPIRING_SOON' | 'EXPIRY_RISK';
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  productId: string;
  titleEn: string; bodyEn: string; titleBn: string; bodyBn: string;
  data: Record<string, unknown>;
}

/** Pure: which alerts the current numbers call for. */
export function evaluateAlerts(stats: ProductStat[], cfg: AlertConfig = DEFAULT_ALERT_CONFIG): AlertDraft[] {
  const out: AlertDraft[] = [];
  for (const s of stats) {
    if (s.status !== 'PUBLISHED') continue;
    const d = { stock: s.stock, dailyVelocity: s.dailyVelocity, daysOfCover: s.daysOfCover, daysToExpiry: s.daysToExpiry };

    // --- expiry (checked first: an expired product must not be sold at all)
    if (s.daysToExpiry !== null && s.daysToExpiry < 0) {
      out.push({
        kind: 'EXPIRED_LISTED', severity: 'CRITICAL', productId: s.id, data: d,
        // v5: Verité now blocks expired batches automatically (lib/protection/sellability.ts); the legal claim
        // that used to be here was not verified against an official source, so the wording is neutral.
        titleEn: `${s.name} has expired: hidden from buyers`,
        bodyEn: `Expiry date ${s.expiryDate} has passed. Buyers can no longer see or order it; ${s.stock} units are still in your stock. Remove them from your shelves and dispose of them according to the rules that apply to you.`,
        titleBn: `${s.name}-এর মেয়াদ শেষ: ক্রেতাদের কাছ থেকে লুকানো হয়েছে`,
        bodyBn: `মেয়াদ উত্তীর্ণের তারিখ ${bn(s.expiryDate!)} পার হয়ে গেছে। ক্রেতারা এটি আর দেখতে বা অর্ডার করতে পারবেন না; আপনার স্টকে এখনো ${bn(s.stock)} টি আছে। এগুলো তাক থেকে সরিয়ে প্রযোজ্য নিয়ম অনুযায়ী নিষ্পত্তি করুন।`,
      });
      continue;
    }
    if (s.daysToExpiry !== null && s.stock > 0) {
      const unsold = s.projectedUnsoldAtExpiry ?? 0;
      if (s.daysToExpiry <= cfg.expiryRiskHorizonDays && unsold > 0 && s.dailyVelocity > 0) {
        out.push({
          kind: 'EXPIRY_RISK', severity: 'WARNING', productId: s.id, data: { ...d, projectedUnsoldAtExpiry: unsold },
          titleEn: `About ${unsold} units of ${s.name} may expire unsold`,
          bodyEn: `At the current rate (${s.dailyVelocity}/day) about ${unsold} of ${s.stock} units will still be in stock on ${s.expiryDate}. Consider a discount or bundle, and sell the oldest batch first.`,
          titleBn: `${s.name}: প্রায় ${bn(unsold)} টি মেয়াদ শেষের আগে বিক্রি নাও হতে পারে`,
          bodyBn: `বর্তমান হারে (দিনে ${bn(s.dailyVelocity)} টি) ${bn(s.expiryDate!)} তারিখে ${bn(s.stock)} টির মধ্যে প্রায় ${bn(unsold)} টি থেকে যাবে। ছাড় বা বান্ডেল অফার বিবেচনা করুন, আর পুরনো ব্যাচ আগে বিক্রি করুন।`,
        });
      } else if (s.daysToExpiry <= cfg.expiryWarnDays) {
        out.push({
          kind: 'EXPIRING_SOON', severity: 'WARNING', productId: s.id, data: d,
          titleEn: `${s.name} expires in ${s.daysToExpiry} days`,
          bodyEn: `${s.stock} units in stock expire on ${s.expiryDate}. Plan to sell or remove them before then.`,
          titleBn: `${s.name}-এর মেয়াদ ${bn(s.daysToExpiry)} দিনে শেষ হবে`,
          bodyBn: `স্টকে থাকা ${bn(s.stock)} টির মেয়াদ ${bn(s.expiryDate!)} তারিখে শেষ। তার আগে বিক্রি বা সরিয়ে নেওয়ার পরিকল্পনা করুন।`,
        });
      }
    }

    // --- stock
    if (s.stock === 0) {
      out.push({
        kind: 'OUT_OF_STOCK', severity: 'CRITICAL', productId: s.id, data: d,
        titleEn: `${s.name} is out of stock`,
        bodyEn: s.dailyVelocity > 0
          ? `It was selling about ${s.dailyVelocity} per day. Restock about ${Math.ceil(s.dailyVelocity * cfg.coverTargetDays)} units to cover ${cfg.coverTargetDays} days.`
          : 'Buyers cannot order it until you restock.',
        titleBn: `${s.name} স্টকে নেই`,
        bodyBn: s.dailyVelocity > 0
          ? `দিনে প্রায় ${bn(s.dailyVelocity)} টি বিক্রি হচ্ছিল। ${bn(cfg.coverTargetDays)} দিনের জন্য প্রায় ${bn(Math.ceil(s.dailyVelocity * cfg.coverTargetDays))} টি আবার মজুত করুন।`
          : 'আবার মজুত না করা পর্যন্ত ক্রেতারা এটি অর্ডার করতে পারবেন না।',
      });
    } else if (s.daysOfCover !== null && s.daysOfCover <= cfg.stockoutWarnDays) {
      const restock = Math.max(0, Math.ceil(s.dailyVelocity * cfg.coverTargetDays - s.stock));
      out.push({
        kind: 'STOCKOUT_SOON', severity: 'WARNING', productId: s.id, data: { ...d, restock, stockoutDate: s.stockoutDate },
        titleEn: `${s.name} will run out in about ${Math.max(1, Math.round(s.daysOfCover))} days`,
        bodyEn: `${s.stock} left, selling about ${s.dailyVelocity} per day (last ${s.windowDays} days). Restock about ${restock} units to cover ${cfg.coverTargetDays} days.`,
        titleBn: `${s.name} প্রায় ${bn(Math.max(1, Math.round(s.daysOfCover)))} দিনের মধ্যে শেষ হয়ে যাবে`,
        bodyBn: `বাকি আছে ${bn(s.stock)} টি, গত ${bn(s.windowDays)} দিনে দিনে প্রায় ${bn(s.dailyVelocity)} টি বিক্রি হয়েছে। ${bn(cfg.coverTargetDays)} দিনের জন্য প্রায় ${bn(restock)} টি মজুত করুন।`,
      });
    } else if (s.stock <= cfg.lowStockUnits) {
      out.push({
        kind: 'LOW_STOCK', severity: 'INFO', productId: s.id, data: d,
        titleEn: `Low stock: ${s.name} (${s.stock} left)`,
        bodyEn: `Only ${s.stock} units left.`,
        titleBn: `স্টক কম: ${s.name} (${bn(s.stock)} টি বাকি)`,
        bodyBn: `মাত্র ${bn(s.stock)} টি বাকি আছে।`,
      });
    }
  }
  return out;
}

/** Store new alerts (at most one per product, kind and day). Returns how many were created. */
export function saveAlerts(db: Db, sellerId: string, drafts: AlertDraft[], now: Date): number {
  const ins = db.prepare(
    `INSERT OR IGNORE INTO seller_notifications (id, seller_id, product_id, kind, severity, title_en, body_en, title_bn, body_bn, data_json, dedupe_key, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const day = dhakaDate(now);
  let created = 0;
  for (const a of drafts) {
    const r = ins.run(newId('ntf'), sellerId, a.productId, a.kind, a.severity, a.titleEn, a.bodyEn, a.titleBn, a.bodyBn, JSON.stringify(a.data),
      `${a.kind}:${a.productId}:${day}`, now.toISOString());
    created += Number(r.changes);
  }
  return created;
}

/** Run the checks for one seller unless they ran less than `minIntervalMinutes` ago. */
export function runChecksIfDue(db: Db, sellerId: string, now: Date, cfg = DEFAULT_ALERT_CONFIG, minIntervalMinutes = 60): { ran: boolean; created: number } {
  const last = db.prepare('SELECT last_run_at FROM assistant_runs WHERE seller_id = ?').get(sellerId) as { last_run_at: string } | undefined;
  if (last && now.getTime() - Date.parse(last.last_run_at) < minIntervalMinutes * 60_000) return { ran: false, created: 0 };
  const created = saveAlerts(db, sellerId, evaluateAlerts(productStats(db, sellerId, now), cfg), now);
  db.prepare('INSERT INTO assistant_runs (seller_id, last_run_at) VALUES (?, ?) ON CONFLICT(seller_id) DO UPDATE SET last_run_at = excluded.last_run_at')
    .run(sellerId, now.toISOString());
  return { ran: true, created };
}

export function listNotifications(db: Db, sellerId: string, limit = 30) {
  return db.prepare(
    `SELECT id, product_id AS productId, kind, severity, title_en AS titleEn, body_en AS bodyEn, title_bn AS titleBn, body_bn AS bodyBn,
            created_at AS createdAt, read_at AS readAt FROM seller_notifications WHERE seller_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?`
  ).all(sellerId, limit);
}

export function unreadCount(db: Db, sellerId: string): number {
  return Number((db.prepare('SELECT COUNT(*) AS c FROM seller_notifications WHERE seller_id = ? AND read_at IS NULL').get(sellerId) as { c: number }).c);
}

/** Mark the seller's own notifications read (ids are filtered by seller, so others' cannot be touched). */
export function markRead(db: Db, sellerId: string, ids: string[] | 'all', now: Date): number {
  if (ids === 'all') {
    return Number(db.prepare('UPDATE seller_notifications SET read_at = ? WHERE seller_id = ? AND read_at IS NULL').run(now.toISOString(), sellerId).changes);
  }
  const stmt = db.prepare('UPDATE seller_notifications SET read_at = ? WHERE id = ? AND seller_id = ? AND read_at IS NULL');
  return ids.slice(0, 200).reduce((n, id) => n + Number(stmt.run(now.toISOString(), id, sellerId).changes), 0);
}

export { sqlTime };
