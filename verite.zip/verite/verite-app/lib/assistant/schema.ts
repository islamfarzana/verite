// Seller assistant: notifications, check throttling and stored weekly summaries.
// Additive tables only. Rollback: DROP TABLE assistant_summaries; DROP TABLE assistant_runs;
// DROP TABLE seller_notifications;
// v5 (buyer protection) adds SCAN_RISK and RECALL_ISSUED. Databases created by v4 are rebuilt once by
// lib/protection/schema.ts (migrateNotificationKinds), keeping every row.
export const NOTIFICATION_KINDS = ['OUT_OF_STOCK', 'STOCKOUT_SOON', 'LOW_STOCK', 'EXPIRED_LISTED', 'EXPIRING_SOON', 'EXPIRY_RISK', 'SCAN_RISK', 'RECALL_ISSUED'] as const;

export function sellerNotificationsTableSql(table = 'seller_notifications'): string {
  return `CREATE TABLE IF NOT EXISTS ${table} (
  id TEXT PRIMARY KEY,
  seller_id TEXT NOT NULL REFERENCES users(id),
  product_id TEXT REFERENCES products(id),
  kind TEXT NOT NULL CHECK (kind IN (${NOTIFICATION_KINDS.map((k) => `'${k}'`).join(',')})),
  severity TEXT NOT NULL CHECK (severity IN ('INFO','WARNING','CRITICAL')),
  title_en TEXT NOT NULL,
  body_en TEXT NOT NULL,
  title_bn TEXT NOT NULL,
  body_bn TEXT NOT NULL,
  data_json TEXT,
  dedupe_key TEXT NOT NULL,
  created_at TEXT NOT NULL,
  read_at TEXT,
  UNIQUE (seller_id, dedupe_key)
);`;
}

export const ASSISTANT_SCHEMA_SQL = `
${sellerNotificationsTableSql()}
CREATE INDEX IF NOT EXISTS ix_notifications_seller ON seller_notifications(seller_id, created_at);

CREATE TABLE IF NOT EXISTS assistant_runs (
  seller_id TEXT PRIMARY KEY REFERENCES users(id),
  last_run_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS assistant_summaries (
  id TEXT PRIMARY KEY,
  seller_id TEXT NOT NULL REFERENCES users(id),
  language TEXT NOT NULL CHECK (language IN ('en','bn')),
  text TEXT NOT NULL,
  source TEXT NOT NULL CHECK (source IN ('AI','TEMPLATE')),
  model TEXT,
  facts_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
`;
