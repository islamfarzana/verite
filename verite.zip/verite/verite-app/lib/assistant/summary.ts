import { AiError, generate, type FetchLike, type GeminiConfig } from '../ai/gemini';
import { toAsciiDigits } from '../ai/normalize';
import { bn } from './alerts';
import type { WeeklyFacts } from './analytics';

// Weekly summary for the seller, in English or Bangla.
// The numbers come from analytics.weeklyFacts(). When an AI key is configured, Gemini turns the
// facts into a short readable paragraph; the result is then CHECKED: every number in the AI text
// must appear in the facts. If the AI invents or changes a number, its text is discarded and the
// deterministic template is used instead. Without an AI key the template is always used.

export type Lang = 'en' | 'bn';

const SYSTEM = [
  'You write a short weekly business summary for a small online seller in Bangladesh.',
  'Use ONLY the numbers and product names in the JSON facts you are given. Do not calculate new numbers,',
  'do not round differently, do not add products, prices, forecasts or advice that needs numbers not in the facts.',
  'Mention urgent items first: expired products still listed, then products running out, then expiring stock.',
  'Maximum 120 words. Plain text, no markdown, no greeting.',
].join(' ');

/** Every number that the summary text is allowed to contain. */
export function allowedNumbers(facts: WeeklyFacts): Set<string> {
  const set = new Set<string>();
  const walk = (v: unknown) => {
    if (typeof v === 'number' && Number.isFinite(v)) {
      set.add(String(v));
      set.add(String(Math.round(v)));
      set.add(String(Math.abs(v)));
      set.add(String(Math.abs(Math.round(v))));
    } else if (typeof v === 'string') {
      for (const m of v.match(/\d+(?:\.\d+)?/g) || []) set.add(m);
    } else if (Array.isArray(v)) v.forEach(walk);
    else if (v && typeof v === 'object') Object.values(v).forEach(walk);
  };
  walk(facts);
  ['7', '14', '30', '1'].forEach((n) => set.add(n)); // "7 days", "14 days", "30 days", "1 week"
  return set;
}

/** Numbers used in a text that are not in the facts (Bengali digits and thousands separators handled). */
export function unsupportedNumbers(text: string, facts: WeeklyFacts): string[] {
  const allowed = allowedNumbers(facts);
  const found = toAsciiDigits(text).replace(/(\d),(\d{3})/g, '$1$2').match(/\d+(?:\.\d+)?/g) || [];
  return found.filter((n) => !allowed.has(n) && !allowed.has(String(Number(n))));
}

const tk = (n: number, lang: Lang) => (lang === 'bn' ? `৳${bn(n)}` : `Tk ${n}`);

/** Deterministic summary from the facts (always correct, less fluent). */
export function templateSummary(f: WeeklyFacts, lang: Lang): string {
  const parts: string[] = [];
  if (lang === 'bn') {
    parts.push(`গত ৭ দিনে ${bn(f.thisWeek.orders)} টি অর্ডারে ${bn(f.thisWeek.units)} টি পণ্য বিক্রি হয়েছে, মোট ${tk(f.thisWeek.revenue, lang)}।`);
    if (f.revenueChangePercent !== null) parts.push(`আগের সপ্তাহের তুলনায় বিক্রি ${bn(Math.abs(f.revenueChangePercent))}% ${f.revenueChangePercent >= 0 ? 'বেড়েছে' : 'কমেছে'}।`);
    if (f.topProducts.length) parts.push(`সবচেয়ে বেশি বিক্রি: ${f.topProducts.map((t) => `${t.name} (${bn(t.units)} টি)`).join(', ')}।`);
    if (f.expiredStillListed.length) parts.push(`জরুরি: মেয়াদ শেষ হলেও তালিকায় আছে — ${f.expiredStillListed.map((x) => x.name).join(', ')}।`);
    if (f.outOfStock.length) parts.push(`স্টকে নেই: ${f.outOfStock.map((x) => x.name).join(', ')}।`);
    if (f.stockingOutWithin7Days.length) parts.push(`৭ দিনের মধ্যে শেষ হতে পারে: ${f.stockingOutWithin7Days.map((x) => `${x.name} (${bn(x.stock)} টি বাকি)`).join(', ')}।`);
    if (f.expiringWithin30Days.length) parts.push(`৩০ দিনের মধ্যে মেয়াদ শেষ: ${f.expiringWithin30Days.map((x) => `${x.name} (${bn(x.daysToExpiry ?? 0)} দিন)`).join(', ')}।`);
    if (f.slowMovers14Days.length) parts.push(`১৪ দিনে বিক্রি হয়নি: ${f.slowMovers14Days.map((x) => x.name).join(', ')}।`);
  } else {
    parts.push(`In the last 7 days you sold ${f.thisWeek.units} units in ${f.thisWeek.orders} orders, for ${tk(f.thisWeek.revenue, lang)}.`);
    if (f.revenueChangePercent !== null) parts.push(`Sales are ${f.revenueChangePercent >= 0 ? 'up' : 'down'} ${Math.abs(f.revenueChangePercent)}% on the week before.`);
    if (f.topProducts.length) parts.push(`Best sellers: ${f.topProducts.map((t) => `${t.name} (${t.units})`).join(', ')}.`);
    if (f.expiredStillListed.length) parts.push(`Urgent: expired but still listed — ${f.expiredStillListed.map((x) => x.name).join(', ')}.`);
    if (f.outOfStock.length) parts.push(`Out of stock: ${f.outOfStock.map((x) => x.name).join(', ')}.`);
    if (f.stockingOutWithin7Days.length) parts.push(`May run out within 7 days: ${f.stockingOutWithin7Days.map((x) => `${x.name} (${x.stock} left)`).join(', ')}.`);
    if (f.expiringWithin30Days.length) parts.push(`Expiring within 30 days: ${f.expiringWithin30Days.map((x) => `${x.name} (${x.daysToExpiry} days)`).join(', ')}.`);
    if (f.slowMovers14Days.length) parts.push(`No sales in 14 days: ${f.slowMovers14Days.map((x) => x.name).join(', ')}.`);
  }
  return parts.join(' ');
}

export interface SummaryResult {
  text: string;
  source: 'AI' | 'TEMPLATE';
  model: string | null;
  fallbackReason: string | null; // why the AI text was not used
}

export async function weeklySummary(cfg: GeminiConfig | null, facts: WeeklyFacts, lang: Lang, fetchImpl?: FetchLike): Promise<SummaryResult> {
  if (!cfg) return { text: templateSummary(facts, lang), source: 'TEMPLATE', model: null, fallbackReason: 'NOT_CONFIGURED' };
  try {
    const text = (await generate(cfg, {
      system: SYSTEM,
      parts: [{ text: `Language: ${lang === 'bn' ? 'Bangla (Bengali script, Bengali digits are fine)' : 'English'}.\nFacts (JSON):\n${JSON.stringify(facts)}` }],
      temperature: 0.2,
    }, fetchImpl)).trim();
    const bad = unsupportedNumbers(text, facts);
    if (bad.length) {
      return { text: templateSummary(facts, lang), source: 'TEMPLATE', model: cfg.model, fallbackReason: `AI_USED_UNSUPPORTED_NUMBERS:${bad.slice(0, 5).join(',')}` };
    }
    return { text: text.slice(0, 1500), source: 'AI', model: cfg.model, fallbackReason: null };
  } catch (err) {
    return { text: templateSummary(facts, lang), source: 'TEMPLATE', model: cfg.model, fallbackReason: err instanceof AiError ? err.category : 'ERROR' };
  }
}
