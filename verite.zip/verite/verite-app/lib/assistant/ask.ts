import { AiError, generateJson, type FetchLike, type GeminiConfig } from '../ai/gemini';
import type { Db } from '../trace/types';
import { bn } from './alerts';
import { dailySeries, periodDays, productStats, slowMovers, topProducts } from './analytics';

// "Ask your shop": the seller asks a question in Bangla or English.
//
// Safety design: the AI only CLASSIFIES the question into one of a fixed set of intents (with
// limited, validated parameters). It never sees the database, never writes SQL, and never writes
// the numbers in the answer. The server runs the fixed query for the seller's OWN products and
// writes the answer from a template. Without an AI key, a keyword matcher (Bangla + English)
// does the classification instead.

export const INTENTS = ['top_products', 'slow_movers', 'stock_status', 'expiring', 'sales_summary', 'unsupported'] as const;
export type Intent = (typeof INTENTS)[number];

export interface Interpretation {
  intent: Intent;
  period: '7d' | '30d' | '90d';
  metric: 'units' | 'revenue';
  productQuery: string | null;
  lang: 'en' | 'bn';
  via: 'AI' | 'KEYWORDS';
}

const INTENT_SCHEMA = {
  type: 'OBJECT',
  properties: {
    intent: { type: 'STRING', enum: [...INTENTS] },
    period: { type: 'STRING', enum: ['7d', '30d', '90d'] },
    metric: { type: 'STRING', enum: ['units', 'revenue'] },
    productQuery: { type: 'STRING', nullable: true },
  },
  required: ['intent', 'period', 'metric'],
};

const INTENT_PROMPT = [
  'Classify a shop owner\'s question about their own online shop into exactly one intent:',
  'top_products (best/most sold products), slow_movers (products not selling), stock_status (stock left / running out, optionally for one product),',
  'expiring (products near or past expiry), sales_summary (total sales/revenue/orders for a period), unsupported (anything else).',
  'period: 7d for "this week/today/7 days", 90d for "3 months/quarter", otherwise 30d. metric: revenue if they ask about money/income/taka, else units.',
  'productQuery: the product name the question mentions, else null. The question may be in Bangla or English. Return JSON only.',
].join(' ');

export const isBangla = (s: string) => (s.match(/[ঀ-৿]/g) || []).length >= 2;

/** Keyword classifier used when no AI key is configured (and as a sanity fallback). */
export function keywordInterpret(q: string): Interpretation {
  const t = q.toLowerCase().normalize('NFC');
  const lang = isBangla(q) ? 'bn' : 'en';
  const has = (...w: string[]) => w.some((x) => t.includes(x.normalize('NFC')));
  const period = has('week', 'সপ্তাহ', 'today', 'আজ', '7 day', '৭ দিন') ? '7d' : has('3 month', 'quarter', '৩ মাস', 'তিন মাস', '90') ? '90d' : '30d';
  const metric = has('revenue', 'income', 'money', 'taka', 'টাকা', 'আয়', 'আয়', 'রেভিনিউ') ? 'revenue' : 'units';
  let intent: Intent = 'unsupported';
  if (has('expir', 'মেয়াদ', 'মেয়াদ')) intent = 'expiring';
  else if (has('slow', 'not selling', "isn't selling", 'বিক্রি হচ্ছে না', 'বিক্রি হয়নি', 'কম বিক্রি')) intent = 'slow_movers';
  else if (has('stock', 'স্টক', 'run out', 'শেষ হয়ে', 'শেষ হবে', 'মজুত')) intent = 'stock_status';
  else if (has('best', 'top', 'most', 'popular', 'সবচেয়ে বেশি', 'সবচেয়ে বেশি', 'বেশি বিক্রি', 'জনপ্রিয়')) intent = 'top_products';
  else if (has('sales', 'sold', 'revenue', 'orders', 'বিক্রি', 'অর্ডার', 'আয়', 'আয়')) intent = 'sales_summary';
  return { intent, period, metric, productQuery: null, lang, via: 'KEYWORDS' };
}

export async function interpret(cfg: GeminiConfig | null, question: string, fetchImpl?: FetchLike): Promise<Interpretation> {
  const fallback = keywordInterpret(question);
  if (!cfg) return fallback;
  try {
    const r = await generateJson<Record<string, unknown>>(cfg, { system: INTENT_PROMPT, parts: [{ text: question.slice(0, 500) }], schema: INTENT_SCHEMA }, fetchImpl);
    const intent = (INTENTS as readonly string[]).includes(String(r.intent)) ? (r.intent as Intent) : 'unsupported';
    const period = ['7d', '30d', '90d'].includes(String(r.period)) ? (r.period as Interpretation['period']) : fallback.period;
    const metric = r.metric === 'revenue' ? 'revenue' : 'units';
    const productQuery = typeof r.productQuery === 'string' && r.productQuery.trim() ? r.productQuery.trim().slice(0, 100) : null;
    return { intent, period, metric, productQuery, lang: fallback.lang, via: 'AI' };
  } catch (err) {
    if (!(err instanceof AiError)) throw err;
    return fallback;
  }
}

const P = { en: { '7d': 'the last 7 days', '30d': 'the last 30 days', '90d': 'the last 90 days' }, bn: { '7d': 'গত ৭ দিনে', '30d': 'গত ৩০ দিনে', '90d': 'গত ৯০ দিনে' } };

/** Run the fixed query for the interpreted intent and write the answer (numbers from the database only). */
export function answer(db: Db, sellerId: string, now: Date, i: Interpretation): { text: string; data: unknown } {
  const L = i.lang;
  const n = (x: number) => (L === 'bn' ? bn(x) : String(x));
  switch (i.intent) {
    case 'top_products': {
      const top = topProducts(db, sellerId, now, i.period, i.metric, 5);
      if (!top.length) return { text: L === 'bn' ? `${P.bn[i.period]} কোনো বিক্রি হয়নি।` : `No sales in ${P.en[i.period]}.`, data: top };
      const list = top.map((t, k) => `${n(k + 1)}. ${t.name} — ${i.metric === 'revenue' ? (L === 'bn' ? `৳${bn(t.revenue)}` : `Tk ${t.revenue}`) : `${n(t.units)} ${L === 'bn' ? 'টি' : 'units'}`}`).join('\n');
      return { text: L === 'bn' ? `${P.bn[i.period]} সবচেয়ে বেশি বিক্রি হয়েছে:\n${list}` : `Best sellers in ${P.en[i.period]}:\n${list}`, data: top };
    }
    case 'slow_movers': {
      const slow = slowMovers(productStats(db, sellerId, now), now, 14);
      if (!slow.length) return { text: L === 'bn' ? 'গত ১৪ দিনে স্টকে থাকা সব পণ্যই অন্তত একবার বিক্রি হয়েছে।' : 'Every product in stock sold at least once in the last 14 days.', data: [] };
      const list = slow.map((s) => `• ${s.name} (${n(s.stock)} ${L === 'bn' ? 'টি স্টকে' : 'in stock'})`).join('\n');
      return { text: L === 'bn' ? `গত ১৪ দিনে বিক্রি হয়নি:\n${list}` : `No sales in the last 14 days:\n${list}`, data: slow };
    }
    case 'stock_status': {
      let stats = productStats(db, sellerId, now).filter((s) => s.status === 'PUBLISHED');
      if (i.productQuery) {
        const q = i.productQuery.toLowerCase();
        const match = stats.filter((s) => s.name.toLowerCase().includes(q) || q.includes(s.name.toLowerCase()));
        if (match.length) stats = match;
      }
      stats.sort((a, b) => (a.daysOfCover ?? Infinity) - (b.daysOfCover ?? Infinity) || a.stock - b.stock);
      const list = stats.slice(0, 8).map((s) => {
        const cover = s.daysOfCover === null
          ? (L === 'bn' ? 'সম্প্রতি বিক্রি হয়নি' : 'not selling recently')
          : (L === 'bn' ? `প্রায় ${bn(Math.round(s.daysOfCover))} দিনে শেষ হবে` : `runs out in about ${Math.round(s.daysOfCover)} days`);
        return `• ${s.name}: ${n(s.stock)} ${L === 'bn' ? 'টি' : 'left'} — ${cover}`;
      }).join('\n');
      return { text: (L === 'bn' ? 'স্টকের অবস্থা:\n' : 'Stock status:\n') + (list || (L === 'bn' ? 'কোনো প্রকাশিত পণ্য নেই।' : 'No published products.')), data: stats };
    }
    case 'expiring': {
      const exp = productStats(db, sellerId, now).filter((s) => s.daysToExpiry !== null && s.daysToExpiry <= 60 && s.stock > 0)
        .sort((a, b) => (a.daysToExpiry! - b.daysToExpiry!));
      if (!exp.length) return { text: L === 'bn' ? '৬০ দিনের মধ্যে কোনো পণ্যের মেয়াদ শেষ হচ্ছে না।' : 'Nothing in stock expires within 60 days.', data: [] };
      const list = exp.map((s) => s.daysToExpiry! < 0
        ? `• ${s.name}: ${L === 'bn' ? `মেয়াদ শেষ (${bn(s.expiryDate!)}) — বিক্রি বন্ধ করুন` : `EXPIRED (${s.expiryDate}) — remove from sale`}`
        : `• ${s.name}: ${L === 'bn' ? `${bn(s.daysToExpiry!)} দিনে মেয়াদ শেষ, ${bn(s.stock)} টি স্টকে` : `expires in ${s.daysToExpiry} days, ${s.stock} in stock`}`).join('\n');
      return { text: (L === 'bn' ? 'মেয়াদ সংক্রান্ত:\n' : 'Expiry:\n') + list, data: exp };
    }
    case 'sales_summary': {
      const series = dailySeries(db, sellerId, now, periodDays(i.period));
      const units = series.reduce((a, d) => a + d.units, 0);
      const revenue = Math.round(series.reduce((a, d) => a + d.revenue, 0) * 100) / 100;
      return {
        text: L === 'bn' ? `${P.bn[i.period]} ${bn(units)} টি পণ্য বিক্রি হয়েছে, মোট ৳${bn(revenue)}।` : `In ${P.en[i.period]} you sold ${units} units for Tk ${revenue}.`,
        data: { units, revenue },
      };
    }
    default:
      return {
        text: L === 'bn'
          ? 'দুঃখিত, আমি শুধু বিক্রি, সবচেয়ে বেশি বিক্রি হওয়া পণ্য, স্টক, মেয়াদ এবং যেসব পণ্য বিক্রি হচ্ছে না — এসব প্রশ্নের উত্তর দিতে পারি।'
          : 'Sorry, I can answer questions about sales, best sellers, stock, expiry and products that are not selling.',
        data: null,
      };
  }
}
