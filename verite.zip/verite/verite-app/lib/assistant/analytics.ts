import type { Db } from '../trace/types';

// Sales analytics for one seller, computed from the existing orders / order_items / products
// tables with plain SQL and arithmetic. These are the FACTS; the AI only phrases them.
//
// Definitions (documented so they can be defended):
//   sales            order_items of non-cancelled orders, attributed to the product's seller
//   daily velocity   units sold in the window / window length in days. The window is 28 days, or the
//                    product's age if younger (minimum 7 days, so a new product isn't over-estimated)
//   days of cover    stock / daily velocity  (infinite when nothing sells)
//   stock-out date   now + days of cover
//   expiry risk      units still unsold on the expiry date if the current velocity continues
//                    = max(0, stock - velocity x days to expiry)
// Times: orders.created_at is UTC ('YYYY-MM-DD HH:MM:SS'); calendar days are Asia/Dhaka (UTC+6).

export const VELOCITY_WINDOW_DAYS = 28;
const DAY_MS = 86_400_000;
const DHAKA_OFFSET_MS = 6 * 3_600_000;

export function sqlTime(d: Date): string {
  return d.toISOString().slice(0, 19).replace('T', ' ');
}
export function dhakaDate(d: Date): string {
  return new Date(d.getTime() + DHAKA_OFFSET_MS).toISOString().slice(0, 10);
}
function daysBetween(fromIsoDate: string, toIsoDate: string): number {
  return Math.round((Date.parse(`${toIsoDate}T00:00:00Z`) - Date.parse(`${fromIsoDate}T00:00:00Z`)) / DAY_MS);
}

export interface ProductStat {
  id: string;
  name: string;
  status: string;
  stock: number;
  price: number;
  expiryDate: string | null;
  units7: number;
  units28: number;
  revenue28: number;
  windowDays: number;
  dailyVelocity: number;
  daysOfCover: number | null; // null = not selling (infinite cover)
  stockoutDate: string | null;
  daysToExpiry: number | null;
  projectedUnsoldAtExpiry: number | null;
  lastSaleAt: string | null;
}

interface SalesRow { product_id: string; units: number; revenue: number; orders: number; last_sale: string | null }

function salesByProduct(db: Db, sellerId: string, from: Date, to: Date): Map<string, SalesRow> {
  const rows = db.prepare(
    `SELECT oi.product_id, SUM(oi.quantity) AS units, SUM(oi.quantity * oi.price) AS revenue, COUNT(DISTINCT o.id) AS orders,
            MAX(o.created_at) AS last_sale
     FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN products p ON p.id = oi.product_id
     WHERE p.seller_id = ? AND o.status <> 'CANCELLED' AND o.created_at >= ? AND o.created_at < ?
     GROUP BY oi.product_id`
  ).all(sellerId, sqlTime(from), sqlTime(to)) as SalesRow[];
  return new Map(rows.map((r) => [r.product_id, { ...r, units: Number(r.units), revenue: Number(r.revenue), orders: Number(r.orders) }]));
}

export function productStats(db: Db, sellerId: string, now: Date): ProductStat[] {
  const products = db.prepare(
    `SELECT id, name, status, stock, price, expiry_date, created_at FROM products WHERE seller_id = ? ORDER BY name`
  ).all(sellerId) as { id: string; name: string; status: string; stock: number; price: number; expiry_date: string | null; created_at: string }[];
  const s7 = salesByProduct(db, sellerId, new Date(now.getTime() - 7 * DAY_MS), now);
  const s28 = salesByProduct(db, sellerId, new Date(now.getTime() - VELOCITY_WINDOW_DAYS * DAY_MS), now);
  const lastSale = db.prepare(
    `SELECT oi.product_id, MAX(o.created_at) AS last_sale FROM order_items oi JOIN orders o ON o.id = oi.order_id
     JOIN products p ON p.id = oi.product_id WHERE p.seller_id = ? AND o.status <> 'CANCELLED' GROUP BY oi.product_id`
  ).all(sellerId) as { product_id: string; last_sale: string }[];
  const lastMap = new Map(lastSale.map((r) => [r.product_id, r.last_sale]));
  const today = dhakaDate(now);

  return products.map((p) => {
    const ageDays = Math.max(0, (now.getTime() - Date.parse(p.created_at.replace(' ', 'T') + 'Z')) / DAY_MS);
    const windowDays = Math.min(VELOCITY_WINDOW_DAYS, Math.max(7, Math.floor(ageDays)));
    const units28 = s28.get(p.id)?.units ?? 0;
    // Units sold inside the product's own window (7..28 days), divided by that window.
    const windowUnits = windowDays === VELOCITY_WINDOW_DAYS ? units28 : windowDays === 7 ? (s7.get(p.id)?.units ?? 0)
      : (salesByProduct(db, sellerId, new Date(now.getTime() - windowDays * DAY_MS), now).get(p.id)?.units ?? 0);
    const dailyVelocity = Math.round((windowUnits / windowDays) * 100) / 100;
    const daysOfCover = dailyVelocity > 0 ? Math.round((p.stock / dailyVelocity) * 10) / 10 : null;
    const daysToExpiry = p.expiry_date ? daysBetween(today, p.expiry_date) : null;
    return {
      id: p.id, name: p.name, status: p.status, stock: p.stock, price: p.price, expiryDate: p.expiry_date,
      units7: s7.get(p.id)?.units ?? 0,
      units28,
      revenue28: Math.round((s28.get(p.id)?.revenue ?? 0) * 100) / 100,
      windowDays,
      dailyVelocity,
      daysOfCover,
      stockoutDate: daysOfCover !== null ? dhakaDate(new Date(now.getTime() + daysOfCover * DAY_MS)) : null,
      daysToExpiry,
      projectedUnsoldAtExpiry: daysToExpiry === null ? null : Math.max(0, Math.round(p.stock - dailyVelocity * Math.max(0, daysToExpiry))),
      lastSaleAt: lastMap.get(p.id) ?? null,
    };
  });
}

export interface PeriodTotals { units: number; revenue: number; orders: number }

function totals(db: Db, sellerId: string, from: Date, to: Date): PeriodTotals {
  const r = db.prepare(
    `SELECT COALESCE(SUM(oi.quantity),0) AS units, COALESCE(SUM(oi.quantity*oi.price),0) AS revenue, COUNT(DISTINCT o.id) AS orders
     FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN products p ON p.id = oi.product_id
     WHERE p.seller_id = ? AND o.status <> 'CANCELLED' AND o.created_at >= ? AND o.created_at < ?`
  ).get(sellerId, sqlTime(from), sqlTime(to)) as { units: number; revenue: number; orders: number };
  return { units: Number(r.units), revenue: Math.round(Number(r.revenue) * 100) / 100, orders: Number(r.orders) };
}

export function periodDays(period: string): number {
  return period === '7d' ? 7 : period === '90d' ? 90 : 30;
}

export function topProducts(db: Db, sellerId: string, now: Date, period = '30d', metric: 'units' | 'revenue' = 'units', limit = 5) {
  const rows = salesByProduct(db, sellerId, new Date(now.getTime() - periodDays(period) * DAY_MS), now);
  const names = new Map((db.prepare('SELECT id, name FROM products WHERE seller_id = ?').all(sellerId) as { id: string; name: string }[]).map((r) => [r.id, r.name]));
  return [...rows.values()]
    .map((r) => ({ id: r.product_id, name: names.get(r.product_id) ?? r.product_id, units: r.units, revenue: Math.round(r.revenue * 100) / 100, orders: r.orders }))
    .sort((a, b) => (metric === 'revenue' ? b.revenue - a.revenue : b.units - a.units) || a.name.localeCompare(b.name))
    .slice(0, limit);
}

/** Products in stock that sold nothing in the last `days` days (and are at least that old). */
export function slowMovers(stats: ProductStat[], now: Date, days = 14) {
  const cutoff = sqlTime(new Date(now.getTime() - days * DAY_MS));
  return stats.filter((s) => s.status === 'PUBLISHED' && s.stock > 0 && (!s.lastSaleAt || s.lastSaleAt < cutoff));
}

export function dailySeries(db: Db, sellerId: string, now: Date, days = 28) {
  const from = new Date(now.getTime() - days * DAY_MS);
  const rows = db.prepare(
    `SELECT date(o.created_at, '+6 hours') AS day, SUM(oi.quantity) AS units, SUM(oi.quantity*oi.price) AS revenue
     FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN products p ON p.id = oi.product_id
     WHERE p.seller_id = ? AND o.status <> 'CANCELLED' AND o.created_at >= ? AND o.created_at < ?
     GROUP BY day ORDER BY day`
  ).all(sellerId, sqlTime(from), sqlTime(now)) as { day: string; units: number; revenue: number }[];
  const map = new Map(rows.map((r) => [r.day, r]));
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const day = dhakaDate(new Date(now.getTime() - i * DAY_MS));
    const r = map.get(day);
    out.push({ day, units: r ? Number(r.units) : 0, revenue: r ? Math.round(Number(r.revenue) * 100) / 100 : 0 });
  }
  return out;
}

export function simulatedOrderCount(db: Db, sellerId: string): number {
  const r = db.prepare(
    `SELECT COUNT(DISTINCT o.id) AS c FROM orders o JOIN order_items oi ON oi.order_id = o.id JOIN products p ON p.id = oi.product_id
     WHERE p.seller_id = ? AND o.order_number LIKE 'SIM-%'`
  ).get(sellerId) as { c: number };
  return Number(r.c);
}

/** The facts behind the weekly summary: every number the AI may use comes from here. */
export function weeklyFacts(db: Db, sellerId: string, now: Date) {
  const thisWeek = totals(db, sellerId, new Date(now.getTime() - 7 * DAY_MS), now);
  const lastWeek = totals(db, sellerId, new Date(now.getTime() - 14 * DAY_MS), new Date(now.getTime() - 7 * DAY_MS));
  const stats = productStats(db, sellerId, now);
  const changePct = lastWeek.revenue > 0 ? Math.round(((thisWeek.revenue - lastWeek.revenue) / lastWeek.revenue) * 100) : null;
  return {
    periodEnd: dhakaDate(now),
    currency: 'BDT',
    thisWeek,
    lastWeek,
    revenueChangePercent: changePct,
    topProducts: topProducts(db, sellerId, now, '7d', 'units', 3).map((t) => ({ name: t.name, units: t.units, revenue: t.revenue })),
    stockingOutWithin7Days: stats.filter((s) => s.daysOfCover !== null && s.daysOfCover <= 7 && s.stock > 0).map((s) => ({ name: s.name, stock: s.stock, daysOfCover: s.daysOfCover })),
    outOfStock: stats.filter((s) => s.status === 'PUBLISHED' && s.stock === 0).map((s) => ({ name: s.name })),
    expiredStillListed: stats.filter((s) => s.status === 'PUBLISHED' && s.daysToExpiry !== null && s.daysToExpiry < 0).map((s) => ({ name: s.name, expiryDate: s.expiryDate })),
    expiringWithin30Days: stats.filter((s) => s.daysToExpiry !== null && s.daysToExpiry >= 0 && s.daysToExpiry <= 30).map((s) => ({ name: s.name, daysToExpiry: s.daysToExpiry, stock: s.stock })),
    slowMovers14Days: slowMovers(stats, now).map((s) => ({ name: s.name, stock: s.stock })),
    simulatedOrdersIncluded: simulatedOrderCount(db, sellerId),
  };
}
export type WeeklyFacts = ReturnType<typeof weeklyFacts>;
