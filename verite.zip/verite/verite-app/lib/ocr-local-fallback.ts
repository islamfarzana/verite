import { createWorker } from 'tesseract.js';
import sharp from 'sharp';
import { extractFieldsFromOcrText } from '@/lib/ocr-extract';

// OCR Microservice Integration — this is now ONLY a development fallback,
// used when OCR_SERVICE_URL isn't reachable and OCR_LOCAL_FALLBACK=true.
// The production OCR engine is the standalone FastAPI/OpenCV/PaddleOCR
// microservice (see /ocr-service) proxied from app/api/ocr/extract/route.ts.
// This file is what that route used to do directly, kept only so local
// development still works end-to-end without running the Docker stack.

export interface LocalOcrResult {
  success: boolean;
  message?: string;
  fields?: ReturnType<typeof extractFieldsFromOcrText>;
  confidence?: number;
  rawText?: string;
}

const ERROR_MESSAGE =
  'Unable to extract information from the uploaded label. Please upload a clearer image or enter the information manually.';

export async function runLocalOcrFallback(file: File): Promise<LocalOcrResult> {
  try {
    const rawBuffer = Buffer.from(await file.arrayBuffer());

    const preprocessed = await sharp(rawBuffer)
      .resize({ width: 2000, withoutEnlargement: false })
      .grayscale()
      .normalize()
      .sharpen()
      .toBuffer();

    const worker = await createWorker('eng');
    let text = '';
    let confidence: number | undefined;
    try {
      const { data } = await worker.recognize(preprocessed);
      text = data.text || '';
      confidence = typeof data.confidence === 'number' ? Math.round(data.confidence * 10) / 10 : undefined;
    } finally {
      await worker.terminate();
    }

    if (!text.trim()) {
      return { success: false, message: ERROR_MESSAGE };
    }

    const fields = extractFieldsFromOcrText(text);
    return { success: true, fields, confidence, rawText: text.trim() };
  } catch {
    return { success: false, message: ERROR_MESSAGE };
  }
}
