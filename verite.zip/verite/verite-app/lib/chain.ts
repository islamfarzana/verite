import { Contract, JsonRpcProvider, Wallet } from 'ethers';

// Real blockchain access for the ProductRegistry smart contract
// (blockchain/contracts/ProductRegistry.sol).
//
// Behaviour is controlled by environment variables so the project still runs
// offline for development:
//   CHAIN_RPC_URL      JSON-RPC endpoint (Polygon Amoy or a local Hardhat node)
//   REGISTRY_ADDRESS   address printed by `npm run deploy:amoy`
//   CHAIN_PRIVATE_KEY  platform wallet used to register hashes (0x-prefixed)
//   CHAIN_NETWORK_NAME label stored in blockchain_records.network
//   CHAIN_EXPLORER_BASE block explorer root, e.g. https://amoy.polygonscan.com
// When these are not set, lib/blockchain.ts keeps using the simulated ledger.

const ABI = [
  'function registerProductHash(string productId, bytes32 hash)',
  'function getRecord(string productId) view returns (bytes32 hash, address registrar, uint64 timestamp, bool exists)',
];

export function chainReadConfigured(): boolean {
  return !!(process.env.CHAIN_RPC_URL && process.env.REGISTRY_ADDRESS);
}

export function chainWriteConfigured(): boolean {
  return chainReadConfigured() && !!process.env.CHAIN_PRIVATE_KEY;
}

export function chainNetworkName(): string {
  return process.env.CHAIN_NETWORK_NAME || 'polygon-amoy';
}

export function isRealNetwork(network: string | null | undefined): boolean {
  return !!network && !network.includes('simulated');
}

export function explorerTxUrl(txHash: string | null | undefined): string | null {
  const base = process.env.CHAIN_EXPLORER_BASE;
  if (!base || !txHash) return null;
  return `${base.replace(/\/$/, '')}/tx/${txHash}`;
}

function provider() {
  return new JsonRpcProvider(process.env.CHAIN_RPC_URL!);
}

/** Send the product fingerprint to the smart contract and wait for 1 confirmation. */
export async function registerOnChain(productId: string, hash: string) {
  const wallet = new Wallet(process.env.CHAIN_PRIVATE_KEY!, provider());
  const contract = new Contract(process.env.REGISTRY_ADDRESS!, ABI, wallet);
  const tx = await contract.registerProductHash(productId, hash);
  const receipt = await tx.wait(1);
  return { txHash: tx.hash as string, blockNumber: Number(receipt.blockNumber) };
}

/** Read the stored fingerprint straight from the contract (a free, read-only call). */
export async function readFromChain(productId: string) {
  const contract = new Contract(process.env.REGISTRY_ADDRESS!, ABI, provider());
  const [hash, registrar, timestamp, exists] = await contract.getRecord(productId);
  if (!exists) return null;
  return { hash: String(hash).toLowerCase(), registrar: String(registrar), timestamp: Number(timestamp) };
}
