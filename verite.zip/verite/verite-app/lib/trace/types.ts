// Minimal database interface shared by better-sqlite3 (the app) and node:sqlite (the tests).
export interface Statement {
  get(...params: any[]): any;
  all(...params: any[]): any[];
  run(...params: any[]): { changes: number | bigint; lastInsertRowid: number | bigint };
}
export interface Db {
  prepare(sql: string): Statement;
  exec(sql: string): unknown;
}
export type Scope = 'UNIT' | 'BATCH';
