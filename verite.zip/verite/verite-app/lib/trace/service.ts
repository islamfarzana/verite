import { newId } from '../ids';
import type { ScanConfig } from './config';
import { generateToken, isValidToken, type RandomBytesFn } from './token';
import { sourceHash } from './source';
import type { Db, Scope } from './types';

export const MAX_UNITS_PER_REQUEST = 200;
export const MAX_UNITS_PER_PRODUCT = 5000;
export const MAX_TOKEN_RETRIES = 5;
const REQUEST_ID_RE = /^[A-Za-z0-9-]{8,64}$/;

export type TraceErrorCode = 'NOT_FOUND' | 'FORBIDDEN' | 'INVALID' | 'NOT_ELIGIBLE' | 'COLLISION_EXHAUSTED';
export class TraceError extends Error {
  constructor(public code: TraceErrorCode, message: string) {
    super(message);
    this.name = 'TraceError';
  }
}

export interface Actor { id: string; role: 'SELLER' | 'ADMIN' | 'BUYER'; }
export interface IdentifierView {
  id: string; token: string; scope: Scope; unitSerial: number | null; batchNumber: string | null;
  status: 'ACTIVE' | 'REVOKED'; createdAt: string; revokedAt: string | null; scanCount?: number; lastScanAt?: string | null; warningCount?: number;
}

const toView = (r: any): IdentifierView => ({
  id: r.id, token: r.token, scope: r.scope, unitSerial: r.unit_serial ?? null, batchNumber: r.batch_number ?? null,
  status: r.status, createdAt: r.created_at, revokedAt: r.revoked_at ?? null,
  ...(r.scan_count !== undefined ? { scanCount: Number(r.scan_count), lastScanAt: r.last_scan_at ?? null, warningCount: Number(r.warning_count ?? 0) } : {}),
});

function inTransaction<T>(db: Db, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch { /* already rolled back */ }
    throw err;
  }
}

const isTokenCollision = (err: unknown) => /UNIQUE constraint failed: trace_identifiers\.token/.test(String((err as any)?.message));

function loadOwnedProduct(db: Db, productId: string, actor: Actor) {
  const product = db.prepare('SELECT id, seller_id, status, batch_number FROM products WHERE id = ?').get(productId);
  if (!product) throw new TraceError('NOT_FOUND', 'Product not found.');
  if (actor.role !== 'ADMIN' && (actor.role !== 'SELLER' || product.seller_id !== actor.id)) {
    throw new TraceError('FORBIDDEN', 'You are not allowed to manage identifiers for this product.');
  }
  return product;
}

export interface IssueInput { productId: string; scope: Scope; quantity?: number; requestId: string; actor: Actor; }

/**
 * Issue server-generated identifiers. BATCH: one code for the product's batch (a product row in
 * this application is one batch, see audit.md). UNIT: `quantity` codes with serials 1..N.
 * Idempotent per (product, requestId): a retry returns the same identifiers.
 */
export function issueIdentifiers(db: Db, input: IssueInput, opts: { now?: Date; randomBytesFn?: RandomBytesFn } = {}) {
  if (!REQUEST_ID_RE.test(input.requestId || '')) throw new TraceError('INVALID', 'requestId must be 8-64 letters, digits or hyphens.');
  if (input.scope !== 'UNIT' && input.scope !== 'BATCH') throw new TraceError('INVALID', 'scope must be UNIT or BATCH.');
  const quantity = input.scope === 'BATCH' ? 1 : input.quantity ?? 1;
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > MAX_UNITS_PER_REQUEST) {
    throw new TraceError('INVALID', `quantity must be a whole number between 1 and ${MAX_UNITS_PER_REQUEST}.`);
  }
  const product = loadOwnedProduct(db, input.productId, input.actor);
  if (product.status !== 'PUBLISHED') throw new TraceError('NOT_ELIGIBLE', 'Publish the product before issuing identifiers.');
  const createdAt = (opts.now ?? new Date()).toISOString();

  return inTransaction(db, () => {
    const sameRequest = db.prepare('SELECT * FROM trace_identifiers WHERE product_id = ? AND issue_group = ? ORDER BY unit_serial').all(product.id, input.requestId);
    if (sameRequest.length) return { created: false, identifiers: sameRequest.map(toView) };

    if (input.scope === 'BATCH') {
      const existing = db.prepare("SELECT * FROM trace_identifiers WHERE product_id = ? AND scope = 'BATCH'").get(product.id);
      if (existing) return { created: false, identifiers: [toView(existing)] };
    } else {
      const total = db.prepare("SELECT COUNT(*) AS n FROM trace_identifiers WHERE product_id = ? AND scope = 'UNIT'").get(product.id).n;
      if (Number(total) + quantity > MAX_UNITS_PER_PRODUCT) throw new TraceError('INVALID', `A product can have at most ${MAX_UNITS_PER_PRODUCT} unit identifiers.`);
    }

    let nextSerial = 1;
    if (input.scope === 'UNIT') {
      nextSerial = Number(db.prepare("SELECT COALESCE(MAX(unit_serial), 0) AS m FROM trace_identifiers WHERE product_id = ? AND scope = 'UNIT'").get(product.id).m) + 1;
    }
    const insert = db.prepare(
      `INSERT INTO trace_identifiers (id, token, scope, product_id, batch_number, unit_serial, issue_group, status, schema_version, issued_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'ACTIVE', 1, ?, ?)`
    );
    const created: IdentifierView[] = [];
    for (let i = 0; i < quantity; i++) {
      const serial = input.scope === 'UNIT' ? nextSerial + i : null;
      let inserted = false;
      for (let attempt = 0; attempt < MAX_TOKEN_RETRIES && !inserted; attempt++) {
        const id = newId('tid');
        const token = generateToken(opts.randomBytesFn);
        try {
          insert.run(id, token, input.scope, product.id, product.batch_number ?? null, serial, input.requestId, input.actor.id, createdAt);
          created.push({ id, token, scope: input.scope, unitSerial: serial, batchNumber: product.batch_number ?? null, status: 'ACTIVE', createdAt, revokedAt: null });
          inserted = true;
        } catch (err) {
          if (!isTokenCollision(err)) throw err;
        }
      }
      if (!inserted) throw new TraceError('COLLISION_EXHAUSTED', 'Could not generate a unique identifier. Nothing was issued; please retry.');
    }
    return { created: true, identifiers: created };
  });
}

export function revokeIdentifier(db: Db, input: { identifierId: string; reason: string; actor: Actor }, now: Date = new Date()) {
  const reason = (input.reason || '').trim();
  if (reason.length < 3 || reason.length > 200) throw new TraceError('INVALID', 'A revocation reason of 3-200 characters is required.');
  const row = db.prepare('SELECT id, product_id, status FROM trace_identifiers WHERE id = ?').get(input.identifierId);
  if (!row) throw new TraceError('NOT_FOUND', 'Identifier not found.');
  loadOwnedProduct(db, row.product_id, input.actor);
  if (row.status === 'REVOKED') return { changed: false };
  db.prepare("UPDATE trace_identifiers SET status = 'REVOKED', revoked_at = ?, revoked_reason = ?, revoked_by = ? WHERE id = ? AND status = 'ACTIVE'")
    .run(now.toISOString(), reason, input.actor.id, row.id);
  return { changed: true };
}

export function listIdentifiers(db: Db, productId: string, actor: Actor): IdentifierView[] {
  loadOwnedProduct(db, productId, actor);
  const rows = db.prepare(
    `SELECT ti.*,
       (SELECT COUNT(*) FROM scan_events se WHERE se.identifier_id = ti.id AND se.outcome IN ('VALID','SUSPICIOUS')) AS scan_count,
       (SELECT MAX(created_at) FROM scan_events se WHERE se.identifier_id = ti.id) AS last_scan_at,
       (SELECT COUNT(*) FROM scan_events se WHERE se.identifier_id = ti.id AND se.outcome = 'SUSPICIOUS') AS warning_count
     FROM trace_identifiers ti WHERE ti.product_id = ? ORDER BY ti.scope, ti.unit_serial`
  ).all(productId);
  return rows.map(toView);
}

export function pruneScanEvents(db: Db, now: Date, retentionDays: number): number {
  const cutoff = new Date(now.getTime() - retentionDays * 86_400_000).toISOString();
  return Number(db.prepare('DELETE FROM scan_events WHERE created_at < ?').run(cutoff).changes);
}

/* ---------------------------- scanning ---------------------------- */

export type ScanStatus = 'VALID' | 'SUSPICIOUS_ACTIVITY' | 'REVOKED' | 'UNKNOWN_IDENTIFIER';
export interface ScanResult {
  status: ScanStatus; scope?: Scope; warning: boolean; message: string; guidance?: string;
  product?: { name: string; brand: string | null; batchNumber: string | null; manufacturingDate: string | null; expiryDate: string | null; productPath: string };
}

export const MESSAGES = {
  validUnit: 'Registered code found. This identifier is registered and active for this product. This is a registration and status check only: it does not prove that this physical item is genuine.',
  validBatch: 'Registered code found. This identifier is registered and active, and it identifies a production batch, not an individual physical item. This is a registration and status check only: it does not prove that this item is genuine.',
  suspicious: 'Possible cloned code / unusual scan activity. This identifier has been scanned repeatedly within a short period. Repeated scans can also be legitimate; this warning does not prove counterfeiting.',
  suspiciousBatchExtra: ' This code identifies a batch, not an individual physical unit. Repeated scans may be normal for a shared batch label.',
  suspiciousGuidance: 'Compare the pack with the product page, check the seller and batch details, and contact the seller or manufacturer if you are unsure.',
  revoked: 'This identifier has been revoked by the issuer and should not be relied on. Contact the seller or manufacturer.',
  unknown: 'This code was not recognised. Check that you scanned the complete code from the product label.',
};

/** The clone-warning rule. `count` and `distinct` already include the scan being evaluated. */
export function evaluateScanPattern(scope: Scope, count: number, distinct: number, cfg: ScanConfig) {
  const threshold = scope === 'UNIT' ? cfg.thresholdUnit : cfg.thresholdBatch;
  const suspicious = count >= threshold && distinct >= cfg.distinctSourceThreshold;
  return { suspicious, reason: `scans=${count}/${threshold} in ${cfg.windowMinutes}m, distinctSources=${distinct}/${cfg.distinctSourceThreshold}` };
}

const unknownResult = (): ScanResult => ({ status: 'UNKNOWN_IDENTIFIER', warning: false, message: MESSAGES.unknown });

function recordEvent(db: Db, identifierId: string | null, outcome: string, source: string, reason: string, createdAt: string) {
  db.prepare('INSERT INTO scan_events (id, identifier_id, outcome, source_hash, reason, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(newId('scan'), identifierId, outcome, source, reason, createdAt);
}

export function processScan(db: Db, input: { token: unknown; sourceHash: string | null; now?: Date }, cfg: ScanConfig): ScanResult {
  // Malformed input never reaches the database.
  if (!isValidToken(input.token)) return unknownResult();
  const now = input.now ?? new Date();
  const createdAt = now.toISOString();
  const source = input.sourceHash || 'unknown';

  const row = db.prepare(
    `SELECT ti.id, ti.scope, ti.status, ti.batch_number, p.id AS product_id, p.name, p.brand, p.status AS product_status,
            p.manufacturing_date, p.expiry_date
     FROM trace_identifiers ti JOIN products p ON p.id = ti.product_id WHERE ti.token = ?`
  ).get(input.token);

  if (!row) {
    recordEvent(db, null, 'UNKNOWN', source, 'unknown_token', createdAt);
    return unknownResult();
  }
  if (row.status === 'REVOKED') {
    recordEvent(db, row.id, 'REVOKED', source, 'identifier_revoked', createdAt);
    return { status: 'REVOKED', scope: row.scope, warning: false, message: MESSAGES.revoked };
  }
  if (row.product_status !== 'PUBLISHED') {
    recordEvent(db, row.id, 'UNKNOWN', source, 'product_not_published', createdAt);
    return unknownResult();
  }

  const windowStart = new Date(now.getTime() - cfg.windowMinutes * 60_000).toISOString();
  const decision = inTransaction(db, () => {
    const prior = db.prepare(
      "SELECT COUNT(*) AS n, COUNT(DISTINCT source_hash) AS d FROM scan_events WHERE identifier_id = ? AND created_at >= ? AND outcome IN ('VALID','SUSPICIOUS')"
    ).get(row.id, windowStart);
    const seen = db.prepare(
      "SELECT 1 AS x FROM scan_events WHERE identifier_id = ? AND created_at >= ? AND outcome IN ('VALID','SUSPICIOUS') AND source_hash = ? LIMIT 1"
    ).get(row.id, windowStart, source);
    const count = Number(prior.n) + 1;
    const distinct = Number(prior.d) + (seen ? 0 : 1);
    const verdict = evaluateScanPattern(row.scope, count, distinct, cfg);
    recordEvent(db, row.id, verdict.suspicious ? 'SUSPICIOUS' : 'VALID', source, verdict.reason, createdAt);
    return verdict;
  });

  const product = {
    name: row.name, brand: row.brand ?? null, batchNumber: row.batch_number ?? null,
    manufacturingDate: row.manufacturing_date ?? null, expiryDate: row.expiry_date ?? null, productPath: `/product/${row.product_id}`,
  };
  if (decision.suspicious) {
    return {
      status: 'SUSPICIOUS_ACTIVITY', scope: row.scope, warning: true,
      message: MESSAGES.suspicious + (row.scope === 'BATCH' ? MESSAGES.suspiciousBatchExtra : ''),
      guidance: MESSAGES.suspiciousGuidance, product,
    };
  }
  return { status: 'VALID', scope: row.scope, warning: false, message: row.scope === 'UNIT' ? MESSAGES.validUnit : MESSAGES.validBatch, product };
}

/* ------------------- request handler (used by the API route) ------------------- */

export interface ScanHandlerDeps {
  db: Db; config: ScanConfig; secret: string; limiter: { allow(key: string, nowMs?: number): boolean }; now?: Date;
}
export function handleScanRequest(deps: ScanHandlerDeps, req: { rawBody: string; ip: string | null }) {
  const now = deps.now ?? new Date();
  if (req.rawBody.length > 2048) return { status: 413, body: { success: false, data: { status: 'ERROR', message: 'Request too large.' } } };
  const source = sourceHash(req.ip, deps.secret);
  if (!deps.limiter.allow(source, now.getTime())) {
    return { status: 429, body: { success: false, data: { status: 'RATE_LIMITED', message: 'Too many scans from this network. Please wait a minute and try again.' } } };
  }
  let token: unknown;
  try { token = JSON.parse(req.rawBody)?.token; } catch { token = undefined; }
  try {
    return { status: 200, body: { success: true, data: processScan(deps.db, { token, sourceHash: source, now }, deps.config) } };
  } catch {
    // Never report an infrastructure problem as a verdict about the product, and never log the token.
    return { status: 503, body: { success: false, data: { status: 'UNAVAILABLE', message: 'The code could not be checked right now. This says nothing about the product. Please try again later.' } } };
  }
}
