// Schema for batch/unit traceability identifiers and scan events.
// Applied by lib/db.ts at start-up (CREATE ... IF NOT EXISTS, so existing data is untouched)
// and by the automated tests, so both use exactly the same definitions.
//
// Rollback (not automatic, destructive for these two tables only):
//   DROP TABLE scan_events; DROP TABLE trace_identifiers;
export const TRACE_SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS trace_identifiers (
  id TEXT PRIMARY KEY,
  token TEXT NOT NULL UNIQUE,
  scope TEXT NOT NULL CHECK (scope IN ('UNIT','BATCH')),
  product_id TEXT NOT NULL REFERENCES products(id),
  batch_number TEXT,
  unit_serial INTEGER,
  issue_group TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','REVOKED')),
  schema_version INTEGER NOT NULL DEFAULT 1,
  issued_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  revoked_at TEXT,
  revoked_reason TEXT,
  revoked_by TEXT REFERENCES users(id),
  CHECK ((scope = 'UNIT' AND unit_serial IS NOT NULL) OR (scope = 'BATCH' AND unit_serial IS NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_trace_one_batch_per_product ON trace_identifiers(product_id) WHERE scope = 'BATCH';
CREATE UNIQUE INDEX IF NOT EXISTS idx_trace_unit_serial ON trace_identifiers(product_id, unit_serial) WHERE scope = 'UNIT';
CREATE INDEX IF NOT EXISTS idx_trace_product ON trace_identifiers(product_id);
CREATE INDEX IF NOT EXISTS idx_trace_issue_group ON trace_identifiers(product_id, issue_group);

-- An identifier is bound to one product/scope/serial for life and a revoked identifier can never be reactivated.
CREATE TRIGGER IF NOT EXISTS trg_trace_immutable_binding
BEFORE UPDATE OF token, scope, product_id, unit_serial ON trace_identifiers
BEGIN SELECT RAISE(ABORT, 'identifier binding is immutable'); END;
CREATE TRIGGER IF NOT EXISTS trg_trace_no_reactivation
BEFORE UPDATE OF status ON trace_identifiers
WHEN OLD.status = 'REVOKED' AND NEW.status <> 'REVOKED'
BEGIN SELECT RAISE(ABORT, 'revoked identifiers cannot be reactivated'); END;

CREATE TABLE IF NOT EXISTS scan_events (
  id TEXT PRIMARY KEY,
  identifier_id TEXT REFERENCES trace_identifiers(id),
  outcome TEXT NOT NULL CHECK (outcome IN ('VALID','SUSPICIOUS','REVOKED','UNKNOWN')),
  source_hash TEXT,
  reason TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_scan_events_identifier_time ON scan_events(identifier_id, created_at);
CREATE INDEX IF NOT EXISTS idx_scan_events_time ON scan_events(created_at);
`;
