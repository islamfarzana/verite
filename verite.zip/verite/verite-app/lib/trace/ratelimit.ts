// Fixed-window in-memory rate limiter.
// LIMITATION: state lives in one Node process. With several server instances, or after a
// restart, the limits are per instance and reset. A shared store (e.g. Redis) is needed
// for a multi-instance deployment.
export class FixedWindowLimiter {
  private hits = new Map<string, { count: number; resetAt: number }>();
  constructor(private limit: number, private windowMs = 60_000, private maxKeys = 10_000) {}

  allow(key: string, nowMs: number = Date.now()): boolean {
    if (this.hits.size > this.maxKeys) {
      for (const [k, v] of this.hits) if (v.resetAt <= nowMs) this.hits.delete(k);
      if (this.hits.size > this.maxKeys) this.hits.clear();
    }
    const entry = this.hits.get(key);
    if (!entry || entry.resetAt <= nowMs) {
      this.hits.set(key, { count: 1, resetAt: nowMs + this.windowMs });
      return true;
    }
    entry.count += 1;
    return entry.count <= this.limit;
  }
}
