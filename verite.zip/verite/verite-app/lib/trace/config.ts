// Configuration for the clone-warning heuristic. Every number here is an INITIAL
// OPERATIONAL HEURISTIC for a demo. None of it is scientifically validated and it
// must be calibrated against real scan data before anyone relies on it.
export interface ScanConfig {
  thresholdUnit: number;            // scans of one UNIT code inside the window that raise the warning
  thresholdBatch: number;           // same for a BATCH code (shared label, so much higher)
  windowMinutes: number;            // rolling window length
  distinctSourceThreshold: number;  // min. distinct privacy-preserving sources inside the window (1 = count only)
  rateLimitPerMinute: number;       // public scan requests per source per minute
  retentionDays: number;            // scan events older than this are pruned
}

export const DEFAULT_SCAN_CONFIG: ScanConfig = {
  thresholdUnit: 3,
  thresholdBatch: 100,
  windowMinutes: 1440,
  distinctSourceThreshold: 1,
  rateLimitPerMinute: 30,
  retentionDays: 90,
};

function intEnv(env: Record<string, string | undefined>, name: string, fallback: number, min: number, max: number): number {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be an integer between ${min} and ${max}`);
  return n;
}

export function loadScanConfig(env: Record<string, string | undefined> = process.env): ScanConfig {
  const cfg: ScanConfig = {
    thresholdUnit: intEnv(env, 'SCAN_WARNING_THRESHOLD_UNIT', DEFAULT_SCAN_CONFIG.thresholdUnit, 2, 10000),
    thresholdBatch: intEnv(env, 'SCAN_WARNING_THRESHOLD_BATCH', DEFAULT_SCAN_CONFIG.thresholdBatch, 2, 1000000),
    windowMinutes: intEnv(env, 'SCAN_WARNING_WINDOW_MINUTES', DEFAULT_SCAN_CONFIG.windowMinutes, 1, 525600),
    distinctSourceThreshold: intEnv(env, 'SCAN_DISTINCT_SOURCE_THRESHOLD', DEFAULT_SCAN_CONFIG.distinctSourceThreshold, 1, 1000),
    rateLimitPerMinute: intEnv(env, 'SCAN_RATE_LIMIT_PER_MINUTE', DEFAULT_SCAN_CONFIG.rateLimitPerMinute, 1, 100000),
    retentionDays: intEnv(env, 'SCAN_EVENT_RETENTION_DAYS', DEFAULT_SCAN_CONFIG.retentionDays, 1, 3650),
  };
  if (cfg.windowMinutes > cfg.retentionDays * 1440) {
    throw new Error('SCAN_WARNING_WINDOW_MINUTES must not exceed SCAN_EVENT_RETENTION_DAYS (the heuristic needs that history)');
  }
  return cfg;
}

/** Trusted base URL used to build QR links. Never taken from a request. */
export function getPublicBaseUrl(env: Record<string, string | undefined> = process.env): string {
  const url = env.PUBLIC_BASE_URL;
  if (url) return url;
  if (env.NODE_ENV === 'production') throw new Error('PUBLIC_BASE_URL must be set in production');
  return 'http://localhost:3000';
}
