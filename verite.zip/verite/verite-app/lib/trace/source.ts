import { createHmac } from 'crypto';

// Privacy-preserving "source signal" for the clone-warning heuristic and rate limiting.
// Only a COARSE network prefix (IPv4 /24, IPv6 /48) is used, and only as a keyed HMAC, so
// the database never contains an IP address. The header is client-supplied unless a trusted
// reverse proxy sets it, so this signal can be spoofed. Treat it as a weak hint.
export function coarseSource(ip: string | null): string {
  if (!ip) return 'unknown';
  const v = ip.trim();
  const v4 = v.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.\d{1,3}$/);
  if (v4) return `${v4[1]}.${v4[2]}.${v4[3]}.0/24`;
  if (v.includes(':')) {
    const parts = v.split(':').filter(Boolean).slice(0, 3);
    return parts.length ? `${parts.join(':')}::/48` : 'unknown';
  }
  return 'unknown';
}

export function sourceHash(ip: string | null, secret: string): string {
  return createHmac('sha256', secret).update(coarseSource(ip)).digest('hex').slice(0, 32);
}

export function clientIpFromHeaders(get: (name: string) => string | null): string | null {
  const xff = get('x-forwarded-for');
  if (xff) return xff.split(',')[0].trim();
  return get('x-real-ip');
}
