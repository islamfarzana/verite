import { NextResponse } from 'next/server';
import { TraceError } from './service';

const STATUS: Record<string, number> = { NOT_FOUND: 404, FORBIDDEN: 403, INVALID: 422, NOT_ELIGIBLE: 409, COLLISION_EXHAUSTED: 503 };

export function traceErrorResponse(err: unknown) {
  if (err instanceof TraceError) return NextResponse.json({ success: false, message: err.message }, { status: STATUS[err.code] ?? 400 });
  console.error('Unexpected traceability error', (err as Error)?.message);
  return NextResponse.json({ success: false, message: 'Something went wrong. Please try again.' }, { status: 500 });
}
