import { randomBytes } from 'crypto';

// Public traceability token: 18 random bytes (144 bits) from the operating system's
// cryptographically secure generator, base64url encoded to exactly 24 characters.
// Not derived from timestamps, product data, sequence numbers or Math.random().
export const TOKEN_BYTES = 18;
export const TOKEN_REGEX = /^[A-Za-z0-9_-]{24}$/;
export const PAYLOAD_VERSION = 'v1';
export type RandomBytesFn = (size: number) => Buffer;

export function generateToken(rb: RandomBytesFn = randomBytes): string {
  return rb(TOKEN_BYTES).toString('base64url');
}

export function isValidToken(value: unknown): value is string {
  return typeof value === 'string' && TOKEN_REGEX.test(value);
}

/** Versioned, opaque QR payload: <trusted base URL>/scan/v1/<token>. Contains no product data. */
export function buildScanUrl(baseUrl: string, token: string): string {
  const base = new URL(baseUrl);
  if (base.protocol !== 'http:' && base.protocol !== 'https:') throw new Error('Base URL must be http(s)');
  if (!isValidToken(token)) throw new Error('Invalid token');
  return `${base.origin}/scan/${PAYLOAD_VERSION}/${token}`;
}
