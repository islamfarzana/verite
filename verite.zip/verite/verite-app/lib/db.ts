import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { TRACE_SCHEMA_SQL } from './trace/schema';
import { IDENTITY_SCHEMA_SQL } from './identity/schema';
import { AI_SCHEMA_SQL } from './ai/schema';
import { ASSISTANT_SCHEMA_SQL } from './assistant/schema';
import { applyProtectionSchema } from './protection/schema';

// NOTE ON PRODUCTION DATABASES
// SQLite (via better-sqlite3) is used here so the whole app runs with zero
// external services — real persistence, real SQL, no mocking. It's a great
// fit for a single-instance deploy (Railway, Render, Fly.io, a VPS, or
// Docker). If you deploy to a stateless serverless platform (Vercel), swap
// this file for a Postgres client (e.g. `pg` + Neon/Supabase) — the schema
// below is already written in portable ANSI SQL so the migration is a
// drop-in: same table shapes as 07_Database_Design.md.

// WHERE YOUR DATA LIVES: one SQLite database file. Every product, order, cart and account is stored in it
// and survives closing the browser, stopping `npm run dev` and restarting the machine. It is lost only if
// the file is deleted or the app is started from a different folder / with a different DATABASE_FILE.
// Check it any time with `npm run db:status`.
export const DB_PATH = path.resolve(process.env.DATABASE_FILE || path.join(process.cwd(), 'data', 'verite.db'));
// Uploaded images are kept next to the database (not in public/, which `next start` does not serve
// for files added after the build). Served by app/api/files/[name]/route.ts.
export const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(path.dirname(DB_PATH), 'uploads'));

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const g = globalThis as unknown as { __veriteDbLogged?: boolean };
if (!g.__veriteDbLogged && process.env.NODE_ENV !== 'test') {
  g.__veriteDbLogged = true;
  console.log(`[verite] database file: ${DB_PATH}`);
}

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('BUYER','SELLER','ADMIN')) DEFAULT 'BUYER',
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  seller_id TEXT NOT NULL REFERENCES users(id),
  category_id TEXT REFERENCES categories(id),
  name TEXT NOT NULL,
  brand TEXT,
  description TEXT,
  barcode TEXT UNIQUE,
  batch_number TEXT,
  manufacturing_date TEXT,
  expiry_date TEXT,
  price REAL NOT NULL CHECK (price > 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  image_emoji TEXT DEFAULT '📦',
  status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','PUBLISHED')),
  verification_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (verification_status IN ('PENDING','VERIFIED','FAILED')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS ocr_results (
  id TEXT PRIMARY KEY,
  product_id TEXT REFERENCES products(id),
  raw_confidence REAL,
  structured_json TEXT,
  requires_review INTEGER DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS blockchain_records (
  id TEXT PRIMARY KEY,
  product_id TEXT UNIQUE NOT NULL REFERENCES products(id),
  keccak_hash TEXT NOT NULL,
  tx_hash TEXT NOT NULL,
  block_number INTEGER NOT NULL,
  network TEXT NOT NULL DEFAULT 'polygon-amoy-simulated',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS verification_logs (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  buyer_id TEXT REFERENCES users(id),
  result TEXT NOT NULL CHECK (result IN ('VERIFIED','FAILED')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS addresses (
  id TEXT PRIMARY KEY,
  buyer_id TEXT NOT NULL REFERENCES users(id),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  division TEXT,
  district TEXT,
  address_line TEXT NOT NULL,
  is_default INTEGER DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  buyer_id TEXT NOT NULL REFERENCES users(id),
  order_number TEXT UNIQUE NOT NULL,
  invoice_number TEXT,
  subtotal REAL NOT NULL DEFAULT 0,
  vat REAL NOT NULL DEFAULT 0,
  delivery_charge REAL NOT NULL DEFAULT 0,
  discount REAL NOT NULL DEFAULT 0,
  grand_total REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'COD',
  delivery_method TEXT NOT NULL DEFAULT 'STANDARD',
  shipping_name TEXT,
  shipping_phone TEXT,
  shipping_address TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES orders(id),
  product_id TEXT NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL,
  price REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES orders(id),
  gateway TEXT NOT NULL,
  transaction_id TEXT NOT NULL,
  amount REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'SUCCESS',
  payment_time TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS shipments (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES orders(id),
  courier TEXT NOT NULL DEFAULT 'Standard Courier',
  tracking_number TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PACKED',
  estimated_delivery TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Product_Image_Gallery_Extension.md: feature addition only. No existing
-- table above is modified. This is the one new table the spec calls for;
-- the marketplace list/search query picks the cover image (sort_order 0)
-- via a correlated subquery, so no other schema change was needed.
CREATE TABLE IF NOT EXISTS product_images (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  image_url TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// Batch/unit traceability identifiers and scan events (see docs/changes/identifier-scan-protection/).
db.exec(TRACE_SCHEMA_SQL);

// Seller onboarding, licence claims/checks and product identity (see docs/changes/seller-licence-verification/).
db.exec(IDENTITY_SCHEMA_SQL);

// v4: AI-assisted listing data and the seller assistant (see docs/changes/ai-assistant-v4/).
db.exec(AI_SCHEMA_SQL);
db.exec(ASSISTANT_SCHEMA_SQL);

// v5: persistent cart, MRP / expiry / recall / label-check / buyer notifications (docs/changes/buyer-protection/).
applyProtectionSchema(db as any);

export default db;
