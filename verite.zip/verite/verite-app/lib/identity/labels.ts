// User-facing wording, kept in one place so every page and API uses the same, non-overclaiming text.

export const MOCK_LABEL = 'MOCK/DEMO REGISTRY — NOT OFFICIAL VERIFICATION';
export const UNCONFIGURED_LABEL = 'No licence registry configured — licence not checked';

export const LICENCE_TYPE_LABEL: Record<string, string> = {
  TRADE_LICENCE: 'Trade licence',
  BSTI_CM_LICENCE: 'BSTI certification-mark (CM) licence',
  BFSA_REGISTRATION: 'BFSA food business registration',
  DGDA_LICENCE: 'DGDA licence',
  OTHER: 'Other licence',
};

export const ENTITY_STATUS_TEXT: Record<string, string> = {
  PENDING: 'Pending admin review',
  APPROVED: 'Identity reviewed and approved by a Verité admin',
  REJECTED: 'Application rejected',
  SUSPENDED: 'Suspended',
};

export const CHECK_RESULT_TEXT: Record<string, string> = {
  NOT_CHECKED: 'Submitted claim — not checked',
  VALID: 'Active according to the registry consulted',
  INVALID: 'Registry reports the licence as invalid',
  EXPIRED: 'Licence expired',
  REVOKED: 'Licence revoked',
  SUSPENDED: 'Licence suspended',
  NOT_FOUND: 'Not found in the registry consulted',
  UNAVAILABLE: 'Could not check the licence right now',
  ERROR: 'The registry returned an unusable answer',
  UNSUPPORTED: 'This licence type cannot be checked by the configured registry',
};

export const MANUFACTURER_IDENTITY_TEXT: Record<string, string> = {
  SAME_ENTITY_AS_SELLER: 'Manufacturer is the seller’s own reviewed business',
  ENTITY_REFERENCE: 'Manufacturer is a business registered on Verité',
  UNVERIFIED_CLAIM: 'Manufacturer named by the seller — unverified claim',
  UNKNOWN: 'Manufacturer not stated',
  NOT_RECORDED_LEGACY: 'Legacy record — manufacturer identity was not recorded',
};

export const REASON_CODES = {
  REJECT: ['DOCUMENTS_INCOMPLETE', 'LICENCE_NOT_VERIFIABLE', 'IDENTITY_MISMATCH', 'DUPLICATE_SUBMISSION', 'OTHER'],
  SUSPEND: ['LICENCE_EXPIRED', 'LICENCE_REVOKED', 'COMPLAINT_UNDER_REVIEW', 'POLICY_VIOLATION', 'OTHER'],
  REINSTATE: ['REVIEW_PASSED', 'LICENCE_RENEWED', 'COMPLAINT_RESOLVED'],
  REOPEN: ['NEW_EVIDENCE', 'LICENCE_RENEWED', 'OTHER'],
} as const;
