import { newId } from '../ids';
import { REASON_CODES } from './labels';
import type { RegistryAdapter, RegistryResult } from './registry';
import { normalizeLicenceNumber } from './registry';
import { CLAIMED_STATUSES, ENTITY_ROLES, LICENCE_TYPES } from './schema';
import {
  IdentityError, type Actor, type ClaimedStatus, type Db, type EntityRole, type EntityRow, type EntityStatus, type LicenceRow, type LicenceType,
} from './types';

// Seller onboarding, admin review and licence checks. Every status change is decided here,
// server-side; no request field can set a status, a verification method or a timestamp.

export interface LicenceInput {
  licenceType: LicenceType;
  licenceNumber: string;
  issuingAuthority: string;
  claimedIssueDate?: string | null;
  claimedExpiryDate?: string | null;
  claimedStatus?: ClaimedStatus;
  claimSource: 'MANUAL_ENTRY' | 'OCR_EXTRACTED';
}

export interface ProfileInput {
  legalName: string;
  displayName: string;
  entityType: 'ORGANIZATION' | 'SOLE_PROPRIETOR';
  roles: EntityRole[];
  contactEmail?: string | null;
  licence: LicenceInput;
}

export interface Deps {
  adapter: RegistryAdapter;
  now?: () => Date;
}

type Trigger = 'SUBMISSION' | 'SELLER_RECHECK' | 'ADMIN_RECHECK' | 'PRE_REGISTRATION' | 'MANUAL_REVIEW';

export function tx<T>(db: Db, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch { /* already rolled back */ }
    throw err;
  }
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const LICENCE_NUMBER_RE = /^[A-Za-z0-9][A-Za-z0-9\-/. ]{2,63}$/;

function text(v: unknown, field: string, min = 2, max = 200): string {
  if (typeof v !== 'string' || v.trim().length < min || v.trim().length > max) throw new IdentityError('INVALID', `${field} must be ${min}-${max} characters.`, { field });
  return v.trim();
}

function optionalDate(v: unknown, field: string): string | null {
  if (v === undefined || v === null || v === '') return null;
  if (typeof v !== 'string' || !DATE_RE.test(v) || Number.isNaN(Date.parse(v))) throw new IdentityError('INVALID', `${field} must be a date (YYYY-MM-DD).`, { field });
  return v;
}

export function validateLicenceInput(raw: LicenceInput): LicenceInput {
  if (!raw || typeof raw !== 'object') throw new IdentityError('INVALID', 'Licence details are required.', { field: 'licence' });
  if (!(LICENCE_TYPES as readonly string[]).includes(raw.licenceType)) throw new IdentityError('INVALID', 'Unknown licence type.', { field: 'licenceType' });
  const licenceNumber = text(raw.licenceNumber, 'Licence number', 3, 64);
  if (!LICENCE_NUMBER_RE.test(licenceNumber)) throw new IdentityError('INVALID', 'Licence number may contain letters, digits, spaces and - / . only.', { field: 'licenceNumber' });
  const claimedIssueDate = optionalDate(raw.claimedIssueDate, 'Issue date');
  const claimedExpiryDate = optionalDate(raw.claimedExpiryDate, 'Expiry date');
  if (claimedIssueDate && claimedExpiryDate && claimedExpiryDate <= claimedIssueDate) {
    throw new IdentityError('INVALID', 'Expiry date must be after the issue date.', { field: 'claimedExpiryDate' });
  }
  const claimedStatus = raw.claimedStatus ?? 'UNKNOWN';
  if (!(CLAIMED_STATUSES as readonly string[]).includes(claimedStatus)) throw new IdentityError('INVALID', 'Unknown claimed status.', { field: 'claimedStatus' });
  if (raw.claimSource !== 'MANUAL_ENTRY' && raw.claimSource !== 'OCR_EXTRACTED') throw new IdentityError('INVALID', 'Unknown claim source.', { field: 'claimSource' });
  return {
    licenceType: raw.licenceType, licenceNumber, issuingAuthority: text(raw.issuingAuthority, 'Issuing authority', 2, 120),
    claimedIssueDate, claimedExpiryDate, claimedStatus, claimSource: raw.claimSource,
  };
}

export function validateProfileInput(raw: ProfileInput): ProfileInput {
  if (!raw || typeof raw !== 'object') throw new IdentityError('INVALID', 'Profile details are required.');
  if (raw.entityType !== 'ORGANIZATION' && raw.entityType !== 'SOLE_PROPRIETOR') throw new IdentityError('INVALID', 'Unknown business type.', { field: 'entityType' });
  const roles = Array.isArray(raw.roles) ? raw.roles : [];
  if (roles.some((r) => !(ENTITY_ROLES as readonly string[]).includes(r))) throw new IdentityError('INVALID', 'Unknown business role.', { field: 'roles' });
  let contactEmail: string | null = null;
  if (raw.contactEmail) {
    if (typeof raw.contactEmail !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw.contactEmail) || raw.contactEmail.length > 200) {
      throw new IdentityError('INVALID', 'Contact email is not valid.', { field: 'contactEmail' });
    }
    contactEmail = raw.contactEmail.trim();
  }
  return {
    legalName: text(raw.legalName, 'Legal business name'),
    displayName: text(raw.displayName, 'Public display name', 2, 120),
    entityType: raw.entityType,
    // A seller-managed business always holds the SELLER role.
    roles: Array.from(new Set<EntityRole>(['SELLER', ...roles])),
    contactEmail,
    licence: validateLicenceInput(raw.licence),
  };
}

// ----------------------------------------------------------------------------------------------
// Reads

export function getEntityForUser(db: Db, userId: string): EntityRow | undefined {
  return db.prepare('SELECT * FROM business_entities WHERE managed_by_user_id = ?').get(userId) as EntityRow | undefined;
}

export function getEntity(db: Db, entityId: string): EntityRow | undefined {
  return db.prepare('SELECT * FROM business_entities WHERE id = ?').get(entityId) as EntityRow | undefined;
}

export function getRoles(db: Db, entityId: string): EntityRole[] {
  return (db.prepare('SELECT role FROM entity_roles WHERE entity_id = ? ORDER BY role').all(entityId) as { role: EntityRole }[]).map((r) => r.role);
}

export function getLicences(db: Db, entityId: string, includeSuperseded = false): LicenceRow[] {
  return db
    .prepare(`SELECT * FROM licence_records WHERE entity_id = ? ${includeSuperseded ? '' : 'AND superseded_at IS NULL'} ORDER BY created_at, id`)
    .all(entityId) as LicenceRow[];
}

export function getLicence(db: Db, licenceId: string): LicenceRow | undefined {
  return db.prepare('SELECT * FROM licence_records WHERE id = ?').get(licenceId) as LicenceRow | undefined;
}

/** History visible to the submitter: no internal notes, no reviewer identity. */
export function publicHistory(db: Db, entityId: string) {
  return db
    .prepare('SELECT previous_status AS previousStatus, new_status AS newStatus, reason_code AS reasonCode, public_note AS publicNote, created_at AS createdAt FROM entity_status_history WHERE entity_id = ? ORDER BY created_at, rowid')
    .all(entityId);
}

/** Full history for admins only. */
export function adminHistory(db: Db, entityId: string) {
  return db
    .prepare(
      `SELECT h.previous_status AS previousStatus, h.new_status AS newStatus, h.reason_code AS reasonCode, h.internal_note AS internalNote,
              h.public_note AS publicNote, h.actor_role AS actorRole, u.name AS actorName, h.created_at AS createdAt
       FROM entity_status_history h LEFT JOIN users u ON u.id = h.actor_user_id WHERE h.entity_id = ? ORDER BY h.created_at, h.rowid`
    )
    .all(entityId);
}

export function checkEvents(db: Db, licenceId: string) {
  return db
    .prepare(
      `SELECT trigger_reason AS triggerReason, result, method, environment, source_label AS sourceLabel, checked_at AS checkedAt,
              attempted_at AS attemptedAt, error_category AS errorCategory FROM licence_check_events WHERE licence_id = ? ORDER BY attempted_at, rowid`
    )
    .all(licenceId);
}

// ----------------------------------------------------------------------------------------------
// Writes

function insertHistory(db: Db, h: {
  entityId: string; previous: EntityStatus | null; next: EntityStatus; reason: string; actor: Actor; at: string; internalNote?: string | null; publicNote?: string | null;
}) {
  db.prepare(
    `INSERT INTO entity_status_history (id, entity_id, previous_status, new_status, reason_code, internal_note, public_note, actor_user_id, actor_role, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(newId('esh'), h.entityId, h.previous, h.next, h.reason, h.internalNote ?? null, h.publicNote ?? null, h.actor.id, h.actor.role, h.at);
}

function setRoles(db: Db, entityId: string, roles: EntityRole[]) {
  db.prepare('DELETE FROM entity_roles WHERE entity_id = ?').run(entityId);
  const ins = db.prepare('INSERT INTO entity_roles (entity_id, role) VALUES (?, ?)');
  for (const r of roles) ins.run(entityId, r);
}

/** Store a licence claim for an entity. Returns the licence id. Must run inside a transaction. */
function upsertLicenceClaim(db: Db, entityId: string, l: LicenceInput, at: string): string {
  const norm = normalizeLicenceNumber(l.licenceNumber);
  const same = db
    .prepare('SELECT id, entity_id FROM licence_records WHERE licence_type = ? AND licence_number_normalized = ? AND superseded_at IS NULL')
    .get(l.licenceType, norm) as { id: string; entity_id: string } | undefined;
  if (same && same.entity_id !== entityId) {
    // Never merge businesses: a licence number already claimed by another business needs an admin.
    throw new IdentityError('CONFLICT', 'This licence number is already linked to another business on Verité. Contact an administrator.');
  }
  if (same) {
    // Same licence re-submitted with corrected details: the claim changes, so the earlier check no
    // longer describes it. The earlier check stays in licence_check_events.
    db.prepare(
      `UPDATE licence_records SET licence_number = ?, issuing_authority = ?, claimed_issue_date = ?, claimed_expiry_date = ?, claimed_status = ?,
         claim_source = ?, check_result = 'NOT_CHECKED', verification_method = 'UNVERIFIED_CLAIM', verification_environment = NULL,
         source_label = NULL, registry_reference = NULL, registry_expiry_date = NULL, checked_at = NULL, error_category = NULL,
         reviewed_by = NULL, updated_at = ? WHERE id = ?`
    ).run(l.licenceNumber, l.issuingAuthority, l.claimedIssueDate ?? null, l.claimedExpiryDate ?? null, l.claimedStatus ?? 'UNKNOWN', l.claimSource, at, same.id);
    return same.id;
  }
  // A new number for the same licence type replaces (supersedes) the previous one, e.g. a renewal.
  db.prepare('UPDATE licence_records SET superseded_at = ?, updated_at = ? WHERE entity_id = ? AND licence_type = ? AND superseded_at IS NULL').run(at, at, entityId, l.licenceType);
  const id = newId('lic');
  db.prepare(
    `INSERT INTO licence_records (id, entity_id, licence_type, licence_number, licence_number_normalized, issuing_authority, claimed_issue_date,
       claimed_expiry_date, claimed_status, claim_source, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(id, entityId, l.licenceType, l.licenceNumber, norm, l.issuingAuthority, l.claimedIssueDate ?? null, l.claimedExpiryDate ?? null, l.claimedStatus ?? 'UNKNOWN', l.claimSource, at, at);
  return id;
}

/** Seller submits (or corrects / resubmits) their business profile and licence claim. */
export async function submitBusinessProfile(db: Db, actor: Actor, rawInput: ProfileInput, deps: Deps) {
  if (actor.role !== 'SELLER') throw new IdentityError('FORBIDDEN', 'Only seller accounts can submit a business profile.');
  const input = validateProfileInput(rawInput);
  const now = deps.now ?? (() => new Date());
  const at = now().toISOString();

  const { entityId, licenceId } = tx(db, () => {
    const existing = getEntityForUser(db, actor.id);
    if (existing && (existing.status === 'APPROVED' || existing.status === 'SUSPENDED')) {
      throw new IdentityError('LOCKED', 'Your business profile has already been reviewed. To change business details, contact an administrator; to renew a licence, use "Add or renew licence".');
    }
    let entityId: string;
    if (!existing) {
      entityId = newId('ent');
      db.prepare(
        `INSERT INTO business_entities (id, legal_name, display_name, entity_type, contact_email, managed_by_user_id, status, status_reason_code,
           status_changed_at, status_changed_by, submitted_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 'PENDING', 'SUBMITTED', ?, ?, ?, ?, ?)`
      ).run(entityId, input.legalName, input.displayName, input.entityType, input.contactEmail ?? null, actor.id, at, actor.id, at, at, at);
      insertHistory(db, { entityId, previous: null, next: 'PENDING', reason: 'SUBMITTED', actor, at });
    } else {
      entityId = existing.id;
      const reason = existing.status === 'REJECTED' ? 'RESUBMITTED' : 'DETAILS_UPDATED';
      db.prepare(
        `UPDATE business_entities SET legal_name = ?, display_name = ?, entity_type = ?, contact_email = ?, status = 'PENDING', status_reason_code = ?,
           public_status_note = NULL, status_changed_at = ?, status_changed_by = ?, submitted_at = ?, updated_at = ? WHERE id = ? AND status = ?`
      ).run(input.legalName, input.displayName, input.entityType, input.contactEmail ?? null, reason, at, actor.id, at, at, entityId, existing.status);
      insertHistory(db, { entityId, previous: existing.status, next: 'PENDING', reason, actor, at });
    }
    setRoles(db, entityId, input.roles);
    const licenceId = upsertLicenceClaim(db, entityId, input.licence, at);
    return { entityId, licenceId };
  });

  const licence = await runLicenceCheck(db, licenceId, deps.adapter, 'SUBMISSION', actor, now);
  return { entity: getEntity(db, entityId)!, roles: getRoles(db, entityId), licence };
}

/** Seller adds or renews a licence on an existing profile. Does not change the entity's status. */
export async function submitLicence(db: Db, actor: Actor, rawLicence: LicenceInput, deps: Deps) {
  if (actor.role !== 'SELLER') throw new IdentityError('FORBIDDEN', 'Only seller accounts can submit licences.');
  const l = validateLicenceInput(rawLicence);
  const now = deps.now ?? (() => new Date());
  const entity = getEntityForUser(db, actor.id);
  if (!entity) throw new IdentityError('NOT_FOUND', 'Submit your business profile first.');
  const licenceId = tx(db, () => upsertLicenceClaim(db, entity.id, l, now().toISOString()));
  return runLicenceCheck(db, licenceId, deps.adapter, 'SUBMISSION', actor, now);
}

/**
 * Ask the configured registry about a licence and record the outcome with its provenance.
 * A failed attempt (UNAVAILABLE/ERROR) never overwrites an earlier definitive answer or its time;
 * it is recorded as an attempt. Every attempt is appended to licence_check_events.
 */
export async function runLicenceCheck(db: Db, licenceId: string, adapter: RegistryAdapter, trigger: Trigger, actor: Actor | null, now: () => Date = () => new Date()) {
  const licence = getLicence(db, licenceId);
  if (!licence) throw new IdentityError('NOT_FOUND', 'Licence not found.');
  let r: RegistryResult;
  try {
    r = await adapter.check({ licenceType: licence.licence_type, licenceNumber: licence.licence_number, issuingAuthority: licence.issuing_authority });
  } catch {
    r = {
      outcome: 'ERROR', mode: adapter.mode, method: adapter.mode === 'MOCK' ? 'MOCK_REGISTRY' : adapter.mode === 'REAL' ? 'REAL_REGISTRY_API' : 'UNVERIFIED_CLAIM',
      environment: null, sourceLabel: adapter.sourceLabel, checkedAt: null, reference: null, expiryDate: null, errorCategory: 'ADAPTER_EXCEPTION',
    };
  }
  const attemptedAt = now().toISOString();
  const failed = r.outcome === 'UNAVAILABLE' || r.outcome === 'ERROR';
  const hasDefinitive = !!licence.checked_at && !['NOT_CHECKED', 'UNAVAILABLE', 'ERROR'].includes(licence.check_result);

  tx(db, () => {
    db.prepare(
      `INSERT INTO licence_check_events (id, licence_id, trigger_reason, result, method, environment, source_label, registry_reference, checked_at, attempted_at, error_category, actor_user_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(newId('lce'), licenceId, trigger, r.outcome, r.method, r.environment, r.sourceLabel, r.reference, r.checkedAt, attemptedAt, r.errorCategory, actor?.id ?? null);
    if (failed && hasDefinitive) {
      db.prepare('UPDATE licence_records SET last_attempt_at = ?, error_category = ?, updated_at = ? WHERE id = ?').run(attemptedAt, r.errorCategory, attemptedAt, licenceId);
    } else {
      db.prepare(
        `UPDATE licence_records SET check_result = ?, verification_method = ?, verification_environment = ?, source_label = ?, registry_reference = ?,
           registry_expiry_date = ?, checked_at = ?, last_attempt_at = ?, error_category = ?, reviewed_by = NULL, updated_at = ? WHERE id = ?`
      ).run(r.outcome, r.method, r.environment, r.sourceLabel, r.reference, r.expiryDate, r.checkedAt, attemptedAt, r.errorCategory, attemptedAt, licenceId);
    }
  });
  return getLicence(db, licenceId)!;
}

/** Re-check a licence: the owning seller, or an admin. */
export async function recheckLicence(db: Db, actor: Actor, licenceId: string, deps: Deps) {
  const licence = getLicence(db, licenceId);
  if (!licence || licence.superseded_at) throw new IdentityError('NOT_FOUND', 'Licence not found.');
  if (actor.role === 'SELLER') {
    const entity = getEntityForUser(db, actor.id);
    if (!entity || entity.id !== licence.entity_id) throw new IdentityError('NOT_FOUND', 'Licence not found.');
  } else if (actor.role !== 'ADMIN') throw new IdentityError('FORBIDDEN', 'Not allowed.');
  return runLicenceCheck(db, licenceId, deps.adapter, actor.role === 'ADMIN' ? 'ADMIN_RECHECK' : 'SELLER_RECHECK', actor, deps.now);
}

// ----------------------------------------------------------------------------------------------
// Admin decisions

export type DecisionAction = 'APPROVE' | 'REJECT' | 'SUSPEND' | 'REINSTATE' | 'REOPEN';

const TRANSITIONS: Record<DecisionAction, { from: EntityStatus; to: EntityStatus; reasons: readonly string[] }> = {
  APPROVE: { from: 'PENDING', to: 'APPROVED', reasons: ['REVIEW_PASSED'] },
  REJECT: { from: 'PENDING', to: 'REJECTED', reasons: REASON_CODES.REJECT },
  SUSPEND: { from: 'APPROVED', to: 'SUSPENDED', reasons: REASON_CODES.SUSPEND },
  REINSTATE: { from: 'SUSPENDED', to: 'APPROVED', reasons: REASON_CODES.REINSTATE },
  REOPEN: { from: 'SUSPENDED', to: 'PENDING', reasons: REASON_CODES.REOPEN },
};

export function allowedActions(status: EntityStatus): DecisionAction[] {
  return (Object.keys(TRANSITIONS) as DecisionAction[]).filter((a) => TRANSITIONS[a].from === status);
}

export function decideEntity(
  db: Db, actor: Actor, entityId: string,
  d: { action: DecisionAction; reasonCode?: string; note?: string | null; publicNote?: string | null },
  now: () => Date = () => new Date()
) {
  if (actor.role !== 'ADMIN') throw new IdentityError('FORBIDDEN', 'Only administrators can review businesses.');
  const t = TRANSITIONS[d.action];
  if (!t) throw new IdentityError('INVALID', 'Unknown action.');
  const reason = d.reasonCode ?? (d.action === 'APPROVE' ? 'REVIEW_PASSED' : '');
  if (!t.reasons.includes(reason)) throw new IdentityError('INVALID', `A reason is required. Allowed: ${t.reasons.join(', ')}.`, { field: 'reasonCode' });
  const note = typeof d.note === 'string' ? d.note.trim().slice(0, 1000) : null;
  const publicNote = typeof d.publicNote === 'string' ? d.publicNote.trim().slice(0, 300) : null;
  if (reason === 'OTHER' && !note) throw new IdentityError('INVALID', 'Explain the reason in the note when using OTHER.', { field: 'note' });

  return tx(db, () => {
    const entity = getEntity(db, entityId);
    if (!entity) throw new IdentityError('NOT_FOUND', 'Business not found.');
    if (entity.managed_by_user_id === actor.id) throw new IdentityError('FORBIDDEN', 'You cannot review a business that your own account manages.');
    if (entity.status !== t.from) throw new IdentityError('INVALID_TRANSITION', `Cannot ${d.action.toLowerCase()} a business that is ${entity.status}.`);
    const at = now().toISOString();
    const res = db.prepare(
      `UPDATE business_entities SET status = ?, status_reason_code = ?, public_status_note = ?, status_changed_at = ?, status_changed_by = ?, updated_at = ?
       WHERE id = ? AND status = ?`
    ).run(t.to, reason, publicNote, at, actor.id, at, entityId, t.from);
    if (Number(res.changes) !== 1) throw new IdentityError('INVALID_TRANSITION', 'The business changed while you were reviewing it. Reload and try again.');
    insertHistory(db, { entityId, previous: t.from, next: t.to, reason, actor, at, internalNote: note, publicNote });
    return getEntity(db, entityId)!;
  });
}

/** An authorised admin records the outcome of reviewing licence evidence by hand. */
export function recordManualLicenceReview(
  db: Db, actor: Actor, licenceId: string, review: { result: 'VALID' | 'INVALID' | 'EXPIRED' | 'REVOKED' | 'SUSPENDED' },
  now: () => Date = () => new Date()
) {
  if (actor.role !== 'ADMIN') throw new IdentityError('FORBIDDEN', 'Only administrators can review licences.');
  if (!['VALID', 'INVALID', 'EXPIRED', 'REVOKED', 'SUSPENDED'].includes(review.result)) throw new IdentityError('INVALID', 'Unknown review result.');
  const licence = getLicence(db, licenceId);
  if (!licence || licence.superseded_at) throw new IdentityError('NOT_FOUND', 'Licence not found.');
  const entity = getEntity(db, licence.entity_id)!;
  if (entity.managed_by_user_id === actor.id) throw new IdentityError('FORBIDDEN', 'You cannot review a licence of a business that your own account manages.');
  const at = now().toISOString();
  const label = 'Manual review by a Verité administrator (document/evidence review — not a registry lookup)';
  tx(db, () => {
    db.prepare(
      `INSERT INTO licence_check_events (id, licence_id, trigger_reason, result, method, environment, source_label, registry_reference, checked_at, attempted_at, error_category, actor_user_id)
       VALUES (?, ?, 'MANUAL_REVIEW', ?, 'AUTHORIZED_MANUAL_REVIEW', NULL, ?, NULL, ?, ?, NULL, ?)`
    ).run(newId('lce'), licenceId, review.result, label, at, at, actor.id);
    db.prepare(
      `UPDATE licence_records SET check_result = ?, verification_method = 'AUTHORIZED_MANUAL_REVIEW', verification_environment = NULL, source_label = ?,
         registry_reference = NULL, registry_expiry_date = NULL, checked_at = ?, last_attempt_at = ?, error_category = NULL, reviewed_by = ?, updated_at = ? WHERE id = ?`
    ).run(review.result, label, at, at, actor.id, at, licenceId);
  });
  return getLicence(db, licenceId)!;
}

export function listEntities(db: Db, actor: Actor, status?: EntityStatus) {
  if (actor.role !== 'ADMIN') throw new IdentityError('FORBIDDEN', 'Only administrators can list businesses.');
  const rows = db
    .prepare(
      `SELECT e.id, e.legal_name AS legalName, e.display_name AS displayName, e.entity_type AS entityType, e.status, e.status_reason_code AS statusReasonCode,
              e.submitted_at AS submittedAt, e.status_changed_at AS statusChangedAt, u.name AS managedByName, u.email AS managedByEmail,
              (SELECT COUNT(*) FROM licence_records l WHERE l.entity_id = e.id AND l.superseded_at IS NULL) AS liveLicences
       FROM business_entities e LEFT JOIN users u ON u.id = e.managed_by_user_id
       ${status ? 'WHERE e.status = ?' : ''} ORDER BY e.submitted_at DESC`
    )
    .all(...(status ? [status] : [])) as Record<string, any>[];
  return rows.map((r) => ({ ...r, roles: getRoles(db, r.id) }));
}
