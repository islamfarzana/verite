// SYNTHETIC, FICTITIOUS records for the mock/demo registry. None of these numbers or holders is real.
// They exist only to exercise application logic (valid, expired, revoked, suspended, invalid, outage).
// A mock result never proves that any real licence is valid.

export interface MockRegistryRecord {
  licenceType: string;
  licenceNumber: string;
  issuingAuthority: string;
  holderName: string;
  status: 'ACTIVE' | 'EXPIRED' | 'REVOKED' | 'SUSPENDED' | 'INVALID' | 'SIMULATE_OUTAGE';
  expiryDate: string | null;
  reference: string;
}

export const MOCK_REGISTRY_RECORDS: MockRegistryRecord[] = [
  { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2026-0001', issuingAuthority: 'Demo City Corporation (fictitious)', holderName: 'GreenMart BD (fictitious demo holder)', status: 'ACTIVE', expiryDate: '2027-06-30', reference: 'MOCK-REF-0001' },
  { licenceType: 'BSTI_CM_LICENCE', licenceNumber: 'DEMO-CM-2026-0002', issuingAuthority: 'Demo Standards Body (fictitious)', holderName: 'Demo Foods Ltd (fictitious)', status: 'ACTIVE', expiryDate: '2028-12-31', reference: 'MOCK-REF-0002' },
  { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2024-0003', issuingAuthority: 'Demo City Corporation (fictitious)', holderName: 'Expired Traders (fictitious)', status: 'ACTIVE', expiryDate: '2025-06-30', reference: 'MOCK-REF-0003' },
  { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2025-0004', issuingAuthority: 'Demo City Corporation (fictitious)', holderName: 'Revoked Mart (fictitious)', status: 'REVOKED', expiryDate: '2027-06-30', reference: 'MOCK-REF-0004' },
  { licenceType: 'BSTI_CM_LICENCE', licenceNumber: 'DEMO-CM-2025-0005', issuingAuthority: 'Demo Standards Body (fictitious)', holderName: 'Suspended Snacks (fictitious)', status: 'SUSPENDED', expiryDate: '2027-01-31', reference: 'MOCK-REF-0005' },
  { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-2025-0006', issuingAuthority: 'Demo City Corporation (fictitious)', holderName: 'Invalid Imports (fictitious)', status: 'INVALID', expiryDate: null, reference: 'MOCK-REF-0006' },
  { licenceType: 'TRADE_LICENCE', licenceNumber: 'DEMO-TL-0000-OUTAGE', issuingAuthority: 'Demo City Corporation (fictitious)', holderName: 'Outage simulation (fictitious)', status: 'SIMULATE_OUTAGE', expiryDate: null, reference: 'MOCK-REF-OUTAGE' },
];
