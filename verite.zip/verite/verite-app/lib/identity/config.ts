// Registry and policy configuration. Read from server environment only; nothing here can be
// chosen by a client request (no client-selected registry URL, mode or outcome).

export type RegistryMode = 'mock' | 'real' | 'off';

export interface IdentityConfig {
  /** Mode actually in effect after safety rules are applied. */
  registryMode: RegistryMode;
  /** Why the effective mode differs from what was requested, if it does. */
  modeNote: string | null;
  real: { baseUrl: string; apiKey: string; sourceLabel: string; supportedTypes: string[]; timeoutMs: number } | null;
  realConfigError: string | null;
  /** A registry result older than this is re-checked before a product is registered. */
  resultTtlHours: number;
  /** Whether an admin's manual licence review can qualify a seller for registration. */
  acceptManualReview: boolean;
}

type Env = Record<string, string | undefined>;

export function loadIdentityConfig(env: Env = process.env): IdentityConfig {
  const isProduction = env.NODE_ENV === 'production';
  const isDemoEnvironment = env.APP_ENVIRONMENT === 'demo';
  const requested = (env.LICENCE_REGISTRY_MODE || '').trim().toLowerCase();
  let registryMode: RegistryMode;
  let modeNote: string | null = null;

  if (requested === '') registryMode = isProduction ? 'off' : 'mock';
  else if (requested === 'mock' || requested === 'real' || requested === 'off') registryMode = requested;
  else {
    registryMode = 'off';
    modeNote = `LICENCE_REGISTRY_MODE="${requested}" is not recognised; licence checks are off.`;
  }

  if (registryMode === 'mock' && isProduction && !isDemoEnvironment) {
    registryMode = 'off';
    modeNote = 'The mock/demo registry is disabled in production unless APP_ENVIRONMENT=demo.';
  }

  let real: IdentityConfig['real'] = null;
  let realConfigError: string | null = null;
  if (registryMode === 'real') {
    const baseUrl = (env.LICENCE_REGISTRY_BASE_URL || '').trim();
    const apiKey = (env.LICENCE_REGISTRY_API_KEY || '').trim();
    const sourceLabel = (env.LICENCE_REGISTRY_SOURCE_LABEL || '').trim();
    if (!baseUrl || !apiKey || !sourceLabel) realConfigError = 'LICENCE_REGISTRY_BASE_URL, LICENCE_REGISTRY_API_KEY and LICENCE_REGISTRY_SOURCE_LABEL are required for LICENCE_REGISTRY_MODE=real.';
    else if (!/^https:\/\//i.test(baseUrl)) realConfigError = 'LICENCE_REGISTRY_BASE_URL must use https.';
    else {
      const timeoutMs = Number(env.LICENCE_REGISTRY_TIMEOUT_MS || 5000);
      real = {
        baseUrl: baseUrl.replace(/\/$/, ''),
        apiKey,
        sourceLabel,
        supportedTypes: (env.LICENCE_REGISTRY_SUPPORTED_TYPES || '').split(',').map((s) => s.trim()).filter(Boolean),
        timeoutMs: Number.isFinite(timeoutMs) && timeoutMs > 0 && timeoutMs <= 30_000 ? timeoutMs : 5000,
      };
    }
  }

  const ttl = Number(env.LICENCE_REGISTRY_RESULT_TTL_HOURS || 24);
  return {
    registryMode,
    modeNote,
    real,
    realConfigError,
    resultTtlHours: Number.isFinite(ttl) && ttl > 0 ? ttl : 24,
    acceptManualReview: env.LICENCE_ACCEPT_MANUAL_REVIEW === 'true',
  };
}

/** Today's calendar date in Bangladesh (Asia/Dhaka), used for every expiry comparison. */
export function todayInDhaka(now: Date = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka', year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
}
