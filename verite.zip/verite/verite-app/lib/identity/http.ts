import { NextRequest, NextResponse } from 'next/server';
import db from '../db';
import { getSession } from '../session';
import { FixedWindowLimiter } from '../trace/ratelimit';
import { loadIdentityConfig } from './config';
import { selectRegistryAdapter } from './registry';
import { IdentityError, type Actor } from './types';

// Route helpers shared by the identity API routes.

const STATUS: Record<string, number> = {
  UNAUTHENTICATED: 401, FORBIDDEN: 403, NOT_FOUND: 404, INVALID: 422, CONFLICT: 409, LOCKED: 409,
  INVALID_TRANSITION: 409, NOT_ELIGIBLE: 409, RATE_LIMITED: 429,
};

export function identityErrorResponse(err: unknown) {
  if (err instanceof IdentityError) {
    const field = err.detail && typeof err.detail.field === 'string' ? err.detail.field : undefined;
    return NextResponse.json({ success: false, code: err.code, message: err.message, ...(field ? { field } : {}) }, { status: STATUS[err.code] ?? 400 });
  }
  // Category only: never the error object, which could contain request data.
  console.error('Unexpected identity error:', (err as Error)?.name || 'unknown');
  return NextResponse.json({ success: false, message: 'Something went wrong. Please try again.' }, { status: 500 });
}

export async function actorFrom(req: NextRequest, role: 'SELLER' | 'ADMIN' | 'SELLER_OR_ADMIN'): Promise<Actor> {
  const s = await getSession(req);
  if (!s) throw new IdentityError('UNAUTHENTICATED', 'Sign in required.');
  const ok = role === 'SELLER_OR_ADMIN' ? s.role === 'SELLER' || s.role === 'ADMIN' : s.role === role;
  if (!ok) throw new IdentityError('FORBIDDEN', role === 'ADMIN' ? 'Administrator access required.' : 'Seller access required.');
  return { id: s.id, role: s.role };
}

/** State-changing routes accept JSON only; with SameSite=Lax cookies this blocks cross-site form posts. */
export function requireJson(req: NextRequest) {
  if (!(req.headers.get('content-type') || '').toLowerCase().startsWith('application/json')) {
    throw new IdentityError('INVALID', 'Requests must be sent as JSON.');
  }
}

export async function jsonBody(req: NextRequest): Promise<any> {
  requireJson(req);
  const text = await req.text();
  if (text.length > 20_000) throw new IdentityError('INVALID', 'Request is too large.');
  try { return JSON.parse(text || '{}'); } catch { throw new IdentityError('INVALID', 'Malformed JSON.'); }
}

const recheckLimiter = new FixedWindowLimiter(10);
export function limitRecheck(actor: Actor) {
  if (!recheckLimiter.allow(`recheck:${actor.id}`)) throw new IdentityError('RATE_LIMITED', 'Too many licence checks. Please wait a minute.');
}

export function identityRuntime() {
  const cfg = loadIdentityConfig();
  const adapter = selectRegistryAdapter(cfg, db as any);
  return {
    cfg,
    adapter,
    policy: { mockAllowed: cfg.registryMode === 'mock', acceptManualReview: cfg.acceptManualReview, resultTtlHours: cfg.resultTtlHours },
  };
}
