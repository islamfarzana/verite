// Seller onboarding, licence claims/checks and product identity references.
// Additive only: no existing table is altered. See docs/changes/seller-licence-verification/delta_spec.md.
//
// Rollback (only safe before any product was registered with hash schema v2):
//   DROP TABLE product_identity; DROP TABLE licence_check_events; DROP TABLE licence_records;
//   DROP TABLE entity_status_history; DROP TABLE entity_roles; DROP TABLE business_entities;
//   DROP TABLE IF EXISTS mock_licence_registry;

export const ENTITY_STATUSES = ['PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED'] as const;
export const ENTITY_ROLES = ['SELLER', 'MANUFACTURER', 'BRAND_OWNER'] as const;
export const LICENCE_TYPES = ['TRADE_LICENCE', 'BSTI_CM_LICENCE', 'BFSA_REGISTRATION', 'DGDA_LICENCE', 'OTHER'] as const;
export const CLAIMED_STATUSES = ['UNKNOWN', 'ACTIVE', 'EXPIRED', 'REVOKED', 'SUSPENDED', 'INVALID'] as const;
export const CHECK_RESULTS = [
  'NOT_CHECKED', 'VALID', 'INVALID', 'EXPIRED', 'REVOKED', 'SUSPENDED', 'NOT_FOUND', 'UNAVAILABLE', 'ERROR', 'UNSUPPORTED',
] as const;
export const VERIFICATION_METHODS = ['UNVERIFIED_CLAIM', 'MOCK_REGISTRY', 'REAL_REGISTRY_API', 'AUTHORIZED_MANUAL_REVIEW'] as const;

const list = (xs: readonly string[]) => xs.map((x) => `'${x}'`).join(',');

export const IDENTITY_SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS business_entities (
  id TEXT PRIMARY KEY,
  legal_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('ORGANIZATION','SOLE_PROPRIETOR')),
  contact_email TEXT,
  managed_by_user_id TEXT REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN (${list(ENTITY_STATUSES)})),
  status_reason_code TEXT,
  public_status_note TEXT,
  status_changed_at TEXT,
  status_changed_by TEXT REFERENCES users(id),
  submitted_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_entity_manager ON business_entities(managed_by_user_id) WHERE managed_by_user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_entity_status ON business_entities(status);

CREATE TABLE IF NOT EXISTS entity_roles (
  entity_id TEXT NOT NULL REFERENCES business_entities(id),
  role TEXT NOT NULL CHECK (role IN (${list(ENTITY_ROLES)})),
  PRIMARY KEY (entity_id, role)
);

CREATE TABLE IF NOT EXISTS entity_status_history (
  id TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL REFERENCES business_entities(id),
  previous_status TEXT,
  new_status TEXT NOT NULL CHECK (new_status IN (${list(ENTITY_STATUSES)})),
  reason_code TEXT NOT NULL,
  internal_note TEXT,
  public_note TEXT,
  actor_user_id TEXT REFERENCES users(id),
  actor_role TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_history_entity ON entity_status_history(entity_id, created_at);
CREATE TRIGGER IF NOT EXISTS trg_history_no_update BEFORE UPDATE ON entity_status_history
BEGIN SELECT RAISE(ABORT, 'entity_status_history is append-only'); END;
CREATE TRIGGER IF NOT EXISTS trg_history_no_delete BEFORE DELETE ON entity_status_history
BEGIN SELECT RAISE(ABORT, 'entity_status_history is append-only'); END;

CREATE TABLE IF NOT EXISTS licence_records (
  id TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL REFERENCES business_entities(id),
  licence_type TEXT NOT NULL CHECK (licence_type IN (${list(LICENCE_TYPES)})),
  licence_number TEXT NOT NULL,
  licence_number_normalized TEXT NOT NULL,
  issuing_authority TEXT NOT NULL,
  claimed_issue_date TEXT,
  claimed_expiry_date TEXT,
  claimed_status TEXT NOT NULL DEFAULT 'UNKNOWN' CHECK (claimed_status IN (${list(CLAIMED_STATUSES)})),
  claim_source TEXT NOT NULL CHECK (claim_source IN ('MANUAL_ENTRY','OCR_EXTRACTED')),
  check_result TEXT NOT NULL DEFAULT 'NOT_CHECKED' CHECK (check_result IN (${list(CHECK_RESULTS)})),
  verification_method TEXT NOT NULL DEFAULT 'UNVERIFIED_CLAIM' CHECK (verification_method IN (${list(VERIFICATION_METHODS)})),
  verification_environment TEXT CHECK (verification_environment IN ('DEMO','PRODUCTION')),
  source_label TEXT,
  registry_reference TEXT,
  registry_expiry_date TEXT,
  checked_at TEXT,
  last_attempt_at TEXT,
  error_category TEXT,
  reviewed_by TEXT REFERENCES users(id),
  superseded_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- One live claim per licence number and type across ALL entities: a second business cannot
-- silently claim the same licence (entities are never merged by email or name).
CREATE UNIQUE INDEX IF NOT EXISTS ux_licence_live ON licence_records(licence_type, licence_number_normalized) WHERE superseded_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_licence_entity ON licence_records(entity_id);

CREATE TABLE IF NOT EXISTS licence_check_events (
  id TEXT PRIMARY KEY,
  licence_id TEXT NOT NULL REFERENCES licence_records(id),
  trigger_reason TEXT NOT NULL CHECK (trigger_reason IN ('SUBMISSION','SELLER_RECHECK','ADMIN_RECHECK','PRE_REGISTRATION','MANUAL_REVIEW')),
  result TEXT NOT NULL CHECK (result IN (${list(CHECK_RESULTS)})),
  method TEXT NOT NULL CHECK (method IN (${list(VERIFICATION_METHODS)})),
  environment TEXT,
  source_label TEXT,
  registry_reference TEXT,
  checked_at TEXT,
  attempted_at TEXT NOT NULL,
  error_category TEXT,
  actor_user_id TEXT REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS ix_check_events_licence ON licence_check_events(licence_id, attempted_at);
CREATE TRIGGER IF NOT EXISTS trg_check_events_no_update BEFORE UPDATE ON licence_check_events
BEGIN SELECT RAISE(ABORT, 'licence_check_events is append-only'); END;
CREATE TRIGGER IF NOT EXISTS trg_check_events_no_delete BEFORE DELETE ON licence_check_events
BEGIN SELECT RAISE(ABORT, 'licence_check_events is append-only'); END;

CREATE TABLE IF NOT EXISTS product_identity (
  product_id TEXT PRIMARY KEY REFERENCES products(id),
  seller_entity_id TEXT REFERENCES business_entities(id),
  manufacturer_entity_id TEXT REFERENCES business_entities(id),
  brand_owner_entity_id TEXT REFERENCES business_entities(id),
  manufacturer_identity TEXT NOT NULL CHECK (manufacturer_identity IN ('ENTITY_REFERENCE','UNVERIFIED_CLAIM','UNKNOWN')),
  manufacturer_claim_name TEXT,
  label_licence_claim TEXT,
  hash_schema_version INTEGER,
  identity_snapshot_json TEXT,
  registration_basis TEXT CHECK (registration_basis IN ('REAL_REGISTRY','MANUAL_LICENCE_REVIEW','MOCK_REGISTRY_DEMO')),
  registered_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (manufacturer_identity <> 'ENTITY_REFERENCE' OR manufacturer_entity_id IS NOT NULL),
  CHECK (manufacturer_identity <> 'UNVERIFIED_CLAIM' OR (manufacturer_claim_name IS NOT NULL AND manufacturer_entity_id IS NULL)),
  CHECK (registered_at IS NULL OR (hash_schema_version IS NOT NULL AND identity_snapshot_json IS NOT NULL AND seller_entity_id IS NOT NULL))
);
-- Once a product is registered, its identity references and snapshot are frozen: historical
-- attribution survives later renames/suspensions, and the hash input cannot be silently rewritten.
CREATE TRIGGER IF NOT EXISTS trg_product_identity_frozen BEFORE UPDATE ON product_identity
WHEN OLD.registered_at IS NOT NULL
BEGIN SELECT RAISE(ABORT, 'product identity is frozen after registration'); END;
`;

// Created by the mock adapter only (never in a database where demo mode is off).
export const MOCK_REGISTRY_SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS mock_licence_registry (
  licence_type TEXT NOT NULL,
  licence_number_normalized TEXT NOT NULL,
  issuing_authority TEXT NOT NULL,
  holder_name TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','EXPIRED','REVOKED','SUSPENDED','INVALID','SIMULATE_OUTAGE')),
  expiry_date TEXT,
  reference TEXT NOT NULL,
  PRIMARY KEY (licence_type, licence_number_normalized)
);
`;
