import type { CHECK_RESULTS, CLAIMED_STATUSES, ENTITY_ROLES, ENTITY_STATUSES, LICENCE_TYPES, VERIFICATION_METHODS } from './schema';

export type { Db, Statement } from '../trace/types';

export type EntityStatus = (typeof ENTITY_STATUSES)[number];
export type EntityRole = (typeof ENTITY_ROLES)[number];
export type LicenceType = (typeof LICENCE_TYPES)[number];
export type ClaimedStatus = (typeof CLAIMED_STATUSES)[number];
export type CheckResult = (typeof CHECK_RESULTS)[number];
export type VerificationMethod = (typeof VERIFICATION_METHODS)[number];
export type RegistrationBasis = 'REAL_REGISTRY' | 'MANUAL_LICENCE_REVIEW' | 'MOCK_REGISTRY_DEMO';
export type ManufacturerIdentity = 'ENTITY_REFERENCE' | 'UNVERIFIED_CLAIM' | 'UNKNOWN';

export interface Actor {
  id: string;
  role: 'BUYER' | 'SELLER' | 'ADMIN';
}

export type IdentityErrorCode =
  | 'UNAUTHENTICATED' | 'FORBIDDEN' | 'NOT_FOUND' | 'INVALID' | 'CONFLICT' | 'LOCKED' | 'INVALID_TRANSITION' | 'NOT_ELIGIBLE' | 'RATE_LIMITED';

export class IdentityError extends Error {
  constructor(public code: IdentityErrorCode, message: string, public detail?: Record<string, unknown>) {
    super(message);
  }
}

export interface EntityRow {
  id: string;
  legal_name: string;
  display_name: string;
  entity_type: 'ORGANIZATION' | 'SOLE_PROPRIETOR';
  contact_email: string | null;
  managed_by_user_id: string | null;
  status: EntityStatus;
  status_reason_code: string | null;
  public_status_note: string | null;
  status_changed_at: string | null;
  submitted_at: string;
}

export interface LicenceRow {
  id: string;
  entity_id: string;
  licence_type: LicenceType;
  licence_number: string;
  licence_number_normalized: string;
  issuing_authority: string;
  claimed_issue_date: string | null;
  claimed_expiry_date: string | null;
  claimed_status: ClaimedStatus;
  claim_source: 'MANUAL_ENTRY' | 'OCR_EXTRACTED';
  check_result: CheckResult;
  verification_method: VerificationMethod;
  verification_environment: 'DEMO' | 'PRODUCTION' | null;
  source_label: string | null;
  registry_reference: string | null;
  registry_expiry_date: string | null;
  checked_at: string | null;
  last_attempt_at: string | null;
  error_category: string | null;
  superseded_at: string | null;
}
