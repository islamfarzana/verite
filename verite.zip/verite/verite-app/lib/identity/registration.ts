import { generateProductHash } from '../blockchain';
import type { PolicyContext } from './policy';
import { evaluateEligibility, isStale } from './policy';
import { computeProductHashV2, HASH_SCHEMA_VERSION, productFieldsFromRow, type IdentitySnapshotRefs } from './hash';
import { keccakUtf8 } from './keccak';
import { getEntity, getEntityForUser, getLicences, getRoles, runLicenceCheck, tx } from './onboarding';
import type { RegistryAdapter } from './registry';
import { IdentityError, type Actor, type Db, type LicenceRow, type ManufacturerIdentity, type RegistrationBasis } from './types';

// Product identity references, registration eligibility and the hash used at publish and verify.

export type ManufacturerInput =
  | { mode: 'SELF' }
  | { mode: 'CLAIM'; name: string }
  | { mode: 'UNKNOWN' }
  | { mode: 'ENTITY'; entityId: string };

export interface ProductIdentityRow {
  product_id: string;
  seller_entity_id: string | null;
  manufacturer_entity_id: string | null;
  brand_owner_entity_id: string | null;
  manufacturer_identity: ManufacturerIdentity;
  manufacturer_claim_name: string | null;
  label_licence_claim: string | null;
  hash_schema_version: number | null;
  identity_snapshot_json: string | null;
  registration_basis: RegistrationBasis | null;
  registered_at: string | null;
}

export interface IdentitySnapshot {
  refs: IdentitySnapshotRefs;
  registration: {
    basis: RegistrationBasis;
    sellerStatus: 'APPROVED';
    licence: null | {
      licenceId: string; licenceType: string; result: string; method: string; environment: string | null; sourceLabel: string | null; checkedAt: string | null;
    };
    registeredAt: string;
  };
}

export function getProductIdentity(db: Db, productId: string): ProductIdentityRow | undefined {
  return db.prepare('SELECT * FROM product_identity WHERE product_id = ?').get(productId) as ProductIdentityRow | undefined;
}

/**
 * Record who the seller says made the product, when the draft is created.
 * Never derived from an email. SELF is only possible when the seller's own reviewed business holds
 * the MANUFACTURER role; any other named manufacturer is stored as an UNVERIFIED claim.
 */
export function recordProductIdentity(
  db: Db, actor: Actor, productId: string,
  input: { manufacturer?: ManufacturerInput; brandOwnerIsSeller?: boolean; labelLicenceClaim?: string | null },
  now: () => Date = () => new Date()
) {
  if (actor.role !== 'SELLER' && actor.role !== 'ADMIN') throw new IdentityError('FORBIDDEN', 'Not allowed.');
  const product = db.prepare('SELECT id, seller_id FROM products WHERE id = ?').get(productId) as { id: string; seller_id: string } | undefined;
  if (!product || (actor.role === 'SELLER' && product.seller_id !== actor.id)) throw new IdentityError('NOT_FOUND', 'Product not found.');
  const sellerEntity = getEntityForUser(db, product.seller_id);
  const roles = sellerEntity ? getRoles(db, sellerEntity.id) : [];
  const m = input.manufacturer ?? { mode: 'UNKNOWN' as const };

  let manufacturerIdentity: ManufacturerIdentity = 'UNKNOWN';
  let manufacturerEntityId: string | null = null;
  let claimName: string | null = null;
  if (m.mode === 'SELF') {
    if (!sellerEntity || !roles.includes('MANUFACTURER')) {
      throw new IdentityError('INVALID', 'Your business profile does not list your business as a manufacturer. Name the manufacturer instead.', { field: 'manufacturer' });
    }
    manufacturerIdentity = 'ENTITY_REFERENCE';
    manufacturerEntityId = sellerEntity.id;
  } else if (m.mode === 'ENTITY') {
    // Referencing another business needs that business's authorisation; no seller flow for it exists yet.
    if (actor.role !== 'ADMIN') throw new IdentityError('FORBIDDEN', 'Only an administrator can link a product to another registered manufacturer.');
    const e = getEntity(db, m.entityId);
    if (!e || !getRoles(db, e.id).includes('MANUFACTURER')) throw new IdentityError('INVALID', 'That business is not a registered manufacturer.');
    manufacturerIdentity = 'ENTITY_REFERENCE';
    manufacturerEntityId = e.id;
  } else if (m.mode === 'CLAIM') {
    const name = typeof m.name === 'string' ? m.name.normalize('NFC').trim() : '';
    if (name.length < 2 || name.length > 200) throw new IdentityError('INVALID', 'Manufacturer name must be 2-200 characters.', { field: 'manufacturer' });
    manufacturerIdentity = 'UNVERIFIED_CLAIM';
    claimName = name;
  }

  let brandOwnerEntityId: string | null = null;
  if (input.brandOwnerIsSeller) {
    if (!sellerEntity || !roles.includes('BRAND_OWNER')) throw new IdentityError('INVALID', 'Your business profile does not list your business as a brand owner.', { field: 'brandOwnerIsSeller' });
    brandOwnerEntityId = sellerEntity.id;
  }
  const labelLicenceClaim = typeof input.labelLicenceClaim === 'string' && input.labelLicenceClaim.trim() ? input.labelLicenceClaim.trim().slice(0, 120) : null;
  const at = now().toISOString();

  db.prepare(
    `INSERT INTO product_identity (product_id, seller_entity_id, manufacturer_entity_id, brand_owner_entity_id, manufacturer_identity, manufacturer_claim_name,
       label_licence_claim, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(product_id) DO UPDATE SET seller_entity_id = excluded.seller_entity_id, manufacturer_entity_id = excluded.manufacturer_entity_id,
       brand_owner_entity_id = excluded.brand_owner_entity_id, manufacturer_identity = excluded.manufacturer_identity,
       manufacturer_claim_name = excluded.manufacturer_claim_name, label_licence_claim = excluded.label_licence_claim, updated_at = excluded.updated_at`
  ).run(productId, sellerEntity?.id ?? null, manufacturerEntityId, brandOwnerEntityId, manufacturerIdentity, claimName, labelLicenceClaim, at, at);
  return getProductIdentity(db, productId)!;
}

export interface RegistrationDeps {
  adapter: RegistryAdapter;
  policy: Omit<PolicyContext, 'now'>;
  now?: () => Date;
}

export type PreparedRegistration =
  | { ok: false; code: string; message: string }
  | { ok: true; alreadyRegistered: boolean; hash: string; snapshot: IdentitySnapshot; basis: RegistrationBasis };

function refsFromSnapshotJson(json: string): IdentitySnapshot {
  return JSON.parse(json) as IdentitySnapshot;
}

/**
 * Decide whether the product may be registered (published and anchored) and, if so, build the
 * identity snapshot and the v2 hash. Writes nothing except licence re-check results.
 */
export async function prepareRegistration(db: Db, actor: Actor, productId: string, deps: RegistrationDeps): Promise<PreparedRegistration> {
  const now = deps.now ?? (() => new Date());
  if (actor.role !== 'SELLER') throw new IdentityError('FORBIDDEN', 'Seller authentication required.');
  const product = db.prepare('SELECT * FROM products WHERE id = ? AND seller_id = ?').get(productId, actor.id) as Record<string, any> | undefined;
  if (!product) throw new IdentityError('NOT_FOUND', 'Product not found');

  const pi = getProductIdentity(db, productId);
  if (pi?.registered_at && pi.identity_snapshot_json) {
    // Already registered (e.g. the chain write is being retried): reuse the frozen snapshot.
    const snapshot = refsFromSnapshotJson(pi.identity_snapshot_json);
    return { ok: true, alreadyRegistered: true, snapshot, basis: snapshot.registration.basis, hash: computeProductHashV2(productFieldsFromRow(product), snapshot.refs, keccakUtf8) };
  }

  // A product already anchored under the legacy v1 rule keeps that commitment; it is never re-hashed.
  if (db.prepare('SELECT 1 FROM blockchain_records WHERE product_id = ?').get(productId)) {
    return { ok: false, code: 'LEGACY_RECORD_EXISTS', message: 'This product was registered before seller review existed (legacy record). Its original fingerprint is kept unchanged.' };
  }

  const entity = getEntityForUser(db, actor.id);
  if (entity?.status === 'APPROVED') {
    // Re-check registry-based results that are missing, failed or older than the TTL.
    for (const l of getLicences(db, entity.id)) {
      if (l.verification_method === 'AUTHORIZED_MANUAL_REVIEW' || deps.adapter.mode === 'NONE') continue;
      const needs = ['NOT_CHECKED', 'UNAVAILABLE', 'ERROR'].includes(l.check_result) || isStale(l.checked_at, { ...deps.policy, now: now() });
      if (needs) await runLicenceCheck(db, l.id, deps.adapter, 'PRE_REGISTRATION', actor, now);
    }
  }
  const licences = entity ? getLicences(db, entity.id) : [];
  const eligibility = evaluateEligibility(entity ?? null, licences, { ...deps.policy, now: now() });
  if (!eligibility.canRegister || !eligibility.basis || !entity) return { ok: false, code: eligibility.code, message: eligibility.message };

  // Identity references (validated again: roles or statuses may have changed since the draft).
  const roles = getRoles(db, entity.id);
  let manufacturer: IdentitySnapshotRefs['manufacturer'] = { identity: 'UNKNOWN', entityId: null, name: null };
  if (pi?.manufacturer_identity === 'ENTITY_REFERENCE' && pi.manufacturer_entity_id) {
    const m = getEntity(db, pi.manufacturer_entity_id);
    const ok = m && getRoles(db, m.id).includes('MANUFACTURER') && m.status === 'APPROVED';
    if (!ok) return { ok: false, code: 'MANUFACTURER_REFERENCE_INVALID', message: 'The manufacturer linked to this product is no longer an approved manufacturer. Edit the manufacturer before publishing.' };
    manufacturer = { identity: 'ENTITY_REFERENCE', entityId: m!.id, name: m!.display_name };
  } else if (pi?.manufacturer_identity === 'UNVERIFIED_CLAIM') {
    manufacturer = { identity: 'UNVERIFIED_CLAIM', entityId: null, name: pi.manufacturer_claim_name };
  }
  let brandOwner: IdentitySnapshotRefs['brandOwner'] = { entityId: null, name: null };
  if (pi?.brand_owner_entity_id) {
    const b = getEntity(db, pi.brand_owner_entity_id);
    if (!b || b.status !== 'APPROVED' || !getRoles(db, b.id).includes('BRAND_OWNER')) {
      return { ok: false, code: 'BRAND_OWNER_REFERENCE_INVALID', message: 'The brand owner linked to this product is no longer an approved brand owner.' };
    }
    brandOwner = { entityId: b.id, name: b.display_name };
  }
  if (!roles.includes('SELLER')) return { ok: false, code: 'NOT_A_SELLER_ENTITY', message: 'Your business profile does not hold the seller role.' };

  const refs: IdentitySnapshotRefs = { seller: { entityId: entity.id, displayName: entity.display_name }, manufacturer, brandOwner };
  const q = licences.find((l) => l.id === eligibility.qualifyingLicenceId) as LicenceRow | undefined;
  const snapshot: IdentitySnapshot = {
    refs,
    registration: {
      basis: eligibility.basis,
      sellerStatus: 'APPROVED',
      licence: q ? {
        licenceId: q.id, licenceType: q.licence_type, result: q.check_result, method: q.verification_method,
        environment: q.verification_environment, sourceLabel: q.source_label, checkedAt: q.checked_at,
      } : null,
      registeredAt: now().toISOString(),
    },
  };
  return { ok: true, alreadyRegistered: false, snapshot, basis: eligibility.basis, hash: computeProductHashV2(productFieldsFromRow(product), refs, keccakUtf8) };
}

/**
 * Freeze the identity snapshot and run the caller's own writes (blockchain record, product status)
 * in the same transaction, so a product is never published without its identity record.
 */
export function finalizeRegistration(db: Db, productId: string, prepared: Extract<PreparedRegistration, { ok: true }>, alsoWrite: () => void) {
  tx(db, () => {
    if (!prepared.alreadyRegistered) {
      const s = prepared.snapshot;
      const at = s.registration.registeredAt;
      const existing = getProductIdentity(db, productId);
      if (existing) {
        db.prepare(
          `UPDATE product_identity SET seller_entity_id = ?, hash_schema_version = ?, identity_snapshot_json = ?, registration_basis = ?, registered_at = ?, updated_at = ?
           WHERE product_id = ? AND registered_at IS NULL`
        ).run(s.refs.seller.entityId, HASH_SCHEMA_VERSION, JSON.stringify(s), prepared.basis, at, at, productId);
      } else {
        db.prepare(
          `INSERT INTO product_identity (product_id, seller_entity_id, manufacturer_identity, hash_schema_version, identity_snapshot_json, registration_basis, registered_at, created_at, updated_at)
           VALUES (?, ?, 'UNKNOWN', ?, ?, ?, ?, ?, ?)`
        ).run(productId, s.refs.seller.entityId, HASH_SCHEMA_VERSION, JSON.stringify(s), prepared.basis, at, at, at);
      }
    }
    alsoWrite();
  });
}

/**
 * The hash a product's CURRENT data should have, under the schema version it was registered with.
 * v2: product row + frozen identity snapshot. v1 (legacy, unchanged rule): product row + seller email.
 */
export function verificationHash(db: Db, product: Record<string, any> & { seller_email?: string | null }): { version: 1 | 2; hash: string } {
  const pi = getProductIdentity(db, product.id);
  if (pi?.hash_schema_version === 2 && pi.identity_snapshot_json) {
    const snapshot = refsFromSnapshotJson(pi.identity_snapshot_json);
    return { version: 2, hash: computeProductHashV2(productFieldsFromRow(product), snapshot.refs, keccakUtf8) };
  }
  return {
    version: 1,
    hash: generateProductHash({
      productId: product.id,
      brand: product.brand || '',
      productName: product.name,
      barcode: product.barcode || '',
      batchNumber: product.batch_number || '',
      manufacturingDate: product.manufacturing_date || '',
      expiryDate: product.expiry_date || '',
      manufacturer: product.seller_email || '',
    }),
  };
}
