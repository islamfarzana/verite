import { CHECK_RESULT_TEXT, ENTITY_STATUS_TEXT, LICENCE_TYPE_LABEL, MOCK_LABEL } from './labels';
import { adminHistory, allowedActions, checkEvents, getEntity, getEntityForUser, getLicences, getRoles, publicHistory } from './onboarding';
import { evaluateEligibility, type PolicyContext } from './policy';
import { IdentityError, type Actor, type Db, type LicenceRow } from './types';

// Response shapes for the seller status page and the admin review page.

export type Evidence = 'REAL_REGISTRY' | 'MOCK_DEMO_REGISTRY' | 'ADMIN_MANUAL_REVIEW' | 'UNVERIFIED_CLAIM' | 'UNABLE_TO_CHECK';

/** How much a licence's current state actually establishes — one label per distinct kind of evidence. */
export function evidenceOf(l: LicenceRow): Evidence {
  if (l.check_result === 'UNAVAILABLE' || l.check_result === 'ERROR') return 'UNABLE_TO_CHECK';
  if (l.check_result === 'NOT_CHECKED' || l.verification_method === 'UNVERIFIED_CLAIM') return 'UNVERIFIED_CLAIM';
  if (l.verification_method === 'MOCK_REGISTRY') return 'MOCK_DEMO_REGISTRY';
  if (l.verification_method === 'AUTHORIZED_MANUAL_REVIEW') return 'ADMIN_MANUAL_REVIEW';
  return 'REAL_REGISTRY';
}

function licenceView(l: LicenceRow, opts: { full: boolean }) {
  return {
    id: l.id,
    licenceType: l.licence_type,
    licenceTypeLabel: LICENCE_TYPE_LABEL[l.licence_type],
    licenceNumber: l.licence_number, // shown to the owner and admins only; never public
    issuingAuthority: l.issuing_authority,
    claimedIssueDate: l.claimed_issue_date,
    claimedExpiryDate: l.claimed_expiry_date,
    claimedStatus: l.claimed_status,
    claimSource: l.claim_source,
    checkResult: l.check_result,
    checkResultText: CHECK_RESULT_TEXT[l.check_result],
    verificationMethod: l.verification_method,
    verificationEnvironment: l.verification_environment,
    evidence: evidenceOf(l),
    isMock: l.verification_method === 'MOCK_REGISTRY',
    sourceLabel: l.source_label,
    registryExpiryDate: l.registry_expiry_date,
    checkedAt: l.checked_at,
    lastAttemptAt: l.last_attempt_at,
    errorCategory: l.error_category,
    supersededAt: l.superseded_at,
    ...(opts.full ? { registryReference: l.registry_reference } : {}),
  };
}

export function sellerOnboardingView(db: Db, actor: Actor, ctx: PolicyContext, registry: { mode: string; label: string; note: string | null }) {
  if (actor.role !== 'SELLER') throw new IdentityError('FORBIDDEN', 'Seller access required.');
  const entity = getEntityForUser(db, actor.id);
  const licences = entity ? getLicences(db, entity.id) : [];
  return {
    registry: { ...registry, mockLabel: MOCK_LABEL },
    entity: entity ? {
      legalName: entity.legal_name, displayName: entity.display_name, entityType: entity.entity_type, contactEmail: entity.contact_email,
      status: entity.status, statusText: ENTITY_STATUS_TEXT[entity.status], statusReasonCode: entity.status_reason_code,
      publicStatusNote: entity.public_status_note, submittedAt: entity.submitted_at, statusChangedAt: entity.status_changed_at,
      roles: getRoles(db, entity.id),
    } : null,
    licences: licences.map((l) => licenceView(l, { full: false })),
    history: entity ? publicHistory(db, entity.id) : [],
    eligibility: evaluateEligibility(entity ?? null, licences, ctx),
  };
}

export function adminEntityView(db: Db, actor: Actor, entityId: string, ctx: PolicyContext) {
  if (actor.role !== 'ADMIN') throw new IdentityError('FORBIDDEN', 'Administrator access required.');
  const entity = getEntity(db, entityId);
  if (!entity) throw new IdentityError('NOT_FOUND', 'Business not found.');
  const live = getLicences(db, entityId);
  const all = getLicences(db, entityId, true);
  const manager = entity.managed_by_user_id
    ? (db.prepare('SELECT name, email FROM users WHERE id = ?').get(entity.managed_by_user_id) as { name: string; email: string } | undefined)
    : undefined;
  return {
    entity: {
      id: entity.id, legalName: entity.legal_name, displayName: entity.display_name, entityType: entity.entity_type, contactEmail: entity.contact_email,
      status: entity.status, statusText: ENTITY_STATUS_TEXT[entity.status], statusReasonCode: entity.status_reason_code,
      publicStatusNote: entity.public_status_note, submittedAt: entity.submitted_at, statusChangedAt: entity.status_changed_at,
      roles: getRoles(db, entity.id), managedBy: manager ?? null, selfManaged: entity.managed_by_user_id === actor.id,
    },
    allowedActions: entity.managed_by_user_id === actor.id ? [] : allowedActions(entity.status),
    licences: all.map((l) => ({ ...licenceView(l, { full: true }), events: checkEvents(db, l.id) })),
    history: adminHistory(db, entityId),
    eligibilityIfApproved: evaluateEligibility({ status: 'APPROVED' }, live, ctx),
  };
}
