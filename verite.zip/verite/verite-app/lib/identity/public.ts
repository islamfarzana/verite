import { CHECK_RESULT_TEXT, ENTITY_STATUS_TEXT, LICENCE_TYPE_LABEL, MANUFACTURER_IDENTITY_TEXT, MOCK_LABEL } from './labels';
import { getEntity, getLicence } from './onboarding';
import { getProductIdentity, type IdentitySnapshot } from './registration';
import type { Db } from './types';

// Public, minimised identity summary for a product page or verification result.
// Never includes: emails, entity/user/licence IDs, licence numbers, internal notes, registry references.

const BASIS_TEXT: Record<string, string> = {
  REAL_REGISTRY: 'Seller licence confirmed by the configured licence registry before registration',
  MANUAL_LICENCE_REVIEW: 'Seller licence reviewed manually by a Verité administrator (not a registry lookup)',
  MOCK_REGISTRY_DEMO: `Seller licence checked against the ${MOCK_LABEL}`,
};

export function publicIdentityFor(db: Db, productId: string) {
  const pi = getProductIdentity(db, productId);
  if (!pi?.registered_at || !pi.identity_snapshot_json) {
    const legacy = db.prepare('SELECT 1 FROM blockchain_records WHERE product_id = ?').get(productId);
    return {
      hashSchemaVersion: legacy ? 1 : null,
      legacy: !!legacy,
      registered: false,
      note: legacy
        ? 'Legacy record: registered before seller review and manufacturer identity were introduced. The seller was not reviewed and the manufacturer was not recorded.'
        : 'Not registered yet.',
      manufacturer: { name: pi?.manufacturer_claim_name ?? null, identity: legacy ? 'NOT_RECORDED_LEGACY' : pi?.manufacturer_identity ?? 'UNKNOWN',
        identityText: MANUFACTURER_IDENTITY_TEXT[legacy ? 'NOT_RECORDED_LEGACY' : pi?.manufacturer_identity ?? 'UNKNOWN'] },
      labelLicenceClaim: pi?.label_licence_claim ?? null,
      warnings: legacy ? ['LEGACY_RECORD'] : [],
    };
  }

  const s = JSON.parse(pi.identity_snapshot_json) as IdentitySnapshot;
  const sellerNow = getEntity(db, s.refs.seller.entityId);
  const manufacturerIdentity =
    s.refs.manufacturer.identity === 'ENTITY_REFERENCE' && s.refs.manufacturer.entityId === s.refs.seller.entityId
      ? 'SAME_ENTITY_AS_SELLER'
      : s.refs.manufacturer.identity;
  const lic = s.registration.licence;
  const licNow = lic ? getLicence(db, lic.licenceId) : undefined;
  const isMock = lic?.method === 'MOCK_REGISTRY';
  const warnings: string[] = [];
  if (isMock) warnings.push('DEMO_REGISTRY_RESULT');
  if (sellerNow && sellerNow.status !== 'APPROVED') warnings.push(`SELLER_${sellerNow.status}_AFTER_REGISTRATION`);
  if (lic && licNow && (licNow.superseded_at ? false : licNow.check_result !== 'VALID')) warnings.push('LICENCE_STATUS_CHANGED_AFTER_REGISTRATION');

  return {
    hashSchemaVersion: 2,
    legacy: false,
    registered: true,
    registeredAt: s.registration.registeredAt,
    registrationBasis: s.registration.basis,
    registrationBasisText: BASIS_TEXT[s.registration.basis],
    seller: {
      name: s.refs.seller.displayName,
      statusAtRegistration: s.registration.sellerStatus,
      currentStatus: sellerNow?.status ?? null,
      currentStatusText: sellerNow ? ENTITY_STATUS_TEXT[sellerNow.status] : null,
      identityReview: 'ADMIN_REVIEWED',
    },
    manufacturer: { name: s.refs.manufacturer.name, identity: manufacturerIdentity, identityText: MANUFACTURER_IDENTITY_TEXT[manufacturerIdentity] },
    brandOwner: s.refs.brandOwner.entityId ? { name: s.refs.brandOwner.name } : null,
    licence: lic ? {
      type: lic.licenceType,
      typeLabel: LICENCE_TYPE_LABEL[lic.licenceType] ?? lic.licenceType,
      method: lic.method,
      isMock,
      isRegistryResult: lic.method === 'REAL_REGISTRY_API',
      sourceLabel: lic.sourceLabel,
      resultAtRegistration: lic.result,
      checkedAt: lic.checkedAt,
      currentResult: licNow?.superseded_at ? 'SUPERSEDED_BY_RENEWAL' : licNow?.check_result ?? null,
      currentResultText: licNow?.superseded_at ? 'Replaced by a newer licence' : licNow ? CHECK_RESULT_TEXT[licNow.check_result] : null,
      currentCheckedAt: licNow?.checked_at ?? null,
    } : null,
    labelLicenceClaim: pi.label_licence_claim,
    warnings,
  };
}
