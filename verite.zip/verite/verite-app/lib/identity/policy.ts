import { todayInDhaka } from './config';
import type { EntityStatus, LicenceRow, RegistrationBasis } from './types';

// THE product-registration eligibility policy. Every caller (publish route, seller status page,
// admin page) uses this one function so the rule cannot drift between controllers.
// Conservative default, not legal advice: the project has no per-category licence requirements,
// so every product needs the seller to be APPROVED and to hold at least one qualifying licence.

export type EligibilityCode =
  | 'NO_BUSINESS_PROFILE' | 'ENTITY_PENDING' | 'ENTITY_REJECTED' | 'ENTITY_SUSPENDED' | 'NO_LICENCE'
  | 'LICENCE_REVOKED' | 'LICENCE_SUSPENDED' | 'LICENCE_EXPIRED' | 'LICENCE_INVALID' | 'LICENCE_NOT_FOUND'
  | 'REGISTRY_UNAVAILABLE' | 'VERIFICATION_UNSUPPORTED' | 'MOCK_NOT_ALLOWED' | 'MANUAL_REVIEW_NOT_ACCEPTED'
  | 'LICENCE_UNVERIFIED' | 'ELIGIBLE_REAL_REGISTRY' | 'ELIGIBLE_MANUAL_REVIEW' | 'ELIGIBLE_DEMO_ONLY';

export interface PolicyContext {
  mockAllowed: boolean;
  acceptManualReview: boolean;
  resultTtlHours: number;
  now: Date;
}

export interface Eligibility {
  canSaveDraft: boolean;
  canRegister: boolean;
  basis: RegistrationBasis | null;
  code: EligibilityCode;
  message: string;
  qualifyingLicenceId: string | null;
}

export const ELIGIBILITY_MESSAGES: Record<EligibilityCode, string> = {
  NO_BUSINESS_PROFILE: 'Submit your business profile and licence for review before publishing products.',
  ENTITY_PENDING: 'Your business profile is waiting for admin review. You can save drafts, but products cannot be published yet.',
  ENTITY_REJECTED: 'Your business application was rejected. Correct it and resubmit before publishing products.',
  ENTITY_SUSPENDED: 'Your business is suspended. Products cannot be published until an admin review is completed.',
  NO_LICENCE: 'Add a licence to your business profile before publishing products.',
  LICENCE_REVOKED: 'A licence on your profile is reported as revoked. Products cannot be published.',
  LICENCE_SUSPENDED: 'A licence on your profile is reported as suspended. Products cannot be published.',
  LICENCE_EXPIRED: 'Your licence has expired. Submit a renewed licence to publish products.',
  LICENCE_INVALID: 'Your licence was reported as invalid. Submit corrected licence details.',
  LICENCE_NOT_FOUND: 'Your licence number was not found in the registry consulted. Check the number and resubmit.',
  REGISTRY_UNAVAILABLE: 'Your licence could not be checked right now, so products cannot be published yet. Try the licence check again later.',
  VERIFICATION_UNSUPPORTED: 'The configured registry cannot check this licence type, so it remains unverified.',
  MOCK_NOT_ALLOWED: 'Your licence was only checked against the demo registry, which does not count outside demo mode.',
  MANUAL_REVIEW_NOT_ACCEPTED: 'Your licence was reviewed manually, but this deployment requires a registry check.',
  LICENCE_UNVERIFIED: 'Your licence is a submitted claim that has not been verified yet.',
  ELIGIBLE_REAL_REGISTRY: 'Eligible: business approved and licence confirmed by the configured registry.',
  ELIGIBLE_MANUAL_REVIEW: 'Eligible: business approved and licence reviewed manually by an authorised admin.',
  ELIGIBLE_DEMO_ONLY: 'Eligible in DEMO MODE ONLY: the licence was checked against the mock/demo registry, which is not official verification.',
};

const HARD_BLOCKS: EligibilityCode[] = ['LICENCE_REVOKED', 'LICENCE_SUSPENDED'];
const SOFT_ORDER: EligibilityCode[] = [
  'LICENCE_EXPIRED', 'LICENCE_INVALID', 'LICENCE_NOT_FOUND', 'REGISTRY_UNAVAILABLE', 'VERIFICATION_UNSUPPORTED',
  'MOCK_NOT_ALLOWED', 'MANUAL_REVIEW_NOT_ACCEPTED', 'LICENCE_UNVERIFIED',
];
const BASIS_RANK: RegistrationBasis[] = ['REAL_REGISTRY', 'MANUAL_LICENCE_REVIEW', 'MOCK_REGISTRY_DEMO'];

type LicenceView = Pick<LicenceRow, 'id' | 'check_result' | 'verification_method' | 'checked_at' | 'registry_expiry_date' | 'claimed_expiry_date' | 'superseded_at'>;

export function isStale(checkedAt: string | null, ctx: Pick<PolicyContext, 'resultTtlHours' | 'now'>): boolean {
  if (!checkedAt) return true;
  return ctx.now.getTime() - new Date(checkedAt).getTime() > ctx.resultTtlHours * 3_600_000;
}

/** Classify one licence: either the basis it qualifies for, or the reason it does not. */
export function classifyLicence(l: LicenceView, ctx: PolicyContext): { basis: RegistrationBasis | null; code: EligibilityCode } {
  if (l.verification_method === 'MOCK_REGISTRY' && !ctx.mockAllowed) return { basis: null, code: 'MOCK_NOT_ALLOWED' };
  switch (l.check_result) {
    case 'REVOKED': return { basis: null, code: 'LICENCE_REVOKED' };
    case 'SUSPENDED': return { basis: null, code: 'LICENCE_SUSPENDED' };
    case 'EXPIRED': return { basis: null, code: 'LICENCE_EXPIRED' };
    case 'INVALID': return { basis: null, code: 'LICENCE_INVALID' };
    case 'NOT_FOUND': return { basis: null, code: 'LICENCE_NOT_FOUND' };
    case 'UNAVAILABLE': case 'ERROR': return { basis: null, code: 'REGISTRY_UNAVAILABLE' };
    case 'UNSUPPORTED': return { basis: null, code: 'VERIFICATION_UNSUPPORTED' };
    case 'NOT_CHECKED': return { basis: null, code: 'LICENCE_UNVERIFIED' };
    case 'VALID': break;
  }
  const expiry = l.registry_expiry_date || l.claimed_expiry_date;
  if (expiry && expiry < todayInDhaka(ctx.now)) return { basis: null, code: 'LICENCE_EXPIRED' };
  if (l.verification_method === 'AUTHORIZED_MANUAL_REVIEW') {
    return ctx.acceptManualReview ? { basis: 'MANUAL_LICENCE_REVIEW', code: 'ELIGIBLE_MANUAL_REVIEW' } : { basis: null, code: 'MANUAL_REVIEW_NOT_ACCEPTED' };
  }
  // A registry "VALID" is only trusted for a limited time; a stale one must be re-checked first.
  if (isStale(l.checked_at, ctx)) return { basis: null, code: 'REGISTRY_UNAVAILABLE' };
  if (l.verification_method === 'REAL_REGISTRY_API') return { basis: 'REAL_REGISTRY', code: 'ELIGIBLE_REAL_REGISTRY' };
  if (l.verification_method === 'MOCK_REGISTRY') return { basis: 'MOCK_REGISTRY_DEMO', code: 'ELIGIBLE_DEMO_ONLY' };
  return { basis: null, code: 'LICENCE_UNVERIFIED' };
}

export function evaluateEligibility(entity: { status: EntityStatus } | null, licences: LicenceView[], ctx: PolicyContext): Eligibility {
  const deny = (code: EligibilityCode): Eligibility => ({
    canSaveDraft: true, canRegister: false, basis: null, code, message: ELIGIBILITY_MESSAGES[code], qualifyingLicenceId: null,
  });
  if (!entity) return deny('NO_BUSINESS_PROFILE');
  if (entity.status !== 'APPROVED') return deny(`ENTITY_${entity.status}` as EligibilityCode);

  const live = licences.filter((l) => !l.superseded_at);
  if (!live.length) return deny('NO_LICENCE');

  const classified = live.map((l) => ({ l, ...classifyLicence(l, ctx) }));
  const hard = HARD_BLOCKS.find((c) => classified.some((x) => x.code === c));
  if (hard) return deny(hard);

  for (const basis of BASIS_RANK) {
    const hit = classified.find((x) => x.basis === basis);
    if (hit) return { canSaveDraft: true, canRegister: true, basis, code: hit.code, message: ELIGIBILITY_MESSAGES[hit.code], qualifyingLicenceId: hit.l.id };
  }
  return deny(SOFT_ORDER.find((c) => classified.some((x) => x.code === c)) || 'LICENCE_UNVERIFIED');
}
