import type { IdentityConfig } from './config';
import { todayInDhaka } from './config';
import { MOCK_LABEL, UNCONFIGURED_LABEL } from './labels';
import { MOCK_REGISTRY_RECORDS } from './mock-registry-data';
import { MOCK_REGISTRY_SCHEMA_SQL } from './schema';
import type { CheckResult, Db, VerificationMethod } from './types';

// Registry adapter contract. The application only ever sees a normalised RegistryResult;
// which adapter answers is decided by server configuration (lib/identity/config.ts).

export interface RegistryQuery {
  licenceType: string;
  licenceNumber: string;
  issuingAuthority: string;
}

export interface RegistryResult {
  outcome: Exclude<CheckResult, 'NOT_CHECKED'>;
  mode: 'MOCK' | 'REAL' | 'NONE';
  method: VerificationMethod;
  environment: 'DEMO' | 'PRODUCTION' | null;
  sourceLabel: string;
  /** Set only when a registry actually answered. Never set for timeouts, errors or "not configured". */
  checkedAt: string | null;
  reference: string | null;
  expiryDate: string | null;
  /** Non-sensitive failure category, e.g. TIMEOUT, NETWORK, HTTP_503, MALFORMED_RESPONSE. */
  errorCategory: string | null;
}

export interface RegistryAdapter {
  readonly name: string;
  readonly mode: 'MOCK' | 'REAL' | 'NONE';
  readonly sourceLabel: string;
  check(q: RegistryQuery): Promise<RegistryResult>;
}

export function normalizeLicenceNumber(raw: string): string {
  return raw.normalize('NFKC').toUpperCase().replace(/\s+/g, '');
}

const isoNow = (now: () => Date) => now().toISOString();

/** Apply the expiry date (Asia/Dhaka calendar day) to an otherwise-active result. */
function applyExpiry(expiryDate: string | null, today: string): 'VALID' | 'EXPIRED' {
  return expiryDate && expiryDate < today ? 'EXPIRED' : 'VALID';
}

// ---------------------------------------------------------------------------------------------
// No registry configured (production default, or real mode with missing settings).
export class UnconfiguredRegistryAdapter implements RegistryAdapter {
  readonly name = 'unconfigured';
  readonly mode = 'NONE' as const;
  readonly sourceLabel = UNCONFIGURED_LABEL;
  constructor(private reason = 'NOT_CONFIGURED') {}
  async check(_q?: RegistryQuery): Promise<RegistryResult> {
    return {
      outcome: 'UNAVAILABLE', mode: 'NONE', method: 'UNVERIFIED_CLAIM', environment: null, sourceLabel: this.sourceLabel,
      checkedAt: null, reference: null, expiryDate: null, errorCategory: this.reason,
    };
  }
}

// ---------------------------------------------------------------------------------------------
// Mock/demo registry backed by a local table of SYNTHETIC records (lib/identity/mock-registry-data.ts).
export const MOCK_SUPPORTED_TYPES = ['TRADE_LICENCE', 'BSTI_CM_LICENCE'];

export function ensureMockRegistry(db: Db) {
  db.exec(MOCK_REGISTRY_SCHEMA_SQL);
  const ins = db.prepare(
    `INSERT OR IGNORE INTO mock_licence_registry (licence_type, licence_number_normalized, issuing_authority, holder_name, status, expiry_date, reference)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  for (const r of MOCK_REGISTRY_RECORDS) {
    ins.run(r.licenceType, normalizeLicenceNumber(r.licenceNumber), r.issuingAuthority, r.holderName, r.status, r.expiryDate, r.reference);
  }
}

export class MockRegistryAdapter implements RegistryAdapter {
  readonly name = 'mock-demo-registry';
  readonly mode = 'MOCK' as const;
  readonly sourceLabel = MOCK_LABEL;
  constructor(private db: Db, private now: () => Date = () => new Date()) {
    ensureMockRegistry(db);
  }

  private result(outcome: RegistryResult['outcome'], extra: Partial<RegistryResult> = {}): RegistryResult {
    return {
      outcome, mode: 'MOCK', method: 'MOCK_REGISTRY', environment: 'DEMO', sourceLabel: MOCK_LABEL,
      checkedAt: isoNow(this.now), reference: null, expiryDate: null, errorCategory: null, ...extra,
    };
  }

  async check(q: RegistryQuery): Promise<RegistryResult> {
    if (!MOCK_SUPPORTED_TYPES.includes(q.licenceType)) return this.result('UNSUPPORTED', { checkedAt: null, errorCategory: 'UNSUPPORTED_TYPE' });
    const row = this.db
      .prepare('SELECT status, expiry_date, reference FROM mock_licence_registry WHERE licence_type = ? AND licence_number_normalized = ?')
      .get(q.licenceType, normalizeLicenceNumber(q.licenceNumber)) as { status: string; expiry_date: string | null; reference: string } | undefined;
    if (!row) return this.result('NOT_FOUND');
    if (row.status === 'SIMULATE_OUTAGE') return this.result('UNAVAILABLE', { checkedAt: null, errorCategory: 'SIMULATED_OUTAGE' });
    const base = { reference: row.reference, expiryDate: row.expiry_date };
    if (row.status === 'ACTIVE') return this.result(applyExpiry(row.expiry_date, todayInDhaka(this.now())), base);
    return this.result(row.status as RegistryResult['outcome'], base);
  }
}

// ---------------------------------------------------------------------------------------------
// Generic HTTPS client for a registry the deployer is AUTHORISED to use. Not connected to any real
// registry in this project: no official BSTI / trade-licence / BFSA / DGDA API is configured.
// Expected contract: GET {baseUrl}/licences/lookup?type=&number=&authority=
//   200 {"status":"ACTIVE|EXPIRED|REVOKED|SUSPENDED|INVALID|NOT_FOUND","expiryDate"?:"YYYY-MM-DD","reference"?:string}
export type FetchLike = (url: string, init: { method: string; headers: Record<string, string>; signal: AbortSignal }) => Promise<{
  status: number;
  json(): Promise<unknown>;
}>;

export class HttpRegistryAdapter implements RegistryAdapter {
  readonly name = 'http-registry';
  readonly mode = 'REAL' as const;
  constructor(
    private cfg: NonNullable<IdentityConfig['real']>,
    private fetchImpl: FetchLike = fetch as unknown as FetchLike,
    private now: () => Date = () => new Date()
  ) {}
  get sourceLabel() { return this.cfg.sourceLabel; }

  private result(outcome: RegistryResult['outcome'], extra: Partial<RegistryResult> = {}): RegistryResult {
    return {
      outcome, mode: 'REAL', method: 'REAL_REGISTRY_API', environment: 'PRODUCTION', sourceLabel: this.cfg.sourceLabel,
      checkedAt: null, reference: null, expiryDate: null, errorCategory: null, ...extra,
    };
  }

  async check(q: RegistryQuery): Promise<RegistryResult> {
    if (this.cfg.supportedTypes.length && !this.cfg.supportedTypes.includes(q.licenceType)) {
      return this.result('UNSUPPORTED', { errorCategory: 'UNSUPPORTED_TYPE' });
    }
    const url = `${this.cfg.baseUrl}/licences/lookup?` + new URLSearchParams({
      type: q.licenceType, number: normalizeLicenceNumber(q.licenceNumber), authority: q.issuingAuthority,
    }).toString();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.cfg.timeoutMs);
    let res: { status: number; json(): Promise<unknown> };
    try {
      res = await this.fetchImpl(url, {
        method: 'GET',
        headers: { Authorization: `Bearer ${this.cfg.apiKey}`, Accept: 'application/json' },
        signal: controller.signal,
      });
    } catch (err) {
      const aborted = controller.signal.aborted || (err as Error)?.name === 'AbortError';
      return this.result('UNAVAILABLE', { errorCategory: aborted ? 'TIMEOUT' : 'NETWORK' });
    } finally {
      clearTimeout(timer);
    }

    if (res.status === 401 || res.status === 403) return this.result('ERROR', { errorCategory: `AUTH_${res.status}` });
    if (res.status === 429) return this.result('UNAVAILABLE', { errorCategory: 'RATE_LIMITED' });
    if (res.status >= 500) return this.result('UNAVAILABLE', { errorCategory: `HTTP_${res.status}` });
    const answeredAt = isoNow(this.now);
    if (res.status === 404) return this.result('NOT_FOUND', { checkedAt: answeredAt });
    if (res.status !== 200) return this.result('ERROR', { errorCategory: `HTTP_${res.status}` });

    let body: any;
    try { body = await res.json(); } catch { return this.result('ERROR', { errorCategory: 'MALFORMED_RESPONSE' }); }
    if (!body || typeof body !== 'object' || typeof body.status !== 'string') return this.result('ERROR', { errorCategory: 'MALFORMED_RESPONSE' });
    const expiryDate = typeof body.expiryDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(body.expiryDate) ? body.expiryDate : null;
    const reference = typeof body.reference === 'string' ? body.reference.slice(0, 120) : null;
    const extra = { checkedAt: answeredAt, expiryDate, reference };
    switch (body.status) {
      case 'ACTIVE': return this.result(applyExpiry(expiryDate, todayInDhaka(this.now())), extra);
      case 'EXPIRED': case 'REVOKED': case 'SUSPENDED': case 'INVALID': case 'NOT_FOUND':
        return this.result(body.status, extra);
      default: return this.result('ERROR', { errorCategory: 'MALFORMED_RESPONSE' });
    }
  }
}

// ---------------------------------------------------------------------------------------------
export function selectRegistryAdapter(cfg: IdentityConfig, db: Db, deps: { fetchImpl?: FetchLike; now?: () => Date } = {}): RegistryAdapter {
  if (cfg.registryMode === 'mock') return new MockRegistryAdapter(db, deps.now);
  if (cfg.registryMode === 'real') {
    // A misconfigured real registry is "unavailable" — it never falls back to the mock.
    if (!cfg.real) return new UnconfiguredRegistryAdapter('REAL_REGISTRY_MISCONFIGURED');
    return new HttpRegistryAdapter(cfg.real, deps.fetchImpl, deps.now);
  }
  return new UnconfiguredRegistryAdapter();
}
