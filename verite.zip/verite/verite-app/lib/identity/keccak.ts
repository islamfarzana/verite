import { keccak256, toUtf8Bytes } from 'ethers';
import type { Utf8Hasher } from './hash';

// The same Keccak-256 used by lib/blockchain.ts (v1) and the Ethereum/Polygon contract.
export const keccakUtf8: Utf8Hasher = (s) => keccak256(toUtf8Bytes(s));
