// Product metadata hash, schema version 2.
//
// v1 (lib/blockchain.ts, unchanged) hashed 8 flat fields and used the SELLER'S EMAIL as
// "manufacturer". v2 commits to stable entity references and a registration-time identity snapshot.
// The algorithm is still Keccak-256 over canonical JSON, so the ProductRegistry contract is unchanged.
// Existing v1 commitments are never recomputed with v2 rules (see verificationHash in registration.ts).
//
// Not hashed on purpose: licence numbers, check results, check times and statuses. They change over
// time and are kept as separate, timestamped evidence; including them would make an honest product
// fail verification the day a licence is re-checked.

export const HASH_SCHEMA_VERSION = 2 as const;

export interface IdentitySnapshotRefs {
  seller: { entityId: string; displayName: string };
  manufacturer: { identity: 'ENTITY_REFERENCE' | 'UNVERIFIED_CLAIM' | 'UNKNOWN'; entityId: string | null; name: string | null };
  brandOwner: { entityId: string | null; name: string | null };
}

export interface ProductFieldsV2 {
  productId: string;
  productName: string;
  brand: string;
  barcode: string;
  batchNumber: string;
  manufacturingDate: string;
  expiryDate: string;
}

export type Utf8Hasher = (s: string) => string;

/** Deterministic JSON: keys sorted at every level, strings NFC-normalised and trimmed, undefined -> null. */
export function canonicalizeV2(value: unknown): string {
  const norm = (v: unknown): unknown => {
    if (v === undefined || v === null) return null;
    if (typeof v === 'string') return v.normalize('NFC').trim();
    if (typeof v === 'number') {
      if (!Number.isInteger(v)) throw new Error('canonicalizeV2: only integers are allowed');
      return v;
    }
    if (typeof v === 'boolean') return v;
    if (Array.isArray(v)) return v.map(norm);
    if (typeof v === 'object') {
      const out: Record<string, unknown> = {};
      for (const k of Object.keys(v as object).sort()) out[k] = norm((v as Record<string, unknown>)[k]);
      return out;
    }
    throw new Error(`canonicalizeV2: unsupported type ${typeof v}`);
  };
  return JSON.stringify(norm(value));
}

export function buildHashPayloadV2(p: ProductFieldsV2, refs: IdentitySnapshotRefs) {
  return {
    schemaVersion: HASH_SCHEMA_VERSION,
    ...p,
    seller: { entityId: refs.seller.entityId, displayName: refs.seller.displayName },
    manufacturer: { identity: refs.manufacturer.identity, entityId: refs.manufacturer.entityId, name: refs.manufacturer.name },
    brandOwner: { entityId: refs.brandOwner.entityId, name: refs.brandOwner.name },
  };
}

export function computeProductHashV2(p: ProductFieldsV2, refs: IdentitySnapshotRefs, keccakUtf8: Utf8Hasher): string {
  return keccakUtf8(canonicalizeV2(buildHashPayloadV2(p, refs)));
}

export function productFieldsFromRow(row: Record<string, any>): ProductFieldsV2 {
  return {
    productId: row.id,
    productName: row.name,
    brand: row.brand || '',
    barcode: row.barcode || '',
    batchNumber: row.batch_number || '',
    manufacturingDate: row.manufacturing_date || '',
    expiryDate: row.expiry_date || '',
  };
}
