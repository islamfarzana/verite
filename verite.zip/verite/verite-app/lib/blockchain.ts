import { keccak256, toUtf8Bytes } from 'ethers';

// Mirrors 05_Blockchain_Module.md "Canonical Serialization Rules":
// sort keys alphabetically, trim strings, no whitespace, UTF-8, ISO dates.
export function canonicalize(obj: Record<string, unknown>): string {
  const sorted: Record<string, unknown> = {};
  Object.keys(obj)
    .sort()
    .forEach((k) => {
      const v = obj[k];
      sorted[k] = typeof v === 'string' ? v.trim() : v;
    });
  return JSON.stringify(sorted);
}

export interface CanonicalProduct {
  productId: string;
  brand: string;
  productName: string;
  barcode: string;
  batchNumber: string;
  manufacturingDate: string;
  expiryDate: string;
  manufacturer: string;
}

// This is a REAL Keccak-256 hash (same algorithm Ethereum/Polygon use),
// computed with ethers.js — not a mock. What's simulated is only the
// on-chain write itself (no live RPC call to a funded Polygon wallet),
// since that requires real gas funds and a private key. The hashing,
// comparison, and tamper-detection logic are fully real and deterministic.
export function generateProductHash(p: CanonicalProduct): string {
  const json = canonicalize(p as unknown as Record<string, unknown>);
  return keccak256(toUtf8Bytes(json));
}

// Deterministic "transaction" derived from the hash, standing in for a
// real Polygon tx until this is wired to a funded wallet + RPC endpoint.
export function simulateChainWrite(hash: string) {
  const txHash = keccak256(toUtf8Bytes(hash + ':tx'));
  const blockNumber = 45_000_000 + (parseInt(hash.slice(2, 8), 16) % 900_000);
  return { txHash, blockNumber };
}
