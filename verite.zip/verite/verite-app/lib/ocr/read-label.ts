import { createWorker } from 'tesseract.js';
import sharp from 'sharp';
import { extractFieldsFromOcrText } from '@/lib/ocr-extract';

// Shared OCR step (moved unchanged out of app/api/ocr/extract/route.ts in v5 so the buyer label check
// uses exactly the same OCR as the seller studio):
//   OCR microservice (OCR_SERVICE_URL: FastAPI/OpenCV/Tesseract ben+eng/PaddleOCR) when configured,
//   otherwise the local tesseract.js fallback (LOCAL_OCR_LANGS, default eng+ben).

export const OCR_ERROR_MESSAGE =
  'Unable to extract information from the uploaded label. Please upload a clearer image or enter the information manually.';
export const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
export const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

interface MicroserviceField {
  value: string | null;
  confidence: number;
}
export interface MicroserviceResponse {
  success: boolean;
  processingTime: number;
  quality: string;
  fields: Record<string, MicroserviceField>;
  rawText: string | null;
  languages?: string[];
  engine?: string;
  sides?: { side: string; quality: string; warnings: string[]; perspectiveCorrected: boolean; rotatedDegrees: number }[];
  message?: string;
}

export interface OcrOutcome {
  fields: Record<string, string | number | null>;
  /** Per-field confidence 0-100 (microservice only). */
  fieldConfidence?: Record<string, number>;
  confidence?: number;
  rawText: string;
  source: 'microservice' | 'local-fallback';
  languages?: string[];
  sides?: MicroserviceResponse['sides'];
  quality?: string;
}

export function flattenMicroserviceResponse(json: MicroserviceResponse): OcrOutcome {
  const flat: Record<string, string | number | null> = {};
  const fieldConfidence: Record<string, number> = {};
  let confidenceSum = 0;
  let confidenceCount = 0;
  for (const [key, field] of Object.entries(json.fields)) {
    // mrp is numeric in the rest of the app (products.price); every other field is a string.
    flat[key] = key === 'mrp' && field.value !== null ? Number(field.value) : field.value;
    if (field.value !== null) {
      confidenceSum += field.confidence;
      confidenceCount += 1;
      fieldConfidence[key] = field.confidence;
    }
  }
  return {
    fields: flat,
    fieldConfidence,
    confidence: confidenceCount > 0 ? Math.round((confidenceSum / confidenceCount) * 10) / 10 : undefined,
    rawText: json.rawText || '',
    source: 'microservice',
    languages: json.languages,
    sides: json.sides,
    quality: json.quality,
  };
}

async function callMicroservice(front: File, back: File | null, opts: { anonymiseFilenames?: boolean }): Promise<Response | null> {
  const serviceUrl = process.env.OCR_SERVICE_URL;
  if (!serviceUrl) return null; // not configured -> caller falls back to local OCR

  const form = new FormData();
  // Buyer photos: the OCR service logs the file name, so a neutral name is sent instead of the buyer's.
  if (opts.anonymiseFilenames) {
    form.append('image', new Blob([await front.arrayBuffer()], { type: front.type }), 'label-front');
    if (back) form.append('backImage', new Blob([await back.arrayBuffer()], { type: back.type }), 'label-back');
  } else {
    form.append('image', front);
    if (back) form.append('backImage', back);
  }
  const headers: Record<string, string> = {};
  if (process.env.OCR_SERVICE_API_KEY) headers['X-API-Key'] = process.env.OCR_SERVICE_API_KEY;

  const controller = new AbortController();
  // Two photos x several preprocessed variants takes longer than the old single-image call.
  const timeout = setTimeout(() => controller.abort(), Number(process.env.OCR_SERVICE_TIMEOUT_MS || 60000));
  try {
    return await fetch(`${serviceUrl.replace(/\/$/, '')}/api/v1/ocr/extract`, { method: 'POST', body: form, headers, signal: controller.signal });
  } catch {
    // Network error / service down / timeout — fall back to local OCR rather than failing outright.
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

// Local development fallback (tesseract.js + sharp). Bangla needs tesseract.js to download the
// "ben" language data the first time (internet required).
async function runLocalFallback(files: File[]): Promise<OcrOutcome | null> {
  const langs = (process.env.LOCAL_OCR_LANGS || 'eng+ben').split('+');
  const worker = await createWorker(langs);
  const texts: string[] = [];
  const confidences: number[] = [];
  try {
    for (const file of files) {
      const pre = await sharp(Buffer.from(await file.arrayBuffer()))
        .rotate() // honour EXIF orientation from phone cameras
        .resize({ width: 2000, withoutEnlargement: false })
        .grayscale()
        .normalize()
        .sharpen()
        .toBuffer();
      const { data } = await worker.recognize(pre);
      if (data.text?.trim()) texts.push(data.text.trim());
      if (typeof data.confidence === 'number') confidences.push(data.confidence);
    }
  } finally {
    await worker.terminate();
  }
  const text = texts.join('\n');
  if (!text.trim()) return null;
  const fields = extractFieldsFromOcrText(text) as unknown as Record<string, string | number | null>;
  return {
    fields,
    confidence: confidences.length ? Math.round((confidences.reduce((a, b) => a + b, 0) / confidences.length) * 10) / 10 : undefined,
    rawText: text,
    source: 'local-fallback',
  };
}

/** Image check by CONTENT (magic bytes), not only the declared MIME type / file name. */
export async function sniffImageType(file: File): Promise<string | null> {
  const b = new Uint8Array(await file.slice(0, 12).arrayBuffer());
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'image/png';
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'image/webp';
  return null;
}

export function validImage(f: FormDataEntryValue | null | undefined): f is File {
  return !!f && typeof f !== 'string' && IMAGE_TYPES.includes(f.type) && f.size > 0 && f.size <= MAX_IMAGE_BYTES;
}

/** Run OCR on one or two photos. Returns the outcome, or an error message (never throws for OCR failures). */
export async function readLabelOcr(front: File, back: File | null, opts: { anonymiseFilenames?: boolean } = {}): Promise<{ ocr: OcrOutcome | null; error: string | null }> {
  try {
    const res = await callMicroservice(front, back, opts);
    if (res) {
      const json = (await res.json().catch(() => null)) as MicroserviceResponse | null;
      if (res.ok && json?.success) return { ocr: flattenMicroserviceResponse(json), error: null };
      return { ocr: null, error: json?.message || OCR_ERROR_MESSAGE }; // service answered: don't re-run OCR on the same unusable image
    }
    const local = await runLocalFallback(back ? [front, back] : [front]);
    return local ? { ocr: local, error: null } : { ocr: null, error: OCR_ERROR_MESSAGE };
  } catch {
    return { ocr: null, error: OCR_ERROR_MESSAGE };
  }
}
