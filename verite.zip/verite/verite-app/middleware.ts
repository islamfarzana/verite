import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, AUTH_COOKIE, dashboardPathFor, JwtPayload } from '@/lib/auth-edge';

const ROLE_PREFIXES: Record<string, JwtPayload['role']> = {
  '/buyer': 'BUYER',
  '/seller': 'SELLER',
  '/admin': 'ADMIN',
};

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const token = req.cookies.get(AUTH_COOKIE)?.value;
  const session = token ? await verifyToken(token) : null;

  // Logged-in users hitting /login shouldn't see the login form again —
  // send them straight to their dashboard (prevents redirect loops).
  if (pathname === '/login' && session) {
    return NextResponse.redirect(new URL(dashboardPathFor(session.role), req.url));
  }

  const matchedPrefix = Object.keys(ROLE_PREFIXES).find((p) => pathname.startsWith(p));
  if (!matchedPrefix) return NextResponse.next();

  // Not logged in at all -> bounce to login, remember where they wanted to go.
  if (!session) {
    const url = new URL('/login', req.url);
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  // Logged in but wrong role for this section -> 403, not a silent redirect
  // back to login (that silent-redirect-to-login-forever was the exact bug
  // this update is fixing).
  const requiredRole = ROLE_PREFIXES[matchedPrefix];
  if (session.role !== requiredRole) {
    return NextResponse.redirect(new URL('/403', req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/buyer/:path*', '/seller/:path*', '/admin/:path*', '/login'],
};
