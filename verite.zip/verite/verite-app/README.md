# Verité — FMCG Marketplace with Blockchain-Enabled Authentication

A real, runnable Next.js 14 application (App Router + TypeScript) implementing the core
flows from the project spec: buyer marketplace, seller product publishing with an
AI-label-extraction step, and a cryptographic (Keccak-256) product fingerprint that's
generated at publish time and re-verified on demand.

This is **not** the Babel-in-browser HTML demo from earlier — it's a real compiled
Next.js build with a real SQLite database, real bcrypt password hashing, real JWT
sessions, and a real cryptographic hash algorithm (the same one Ethereum/Polygon use).

## Run it locally

```bash
npm install
cp .env.example .env        # then set JWT_SECRET to a random string
npm run seed                # creates demo users + 6 published, hashed products
npm run dev                 # http://localhost:3000
```

Demo accounts (password `Password123!` for all):
- `buyer@verite.app`
- `seller@verite.app`
- `admin@verite.app`

### Seller onboarding & licence verification (added 2026-10-28)

New sellers must submit a business profile and licence (**Business Verification**) and be approved by an
admin (**Seller Reviews**) before they can publish. Licences are checked by a pluggable registry adapter;
in development this is a **MOCK/DEMO registry with fictitious records — not official verification**.
No real Bangladeshi licence registry is connected. After `npm run seed`, sign in as `admin@verite.app`,
approve "GreenMart BD", then publish as `seller@verite.app`. Details, policy and limits:
`docs/changes/seller-licence-verification/`. Tests: `npm run test:identity`.

### AI features, Bangla OCR and the seller assistant (v4, added 2026-10-28)

Seller Studio now reads the **front and back** of the pack in **Bangla and English**, cross-checks the
OCR with **Google Gemini** (free tier, optional: set `GEMINI_API_KEY`), marks every field with how it was
obtained, and can make an **enhanced cover photo** from the real front photo. The **Seller Assistant**
(`/seller/assistant`) gives stock-out and expiry alerts, best sellers, slow movers, a weekly summary in
English or বাংলা and "ask your shop". Demo sales: `npm run simulate:sales` (clearly labelled simulated).
Details: `docs/changes/ai-assistant-v4/`. Tests: `npm run test:ai`, `npm run test:assistant`.

### Where your data is saved (v5)

Everything is stored in **one SQLite database file**, `verite-app/data/verite.db` (or `DATABASE_FILE`):
accounts, products (drafts too), **buyers' carts**, orders, recalls and notices. Uploaded images go to
`data/uploads`. Closing the browser, stopping `npm run dev` or restarting the computer/Codespace does not
lose anything. Data is lost only if that file is deleted, or if the app is started from another folder
(which creates a new empty database). Check any time:

```bash
npm run db:status     # prints the database path, counts and the latest products
```

Sellers find every product they created, including drafts that are waiting for approval, under
**My Products** (`/seller/products`). Buyers' carts are saved to their account, not to the browser.

### Buyer protection (v5, added 2026-10-29)

- **Check my pack** (`/product/<id>/check`): a buyer photographs the pack; Bangla + English OCR reads it and
  every field is compared with the registered batch (match / does not match / uncertain / not read).
  Photos are not stored and never sent to an AI company. A mismatch means "needs checking", never "fake".
- **MRP guard:** every listing has the MRP printed on the pack; a selling price above it is refused on the
  server (create, price change, publish and checkout).
- **Expiry protection:** expired batches disappear from the marketplace and cannot be added to a cart or
  ordered; buyers see "মেয়াদ শেষ হতে X দিন বাকি".
- **QR clone-risk alerts** for sellers, from real scan events (a warning, never a verdict).
- **Batch recall:** the seller (own products) or an admin stops sales of a batch at once, and buyers who
  ordered that batch get an in-app notice (**Notifications**). Admin page: **Protection**.

Details, policy decisions and limits: `docs/changes/buyer-protection/`. Tests: `npm run test:protection`
(or `npm run test:all`).

## Deploy it for real

The simplest real deployment, since this app uses an embedded SQLite database on disk:

**Railway or Render (recommended — 5 minutes):**
1. Push this folder to a GitHub repo.
2. On Railway/Render: "New Project" → "Deploy from GitHub repo".
3. Set the `JWT_SECRET` environment variable (any random string).
4. Set the start command to `npm run build && npm run seed && npm start` (first deploy only — remove `npm run seed` after, so it doesn't reseed on every restart).
5. Attach a persistent volume mounted at `/app/data` so the SQLite file survives restarts (both platforms support this — "Volumes" in the project settings).

**Vercel:** works too, but Vercel's serverless functions have an ephemeral filesystem,
so a SQLite file won't persist between requests reliably. For Vercel, swap `lib/db.ts`
for a hosted Postgres client (e.g. [Neon](https://neon.tech) or
[Supabase](https://supabase.com), both have generous free tiers) — the SQL schema in
`lib/db.ts` is already portable ANSI SQL, so it's a same-shape migration, not a rewrite.

**Docker / your own VPS:** a plain `Dockerfile` running `npm run build && npm start`
works as-is, since SQLite just needs a writable disk.

## What's real vs. what's scoped down from the full spec

The original spec (10 documents) describes a multi-service system: a NestJS backend,
a separate FastAPI + PaddleOCR + YOLOv11 computer-vision microservice, a Solidity smart
contract deployed to Polygon mainnet, PostgreSQL, Redis, BullMQ, and Kubernetes. That's
several weeks of work across several services and cannot be one deliverable. What's
**real** in this build, specifically:

| Piece | Status |
|---|---|
| Password hashing (bcrypt, 12 rounds) | Real |
| JWT auth & sessions | Real |
| SQL database (schema, transactions, constraints) | Real (SQLite; swap-ready for Postgres) |
| Keccak-256 canonical hashing | Real (via `ethers.js`, same algorithm as on-chain) |
| Hash comparison / tamper detection | Real — verified end-to-end: changing a product's data changes its recomputed hash and fails verification |
| Checkout with stock decrement | Real DB transaction |
| OCR field extraction (regex, date normalization, confidence scoring) | Real logic, running on typed/pasted label text |
| OCR **image reading** (PaddleOCR/YOLOv11 computer vision) | **Not included** — needs a GPU-backed Python model service; see `app/api/ocr/upload/route.ts` for exactly where to plug one in |
| Seller approval workflow, licence claims, eligibility policy | Real (server-enforced, audited) |
| Licence registry lookup | **Mock/demo only** (fictitious records); real HTTPS adapter exists but no authorised registry is configured |
| Writing the hash to an actual Polygon transaction | **Simulated** (deterministic, derived from the real hash) — needs a funded wallet + RPC endpoint; see `lib/blockchain.ts` |

## Wiring in the real blockchain write

`lib/blockchain.ts` computes a genuine Keccak-256 hash. To make the on-chain write real
instead of simulated:
1. Deploy the `ProductVerification` contract from `05_Blockchain_Module.md` to Polygon
   Amoy (testnet) via Hardhat.
2. Fund a wallet with test MATIC.
3. Replace `simulateChainWrite()` with an `ethers.Contract` call to
   `registerProductHash(hash)`, store the returned transaction hash and block number.

## Wiring in the real OCR model

`app/api/ocr/upload/route.ts` currently parses label **text** with regex (real logic,
same rules as the spec). To read actual label **images**:
1. Stand up the FastAPI service described in `06_AI_OCR_Module.md` (PaddleOCR + YOLOv11).
2. Point `OCR_SERVICE_URL` at it and forward the uploaded image there instead of the
   `labelText` string.

## Stack

Next.js 14 (App Router) · TypeScript · Tailwind CSS · better-sqlite3 · bcryptjs ·
jsonwebtoken · ethers.js · zod
