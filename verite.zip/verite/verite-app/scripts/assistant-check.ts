import db from '../lib/db';
import { loadAlertConfig, runChecksIfDue } from '../lib/assistant/alerts';

// Run the seller assistant's stock and expiry checks for every seller.
// Schedule this (e.g. hourly with cron, a Windows scheduled task or a hosting platform's cron):
//   npm run assistant:check
const sellers = db.prepare("SELECT id, email FROM users WHERE role = 'SELLER'").all() as { id: string; email: string }[];
const now = new Date();
let total = 0;
for (const s of sellers) {
  const r = runChecksIfDue(db as any, s.id, now, loadAlertConfig(), 0);
  total += r.created;
}
console.log(`Checked ${sellers.length} sellers; ${total} new alerts.`);
