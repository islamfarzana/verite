import fs from 'fs';
import db, { DB_PATH, UPLOAD_DIR } from '../lib/db';

// Shows WHERE the data is stored and what is in it, so you can confirm that products, carts and orders
// are saved (run it, restart the app, run it again: the numbers stay). Usage: npm run db:status
const count = (sql: string, ...p: unknown[]) => Number((db.prepare(sql).get(...p) as { c: number }).c);
const size = fs.existsSync(DB_PATH) ? fs.statSync(DB_PATH).size : 0;
const uploads = fs.existsSync(UPLOAD_DIR) ? fs.readdirSync(UPLOAD_DIR).length : 0;

console.log(`Database file : ${DB_PATH} (${(size / 1024).toFixed(0)} KB)`);
console.log(`Uploaded images: ${UPLOAD_DIR} (${uploads} files)`);
console.log('');
console.log(`Users          : ${count('SELECT COUNT(*) AS c FROM users')} (sellers ${count("SELECT COUNT(*) AS c FROM users WHERE role='SELLER'")}, buyers ${count("SELECT COUNT(*) AS c FROM users WHERE role='BUYER'")})`);
console.log(`Products       : ${count('SELECT COUNT(*) AS c FROM products')} (published ${count("SELECT COUNT(*) AS c FROM products WHERE status='PUBLISHED'")}, drafts ${count("SELECT COUNT(*) AS c FROM products WHERE status='DRAFT'")})`);
console.log(`Cart lines     : ${count('SELECT COUNT(*) AS c FROM cart_items')} (buyers with a saved cart: ${count('SELECT COUNT(DISTINCT buyer_id) AS c FROM cart_items')})`);
console.log(`Orders         : ${count("SELECT COUNT(*) AS c FROM orders WHERE order_number NOT LIKE 'SIM-%'")} real, ${count("SELECT COUNT(*) AS c FROM orders WHERE order_number LIKE 'SIM-%'")} simulated`);
console.log(`Recalls        : ${count("SELECT COUNT(*) AS c FROM batch_recalls WHERE status='ACTIVE'")} active, ${count("SELECT COUNT(*) AS c FROM batch_recalls WHERE status='CLOSED'")} closed`);
console.log(`Label checks   : ${count('SELECT COUNT(*) AS c FROM label_checks')}`);
console.log('');
const recent = db.prepare("SELECT p.name, p.status, u.email, p.created_at FROM products p JOIN users u ON u.id = p.seller_id ORDER BY p.created_at DESC LIMIT 5").all() as any[];
console.log('Latest products:');
for (const r of recent) console.log(`  ${r.created_at}  ${r.status.padEnd(9)} ${r.name}  (seller ${r.email})`);
