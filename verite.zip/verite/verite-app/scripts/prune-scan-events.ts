// Delete scan events older than SCAN_EVENT_RETENTION_DAYS (default 90).
// Run on a schedule (cron / Task Scheduler):  npm run prune:scans
import db from '../lib/db';
import { loadScanConfig } from '../lib/trace/config';
import { pruneScanEvents } from '../lib/trace/service';

const cfg = loadScanConfig();
const removed = pruneScanEvents(db as any, new Date(), cfg.retentionDays);
console.log(`Removed ${removed} scan event(s) older than ${cfg.retentionDays} days.`);
