import db from '../lib/db';
import { newId } from '../lib/ids';

// SIMULATED order history for demonstrating the seller assistant. NOT real sales.
// Every simulated order has an order number starting with "SIM-" and shipping name
// "Simulated demo order", and the assistant shows how many are included.
//
//   npm run simulate:sales                       60 days for seller@verite.app
//   npm run simulate:sales -- --days 90 --seller someone@example.com
//   npm run simulate:sales -- --clear            remove all simulated orders again
//
// Stock is NOT changed (so the existing stock numbers stay as seeded).

const args = process.argv.slice(2);
const opt = (name: string, d: string) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 && args[i + 1] ? args[i + 1] : d;
};

function clear() {
  const ids = (db.prepare("SELECT id FROM orders WHERE order_number LIKE 'SIM-%'").all() as { id: string }[]).map((r) => r.id);
  for (const id of ids) {
    db.prepare('DELETE FROM order_items WHERE order_id = ?').run(id);
    db.prepare('DELETE FROM orders WHERE id = ?').run(id);
  }
  console.log(`Removed ${ids.length} simulated orders.`);
}

// Deterministic pseudo-random numbers, so the demo looks the same every time.
function rng(seed: number) {
  return () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };
}

function poisson(lambda: number, r: () => number) {
  const L = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do { k++; p *= r(); } while (p > L);
  return k - 1;
}

function simulate() {
  const days = Number(opt('days', '60'));
  const sellerEmail = opt('seller', 'seller@verite.app');
  const seller = db.prepare("SELECT id FROM users WHERE email = ? AND role = 'SELLER'").get(sellerEmail) as { id: string } | undefined;
  const buyer = db.prepare("SELECT id FROM users WHERE role = 'BUYER' ORDER BY created_at LIMIT 1").get() as { id: string } | undefined;
  if (!seller || !buyer) {
    console.error('Run `npm run seed` first (needs a seller and a buyer account).');
    process.exit(1);
  }
  const products = db.prepare("SELECT id, name, price FROM products WHERE seller_id = ? AND status = 'PUBLISHED'").all(seller.id) as { id: string; name: string; price: number }[];
  if (!products.length) {
    console.error('The seller has no published products.');
    process.exit(1);
  }
  const r = rng(42);
  // Each product gets a base daily demand and a trend, so there are clear best sellers and slow movers.
  const profile = products.map((p, i) => ({ ...p, base: [3.2, 0.5, 2.0, 1.4, 0.0, 0.9, 1.1, 0.3][i % 8], trend: [1.3, 0.8, 1.0, 1.6, 1, 0.9, 1.1, 1][i % 8] }));
  const insertOrder = db.prepare(
    `INSERT INTO orders (id, buyer_id, order_number, invoice_number, subtotal, vat, delivery_charge, discount, grand_total, total, payment_method,
       delivery_method, shipping_name, shipping_phone, shipping_address, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 60, 0, ?, ?, 'COD', 'STANDARD', 'Simulated demo order', '00000000000', 'Simulated', 'DELIVERED', ?)`
  );
  const insertItem = db.prepare('INSERT INTO order_items (id, order_id, product_id, quantity, price) VALUES (?, ?, ?, ?, ?)');
  let orders = 0;
  db.exec('BEGIN');
  try {
    for (let d = days; d >= 1; d--) {
      const when = new Date(Date.now() - d * 86_400_000);
      const weekday = new Date(when.getTime() + 6 * 3_600_000).getUTCDay();
      const weekend = weekday === 5 || weekday === 6 ? 1.35 : 1; // Friday/Saturday busier
      for (const p of profile) {
        const progress = 1 - d / days; // 0 -> 1 over the period
        const lambda = p.base * weekend * (1 + (p.trend - 1) * progress);
        let units = poisson(lambda, r);
        while (units > 0) {
          const qty = Math.min(units, 1 + Math.floor(r() * 3));
          units -= qty;
          const subtotal = p.price * qty;
          const vat = Math.round(subtotal * 0.05 * 100) / 100;
          const id = newId('ord');
          const t = new Date(when.getTime() + Math.floor(r() * 12) * 3_600_000).toISOString().slice(0, 19).replace('T', ' ');
          insertOrder.run(id, buyer.id, `SIM-${id.slice(4, 12).toUpperCase()}`, `SIM-INV-${orders}`, subtotal, vat, subtotal + vat + 60, subtotal + vat + 60, t);
          insertItem.run(newId('oit'), id, p.id, qty, p.price);
          orders++;
        }
      }
    }
    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
  console.log(`Created ${orders} SIMULATED orders over ${days} days for ${products.length} products of ${sellerEmail}.`);
  console.log('They are labelled SIM- and shown as simulated in the Seller Assistant. Remove with: npm run simulate:sales -- --clear');
}

if (args.includes('--clear')) clear();
else simulate();
