import db from '../lib/db';

// Read-only report: which products are LEGACY (registered before seller review / manufacturer identity)
// and which have a v2 identity record. Nothing is changed and nothing is promoted to "verified".
// Usage: npm run identity:report

const rows = db
  .prepare(
    `SELECT p.id, p.name, p.status, u.name AS seller_account, pi.hash_schema_version AS v, pi.registration_basis AS basis,
            pi.manufacturer_identity AS manufacturer, (bc.product_id IS NOT NULL) AS anchored
     FROM products p
     LEFT JOIN users u ON u.id = p.seller_id
     LEFT JOIN product_identity pi ON pi.product_id = p.id
     LEFT JOIN blockchain_records bc ON bc.product_id = p.id
     ORDER BY p.created_at`
  )
  .all() as any[];

const legacy = rows.filter((r) => r.anchored && r.v !== 2);
const v2 = rows.filter((r) => r.v === 2);
const drafts = rows.filter((r) => !r.anchored);

console.log(`Products: ${rows.length}  |  v2 (identity recorded): ${v2.length}  |  legacy v1 (needs review): ${legacy.length}  |  not registered: ${drafts.length}`);
console.log('\nLEGACY v1 records — hash uses the seller account email as "manufacturer"; manufacturer identity UNKNOWN; kept unchanged:');
for (const r of legacy) console.log(`  ${r.id}  ${r.name}  (seller account: ${r.seller_account})`);
console.log('\nThese records are AMBIGUOUS by design: the old data never said who manufactured them. They are shown as "legacy record"');
console.log('on the product page. To give one a v2 identity, register it again as a new product after the seller is approved.');
