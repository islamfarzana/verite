// Demo helper for the defense: simulate an attacker editing a product row
// directly in the database. The blockchain still holds the original
// fingerprint, so pressing "Verify Product" afterwards must FAIL.
//
// Usage:  npx tsx scripts/tamper.ts <productId or barcode> <new expiry date, YYYY-MM-DD>
import db from '../lib/db';

const [, , key, newExpiry] = process.argv;
if (!key || !newExpiry) {
  console.error('Usage: npx tsx scripts/tamper.ts <productId or barcode> <new expiry date YYYY-MM-DD>');
  process.exit(1);
}

const before = db.prepare('SELECT id, name, expiry_date FROM products WHERE id = ? OR barcode = ?').get(key, key) as
  | { id: string; name: string; expiry_date: string }
  | undefined;
if (!before) {
  console.error('No product found for:', key);
  process.exit(1);
}

db.prepare('UPDATE products SET expiry_date = ? WHERE id = ?').run(newExpiry, before.id);
console.log(`Tampered "${before.name}" (${before.id}): expiry ${before.expiry_date} -> ${newExpiry}`);
console.log('Now press "Verify Product" on that product page: the result should be FAILED.');
