import db from '../lib/db';
import { hashPassword } from '../lib/auth';
import { newId } from '../lib/ids';
import { generateProductHash, simulateChainWrite } from '../lib/blockchain';
import { loadIdentityConfig } from '../lib/identity/config';
import { getEntityForUser, submitBusinessProfile } from '../lib/identity/onboarding';
import { selectRegistryAdapter } from '../lib/identity/registry';

async function main() {
  console.log('Seeding database…');

  const admin = { id: newId('usr'), name: 'Admin', email: 'admin@verite.app', role: 'ADMIN' as const };
  const seller = { id: newId('usr'), name: 'GreenMart BD', email: 'seller@verite.app', role: 'SELLER' as const };
  const buyer = { id: newId('usr'), name: 'Test Buyer', email: 'buyer@verite.app', role: 'BUYER' as const };

  const pwd = await hashPassword('Password123!');
  const insertUser = db.prepare('INSERT OR IGNORE INTO users (id,name,email,password_hash,role) VALUES (?,?,?,?,?)');
  for (const u of [admin, seller, buyer]) insertUser.run(u.id, u.name, u.email, pwd, u.role);

  // Re-fetch the REAL row id for each user. If a user with this email already
  // existed (from a previous run of this script), INSERT OR IGNORE silently
  // skipped our insert and kept the row's original id — using the freshly
  // generated `seller.id` below would then point at a user row that was
  // never actually written, breaking every foreign key that follows.
  const idByEmail = (email: string) => (db.prepare('SELECT id FROM users WHERE email = ?').get(email) as { id: string }).id;
  const sellerId = idByEmail(seller.email);

  const categories = [
    { id: newId('cat'), name: 'Dairy', slug: 'dairy' },
    { id: newId('cat'), name: 'Cooking', slug: 'cooking' },
    { id: newId('cat'), name: 'Grains', slug: 'grains' },
    { id: newId('cat'), name: 'Snacks', slug: 'snacks' },
    { id: newId('cat'), name: 'Beverages', slug: 'beverages' },
  ];
  const insertCat = db.prepare('INSERT OR IGNORE INTO categories (id,name,slug) VALUES (?,?,?)');
  categories.forEach((c) => insertCat.run(c.id, c.name, c.slug));

  // Same idea for categories: look up the real id by slug rather than trust
  // the id generated above, in case the category already existed.
  const categoryIdBySlug: Record<string, string> = {};
  for (const c of categories) {
    categoryIdBySlug[c.name] = (db.prepare('SELECT id FROM categories WHERE slug = ?').get(c.slug) as { id: string }).id;
  }

  // v5 demo: one batch that is always ~20 days from expiry when you seed, to show the "expires in X days" badge.
  const nearExpiry = new Date(Date.now() + 20 * 86_400_000 + 6 * 3_600_000).toISOString().slice(0, 10);
  const products = [
    { name: 'Mango Juice 1L', brand: 'FruitFarm', cat: 'Beverages', barcode: '8904441112223', batch: 'LOT-MJ-020', mfg: '2026-07-01', exp: nearExpiry, price: 140, stock: 40, emoji: '🧃' },
    { name: 'Fresh Full Cream Milk 1L', brand: 'DailyPure', cat: 'Dairy', barcode: '8901234567890', batch: 'LOT-241A', mfg: '2026-01-01', exp: '2026-08-31', price: 120, stock: 84, emoji: '🥛' },
    { name: 'Extra Virgin Olive Oil 500ml', brand: 'OlivaGold', cat: 'Cooking', barcode: '8901112223334', batch: 'LOT-982C', mfg: '2025-11-10', exp: '2027-05-10', price: 650, stock: 32, emoji: '🫒' },
    { name: 'Basmati Rice 5kg', brand: 'Chinigura', cat: 'Grains', barcode: '8905556667778', batch: 'LOT-330X', mfg: '2026-02-15', exp: '2027-02-15', price: 780, stock: 150, emoji: '🍚' },
    { name: 'Instant Noodles Pack (5x)', brand: 'QuickBite', cat: 'Snacks', barcode: '8909998887776', batch: 'LOT-118B', mfg: '2026-04-01', exp: '2026-10-01', price: 250, stock: 6, emoji: '🍜' },
    { name: 'Green Tea 100 Bags', brand: 'LeafWell', cat: 'Beverages', barcode: '8903334445556', batch: 'LOT-771D', mfg: '2026-03-05', exp: '2027-09-05', price: 340, stock: 60, emoji: '🍵' },
    { name: 'Dark Chocolate Bar 90%', brand: 'CacaoNoir', cat: 'Snacks', barcode: '8907776665554', batch: 'LOT-556E', mfg: '2026-01-20', exp: '2027-01-20', price: 410, stock: 45, emoji: '🍫' },
  ];

  const findProductByBarcode = db.prepare('SELECT id FROM products WHERE barcode = ?');
  const insertProduct = db.prepare(
    `INSERT INTO products (id, seller_id, category_id, name, brand, barcode, batch_number, manufacturing_date, expiry_date, price, stock, image_emoji, status, verification_status)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'PUBLISHED','VERIFIED')`
  );
  const insertRecord = db.prepare(
    `INSERT OR IGNORE INTO blockchain_records (id, product_id, keccak_hash, tx_hash, block_number) VALUES (?,?,?,?,?)`
  );

  for (const p of products) {
    // Skip entirely if this product (matched by its unique barcode) was
    // already seeded in a previous run — prevents duplicate products AND
    // prevents attaching a blockchain record to an id that was never
    // actually inserted (the bug that caused the FOREIGN KEY crash).
    const existing = findProductByBarcode.get(p.barcode) as { id: string } | undefined;
    if (existing) continue;

    const catId = categoryIdBySlug[p.cat];
    const id = newId('prod');
    insertProduct.run(id, sellerId, catId, p.name, p.brand, p.barcode, p.batch, p.mfg, p.exp, p.price, p.stock, p.emoji);

    const hash = generateProductHash({
      productId: id,
      brand: p.brand,
      productName: p.name,
      barcode: p.barcode,
      batchNumber: p.batch,
      manufacturingDate: p.mfg,
      expiryDate: p.exp,
      manufacturer: seller.email,
    });
    const { txHash, blockNumber } = simulateChainWrite(hash);
    insertRecord.run(newId('bcr'), id, hash, txHash, blockNumber);
  }

  // v5 buyer protection: demo MRPs for the seeded listings (FICTITIOUS demo values, source SEED_DEMO, not
  // reviewed). Olive oil is priced below its MRP to show a discount. Existing MRPs are never overwritten.
  const demoMrp: Record<string, number> = { '8901112223334': 70000 };
  for (const p of products) {
    db.prepare("UPDATE products SET mrp_paisa = ?, mrp_source = 'SEED_DEMO', mrp_status = 'UNREVIEWED' WHERE barcode = ? AND mrp_paisa IS NULL")
      .run(demoMrp[p.barcode] ?? p.price * 100, p.barcode);
  }

  // Seller onboarding & licence verification: give the demo seller a business profile with a
  // SYNTHETIC licence claim. It is submitted as PENDING — the seed does NOT approve it. Sign in as
  // admin and approve it under "Seller Reviews" before publishing new products.
  // (The 6 products above are LEGACY demo records hashed with the original v1 rule; they are kept
  // unchanged to show that old records still verify.)
  if (!getEntityForUser(db as any, sellerId)) {
    const adapter = selectRegistryAdapter(loadIdentityConfig(), db as any);
    await submitBusinessProfile(db as any, { id: sellerId, role: 'SELLER' }, {
      legalName: 'GreenMart BD Ltd (demo)',
      displayName: 'GreenMart BD',
      entityType: 'ORGANIZATION',
      roles: ['SELLER', 'MANUFACTURER'],
      contactEmail: null,
      licence: {
        licenceType: 'TRADE_LICENCE',
        licenceNumber: 'DEMO-TL-2026-0001',
        issuingAuthority: 'Demo City Corporation (fictitious)',
        claimedExpiryDate: '2027-06-30',
        claimSource: 'MANUAL_ENTRY',
      },
    }, { adapter });
    console.log(`Demo seller business submitted for review (PENDING). Licence registry mode: ${adapter.mode}.`);
  }

  console.log('Seed complete.');
  console.log('Note: the demo milk and noodles batches are past their expiry date, so buyers no longer see them (expiry protection).');
  console.log('Login with: seller@verite.app / buyer@verite.app / admin@verite.app — password: Password123!');
  console.log('Next: sign in as admin@verite.app → Seller Reviews → approve "GreenMart BD", then publish as the seller.');
}

main();
