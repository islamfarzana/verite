// Small status badges for seller onboarding and licence evidence. Each kind of evidence has its own
// wording and colour, so a mock/demo result, an admin review and a real registry check never look alike.
// Only a VALID answer from a real configured registry is green.

const TONE: Record<string, string> = {
  green: 'bg-secondary/15 text-[#16803C]',
  blue: 'bg-primary/10 text-primary',
  amber: 'bg-warning/15 text-[#B45309]',
  red: 'bg-danger/15 text-danger',
  gray: 'bg-slate-100 text-slate-600',
};

export function Badge({ tone, children }: { tone: keyof typeof TONE; children: React.ReactNode }) {
  return <span className={`inline-block text-[11px] font-bold rounded-full px-2.5 py-1 ${TONE[tone]}`}>{children}</span>;
}

export function EntityStatusBadge({ status }: { status: string | null | undefined }) {
  if (status === 'APPROVED') return <Badge tone="blue">Identity reviewed by admin</Badge>;
  if (status === 'PENDING') return <Badge tone="amber">Pending admin review</Badge>;
  if (status === 'REJECTED') return <Badge tone="red">Rejected</Badge>;
  if (status === 'SUSPENDED') return <Badge tone="red">Suspended</Badge>;
  return <Badge tone="gray">No business profile</Badge>;
}

const BAD: Record<string, string> = {
  EXPIRED: 'Licence expired', REVOKED: 'Licence revoked', SUSPENDED: 'Licence suspended', INVALID: 'Reported invalid', NOT_FOUND: 'Not found in registry',
  UNSUPPORTED: 'Type not checkable',
};

/** Badge for a licence's current state: what it actually establishes, and from which kind of source. */
export function LicenceBadge({ checkResult, method }: { checkResult: string; method: string }) {
  if (checkResult === 'UNAVAILABLE' || checkResult === 'ERROR') return <Badge tone="gray">Unable to check right now</Badge>;
  if (checkResult === 'NOT_CHECKED' || method === 'UNVERIFIED_CLAIM') return <Badge tone="gray">Submitted claim — not verified</Badge>;
  const mock = method === 'MOCK_REGISTRY';
  if (checkResult !== 'VALID') return <Badge tone="red">{BAD[checkResult] || checkResult}{mock ? ' (MOCK/DEMO)' : ''}</Badge>;
  if (mock) return <Badge tone="amber">MOCK/DEMO registry: active — NOT OFFICIAL</Badge>;
  if (method === 'AUTHORIZED_MANUAL_REVIEW') return <Badge tone="blue">Reviewed manually by admin — not a registry lookup</Badge>;
  return <Badge tone="green">Active per configured registry</Badge>;
}

export function fmtTime(iso: string | null | undefined) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-GB', { timeZone: 'Asia/Dhaka', dateStyle: 'medium', timeStyle: 'short' }) + ' (Dhaka)';
}
