import { Badge } from '@/components/IdentityBadges';

// v5 buyer protection: small, reusable status pieces. Bangla first (buyers), English below.

export function ExpiryBadge({ expiry, compact = false }: { expiry: { state: string; textEn: string | null; textBn: string | null } | null | undefined; compact?: boolean }) {
  if (!expiry || expiry.state === 'OK') return null;
  const tone = expiry.state === 'EXPIRED' || expiry.state === 'UNKNOWN' ? 'red' : 'amber';
  return (
    <Badge tone={tone}>
      <span lang="bn">{expiry.textBn}</span>
      {!compact && expiry.textEn ? <span className="font-normal"> · {expiry.textEn}</span> : null}
    </Badge>
  );
}

export function RecallBanner({ recall }: { recall: { reasonCode: string; publicMessage: string | null; createdAt: string } | null | undefined }) {
  if (!recall) return null;
  return (
    <div className="rounded-xl border-2 border-danger/50 bg-danger/5 p-4 mb-5 text-sm">
      <div className="font-bold text-danger" lang="bn">এই ব্যাচটি প্রত্যাহার করা হয়েছে</div>
      <div className="font-semibold text-danger">This batch has been recalled ({recall.createdAt.slice(0, 10)}) — it cannot be bought.</div>
      {recall.publicMessage && <div className="mt-1">“{recall.publicMessage}”</div>}
      <div className="text-muted text-xs mt-1">
        If you already bought it, check your notifications and contact the seller. A recall is recorded in Verité’s database; the on-chain
        fingerprint is not changed by it.
      </div>
    </div>
  );
}

export function BlockerList({ blockers }: { blockers: { code: string; en: string; bn: string }[] | null | undefined }) {
  if (!blockers || blockers.length === 0) return null;
  return (
    <ul className="text-xs space-y-1">
      {blockers.map((b) => (
        <li key={b.code}>
          <span lang="bn" className="font-semibold">{b.bn}</span> <span className="text-muted">{b.en}</span>
        </li>
      ))}
    </ul>
  );
}

export const RESULT_LOOK: Record<string, { label: string; bn: string; cls: string }> = {
  MATCH: { label: 'Matches', bn: 'মিলেছে', cls: 'bg-secondary/15 text-[#16803C]' },
  MISMATCH: { label: 'Does not match', bn: 'মিলছে না', cls: 'bg-danger/15 text-danger' },
  UNCERTAIN: { label: 'Uncertain', bn: 'নিশ্চিত নয়', cls: 'bg-warning/15 text-[#B45309]' },
  NOT_FOUND_ON_LABEL: { label: 'Not read from photo', bn: 'ছবি থেকে পড়া যায়নি', cls: 'bg-slate-100 text-slate-600' },
  NOT_REGISTERED: { label: 'Not in registered record', bn: 'নিবন্ধিত তথ্যে নেই', cls: 'bg-slate-100 text-slate-600' },
  NOT_APPLICABLE: { label: 'Not applicable', bn: 'প্রযোজ্য নয়', cls: 'bg-slate-100 text-slate-500' },
};

export function ResultChip({ result }: { result: string }) {
  const l = RESULT_LOOK[result] || { label: result, bn: '', cls: 'bg-slate-100 text-slate-600' };
  return <span className={`text-[10px] font-bold rounded-full px-2 py-0.5 whitespace-nowrap ${l.cls}`}><span lang="bn">{l.bn}</span> · {l.label}</span>;
}
