'use client';
import Link from 'next/link';
import { useSession, logout, dashboardPathFor } from '@/lib/client-auth';

export default function NavBar() {
  const { user, loading } = useSession();

  return (
    <div className="sticky top-0 z-50 bg-bg/85 backdrop-blur border-b border-line">
      <div className="max-w-6xl mx-auto px-6 py-3.5 flex items-center justify-between">
        <Link href="/" className="font-display font-bold text-xl flex items-center gap-2">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L21 6.5V12C21 17 17.5 20.7 12 22C6.5 20.7 3 17 3 12V6.5L12 2Z" fill="#2563EB" />
            <path d="M8.5 12.2L11 14.7L15.8 9.5" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          Verité
        </Link>
        <div className="flex gap-7 text-sm font-semibold text-muted">
          <Link href="/" className="hover:text-primary">Marketplace</Link>
          {!loading && user?.role === 'SELLER' && <Link href="/seller/dashboard" className="hover:text-primary">Seller Studio</Link>}
          {!loading && user?.role === 'SELLER' && <Link href="/seller/products" className="hover:text-primary">My Products</Link>}
          {!loading && user?.role === 'SELLER' && <Link href="/seller/codes" className="hover:text-primary">QR Codes</Link>}
          {!loading && user?.role === 'SELLER' && <Link href="/seller/onboarding" className="hover:text-primary">Business Verification</Link>}
          {!loading && user?.role === 'SELLER' && <Link href="/seller/assistant" className="hover:text-primary">Assistant</Link>}
          {!loading && user?.role === 'ADMIN' && <Link href="/admin/dashboard" className="hover:text-primary">Admin</Link>}
          {!loading && user?.role === 'ADMIN' && <Link href="/admin/sellers" className="hover:text-primary">Seller Reviews</Link>}
          {!loading && user?.role === 'ADMIN' && <Link href="/admin/protection" className="hover:text-primary">Protection</Link>}
          {!loading && user?.role === 'BUYER' && <Link href="/buyer/orders" className="hover:text-primary">My Orders</Link>}
          {!loading && user?.role === 'BUYER' && <Link href="/buyer/notifications" className="hover:text-primary">Notifications</Link>}
          <Link href="/verify" className="hover:text-primary">Verify</Link>
        </div>
        <div className="flex gap-2 items-center">
          {!loading && user ? (
            <>
              <Link href={dashboardPathFor(user.role)} className="text-xs text-muted mr-1 hover:text-primary">
                {user.name} <span className="bg-primary/10 text-primary rounded-full px-2 py-0.5">{user.role}</span>
              </Link>
              {user.role === 'BUYER' && (
                <Link href="/buyer/cart" className="btn btn-ghost text-xs px-3 py-1.5">🛒 Cart</Link>
              )}
              <button className="btn btn-ghost text-xs px-3 py-1.5" onClick={logout}>Sign Out</button>
            </>
          ) : (
            !loading && <Link href="/login" className="btn btn-primary text-xs px-4 py-2">Sign In</Link>
          )}
        </div>
      </div>
    </div>
  );
}
