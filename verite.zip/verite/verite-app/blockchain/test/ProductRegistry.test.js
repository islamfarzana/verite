const { expect } = require('chai');
const { ethers } = require('hardhat');

describe('ProductRegistry', () => {
  let registry, owner, other;
  const hashA = ethers.keccak256(ethers.toUtf8Bytes('product A data'));
  const hashB = ethers.keccak256(ethers.toUtf8Bytes('product A tampered data'));

  beforeEach(async () => {
    [owner, other] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory('ProductRegistry');
    registry = await Factory.deploy();
    await registry.waitForDeployment();
  });

  it('registers a hash and reads it back', async () => {
    await registry.registerProductHash('prod_1', hashA);
    const [hash, registrar, timestamp, exists] = await registry.getRecord('prod_1');
    expect(exists).to.equal(true);
    expect(hash).to.equal(hashA);
    expect(registrar).to.equal(owner.address);
    expect(timestamp).to.be.greaterThan(0n);
  });

  it('reports exists = false for an unknown product', async () => {
    const [, , , exists] = await registry.getRecord('never_registered');
    expect(exists).to.equal(false);
  });

  it('never lets a registered record be overwritten', async () => {
    await registry.registerProductHash('prod_1', hashA);
    await expect(registry.registerProductHash('prod_1', hashB)).to.be.revertedWith('already registered');
    const [hash] = await registry.getRecord('prod_1');
    expect(hash).to.equal(hashA);
  });

  it('rejects wallets that are not authorised', async () => {
    await expect(registry.connect(other).registerProductHash('prod_2', hashA)).to.be.revertedWith('not authorised');
  });

  it('lets the owner authorise another registrar', async () => {
    await registry.setAuthorised(other.address, true);
    await registry.connect(other).registerProductHash('prod_2', hashA);
    const [, registrar] = await registry.getRecord('prod_2');
    expect(registrar).to.equal(other.address);
  });

  it('only lets the owner change registrars', async () => {
    await expect(registry.connect(other).setAuthorised(other.address, true)).to.be.revertedWith('not owner');
  });

  it('rejects an empty product id', async () => {
    await expect(registry.registerProductHash('', hashA)).to.be.revertedWith('empty product id');
  });

  it('emits ProductRegistered', async () => {
    await expect(registry.registerProductHash('prod_3', hashA)).to.emit(registry, 'ProductRegistered');
  });
});
