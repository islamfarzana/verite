require('@nomicfoundation/hardhat-toolbox');
// Reuse the marketplace's .env so the wallet and RPC are configured in one place.
require('dotenv').config({ path: '../.env' });

const { CHAIN_RPC_URL, CHAIN_PRIVATE_KEY } = process.env;

module.exports = {
  solidity: {
    version: '0.8.24',
    // "paris" avoids opcodes that some EVM chains do not support yet.
    settings: { evmVersion: 'paris', optimizer: { enabled: true, runs: 200 } },
  },
  networks: {
    // Polygon Amoy testnet (chain ID 80002, gas token POL).
    amoy: {
      url: CHAIN_RPC_URL || 'https://rpc-amoy.polygon.technology',
      chainId: 80002,
      accounts: CHAIN_PRIVATE_KEY ? [CHAIN_PRIVATE_KEY] : [],
    },
    // Local node started with `npx hardhat node` (no faucet, no internet needed).
    localhost: { url: 'http://127.0.0.1:8545' },
  },
};
