# Verité ProductRegistry smart contract

One immutable Keccak-256 fingerprint per product. The marketplace registers the
fingerprint when a seller publishes; the buyer's "Verify Product" button reads it
back **from the contract** (not from SQLite) and compares it with a fingerprint
recomputed from the current product data.

Contract functions: `registerProductHash(productId, hash)`, `getRecord(productId)`.
A record can never be overwritten. Only authorised wallets can register.

## A. Run the contract tests (no internet wallet needed)

```
cd blockchain
npm install
npx hardhat test
```
You should see 8 passing tests.

## B. Local demo (no faucet, no wallet)

Terminal 1:
```
cd blockchain
npx hardhat node
```
It prints test accounts with private keys. Copy the private key of **Account #0**
(these local keys are public and worth nothing).

Terminal 2:
```
cd blockchain
npm run deploy:local
```
Put these in `verite-app/.env`:
```
CHAIN_RPC_URL=http://127.0.0.1:8545
REGISTRY_ADDRESS=<address printed by deploy>
CHAIN_PRIVATE_KEY=<Account #0 private key, starting 0x>
CHAIN_NETWORK_NAME=hardhat-local
CHAIN_EXPLORER_BASE=
```

## C. Polygon Amoy testnet demo (shows the transaction on a block explorer)

1. Install MetaMask and create a NEW wallet used only for testing.
2. Add the network: name Polygon Amoy, RPC https://rpc-amoy.polygon.technology,
   chain ID 80002, symbol POL, explorer https://amoy.polygonscan.com
3. Get free test POL at https://faucet.polygon.technology/ (or the Alchemy Amoy faucet).
4. MetaMask: Account details -> export private key. Add `0x` in front of it.
5. In `verite-app/.env`:
```
CHAIN_RPC_URL=https://rpc-amoy.polygon.technology
CHAIN_PRIVATE_KEY=0x<your test wallet key>
CHAIN_NETWORK_NAME=polygon-amoy
CHAIN_EXPLORER_BASE=https://amoy.polygonscan.com
```
6. Deploy:
```
cd blockchain
npm run deploy:amoy
```
7. Copy the printed `REGISTRY_ADDRESS=...` line into `verite-app/.env`.
8. Restart `npm run dev`, publish a product as the seller, then open the
   "View transaction on block explorer" link on the product page.

If the public RPC is busy, try https://polygon-amoy.drpc.org.

## D. Tamper demonstration for the defense

1. Publish a product (real transaction).
2. Verify it: result VERIFIED.
3. Simulate an attacker editing the database:
   `npx tsx scripts/tamper.ts <productId or barcode> 2030-12-31`
4. Verify again: result FAILED, because the contract still holds the original fingerprint.

## Trust model (state this honestly)

- The marketplace wallet signs the registration, so the chain proves the data was
  not changed AFTER registration. It does not prove the seller told the truth at
  entry time. Seller approval and licence checks address that.
- Seeded demo products use the simulated ledger and are labelled as such.
