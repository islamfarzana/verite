// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title ProductRegistry
/// @notice Stores one immutable Keccak-256 fingerprint per product so that
///         anyone can later check whether the product data they see still
///         matches what was registered. Only authorised registrars (the
///         marketplace wallet, plus any wallet the owner approves) can write.
///         Records can never be changed or deleted once registered.
contract ProductRegistry {
    struct Record {
        bytes32 hash;
        address registrar;
        uint64 timestamp;
        bool exists;
    }

    address public immutable owner;
    mapping(address => bool) public authorised;
    mapping(bytes32 => Record) private records; // key = keccak256(bytes(productId))

    event ProductRegistered(
        bytes32 indexed productKey,
        string productId,
        bytes32 hash,
        address indexed registrar,
        uint64 timestamp
    );
    event RegistrarChanged(address indexed registrar, bool allowed);

    constructor() {
        owner = msg.sender;
        authorised[msg.sender] = true;
        emit RegistrarChanged(msg.sender, true);
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "not owner");
        _;
    }

    function setAuthorised(address registrar, bool allowed) external onlyOwner {
        authorised[registrar] = allowed;
        emit RegistrarChanged(registrar, allowed);
    }

    /// @notice Register the fingerprint of a product. Reverts if the product
    ///         was already registered, so a record cannot be overwritten.
    function registerProductHash(string calldata productId, bytes32 hash) external {
        require(authorised[msg.sender], "not authorised");
        require(bytes(productId).length > 0, "empty product id");
        bytes32 key = keccak256(bytes(productId));
        require(!records[key].exists, "already registered");

        uint64 ts = uint64(block.timestamp);
        records[key] = Record(hash, msg.sender, ts, true);
        emit ProductRegistered(key, productId, hash, msg.sender, ts);
    }

    /// @notice Read the stored fingerprint. `exists` is false for unknown products.
    function getRecord(string calldata productId)
        external
        view
        returns (bytes32 hash, address registrar, uint64 timestamp, bool exists)
    {
        Record storage r = records[keccak256(bytes(productId))];
        return (r.hash, r.registrar, r.timestamp, r.exists);
    }
}
