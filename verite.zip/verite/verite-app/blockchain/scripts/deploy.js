const hre = require('hardhat');
const fs = require('fs');
const path = require('path');

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log(`Deploying ProductRegistry on "${hre.network.name}" from ${deployer.address}`);

  const Factory = await hre.ethers.getContractFactory('ProductRegistry');
  const contract = await Factory.deploy();
  await contract.waitForDeployment();

  const address = await contract.getAddress();
  const tx = contract.deploymentTransaction();
  console.log(`ProductRegistry deployed to: ${address}`);
  console.log(`Deployment transaction:      ${tx.hash}`);

  const dir = path.join(__dirname, '..', 'deployments');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(
    path.join(dir, `${hre.network.name}.json`),
    JSON.stringify({ network: hre.network.name, address, deployer: deployer.address, txHash: tx.hash, deployedAt: new Date().toISOString() }, null, 2)
  );

  console.log('\nNext step: add this line to verite-app/.env');
  console.log(`REGISTRY_ADDRESS=${address}`);
}

main().catch((err) => { console.error(err); process.exitCode = 1; });
