from app.utils.dates import normalize_date


def test_full_iso_date():
    assert normalize_date("2027-08-31", end_of_month_if_day_missing=True) == "2027-08-31"


def test_dd_mm_yyyy():
    assert normalize_date("31-08-2027", end_of_month_if_day_missing=True) == "2027-08-31"


def test_month_slash_two_digit_year_expiry_uses_last_day():
    assert normalize_date("08/26", end_of_month_if_day_missing=True) == "2026-08-31"


def test_month_year_manufacturing_uses_first_day():
    assert normalize_date("02/2026", end_of_month_if_day_missing=False) == "2026-02-01"


def test_month_name_and_year():
    assert normalize_date("AUG26", end_of_month_if_day_missing=True) == "2026-08-31"
    assert normalize_date("Aug 2026", end_of_month_if_day_missing=True) == "2026-08-31"


def test_leap_year_february_end_of_month():
    assert normalize_date("02/2028", end_of_month_if_day_missing=True) == "2028-02-29"


def test_unparseable_returns_none():
    assert normalize_date("not a date", end_of_month_if_day_missing=True) is None


def test_empty_returns_none():
    assert normalize_date("", end_of_month_if_day_missing=True) is None
