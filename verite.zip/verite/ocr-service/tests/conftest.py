import sys
from pathlib import Path

# Lets tests import tests/synthetic_labels.py directly.
sys.path.insert(0, str(Path(__file__).parent))
