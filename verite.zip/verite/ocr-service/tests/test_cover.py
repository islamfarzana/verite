"""Enhanced cover photo: background removed, packet flattened, colours unchanged."""
import cv2
import numpy as np

from app.services.cover import CANVAS, make_cover


def _packet_photo(bg=(200, 200, 205)):
    canvas = np.full((1200, 1200, 3), bg, np.uint8)
    packet = np.full((530, 400, 3), (230, 140, 40), np.uint8)  # blue-ish packet (BGR)
    cv2.putText(packet, "RICE 5KG", (40, 120), cv2.FONT_HERSHEY_SIMPLEX, 2, (20, 20, 20), 5)
    canvas[300:830, 400:800] = packet
    return canvas


def _jpg(img):
    return cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 95])[1].tobytes()


def test_background_is_removed_and_canvas_is_white_square():
    r = make_cover(_jpg(_packet_photo()))
    assert r.method == "grabcut"
    assert r.image.shape == (CANVAS, CANVAS, 3)
    for y, x in [(5, 5), (5, CANVAS - 5), (CANVAS - 5, 5), (CANVAS - 5, CANVAS - 5)]:
        assert r.image[y, x].tolist() == [255, 255, 255]


def test_packet_colours_are_not_changed():
    r = make_cover(_jpg(_packet_photo()))
    centre = r.image[CANVAS // 2, CANVAS // 2].astype(int)
    assert np.abs(centre - np.array([230, 140, 40])).max() <= 12  # JPEG tolerance only


def test_tilted_packet_is_flattened():
    img = _packet_photo()
    m = cv2.getRotationMatrix2D((600, 565), 8, 1.0)
    tilted = cv2.warpAffine(img, m, (1200, 1200), borderValue=(200, 200, 205))
    r = make_cover(_jpg(tilted))
    assert r.method == "grabcut"
    assert r.perspective_corrected is True


def test_unsegmentable_photo_falls_back_to_crop_only():
    noise = np.random.default_rng(0).integers(0, 255, (800, 800, 3), dtype=np.uint8)
    r = make_cover(_jpg(noise))
    assert r.image.shape == (CANVAS, CANVAS, 3)
    assert r.method in ("crop-only", "grabcut")
