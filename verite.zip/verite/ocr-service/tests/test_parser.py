from app.services.ocr_engine import TextRegion
from app.services.parser import parse


def _regions(*lines: str) -> list[TextRegion]:
    return [TextRegion(text=line, confidence=95.0) for line in lines]


def test_extracts_batch_number():
    fields = parse(_regions("LOT552F"))
    assert fields["batchNumber"].value == "LOT552F"


def test_extracts_mrp():
    fields = parse(_regions("MRP 410"))
    assert fields["mrp"].value == "410"


def test_extracts_barcode_prefers_longest_numeric_run():
    fields = parse(_regions("8901234567890", "410"))
    assert fields["barcode"].value == "8901234567890"


def test_extracts_weight_with_unit():
    fields = parse(_regions("25 KG"))
    assert fields["weight"].value == "25 KG"


def test_extracts_and_normalizes_dates():
    fields = parse(_regions("MFG 02/2026", "EXP 08/2027"))
    assert fields["manufacturingDate"].value == "2026-02-01"
    assert fields["expiryDate"].value == "2027-08-31"


def test_extracts_brand_with_keyword():
    fields = parse(_regions("Brand: GreenMart"))
    assert fields["brand"].value == "GreenMart"


def test_missing_fields_are_null_not_fabricated():
    fields = parse(_regions("random unrelated text with no fields"))
    assert fields["batchNumber"].value is None
    assert fields["batchNumber"].confidence == 0.0
    assert fields["mrp"].value is None


def test_duplicate_lines_are_deduplicated():
    fields = parse(_regions("MRP 410", "MRP 410", "MRP 410"))
    assert fields["mrp"].value == "410"


def test_full_label_example_from_spec():
    fields = parse(
        _regions(
            "GREENMART PREMIUM RICE",
            "LOT552F",
            "MFG 02/2026",
            "EXP 08/2027",
            "MRP 410",
            "25 KG",
            "8901234567890",
        )
    )
    assert fields["batchNumber"].value == "LOT552F"
    assert fields["manufacturingDate"].value == "2026-02-01"
    assert fields["expiryDate"].value == "2027-08-31"
    assert fields["mrp"].value == "410"
    assert fields["weight"].value == "25 KG"
    assert fields["barcode"].value == "8901234567890"
