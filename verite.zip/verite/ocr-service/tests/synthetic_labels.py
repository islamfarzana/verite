"""SYNTHETIC test labels rendered with a Bengali font (Noto Sans Bengali, OFL licence).

These images are generated for automated tests; they are clean, flat and printed in one font,
so passing them shows the pipeline WORKS on Bangla, not how accurate it is on real packaging
photos (see docs: the 50-100 real-label evaluation is separate).
"""
import os
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    os.environ.get("OCR_TEST_BENGALI_FONT", ""),
    "/usr/share/fonts/truetype/noto/NotoSansBengali-Regular.ttf",
    "/home/claude/google-fonts/ofl/notosansbengali/NotoSansBengali[wdth,wght].ttf",
]


def bengali_font_path() -> str | None:
    for p in FONT_CANDIDATES:
        if p and Path(p).exists():
            return p
    return None


FRONT_LINES = [
    "চাষী চিনিগুড়া চাল",
    "Chashi Chinigura Rice",
    "নিট ওজন: ১ কেজি",
]
BACK_LINES = [
    "প্রস্তুতকারক: প্রাণ এগ্রো লিমিটেড",
    "ব্যাচ নং: LOT-241A",
    "উৎপাদনের তারিখ: ১৫/০১/২০২৬",
    "মেয়াদ উত্তীর্ণের তারিখ: ১৪/০১/২০২৭",
    "সর্বোচ্চ খুচরা মূল্য: ১৫০ টাকা",
    "বিএসটিআই সিএম লাইসেন্স নং: DEMO-CM-0002",
]


def render_label(lines: list[str], size=(1400, 900), font_px=54, bg=(250, 247, 240)) -> np.ndarray:
    font = ImageFont.truetype(bengali_font_path(), font_px, layout_engine=ImageFont.Layout.RAQM)
    img = Image.new("RGB", size, bg)
    draw = ImageDraw.Draw(img)
    y = 60
    for line in lines:
        draw.text((70, y), line, font=font, fill=(25, 25, 25))
        y += int(font_px * 1.7)
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)


def as_photo_of_packet(label: np.ndarray, *, tilt_px: int = 90, canvas=(1800, 1400), bg=(60, 90, 70)) -> np.ndarray:
    """Place the label on a dark table, seen at an angle (perspective), like a phone photo."""
    h, w = label.shape[:2]
    cw, ch = canvas
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    dst = np.float32([[180 + tilt_px, 200], [cw - 220, 160 + tilt_px], [cw - 160 - tilt_px, ch - 180], [220, ch - 240 + tilt_px]])
    m = cv2.getPerspectiveTransform(src, dst)
    out = np.full((ch, cw, 3), bg, np.uint8)
    warped = cv2.warpPerspective(label, m, (cw, ch))
    mask = cv2.warpPerspective(np.full((h, w), 255, np.uint8), m, (cw, ch))
    out[mask > 0] = warped[mask > 0]
    return out


def darken(img: np.ndarray, factor: float = 0.45) -> np.ndarray:
    return np.clip(img.astype(np.float32) * factor, 0, 255).astype(np.uint8)


def encode(img: np.ndarray, ext: str = ".jpg") -> bytes:
    ok, buf = cv2.imencode(ext, img, [cv2.IMWRITE_JPEG_QUALITY, 90])
    assert ok
    return buf.tobytes()
