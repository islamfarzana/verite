"""API-level tests for the v4 endpoints. They need the full service environment (FastAPI,
SQLAlchemy, Tesseract with 'ben'), e.g. inside the Docker image; elsewhere they are skipped."""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("sqlalchemy")

from fastapi.testclient import TestClient  # noqa: E402

from synthetic_labels import BACK_LINES, FRONT_LINES, bengali_font_path, encode, render_label  # noqa: E402


class _FakeSession:
    """Stands in for the database session: the endpoint logic, not Postgres, is under test."""

    def add(self, obj):
        if getattr(obj, "id", None) is None:
            obj.id = "test"

    def commit(self):
        pass

    def flush(self):
        pass


@pytest.fixture(scope="module")
def client():
    from app.main import app
    from app.models.database import get_db

    app.dependency_overrides[get_db] = lambda: _FakeSession()
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.mark.skipif(bengali_font_path() is None, reason="needs a Bengali font")
def test_extract_front_and_back(client):
    files = {
        "image": ("front.jpg", encode(render_label(FRONT_LINES)), "image/jpeg"),
        "backImage": ("back.jpg", encode(render_label(BACK_LINES)), "image/jpeg"),
    }
    res = client.post("/api/v1/ocr/extract", files=files)
    assert res.status_code == 200, res.text
    body = res.json()
    assert body["fields"]["expiryDate"]["value"] == "2027-01-14"
    assert body["fields"]["productNameBn"]["value"] == "চাষী চিনিগুড়া চাল"
    assert "bn" in body["languages"] and "en" in body["languages"]
    assert [s["side"] for s in body["sides"]] == ["front", "back"]


@pytest.mark.skipif(bengali_font_path() is None, reason="needs a Bengali font")
def test_extract_front_only_still_works(client):
    res = client.post("/api/v1/ocr/extract", files={"image": ("front.jpg", encode(render_label(FRONT_LINES)), "image/jpeg")})
    assert res.status_code == 200, res.text
    assert len(res.json()["sides"]) == 1


def test_cover_returns_jpeg(client):
    import cv2
    import numpy as np

    img = np.full((800, 800, 3), (200, 200, 205), np.uint8)
    img[200:600, 250:550] = (230, 140, 40)
    res = client.post("/api/v1/ocr/cover", files={"image": ("p.jpg", cv2.imencode(".jpg", img)[1].tobytes(), "image/jpeg")})
    assert res.status_code == 200
    assert res.headers["content-type"] == "image/jpeg"
    assert res.headers["x-cover-method"] in ("grabcut", "crop-only")


def test_rejects_non_image(client):
    res = client.post("/api/v1/ocr/cover", files={"image": ("a.txt", b"hello", "text/plain")})
    assert res.status_code == 400
