"""Bangla + English parsing (text level). No OCR engine needed."""
import unicodedata

from app.services.ocr_engine import TextRegion
from app.services.parser import detect_languages, parse
from app.utils.dates import normalize_date


def _regions(*lines: str, side: str = "front") -> list[TextRegion]:
    return [TextRegion(text=line, confidence=90.0, side=side) for line in lines]


def test_bangla_back_label_fields():
    f = parse(_regions(
        "প্রস্তুতকারক: প্রাণ এগ্রো লিমিটেড",
        "ব্যাচ নং: LOT-241A",
        "উৎপাদনের তারিখ: ১৫/০১/২০২৬",
        "মেয়াদ উত্তীর্ণের তারিখ: ১৪/০১/২০২৭",
        "সর্বোচ্চ খুচরা মূল্য: ১৫০ টাকা",
        "নিট ওজন: ৫০০ গ্রাম",
        "বিএসটিআই সিএম লাইসেন্স নং: DEMO-CM-0002",
        side="back",
    ))
    assert f["manufacturer"].value == "প্রাণ এগ্রো লিমিটেড"
    assert f["batchNumber"].value == "LOT-241A"
    assert f["manufacturingDate"].value == "2026-01-15"
    assert f["expiryDate"].value == "2027-01-14"
    assert f["mrp"].value == "150"
    assert f["weight"].value == "500 G"
    assert f["licenceNumber"].value == "DEMO-CM-0002"


def test_ocr_vowel_confusion_is_tolerated():
    # OCR commonly returns "মুল্য" for "মূল্য" and "মেয়াদ" with a decomposed "য়".
    decomposed = unicodedata.normalize("NFD", "মেয়াদ উত্তীর্ণের তারিখ: ০৮/২০২৭")
    f = parse(_regions("সর্বোচ্চ খুচরা মুল্য: ৯৫ টাকা", decomposed))
    assert f["mrp"].value == "95"
    assert f["expiryDate"].value == "2027-08-31"


def test_bengali_visarga_used_as_colon_and_khanda_ta_variant():
    f = parse(_regions("উত্‌পাদন তারিখঃ ০১/০৩/২০২৬", "মেয়াদঃ ০১/০৩/২০২৮"))
    assert f["manufacturingDate"].value == "2026-03-01"
    assert f["expiryDate"].value == "2028-03-01"


def test_product_names_in_both_scripts_come_from_the_front():
    regions = _regions("চাষী চিনিগুড়া চাল", "Chashi Chinigura Rice", "নিট ওজন: ১ কেজি") + _regions(
        "Distributed in Bangladesh", "বাংলাদেশে বাজারজাত", side="back"
    )
    f = parse(regions)
    assert f["productName"].value == "Chashi Chinigura Rice"
    assert f["productNameBn"].value == "চাষী চিনিগুড়া চাল"
    assert f["weight"].value == "1 KG"


def test_label_value_lines_are_never_taken_as_the_product_name():
    f = parse(_regions("সর্বোচ্চ খুচরা মূল্য: ১৫০ টাকা", "চিনিগুড়া চাল"))
    assert f["productNameBn"].value == "চিনিগুড়া চাল"


def test_mixed_line_mfg_and_exp_on_one_line():
    f = parse(_regions("MFG: 02/2026 EXP: 08/2027"))
    assert f["manufacturingDate"].value == "2026-02-01"
    assert f["expiryDate"].value == "2027-08-31"


def test_licence_value_must_contain_a_digit():
    f = parse(_regions("লাইসেন্স: প্রযোজ্য নয়"))
    assert f["licenceNumber"].value is None


def test_brand_is_not_taken_from_a_manufacturer_line():
    f = parse(_regions("Manufactured by: Acme Mills Ltd"))
    assert f["manufacturer"].value == "Acme Mills Ltd"
    assert f["brand"].value is None


def test_language_detection():
    assert detect_languages("চাষী চিনিগুড়া চাল Chashi Rice") == ["bn", "en"]
    assert detect_languages("MRP 410") == ["en"]
    assert detect_languages("") == []


def test_bangla_dates():
    assert normalize_date("১৫ জানুয়ারি ২০২৬", end_of_month_if_day_missing=True) == "2026-01-15"
    assert normalize_date("জানুয়ারী ২০২৬", end_of_month_if_day_missing=True) == "2026-01-31"
    assert normalize_date("০৩/২০২৬", end_of_month_if_day_missing=False) == "2026-03-01"
    assert normalize_date("১৫ মে ২০২৬", end_of_month_if_day_missing=False) == "2026-05-15"


def test_month_word_only_replaced_as_a_whole_word():
    # "মে" (May) inside "মেয়াদ" (expiry) must not turn into a month.
    assert normalize_date("মেয়াদ", end_of_month_if_day_missing=True) is None


def test_more_english_date_formats():
    assert normalize_date("15 JAN 2026", end_of_month_if_day_missing=False) == "2026-01-15"
    assert normalize_date("15-Jan-26", end_of_month_if_day_missing=False) == "2026-01-15"
    assert normalize_date("31.08.2027", end_of_month_if_day_missing=True) == "2027-08-31"
    assert normalize_date("31/08/27", end_of_month_if_day_missing=True) == "2027-08-31"
