"""End-to-end OCR on SYNTHETIC Bangla+English label images (rendered with Noto Sans Bengali).

Shows the pipeline reads Bangla through perspective, rotation and low light. Synthetic, clean,
single-font images: this is a functional test, NOT an accuracy measurement on real packaging.
Skipped automatically when Tesseract's Bengali data ("ben") or a Bengali font is unavailable.
"""
import cv2
import pytest

from synthetic_labels import BACK_LINES, FRONT_LINES, as_photo_of_packet, bengali_font_path, darken, encode, render_label

pytesseract = pytest.importorskip("pytesseract")
try:
    _LANGS = set(pytesseract.get_languages(config=""))
except Exception:  # tesseract binary missing
    _LANGS = set()
pytestmark = pytest.mark.skipif(
    "ben" not in _LANGS or bengali_font_path() is None, reason="needs tesseract 'ben' data and a Bengali font"
)


@pytest.fixture(scope="module")
def engine():
    from app.core.config import settings
    from app.services.ocr_engine import OcrEngine

    settings.OCR_ENGINE = "tesseract"
    e = OcrEngine()
    e.load()
    return e


def _read(engine, img, side="back"):
    from app.services import preprocessing
    from app.services.parser import parse

    prepared = preprocessing.prepare_variants(encode(img))
    _variant, regions = engine.recognize_best(prepared.variants)
    for r in regions:
        r.side = side
    return prepared, regions, parse(regions)


CORE = {"manufacturingDate": "2026-01-15", "expiryDate": "2027-01-14", "mrp": "150", "manufacturer": "প্রাণ এগ্রো লিমিটেড"}


def _check_core(fields):
    for k, v in CORE.items():
        assert fields[k].value == v, (k, fields[k].value)


def test_flat_bangla_back_label(engine):
    _p, _r, f = _read(engine, render_label(BACK_LINES))
    _check_core(f)


def test_front_label_names_in_both_scripts(engine):
    _p, _r, f = _read(engine, render_label(FRONT_LINES), side="front")
    assert f["productName"].value == "Chashi Chinigura Rice"
    assert f["productNameBn"].value == "চাষী চিনিগুড়া চাল"
    assert f["weight"].value == "1 KG"


def test_photo_at_an_angle_is_flattened_and_read(engine):
    p, _r, f = _read(engine, as_photo_of_packet(render_label(BACK_LINES)))
    assert p.perspective_corrected is True
    _check_core(f)
    assert f["batchNumber"].value == "LOT-241A"


def test_sideways_photo_is_rotated_and_read(engine):
    p, _r, f = _read(engine, cv2.rotate(render_label(BACK_LINES), cv2.ROTATE_90_CLOCKWISE))
    assert p.rotated_degrees in (90, 270)
    _check_core(f)


def test_dark_photo_is_read(engine):
    _p, _r, f = _read(engine, darken(render_label(BACK_LINES)))
    _check_core(f)


def test_front_and_back_together(engine):
    from app.services.parser import parse

    _p1, front, _ = _read(engine, render_label(FRONT_LINES), side="front")
    _p2, back, _ = _read(engine, render_label(BACK_LINES), side="back")
    f = parse(front + back)
    assert f["productName"].value == "Chashi Chinigura Rice"
    assert f["productNameBn"].value == "চাষী চিনিগুড়া চাল"
    _check_core(f)


def test_read_photos_front_and_back_with_voting(engine):
    """The exact function the /extract route uses: both photos, variants and field-level voting."""
    from app.services.extraction import read_photos

    r = read_photos(engine, encode(render_label(FRONT_LINES)), encode(as_photo_of_packet(render_label(BACK_LINES))))
    assert [s.side for s in r.sides] == ["front", "back"]
    assert r.sides[1].perspective_corrected is True
    assert r.fields["productNameBn"].value == "চাষী চিনিগুড়া চাল"
    _check_core(r.fields)
