from fastapi.testclient import TestClient

from app.main import app


def test_health_endpoint_shape():
    with TestClient(app) as client:
        res = client.get("/health")
        assert res.status_code == 200
        body = res.json()
        assert "status" in body
        assert "ocr" in body
        assert "database" in body


def test_version_endpoint():
    with TestClient(app) as client:
        res = client.get("/version")
        assert res.status_code == 200
        assert res.json()["service"] == "OCR"
