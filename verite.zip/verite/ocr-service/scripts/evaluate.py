"""
OCR evaluation — field-level precision and recall on LABELLED photos.

Use it for the thesis evaluation chapter with 50-100 REAL Bangladeshi labels:

    python scripts/evaluate.py --images data/labels --truth data/labels/truth.csv --out results/

truth.csv columns (UTF-8; leave a cell empty if the field is not printed on the pack):
    front,back,productName,productNameBn,manufacturer,batchNumber,manufacturingDate,expiryDate,mrp,weight,licenceNumber
    rice_front.jpg,rice_back.jpg,Chashi Chinigura Rice,চাষী চিনিগুড়া চাল,...,2026-01-15,2027-01-14,150,1 KG,...

It runs every configuration (ablation) below on every pack and reports, per field:
    precision = correct / fields the system filled in
    recall    = correct / fields actually printed on the pack
A value is "correct" when it matches the truth after normalisation (case, spaces, Bengali digits).

Configurations:
    baseline-eng        Tesseract English only, single image, no perspective/orientation/variants
                        (close to the v3 Tesseract path)
    ben+eng-plain       Tesseract Bangla+English, no extra preprocessing
    ben+eng-full-bestvariant  + perspective + orientation + 3 variants, keep the best-scoring variant
    ben+eng-full-voting       + perspective + orientation + 3 variants, field-level voting (v4 default)
    (PaddleOCR configs are added automatically when paddleocr is installed.)

--synthetic N generates N SYNTHETIC packs (rendered text, random tilt/rotation/darkness) to show the
tool working. Synthetic results are NOT a measure of real-world accuracy and must not be reported
as such.
"""
import argparse
import csv
import json
import random
import sys
import time
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

FIELDS = ["productName", "productNameBn", "manufacturer", "batchNumber", "manufacturingDate", "expiryDate", "mrp", "weight",
          "licenceNumber"]


def norm(v) -> str:
    from app.utils.dates import to_ascii_digits

    if v is None:
        return ""
    v = unicodedata.normalize("NFC", to_ascii_digits(str(v))).casefold()
    return "".join(v.split()).strip(".:-")


def configs():
    out = [
        ("baseline-eng", dict(lang="eng", perspective=False, orient=False, variants=False, paddle=False)),
        ("ben+eng-plain", dict(lang="ben+eng", perspective=False, orient=False, variants=False, paddle=False)),
        ("ben+eng-full-bestvariant", dict(lang="ben+eng", perspective=True, orient=True, variants=True, voting=False, paddle=False)),
        ("ben+eng-full-voting", dict(lang="ben+eng", perspective=True, orient=True, variants=True, voting=True, paddle=False)),
    ]
    try:
        import paddleocr  # noqa: F401
        out.append(("paddle+ben-hybrid-full", dict(lang="ben+eng", perspective=True, orient=True, variants=True, paddle=True)))
    except Exception:
        pass
    return out


def build_engine(cfg):
    from app.core.config import settings
    from app.services.ocr_engine import OcrEngine

    settings.OCR_ENGINE = "hybrid" if cfg["paddle"] else "tesseract"
    settings.TESSERACT_LANG = cfg["lang"]
    e = OcrEngine()
    e.load()
    return e


def read_pack(engine, cfg, front: bytes, back: bytes | None):
    from app.services.extraction import read_photos

    result = read_photos(engine, front, back, perspective=cfg["perspective"], orient=cfg["orient"], variants=cfg["variants"],
                         voting=cfg.get("voting", cfg["variants"]))
    return {k: v.value for k, v in result.fields.items()}


def make_synthetic(n: int, out_dir: Path, seed: int = 7) -> Path:
    import cv2
    from synthetic_labels import BACK_LINES, FRONT_LINES, as_photo_of_packet, darken, render_label

    rnd = random.Random(seed)
    out_dir.mkdir(parents=True, exist_ok=True)
    truth = out_dir / "truth.csv"
    with truth.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["front", "back"] + FIELDS)
        for i in range(n):
            front, back = render_label(FRONT_LINES), render_label(BACK_LINES)
            condition = rnd.choice(["flat", "angle", "rotated", "dark"])
            if condition == "angle":
                back = as_photo_of_packet(back, tilt_px=rnd.randint(40, 120))
            elif condition == "rotated":
                back = cv2.rotate(back, rnd.choice([cv2.ROTATE_90_CLOCKWISE, cv2.ROTATE_180]))
            elif condition == "dark":
                back = darken(back, rnd.uniform(0.35, 0.6))
            fn, bn = f"syn{i:03d}_{condition}_front.jpg", f"syn{i:03d}_{condition}_back.jpg"
            cv2.imwrite(str(out_dir / fn), front)
            cv2.imwrite(str(out_dir / bn), back)
            w.writerow([fn, bn, "Chashi Chinigura Rice", "চাষী চিনিগুড়া চাল", "প্রাণ এগ্রো লিমিটেড", "LOT-241A", "2026-01-15",
                        "2027-01-14", "150", "1 KG", "DEMO-CM-0002"])
    return truth


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", type=Path)
    ap.add_argument("--truth", type=Path)
    ap.add_argument("--out", type=Path, default=Path("evaluation_results"))
    ap.add_argument("--synthetic", type=int, default=0, help="generate N synthetic packs instead (demo only)")
    args = ap.parse_args()

    if args.synthetic:
        args.images = args.out / "synthetic_images"
        args.truth = make_synthetic(args.synthetic, args.images)
    if not args.images or not args.truth:
        ap.error("--images and --truth are required (or --synthetic N)")

    rows = list(csv.DictReader(args.truth.open(encoding="utf-8")))
    args.out.mkdir(parents=True, exist_ok=True)
    summary = {}
    detail_path = args.out / "per_pack.csv"
    with detail_path.open("w", newline="", encoding="utf-8") as dfh:
        dw = csv.writer(dfh)
        dw.writerow(["config", "front", "field", "expected", "extracted", "correct"])
        for name, cfg in configs():
            engine = build_engine(cfg)
            stats = {f: {"tp": 0, "filled": 0, "present": 0} for f in FIELDS}
            t0 = time.time()
            for row in rows:
                front = (args.images / row["front"]).read_bytes()
                back = (args.images / row["back"]).read_bytes() if row.get("back") else None
                got = read_pack(engine, cfg, front, back)
                for f in FIELDS:
                    exp, val = norm(row.get(f)), norm(got.get(f))
                    ok = bool(exp) and exp == val
                    stats[f]["present"] += bool(exp)
                    stats[f]["filled"] += bool(val)
                    stats[f]["tp"] += ok
                    dw.writerow([name, row["front"], f, row.get(f, ""), got.get(f) or "", int(ok)])
            secs = (time.time() - t0) / max(len(rows), 1)
            summary[name] = {"seconds_per_pack": round(secs, 2), "fields": {}}
            for f, s in stats.items():
                p = s["tp"] / s["filled"] if s["filled"] else None
                r = s["tp"] / s["present"] if s["present"] else None
                summary[name]["fields"][f] = {"precision": p, "recall": r, **s}
            print(f"done: {name} ({secs:.1f}s/pack)")

    (args.out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    fmt = lambda x: "—" if x is None else f"{x:.2f}"  # noqa: E731
    lines = [f"# OCR evaluation ({'SYNTHETIC — not real-world accuracy' if args.synthetic else 'labelled photos'})", "",
             f"Packs: {len(rows)}", "", "Recall per field (precision in brackets):", "",
             "| Field | " + " | ".join(summary) + " |", "|---|" + "---|" * len(summary)]
    for f in FIELDS:
        cells = [f"{fmt(summary[c]['fields'][f]['recall'])} ({fmt(summary[c]['fields'][f]['precision'])})" for c in summary]
        lines.append(f"| {f} | " + " | ".join(cells) + " |")
    lines.append("| seconds per pack | " + " | ".join(str(summary[c]["seconds_per_pack"]) for c in summary) + " |")
    (args.out / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
