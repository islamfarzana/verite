"""
Database layer — Database_Integration.md.

Intentionally a completely separate database from the marketplace's SQLite
DB. This service is the System of Record for OCR request/result history
only; the marketplace remains the System of Record for products (§1, §24).
"""
import uuid
from datetime import datetime

from sqlalchemy import Column, String, Integer, Float, Text, DateTime, ForeignKey, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session

from app.core.config import settings

Base = declarative_base()


def _uuid() -> str:
    return str(uuid.uuid4())


class OcrRequest(Base):
    __tablename__ = "ocr_requests"

    id = Column(String, primary_key=True, default=_uuid)
    request_id = Column(String, unique=True, index=True, default=_uuid)
    image_name = Column(String)
    image_size = Column(Integer)
    image_type = Column(String)
    processing_status = Column(String, default="PENDING")
    processing_time_ms = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


class OcrResult(Base):
    __tablename__ = "ocr_results"

    id = Column(String, primary_key=True, default=_uuid)
    request_id = Column(String, ForeignKey("ocr_requests.request_id"), index=True)
    quality = Column(String)
    average_confidence = Column(Float)
    barcode = Column(String, nullable=True)
    raw_text = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class OcrField(Base):
    __tablename__ = "ocr_fields"

    id = Column(String, primary_key=True, default=_uuid)
    result_id = Column(String, ForeignKey("ocr_results.id"), index=True)
    field_name = Column(String)
    field_value = Column(Text, nullable=True)
    confidence = Column(Float)
    normalized_value = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class OcrLog(Base):
    __tablename__ = "ocr_logs"

    id = Column(String, primary_key=True, default=_uuid)
    request_id = Column(String, index=True, nullable=True)
    log_level = Column(String)
    message = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)


# --- engine/session plumbing -------------------------------------------------

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db() -> None:
    """Creates tables if they don't exist. A real production deployment
    should use Alembic migrations instead (Database_Integration.md uses
    Alembic as the stated migration tool) — this call is the safe minimum
    so the service works out of the box; swap for `alembic upgrade head`
    in CI/CD once migrations are authored."""
    Base.metadata.create_all(bind=engine)


def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
