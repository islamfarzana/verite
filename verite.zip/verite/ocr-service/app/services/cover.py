"""
Enhanced product cover photo — made from the seller's REAL front photo.

This is deliberately NOT generative AI. Generative image models redraw packaging and routinely
change text (Bangla especially), logos, weights and colours; on a product-authenticity platform
the cover must show the real packet. Every packet pixel in the output comes from the photo.

Steps (classic computer vision, OpenCV only — no extra model download):
  1. Perspective flatten when a clear four-corner outline is found (same as OCR preprocessing).
  2. Foreground segmentation with GrabCut (iterative graph-cut segmentation, Rother et al. 2004).
     When the photo's border has a fairly uniform colour (a table, a sheet of paper), pixels close
     to that colour seed the background model; otherwise GrabCut starts from a rectangle a few
     percent inside the frame. The mask is cleaned (opening, largest region, holes filled).
  3. Sanity check: if the "product" mask is implausibly small or large, segmentation is not
     trusted and the photo is only cropped/straightened ("crop-only").
  4. Centred on a white square canvas with padding — a studio-style marketplace cover.
     Colours and tones of the packet are NOT changed (no white balance, no filters): automatic
     colour correction shifted brand colours in testing, which is exactly what must not happen.
"""
from dataclasses import dataclass

import cv2
import numpy as np

from app.services.preprocessing import _order_corners, correct_perspective, decode_image, four_point_warp, resize

CANVAS = 1000
PADDING = 0.08


@dataclass
class CoverResult:
    image: np.ndarray  # BGR, CANVAS x CANVAS
    method: str  # grabcut | crop-only
    perspective_corrected: bool
    foreground_ratio: float


def _border_background(lab: np.ndarray, ring: float = 0.03):
    """Median colour of the frame border and how uniform it is (median absolute deviation)."""
    h, w = lab.shape[:2]
    b = max(2, int(min(h, w) * ring))
    border = np.concatenate([lab[:b].reshape(-1, 3), lab[-b:].reshape(-1, 3), lab[:, :b].reshape(-1, 3), lab[:, -b:].reshape(-1, 3)])
    median = np.median(border, axis=0)
    mad = float(np.median(np.linalg.norm(border - median, axis=1)))
    return median, mad


def _clean_mask(fg: np.ndarray) -> np.ndarray:
    k = max(3, int(min(fg.shape) * 0.01)) | 1
    fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, np.ones((k, k), np.uint8), iterations=2)
    fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8), iterations=2)
    contours, _ = cv2.findContours(fg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return fg
    largest = max(contours, key=cv2.contourArea)
    out = np.zeros_like(fg)
    cv2.drawContours(out, [largest], -1, 255, thickness=cv2.FILLED)  # keep the packet, fill holes
    return out


def segment_product(img: np.ndarray, margin: float = 0.04, iterations: int = 5) -> tuple[np.ndarray, float, str]:
    """GrabCut foreground mask (uint8 0/255), the fraction of the frame it covers, and the seeding used."""
    h, w = img.shape[:2]
    lab = cv2.cvtColor(cv2.GaussianBlur(img, (5, 5), 0), cv2.COLOR_BGR2LAB).astype(np.float32)
    median, mad = _border_background(lab)
    bgd, fgd = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
    if mad < 12:  # fairly uniform background: seed GrabCut with colour distance to it
        dist = np.linalg.norm(lab - median, axis=2)
        thr = max(14.0, 3.0 * mad)
        mask = np.full((h, w), cv2.GC_PR_FGD, np.uint8)
        mask[dist < 2 * thr] = cv2.GC_PR_BGD
        mask[dist < thr] = cv2.GC_BGD
        ring = max(2, int(min(h, w) * 0.01))
        mask[:ring], mask[-ring:], mask[:, :ring], mask[:, -ring:] = cv2.GC_BGD, cv2.GC_BGD, cv2.GC_BGD, cv2.GC_BGD
        if (mask == cv2.GC_PR_FGD).sum() == 0:
            return np.zeros((h, w), np.uint8), 0.0, "uniform-background"
        cv2.grabCut(img, mask, None, bgd, fgd, iterations, cv2.GC_INIT_WITH_MASK)
        seeding = "uniform-background"
    else:
        mask = np.zeros((h, w), np.uint8)
        rect = (int(w * margin), int(h * margin), int(w * (1 - 2 * margin)), int(h * (1 - 2 * margin)))
        cv2.grabCut(img, mask, rect, bgd, fgd, iterations, cv2.GC_INIT_WITH_RECT)
        seeding = "rectangle"
    fg = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
    fg = _clean_mask(fg)
    return fg, float(fg.mean() / 255.0), seeding


def compose_on_canvas(img: np.ndarray, mask: np.ndarray | None) -> np.ndarray:
    if mask is not None:
        ys, xs = np.where(mask > 0)
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        img, mask = img[y0:y1, x0:x1], mask[y0:y1, x0:x1]
    h, w = img.shape[:2]
    inner = int(CANVAS * (1 - 2 * PADDING))
    scale = inner / max(h, w)
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    img = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC)
    canvas = np.full((CANVAS, CANVAS, 3), 255, np.uint8)
    x, y = (CANVAS - nw) // 2, (CANVAS - nh) // 2
    if mask is None:
        canvas[y:y + nh, x:x + nw] = img
    else:
        m = cv2.resize(mask, (nw, nh), interpolation=cv2.INTER_LINEAR)
        m = cv2.GaussianBlur(m, (5, 5), 0).astype(np.float32)[..., None] / 255.0  # soft edge
        region = canvas[y:y + nh, x:x + nw].astype(np.float32)
        canvas[y:y + nh, x:x + nw] = (img.astype(np.float32) * m + region * (1 - m)).astype(np.uint8)
    return canvas


def make_cover(raw_bytes: bytes, *, min_fg: float = 0.05, max_fg: float = 0.95) -> CoverResult:
    img = resize(decode_image(raw_bytes), 1400)
    img, corrected = correct_perspective(img)
    try:
        mask, ratio, _seeding = segment_product(img)
    except cv2.error:
        mask, ratio = None, 0.0
    if mask is None or not (min_fg <= ratio <= max_fg):
        return CoverResult(compose_on_canvas(img, None), "crop-only", corrected, ratio)
    if not corrected:
        # The segmented packet outline is often a cleaner quadrilateral than raw edges: if it has
        # four corners, flatten the packet with the same four-point transform.
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            c = max(contours, key=cv2.contourArea)
            approx = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
            if len(approx) == 4 and cv2.isContourConvex(approx):
                corners = _order_corners(approx)
                img = four_point_warp(img, corners)
                mask = four_point_warp(cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR), corners)[..., 0]
                mask = np.where(mask > 127, 255, 0).astype(np.uint8)
                corrected = True
    return CoverResult(compose_on_canvas(img, mask), "grabcut", corrected, ratio)
