"""
Regex Parser — Regex_Parser.md.

Converts raw OCR text into structured fields. Every field is either a real
match from the text (with a confidence score derived from the underlying
OCR confidence of the text region it came from) or explicitly null — never
fabricated (§24: "Do not generate fake values. Do not guess missing
information.").

Bangla + English: every field has English and Bengali keyword patterns
(e.g. "EXP" and "মেয়াদ উত্তীর্ণের তারিখ"). Bengali digits are converted to
ASCII before matching numbers and dates. Text is NFC-normalised first, so
"য়" written as one code point or as "য" + nukta compares equal.
"""
import re
import unicodedata
from dataclasses import dataclass
from typing import Optional

from app.services.ocr_engine import TextRegion
from app.utils.dates import normalize_date, to_ascii_digits


def _nfc(s: str) -> str:
    return unicodedata.normalize("NFC", s)


# OCR often confuses short/long Bengali vowel signs (ি/ী, ু/ূ), e.g. reads "মূল্য" as "মুল্য".
# Keywords therefore accept either form.
_VOWEL_FUZZ = {"ি": "[িী]", "ী": "[িী]", "ু": "[ুূ]", "ূ": "[ুূ]"}


def _fuzz(pattern: str) -> str:
    return "".join(_VOWEL_FUZZ.get(ch, ch) for ch in pattern)


def _rx(pattern: str, flags: int = re.IGNORECASE) -> re.Pattern:
    return re.compile(_fuzz(_nfc(pattern)), flags)


# Colon variants used on Bangla labels: ":" and the Bengali visarga "ঃ".
_SEP = r"\s*[:ঃ\-–=]?\s*"
# A date value: digits/letters/Bengali letters with / - . , and spaces, but never a line break.
_DATE_VALUE = r"([0-9A-Za-zঀ-৿](?:[0-9A-Za-zঀ-৿/\-\.,]|[^\S\n]){2,28})"
# "উৎ" is printed with khanda-ta (ৎ) but OCR often returns "ত্" — accept both.
_UT = r"উ(?:ৎ|ত্‍?)"

_BATCH_DIRECT_RE = _rx(r"\b((?:LOT|BATCH)[A-Z0-9\-]{2,})\b")
_BATCH_LABELED_RE = _rx(r"(?:LOT|BATCH|B\.?\s?NO|ব্যাচ|লট)\s*(?:NO\.?|NUMBER|#|নং|নম্বর|নাম্বার)?" + _SEP + r"([A-Z0-9][A-Z0-9\-/]{1,})")
_MFG_RE = _rx(
    r"(?:MFG|MFD|MANUFACTURED(?:\s+ON)?|MANUFACTURING\s+DATE|PACKED(?:\s+ON)?|PKD|PACKING\s+DATE|DATE\s+OF\s+MFG"
    + rf"|{_UT}পাদন(?:ের)?\s*(?:তারিখ|তাং)|{_UT}পাদন|প্রস্তুত(?:ের|করণের)?\s*(?:তারিখ|তাং)|মোড়কজাত(?:করণের)?\s*(?:তারিখ|তাং)|প্যাকিং(?:ের)?\s*(?:তারিখ|তাং))"
    + _SEP + _DATE_VALUE
)
_EXP_RE = _rx(
    r"(?:EXP(?:IRY)?(?:\s+DATE)?|EXPIRES(?:\s+ON)?|BEST\s+BEFORE|USE\s+BEFORE|USE\s+BY|BBE?"
    r"|মেয়াদ\s*(?:উত্তীর্ণ(?:ের)?|শেষ(?:ের)?)?\s*(?:তারিখ|তাং)?|মেয়াদোত্তীর্ণ(?:ের)?\s*(?:তারিখ|তাং)?|ব্যবহারের\s*(?:শেষ\s*)?(?:তারিখ|মেয়াদ))"
    + _SEP + _DATE_VALUE
)
_MRP_RE = _rx(
    r"(?:M\.?R\.?P\.?|PRICE|TK\.?|৳|RS\.?|সর্বোচ্চ\s*খুচরা\s*মূল্য|খুচরা\s*মূল্য|মূল্য|দাম)"
    + _SEP + r"(?:৳|TK\.?|টাকা)?\s*([0-9]+(?:\.[0-9]{1,2})?)"
)
_WEIGHT_RE = _rx(r"\b([0-9]+(?:\.[0-9]+)?)\s*(KG|G|GM|GMS|MG|L|LTR|ML)\b")
_WEIGHT_BN_RE = _rx(r"([0-9]+(?:\.[0-9]+)?)\s*(কেজি|কে\.জি\.?|গ্রাম|গ্রা\.?|মিলি(?:লিটার)?|মি\.লি\.?|লিটার|লি\.?)")
_BN_UNIT = {"কেজি": "KG", "কে.জি": "KG", "কে.জি.": "KG", "গ্রাম": "G", "গ্রা": "G", "গ্রা.": "G",
            "মিলি": "ML", "মিলিলিটার": "ML", "মি.লি": "ML", "মি.লি.": "ML", "লিটার": "L", "লি": "L", "লি.": "L"}
_EN_UNIT = {"GM": "G", "GMS": "G", "LTR": "L"}
_BRAND_RE = _rx(r"(?:BRAND|ব্র্যান্ড|ব্রান্ড)" + _SEP + r"(.+)")
_MANUFACTURER_RE = _rx(
    r"(?:MANUFACTURED\s+BY|MANUFACTURER|PRODUCED\s+BY|MADE\s+BY|MFD\.?\s+BY|MKTD\.?\s+BY|MARKETED\s+BY"
    + rf"|প্রস্তুতকারক(?:\s*প্রতিষ্ঠান)?|প্রস্তুতকারী|{_UT}পাদনকারী(?:\s*প্রতিষ্ঠান)?|প্রস্তুত\s*ও\s*বাজারজাতকারী|বাজারজাতকারী)"
    + _SEP + r"(.+)"
)
_ORIGIN_RE = _rx(r"(?:MADE\s+IN|COUNTRY\s+OF\s+ORIGIN|ORIGIN|উৎপত্তি(?:স্থল|র\s*দেশ)|{UT}পাদনকারী\s*দেশ)".replace("{UT}", _UT) + _SEP + r"(.+)")
_LICENCE_RE = _rx(
    r"(?:BSTI\s*(?:CM\s*)?(?:LICEN[CS]E)?\s*(?:NO\.?)?|CM\s*LICEN[CS]E\s*(?:NO\.?)?|LICEN[CS]E\s*(?:NO\.?)?|REG(?:ISTRATION)?\.?\s*(?:NO\.?)?|FDA"
    r"|বিএসটিআই\s*(?:সিএম)?\s*(?:লাইসেন্স)?\s*(?:নং|নম্বর)?|লাইসেন্স\s*(?:নং|নম্বর)?|নিবন্ধন\s*(?:নং|নম্বর)?)"
    + _SEP + r"(.+)"
)
_BARCODE_RE = re.compile(r"\b(\d{8,14})\b")

# Any field keyword — used to cut a captured value where the next field starts on the same line.
_NEXT_FIELD_RE = _rx(
    r"\s(?:MFG|MFD|EXP|EXPIRY|BEST\s+BEFORE|BATCH|LOT|MRP|PRICE|NET|WT|"
    + rf"{_UT}পাদন|মেয়াদ|ব্যাচ|মূল্য|ওজন|সর্বোচ্চ)"
)

_BENGALI_CHAR = re.compile(r"[ঀ-৿]")
_LATIN_CHAR = re.compile(r"[A-Za-z]")


@dataclass
class FieldResult:
    value: Optional[str]
    confidence: float  # 0 when value is None


def _clean(text: str) -> str:
    """Text cleaning — Regex_Parser.md §4-5: NFC-normalise, collapse whitespace,
    strip control/invisible characters, normalize unicode punctuation."""
    text = _nfc(text)
    text = text.replace("’", "'").replace("‘", "'")
    text = text.replace("“", '"').replace("”", '"')
    text = text.replace("–", "-").replace("—", "-")
    text = text.replace("‌", "")  # ZWNJ: OCR noise, not meaningful in field values
    text = re.sub(r"[\t\r]+", " ", text)
    text = re.sub(r" {2,}", " ", text)
    return text.strip()


def _match_text(text: str) -> str:
    """Same text, with Bengali digits as ASCII, for numeric/date matching."""
    return to_ascii_digits(text)


def _confidence_for_match(match_text: str, regions: list[TextRegion]) -> float:
    """A matched value's confidence is the OCR confidence of whichever text
    region it was found in — not a fabricated number. Falls back to the
    average region confidence if we can't pin down the exact source region."""
    match_lower = _match_text(match_text).lower()
    for region in regions:
        if match_lower in _match_text(_clean(region.text)).lower():
            return region.confidence
    if regions:
        return round(sum(r.confidence for r in regions) / len(regions), 2)
    return 0.0


def _cut_at_next_field(value: str) -> str:
    m = _NEXT_FIELD_RE.search(" " + value)
    return value[: max(m.start() - 1, 0)] if m else value


def _find(
    pattern: re.Pattern, text: str, regions: list[TextRegion], *, cut: bool = False, after_last_colon: bool = False,
    must_have_digit: bool = False,
) -> FieldResult:
    m = pattern.search(text)
    if not m:
        return FieldResult(value=None, confidence=0.0)
    value = _clean(m.group(1))
    # Field values shouldn't bleed across lines/fields.
    value = value.split("\n")[0]
    if cut:
        value = _cut_at_next_field(value)
    if after_last_colon:
        # "BSTI CM licence no: X" where OCR garbled part of the label words: keep what follows the colon.
        parts = re.split(r"[:ঃ]", value)
        if len(parts) > 1 and parts[-1].strip():
            value = parts[-1]
    value = value.strip(" .:-ঃ|")
    if must_have_digit and not re.search(r"\d", value):
        return FieldResult(value=None, confidence=0.0)
    if not value:
        return FieldResult(value=None, confidence=0.0)
    return FieldResult(value=value, confidence=_confidence_for_match(value, regions))


def extract_barcode(text: str, regions: list[TextRegion]) -> FieldResult:
    matches = _BARCODE_RE.findall(text)
    if not matches:
        return FieldResult(value=None, confidence=0.0)
    # Prefer the longest numeric run (EAN-13/UPC are 12-13 digits; shorter
    # runs are more likely to be a price or date fragment).
    best = max(set(matches), key=len)
    return FieldResult(value=best, confidence=_confidence_for_match(best, regions))


def extract_batch_number(text: str, regions: list[TextRegion]) -> FieldResult:
    m = _BATCH_DIRECT_RE.search(text)
    if m:
        value = m.group(1).upper()
        return FieldResult(value=value, confidence=_confidence_for_match(value, regions))
    m = _BATCH_LABELED_RE.search(text)
    if m:
        value = m.group(1).strip(" .:-/").upper()
        if value:
            return FieldResult(value=value, confidence=_confidence_for_match(value, regions))
    return FieldResult(value=None, confidence=0.0)


def extract_weight(text: str, regions: list[TextRegion]) -> FieldResult:
    m = _WEIGHT_RE.search(text)
    if m:
        unit = m.group(2).upper()
        value = f"{m.group(1)} {_EN_UNIT.get(unit, unit)}"
        return FieldResult(value=value, confidence=_confidence_for_match(m.group(0), regions))
    m = _WEIGHT_BN_RE.search(text)
    if m:
        unit = _BN_UNIT.get(m.group(2).rstrip(), _BN_UNIT.get(m.group(2).rstrip("."), None))
        if unit:
            return FieldResult(value=f"{m.group(1)} {unit}", confidence=_confidence_for_match(m.group(1), regions))
    return FieldResult(value=None, confidence=0.0)


def _script_share(line: str, rx: re.Pattern) -> float:
    letters = [c for c in line if not c.isspace() and not c.isdigit()]
    if not letters:
        return 0.0
    return sum(1 for c in letters if rx.match(c)) / len(letters)


_KNOWN = [_BATCH_DIRECT_RE, _BATCH_LABELED_RE, _MFG_RE, _EXP_RE, _MRP_RE, _BRAND_RE, _BARCODE_RE, _WEIGHT_RE, _WEIGHT_BN_RE,
          _MANUFACTURER_RE, _LICENCE_RE, _ORIGIN_RE]


def _name_candidate(lines: list[str], regions: list[TextRegion], script: re.Pattern, min_share: float) -> FieldResult:
    """§7: no reliable literal keyword usually precedes the product name on
    real packaging, so the practical, honest heuristic is the first
    substantial text line, in the wanted script, that isn't itself a recognized
    field line. It only ever returns text that was actually read."""
    for line in lines:
        line = _clean(line)
        if len(line) < 3 or line.isdigit():
            continue
        # Product names are headings, not "label: value" lines.
        if ":" in line or "ঃ" in line:
            continue
        if any(p.search(_match_text(line)) for p in _KNOWN):
            continue
        if _script_share(line, script) < min_share:
            continue
        return FieldResult(value=line, confidence=_confidence_for_match(line, regions))
    return FieldResult(value=None, confidence=0.0)


def detect_languages(text: str) -> list[str]:
    langs = []
    if len(_BENGALI_CHAR.findall(text)) >= 3:
        langs.append("bn")
    if len(_LATIN_CHAR.findall(text)) >= 3:
        langs.append("en")
    return langs


def _dedupe(regions: list[TextRegion]) -> list[TextRegion]:
    # Duplicate removal — §22: OCR often repeats the same line.
    seen: set[str] = set()
    out: list[TextRegion] = []
    for r in regions:
        key = _clean(r.text).lower()
        if key and key not in seen:
            seen.add(key)
            out.append(r)
    return out


def parse(regions: list[TextRegion]) -> dict[str, FieldResult]:
    """Main entrypoint: raw OCR text regions -> structured fields dict.

    Regions may come from the front and the back of the pack (TextRegion.side).
    Product names are taken from the front first; every other field is searched
    in all text, front first."""
    deduped = _dedupe(regions)
    raw_text = "\n".join(_clean(r.text) for r in deduped)
    full_text = _match_text(raw_text)

    front_lines = [_clean(r.text) for r in deduped if getattr(r, "side", "front") == "front"]
    all_lines = [_clean(r.text) for r in deduped]

    mfg = _find(_MFG_RE, full_text, deduped, cut=True)
    exp = _find(_EXP_RE, full_text, deduped, cut=True)

    name_en = _name_candidate(front_lines, deduped, _LATIN_CHAR, 0.6)
    if name_en.value is None:
        name_en = _name_candidate(all_lines, deduped, _LATIN_CHAR, 0.6)
    name_bn = _name_candidate(front_lines, deduped, _BENGALI_CHAR, 0.6)
    if name_bn.value is None:
        name_bn = _name_candidate(all_lines, deduped, _BENGALI_CHAR, 0.6)

    return {
        "productName": name_en,
        "productNameBn": name_bn,
        "brand": _find(_BRAND_RE, full_text, deduped),
        "manufacturer": _find(_MANUFACTURER_RE, raw_text, deduped),
        "batchNumber": extract_batch_number(full_text, deduped),
        "manufacturingDate": FieldResult(
            value=normalize_date(mfg.value, end_of_month_if_day_missing=False) if mfg.value else None,
            confidence=mfg.confidence,
        ),
        "expiryDate": FieldResult(
            value=normalize_date(exp.value, end_of_month_if_day_missing=True) if exp.value else None,
            confidence=exp.confidence,
        ),
        "barcode": extract_barcode(full_text, deduped),
        "mrp": _find(_MRP_RE, full_text, deduped),
        "weight": extract_weight(full_text, deduped),
        "countryOfOrigin": _find(_ORIGIN_RE, raw_text, deduped),
        "licenceNumber": _find(_LICENCE_RE, full_text, deduped, after_last_colon=True, must_have_digit=True),
    }


def vote(readings: list[dict[str, FieldResult]]) -> dict[str, FieldResult]:
    """Combine the parses of several preprocessed versions of the same photo(s), field by field.

    Each version can misread different characters (e.g. "LOT" as "107" on a binarised image).
    For every field, the value with the highest total OCR confidence across versions wins, so a
    value read the same way by several versions beats a one-off misreading. The winner keeps its
    best single confidence. Nothing is invented: only values that some version actually read.
    """
    if not readings:
        return {}
    out: dict[str, FieldResult] = {}
    for key in readings[0]:
        tally: dict[str, list[float]] = {}
        for r in readings:
            f = r.get(key)
            if f is not None and f.value:
                tally.setdefault(f.value, []).append(f.confidence)
        if not tally:
            out[key] = FieldResult(value=None, confidence=0.0)
            continue
        best = max(tally.items(), key=lambda kv: (sum(kv[1]), len(kv[1]), max(kv[1])))
        out[key] = FieldResult(value=best[0], confidence=max(best[1]))
    return out
