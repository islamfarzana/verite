"""
OCR engine wrapper — PaddleOCR_Integration.md.

The model is loaded exactly once (in FastAPI's lifespan startup hook, see
main.py) and reused for every request — never reloaded per-request
(§7 "Do not reload the model for every request").

Engines:
  * PaddleOCR — strong on English, but it has NO Bengali model.
  * Tesseract — LSTM recogniser; with TESSERACT_LANG="ben+eng" it reads Bangla and English.
  * hybrid (default) — PaddleOCR (English) + Tesseract (Bangla+English); the text regions of
    both are combined, so Bangla lines are no longer lost. If PaddleOCR cannot load, hybrid
    runs Tesseract alone.

Tesseract returns words; they are grouped back into LINES (block/paragraph/line numbers), so
"MFG: 03/2026" stays one line and line-based parsing (product name, keyword: value) works.
"""
from dataclasses import dataclass

import numpy as np

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class TextRegion:
    text: str
    confidence: float  # 0-100
    side: str = "front"  # front | back
    engine: str = ""


def _tesseract_lines(image: np.ndarray, lang: str, psm: int) -> list[TextRegion]:
    import pytesseract
    from pytesseract import Output

    data = pytesseract.image_to_data(image, lang=lang, config=f"--oem 1 --psm {psm}", output_type=Output.DICT)
    lines: dict[tuple, list[tuple[str, float]]] = {}
    order: list[tuple] = []
    for i, word in enumerate(data["text"]):
        word = (word or "").strip()
        conf = float(data["conf"][i])
        if not word or conf < 0:
            continue
        key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        if key not in lines:
            lines[key] = []
            order.append(key)
        lines[key].append((word, conf))
    regions = []
    for key in order:
        words = lines[key]
        text = " ".join(w for w, _ in words)
        conf = round(sum(c for _, c in words) / len(words), 2)
        regions.append(TextRegion(text=text, confidence=conf, engine="tesseract"))
    return regions


def reading_score(regions: list[TextRegion]) -> float:
    """How well an image was read: confident characters, ignoring single-character noise.
    Used to choose between preprocessing variants and segmentation modes."""
    score = 0.0
    for r in regions:
        chars = len(r.text.replace(" ", ""))
        if chars < 2:
            continue
        score += chars * (r.confidence / 100.0) ** 2
    return round(score, 2)


class OcrEngine:
    def __init__(self):
        self._paddle = None
        self._tesseract = False
        self._engine_name = settings.OCR_ENGINE

    def load(self) -> None:
        mode = settings.OCR_ENGINE
        if mode in ("paddleocr", "hybrid"):
            self._load_paddleocr()
        if mode in ("tesseract", "hybrid") or self._paddle is None:
            self._load_tesseract()
        if self._paddle is not None and self._tesseract:
            self._engine_name = "hybrid"
        elif self._paddle is not None:
            self._engine_name = "paddleocr"
        else:
            self._engine_name = "tesseract"
        logger.info("OCR engine ready: %s (tesseract lang=%s)", self._engine_name, settings.TESSERACT_LANG)

    def _load_paddleocr(self) -> None:
        try:
            from paddleocr import PaddleOCR

            # PaddleOCR has no Bengali model; it is used for English text only.
            self._paddle = PaddleOCR(
                use_angle_cls=True,
                lang=settings.OCR_LANGUAGE,
                use_gpu=settings.OCR_USE_GPU,
                show_log=False,
            )
            logger.info("PaddleOCR model loaded (lang=%s, gpu=%s)", settings.OCR_LANGUAGE, settings.OCR_USE_GPU)
        except Exception:
            logger.exception("Failed to load PaddleOCR; Tesseract will be used")
            self._paddle = None

    def _load_tesseract(self) -> None:
        import pytesseract

        available = set(pytesseract.get_languages(config=""))
        wanted = [lang for lang in settings.TESSERACT_LANG.split("+") if lang]
        missing = [lang for lang in wanted if lang not in available]
        if missing:
            logger.warning("Tesseract language data missing: %s (install tesseract-ocr-%s)", missing, "/".join(missing))
        self._tess_lang = "+".join([lang for lang in wanted if lang in available]) or "eng"
        self._tesseract = True

    def unload(self) -> None:
        self._paddle = None
        self._tesseract = False

    @property
    def engine_name(self) -> str:
        return self._engine_name

    @property
    def is_loaded(self) -> bool:
        return self._paddle is not None or self._tesseract

    @property
    def languages(self) -> list[str]:
        langs = []
        if self._tesseract and "ben" in getattr(self, "_tess_lang", ""):
            langs.append("bn")
        langs.append("en")
        return langs

    def recognize(self, image: np.ndarray) -> list[TextRegion]:
        """Read one image with the configured engine(s)."""
        if not self.is_loaded:
            raise RuntimeError("OCR engine not loaded")
        regions: list[TextRegion] = []
        if self._paddle is not None:
            regions.extend(self._recognize_paddle(image))
        if self._tesseract:
            regions.extend(self._recognize_tesseract(image))
        return regions

    def recognize_best(self, variants: list[tuple[str, np.ndarray]]) -> tuple[str, list[TextRegion]]:
        """Read several preprocessed versions of the same photo and keep the best reading.
        PaddleOCR (slow) runs once on the first variant; Tesseract runs on every variant."""
        if not self.is_loaded:
            raise RuntimeError("OCR engine not loaded")
        paddle_regions = self._recognize_paddle(variants[0][1]) if self._paddle is not None else []
        best_name, best_regions, best_score = variants[0][0], [], -1.0
        if self._tesseract:
            for name, img in variants:
                regions = self._recognize_tesseract(img)
                score = reading_score(regions)
                if score > best_score:
                    best_name, best_regions, best_score = name, regions, score
        return best_name, paddle_regions + best_regions

    def recognize_variants(self, variants: list[tuple[str, np.ndarray]]) -> list[tuple[str, list[TextRegion]]]:
        """Read every preprocessed version of the photo (for field-level voting, see parser.vote).
        PaddleOCR (slow) runs once, on the first variant, and its regions are shared by all."""
        if not self.is_loaded:
            raise RuntimeError("OCR engine not loaded")
        paddle_regions = self._recognize_paddle(variants[0][1]) if self._paddle is not None else []
        out = []
        for name, img in variants:
            tess = self._recognize_tesseract(img) if self._tesseract else []
            out.append((name, paddle_regions + tess))
        return out

    def _recognize_paddle(self, image: np.ndarray) -> list[TextRegion]:
        result = self._paddle.ocr(image, cls=True)
        regions: list[TextRegion] = []
        for line in result or []:
            for _box, (text, conf) in line or []:
                regions.append(TextRegion(text=text, confidence=round(conf * 100, 2), engine="paddleocr"))
        return regions

    def _recognize_tesseract(self, image: np.ndarray) -> list[TextRegion]:
        best: list[TextRegion] = []
        best_score = -1.0
        for psm in settings.TESSERACT_PSM_MODES:
            regions = _tesseract_lines(image, getattr(self, "_tess_lang", "eng"), psm)
            score = reading_score(regions)
            if score > best_score:
                best, best_score = regions, score
        return best


# Module-level singleton — imported by main.py (load/unload) and routes/ocr.py (recognize).
ocr_engine = OcrEngine()
