"""Barcode detection — runs independently of OCR (PaddleOCR_Integration.md §15)."""
from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class BarcodeResult:
    value: str
    type: str
    confidence: float


def detect_barcode(image: np.ndarray) -> Optional[BarcodeResult]:
    try:
        from pyzbar.pyzbar import decode
    except ImportError:
        return None

    results = decode(image)
    if not results:
        return None

    # Prefer EAN-13/UPC (product barcodes) over QR/Code128 if multiple are found.
    priority = {"EAN13": 0, "UPCA": 1, "UPCE": 1, "CODE128": 2, "QRCODE": 3}
    best = min(results, key=lambda r: priority.get(r.type, 9))
    return BarcodeResult(value=best.data.decode("utf-8", errors="ignore"), type=best.type, confidence=100.0)
