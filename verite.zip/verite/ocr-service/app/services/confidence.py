"""Confidence Engine — System_Architecture.md §12, PaddleOCR_Integration.md §15."""
from app.services.barcode import BarcodeResult
from app.services.parser import FieldResult


def reconcile_barcode(ocr_barcode: FieldResult, detected: BarcodeResult | None) -> FieldResult:
    """If both the barcode-scan library and the OCR regex found a barcode,
    prefer the scanner's result when its confidence is higher (barcode scans
    are effectively exact-or-nothing, so this almost always wins) — §15."""
    if detected and (not ocr_barcode.value or detected.confidence >= ocr_barcode.confidence):
        return FieldResult(value=detected.value, confidence=detected.confidence)
    return ocr_barcode


def overall_confidence(fields: dict[str, FieldResult]) -> float:
    scored = [f.confidence for f in fields.values() if f.value is not None]
    if not scored:
        return 0.0
    return round(sum(scored) / len(scored), 1)
