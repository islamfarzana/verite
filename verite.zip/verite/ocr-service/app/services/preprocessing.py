"""
OpenCV preprocessing — OpenCV_Preprocessing.md.

Pipeline (real cv2 code): decode, resize, blur/brightness quality check, grayscale,
bilateral denoise, CLAHE contrast enhancement, minAreaRect deskew, sharpening.

Robustness additions (v4):
  * Perspective correction — when the photo shows the packet's four corners (a clear
    quadrilateral outline covering a large part of the frame), the packet is flattened with
    a four-point perspective transform. If no confident outline is found, the photo is used
    as-is: on curved or glossy packs a wrong warp does more harm than none.
  * Orientation — Tesseract's OSD detects photos taken sideways/upside down (90/180/270°).
  * Small photos are upscaled 2x (Tesseract reads text best when letters are ~30 px tall).
  * Variants — several cleaned versions of the same photo (enhanced, plain grayscale,
    adaptive-threshold binary); the OCR engine reads each and keeps the best reading.
"""
from dataclasses import dataclass

import cv2
import numpy as np

MAX_DIMENSION = 1800  # OpenCV_Preprocessing.md §5


@dataclass
class QualityReport:
    brightness: float
    blur_score: float
    quality: str  # EXCELLENT | GOOD | FAIR | POOR
    warnings: list[str]


def decode_image(raw_bytes: bytes) -> np.ndarray:
    arr = np.frombuffer(raw_bytes, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Image could not be decoded")
    return img


def resize(img: np.ndarray, max_dim: int = MAX_DIMENSION) -> np.ndarray:
    h, w = img.shape[:2]
    if max(h, w) <= max_dim:
        return img
    scale = max_dim / max(h, w)
    interpolation = cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC
    return cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=interpolation)


def _blur_score(gray: np.ndarray) -> float:
    # Variance of Laplacian — OpenCV_Preprocessing.md §21.
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def assess_quality(img: np.ndarray) -> QualityReport:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    brightness = float(np.mean(gray))
    blur = _blur_score(gray)

    warnings: list[str] = []
    if blur < 60:
        warnings.append("Image is too blurry for reliable OCR.")
    if brightness < 40:
        warnings.append("Image is too dark.")
    elif brightness > 220:
        warnings.append("Image is overexposed.")
    h, w = img.shape[:2]
    if min(h, w) < 400:
        warnings.append("Image resolution is low; results may be less accurate.")

    if not warnings and blur > 150:
        quality = "EXCELLENT"
    elif not warnings:
        quality = "GOOD"
    elif len(warnings) == 1:
        quality = "FAIR"
    else:
        quality = "POOR"

    return QualityReport(brightness=brightness, blur_score=blur, quality=quality, warnings=warnings)


def deskew(gray: np.ndarray) -> np.ndarray:
    """Corrects small rotational skew (±15°, per spec) using minAreaRect over
    thresholded foreground pixels — the standard, reliable OpenCV deskew
    technique for text-bearing images."""
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(thresh > 0))
    if coords.shape[0] < 20:
        return gray  # not enough foreground to estimate a reliable angle
    angle = cv2.minAreaRect(coords)[-1]
    angle = -(90 + angle) if angle < -45 else -angle
    if abs(angle) < 0.5 or abs(angle) > 15:
        return gray  # ignore negligible or out-of-spec skew
    (h, w) = gray.shape[:2]
    center = (w // 2, h // 2)
    matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
    return cv2.warpAffine(gray, matrix, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def enhance_contrast(gray: np.ndarray) -> np.ndarray:
    # CLAHE — OpenCV_Preprocessing.md §10, recommended params.
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return clahe.apply(gray)


def denoise(gray: np.ndarray) -> np.ndarray:
    # Bilateral filter — preserves edges (text) while smoothing noise.
    return cv2.bilateralFilter(gray, d=9, sigmaColor=75, sigmaSpace=75)


def sharpen(gray: np.ndarray) -> np.ndarray:
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    return cv2.filter2D(gray, -1, kernel)


def preprocess(raw_bytes: bytes) -> tuple[np.ndarray, QualityReport]:
    """Full pipeline: decode -> resize -> quality check -> grayscale ->
    denoise -> CLAHE -> deskew -> sharpen. Returns an OCR-ready grayscale
    image plus the quality report (FR-03, §2 pipeline)."""
    img = decode_image(raw_bytes)
    img = resize(img)
    quality = assess_quality(img)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = denoise(gray)
    gray = enhance_contrast(gray)
    gray = deskew(gray)
    gray = sharpen(gray)

    return gray, quality


# ---------------------------------------------------------------------------------------------
# v4: perspective correction, orientation, variants

MIN_DIMENSION_FOR_OCR = 1000


def _order_corners(pts: np.ndarray) -> np.ndarray:
    pts = pts.reshape(4, 2).astype("float32")
    s = pts.sum(axis=1)
    d = np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], dtype="float32")


def find_packet_outline(img: np.ndarray, min_area_ratio: float = 0.25, max_area_ratio: float = 0.97):
    """Largest convex 4-corner contour that covers 25-97% of the frame, or None.
    (Edges via Canny, closed with dilation, polygon via approxPolyDP.)"""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)
    edges = cv2.dilate(edges, np.ones((5, 5), np.uint8), iterations=2)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    frame_area = img.shape[0] * img.shape[1]
    for c in sorted(contours, key=cv2.contourArea, reverse=True)[:5]:
        area = cv2.contourArea(c)
        if not (min_area_ratio * frame_area <= area <= max_area_ratio * frame_area):
            continue
        approx = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
        if len(approx) == 4 and cv2.isContourConvex(approx):
            return _order_corners(approx)
    return None


def four_point_warp(img: np.ndarray, corners: np.ndarray) -> np.ndarray:
    tl, tr, br, bl = corners
    width = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl)))
    height = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
    if width < 50 or height < 50:
        return img
    dst = np.array([[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]], dtype="float32")
    matrix = cv2.getPerspectiveTransform(corners, dst)
    return cv2.warpPerspective(img, matrix, (width, height), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def correct_perspective(img: np.ndarray) -> tuple[np.ndarray, bool]:
    corners = find_packet_outline(img)
    if corners is None:
        return img, False
    return four_point_warp(img, corners), True


def auto_orient(gray: np.ndarray) -> tuple[np.ndarray, int]:
    """Rotate by 90/180/270 degrees when Tesseract OSD is confident the text is sideways."""
    try:
        import pytesseract

        osd = pytesseract.image_to_osd(gray, config="--psm 0 -c min_characters_to_try=10")
    except Exception:
        return gray, 0
    rotate, confidence = 0, 0.0
    for line in osd.splitlines():
        if line.startswith("Rotate:"):
            rotate = int(line.split(":")[1])
        elif line.startswith("Orientation confidence:"):
            confidence = float(line.split(":")[1])
    if rotate not in (90, 180, 270) or confidence < 2.0:
        return gray, 0
    codes = {90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_COUNTERCLOCKWISE}
    return cv2.rotate(gray, codes[rotate]), rotate


def upscale_if_small(img: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    if max(h, w) >= MIN_DIMENSION_FOR_OCR:
        return img
    return cv2.resize(img, (w * 2, h * 2), interpolation=cv2.INTER_CUBIC)


@dataclass
class PreparedImage:
    variants: list[tuple[str, np.ndarray]]
    quality: QualityReport
    perspective_corrected: bool
    rotated_degrees: int


def prepare_variants(raw_bytes: bytes, *, perspective: bool = True, orient: bool = True, variants: bool = True) -> PreparedImage:
    """decode -> resize -> (perspective) -> quality -> grayscale -> (orientation) -> upscale ->
    variants: 'enhanced' (denoise+CLAHE+deskew+sharpen), 'gray' (denoise+deskew), 'binary'
    (adaptive Gaussian threshold of 'enhanced')."""
    img = resize(decode_image(raw_bytes))
    corrected = False
    if perspective:
        img, corrected = correct_perspective(img)
    quality = assess_quality(img)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    rotated = 0
    if orient:
        gray, rotated = auto_orient(gray)
    gray = upscale_if_small(gray)

    denoised = denoise(gray)
    enhanced = sharpen(deskew(enhance_contrast(denoised)))
    out = [("enhanced", enhanced)]
    if variants:
        out.append(("gray", deskew(denoised)))
        binary = cv2.adaptiveThreshold(enhanced, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 15)
        out.append(("binary", binary))
    return PreparedImage(variants=out, quality=quality, perspective_corrected=corrected, rotated_degrees=rotated)
