"""Shared front/back photo reading used by the API route and the evaluation script.

photo(s) -> per side: perspective / orientation / variants (preprocessing.prepare_variants)
         -> OCR on every variant (ocr_engine.recognize_variants)
         -> parse each variant (front + back together) -> field-level vote (parser.vote)
"""
from dataclasses import dataclass, field
from typing import Optional

from app.services import preprocessing
from app.services.ocr_engine import OcrEngine, TextRegion, reading_score
from app.services.parser import FieldResult, parse, vote


@dataclass
class SideReading:
    side: str
    quality: preprocessing.QualityReport
    variant: str
    perspective_corrected: bool
    rotated_degrees: int
    regions: list[TextRegion]


@dataclass
class PhotosReading:
    fields: dict[str, FieldResult]
    sides: list[SideReading] = field(default_factory=list)

    @property
    def regions(self) -> list[TextRegion]:
        return [r for s in self.sides for r in s.regions]


def read_photos(engine: OcrEngine, front: bytes, back: Optional[bytes] = None, *, perspective: bool = True, orient: bool = True,
                variants: bool = True, voting: bool = True) -> PhotosReading:
    per_side: list[tuple[str, preprocessing.PreparedImage, list[tuple[str, list[TextRegion]]]]] = []
    for side, data in (("front", front), ("back", back)):
        if data is None:
            continue
        prepared = preprocessing.prepare_variants(data, perspective=perspective, orient=orient, variants=variants)
        readings = engine.recognize_variants(prepared.variants)
        for _name, regions in readings:
            for r in regions:
                r.side = side
        per_side.append((side, prepared, readings))

    sides: list[SideReading] = []
    for side, prepared, readings in per_side:
        name, regions = max(readings, key=lambda nr: reading_score(nr[1]))  # best variant: shown as raw text
        sides.append(SideReading(side, prepared.quality, name, prepared.perspective_corrected, prepared.rotated_degrees, regions))

    if voting and all(len(r) > 1 for _s, _p, r in per_side):
        n = min(len(r) for _s, _p, r in per_side)
        parses = [parse([reg for _s, _p, r in per_side for reg in r[i][1]]) for i in range(n)]
        fields = vote(parses)
    else:
        fields = parse([reg for s in sides for reg in s.regions])
    return PhotosReading(fields=fields, sides=sides)
