"""
AI OCR Microservice for FMCG Marketplace
Entrypoint — see README.md for architecture and run instructions.

This service is intentionally independent of the Next.js marketplace. It
knows nothing about sellers, buyers, authentication, blockchain, or product
publishing — it accepts a label image and returns structured JSON. The
Next.js app's /api/ocr/extract route is a thin proxy in front of this.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.logging import configure_logging, get_logger
from app.api.routes import health, ocr
from app.middleware.logging_middleware import RequestLoggingMiddleware
from app.middleware.exception_handler import (
    ocr_exception_handler,
    unhandled_exception_handler,
)
from app.services.ocr_engine import ocr_engine
from app.models.database import init_db
from app.utils.errors import OcrServiceError

configure_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load the OCR model ONCE at startup, never per-request (FR: "Do not
    # reload the model for every request" / performance target < 5s startup).
    logger.info("startup: initializing database")
    init_db()
    logger.info("startup: loading OCR engine (%s)", settings.OCR_ENGINE)
    ocr_engine.load()
    logger.info("startup: OCR engine ready")
    yield
    logger.info("shutdown: releasing OCR engine")
    ocr_engine.unload()


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description="Standalone OCR microservice: label image -> structured FMCG product fields.",
    lifespan=lifespan,
    docs_url="/docs",
    openapi_url="/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
app.add_middleware(RequestLoggingMiddleware)

app.add_exception_handler(OcrServiceError, ocr_exception_handler)
app.add_exception_handler(Exception, unhandled_exception_handler)

app.include_router(health.router, tags=["health"])
app.include_router(ocr.router, prefix="/api/v1/ocr", tags=["ocr"])


# Optional: real Prometheus /metrics endpoint (not a mock — genuinely wired
# up), gated so the service still runs fine without the extra dependency.
if settings.ENABLE_METRICS:
    try:
        from prometheus_fastapi_instrumentator import Instrumentator

        Instrumentator().instrument(app).expose(app, endpoint="/metrics")
    except ImportError:
        logger.warning("ENABLE_METRICS=true but prometheus-fastapi-instrumentator is not installed")


@app.get("/", include_in_schema=False)
async def root():
    return JSONResponse({"service": settings.APP_NAME, "version": settings.VERSION, "docs": "/docs"})
