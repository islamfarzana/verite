class OcrServiceError(Exception):
    """Raised for any expected/handled failure. Carries an HTTP status and a
    user-safe message — never a stack trace or internal path (Security.md §20)."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(message)


UNSUPPORTED_FORMAT = "Unsupported file format."
FILE_TOO_LARGE = "Maximum upload size exceeded."
OCR_FAILED = "Unable to extract readable text from the uploaded image."
IMAGE_UNREADABLE = "The uploaded file could not be read as an image."
INTERNAL_ERROR = "Internal OCR service error."
