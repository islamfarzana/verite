"""
Date normalization — Regex_Parser.md §9, §10, §20.

Rule: if the day is missing, expiry dates use the LAST day of that month,
manufacturing dates use the FIRST day of that month (this matches how FMCG
labels are actually printed — "EXP 08/26" means "valid through end of Aug
2026", "MFG 02/2026" means "made sometime in Feb 2026").

Bangla support: Bengali digits (০-৯) and Bengali month names (জানুয়ারি …
ডিসেম্বর) are converted before parsing, so "১৫ জানুয়ারি ২০২৬" and
"০৩/২০২৬" are read the same way as their English equivalents.
"""
import calendar
import re
import unicodedata
from datetime import date
from typing import Optional

_MONTH_NAMES = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}

_BN_DIGITS = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")

# Bengali month names (with common spelling variants) -> English 3-letter month.
_BN_MONTHS = {
    "জানুয়ারি": "JAN", "জানুয়ারী": "JAN", "জানু": "JAN",
    "ফেব্রুয়ারি": "FEB", "ফেব্রুয়ারী": "FEB", "ফেব্রু": "FEB",
    "মার্চ": "MAR",
    "এপ্রিল": "APR",
    "মে": "MAY",
    "জুন": "JUN",
    "জুলাই": "JUL",
    "আগস্ট": "AUG", "আগষ্ট": "AUG",
    "সেপ্টেম্বর": "SEP", "সেপ্টে": "SEP",
    "অক্টোবর": "OCT", "অক্টো": "OCT",
    "নভেম্বর": "NOV", "নভে": "NOV",
    "ডিসেম্বর": "DEC", "ডিসে": "DEC",
}
# Longest names first so "জানুয়ারি" wins over "জানু"; NFC so OCR output and keys compare equal.
_BN_MONTH_ITEMS = sorted(
    ((unicodedata.normalize("NFC", k), v) for k, v in _BN_MONTHS.items()), key=lambda kv: -len(kv[0])
)


def to_ascii_digits(text: str) -> str:
    """Bengali digits -> ASCII digits. Leaves every other character unchanged."""
    return text.translate(_BN_DIGITS)


def _bangla_to_latin_date(text: str) -> str:
    text = to_ascii_digits(unicodedata.normalize("NFC", text))
    for bn, en in _BN_MONTH_ITEMS:
        # Whole words only: "মে" (May) must not match inside "মেয়াদ" (expiry).
        text = re.sub(rf"(?<![ঀ-৿]){re.escape(bn)}(?![ঀ-৿])", f" {en} ", text)
    text = text.replace("ইং", " ").replace("সাল", " ")
    return re.sub(r"\s+", " ", text).strip()


# Ordered from most to least specific.
_PATTERNS = [
    # 2026-08-31 / 2026/08/31 / 2026.08.31
    (re.compile(r"(\d{4})[/\-\.](\d{1,2})[/\-\.](\d{1,2})"), lambda m: (int(m[1]), int(m[2]), int(m[3]))),
    # 31-08-2026 / 31/08/2026 / 31.08.2026
    (re.compile(r"(\d{1,2})[/\-\.](\d{1,2})[/\-\.](\d{4})"), lambda m: (int(m[3]), int(m[2]), int(m[1]))),
    # 31/08/26 (day/month/2-digit year)
    (re.compile(r"^(\d{1,2})[/\-\.](\d{1,2})[/\-\.](\d{2})$"), lambda m: (2000 + int(m[3]), int(m[2]), int(m[1]))),
    # 15 JAN 2026 / 15-JAN-26 / 15JAN2026
    (
        re.compile(r"(\d{1,2})[\s\-\.]*([A-Za-z]{3,9})[\s\-\.,]*(\d{4}|\d{2})\b", re.IGNORECASE),
        lambda m: (
            (2000 + int(m[3])) if len(m[3]) == 2 else int(m[3]),
            _MONTH_NAMES.get(m[2][:3].lower()),
            int(m[1]),
        ),
    ),
    # 2026-08 / 2026/08 (month-only, ISO-ish order)
    (re.compile(r"^(\d{4})[/\-\.](\d{1,2})$"), lambda m: (int(m[1]), int(m[2]), None)),
    # 08-2026 / 08/2026 (month-only, DD-first order)
    (re.compile(r"^(\d{1,2})[/\-\.](\d{4})$"), lambda m: (int(m[2]), int(m[1]), None)),
    # 08/26 (month/2-digit-year)
    (re.compile(r"^(\d{1,2})/(\d{2})$"), lambda m: (2000 + int(m[2]), int(m[1]), None)),
    # AUG26 / AUG-26 / AUG 2026
    (
        re.compile(r"([A-Za-z]{3,9})[\s\-\.]?(\d{2,4})", re.IGNORECASE),
        lambda m: (
            (2000 + int(m[2])) if len(m[2]) == 2 else int(m[2]),
            _MONTH_NAMES.get(m[1][:3].lower()),
            None,
        ),
    ),
    # 082026 (MMYYYY, 6 digits)
    (re.compile(r"^(\d{2})(\d{4})$"), lambda m: (int(m[2]), int(m[1]), None)),
]


def normalize_date(raw: str, *, end_of_month_if_day_missing: bool) -> Optional[str]:
    """Best-effort parse of a raw date string into ISO YYYY-MM-DD, or None if
    it can't be confidently parsed. Never guesses a value out of thin air —
    only reformats what was actually present in the text."""
    if not raw:
        return None
    text = _bangla_to_latin_date(raw.strip()).strip(" .,:-")

    for pattern, extractor in _PATTERNS:
        m = pattern.search(text)
        if not m:
            continue
        try:
            year, month, day = extractor(m)
        except (TypeError, ValueError):
            continue
        if not month or not (1 <= month <= 12):
            continue
        if year < 100:
            year += 2000
        if not (1990 <= year <= 2100):
            continue

        if day is None:
            day = calendar.monthrange(year, month)[1] if end_of_month_if_day_missing else 1
        else:
            if not (1 <= day <= 31):
                continue
            max_day = calendar.monthrange(year, month)[1]
            day = min(day, max_day)

        try:
            return date(year, month, day).isoformat()
        except ValueError:
            continue

    return None
