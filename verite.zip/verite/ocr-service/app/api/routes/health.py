from fastapi import APIRouter

from app.core.config import settings
from app.models.database import engine
from app.schemas.response import HealthResponse, VersionResponse
from app.services.ocr_engine import ocr_engine

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health():
    db_status = "connected"
    try:
        with engine.connect():
            pass
    except Exception:
        db_status = "unavailable"

    return HealthResponse(
        status="healthy" if ocr_engine.is_loaded and db_status == "connected" else "degraded",
        version=settings.VERSION,
        ocr="loaded" if ocr_engine.is_loaded else "not_loaded",
        database=db_status,
    )


@router.get("/version", response_model=VersionResponse)
async def version():
    return VersionResponse(version=settings.VERSION, environment=settings.APP_ENV)
