import time

import cv2
from typing import Optional

from fastapi import APIRouter, Depends, File, UploadFile, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.api.dependencies import validate_upload
from app.core.logging import get_logger
from app.core.security import verify_service_api_key
from app.models.database import get_db, OcrRequest, OcrResult, OcrField
from app.core.config import settings
from app.schemas.response import OcrResponse, OcrFields, FieldValue, BarcodeResponse, SideInfo
from app.services import preprocessing
from app.services.barcode import detect_barcode
from app.services.confidence import overall_confidence, reconcile_barcode
from app.services.ocr_engine import ocr_engine
from app.services.cover import make_cover
from app.services.extraction import read_photos
from app.services.parser import detect_languages
from app.utils.errors import OcrServiceError, OCR_FAILED, IMAGE_UNREADABLE

router = APIRouter(dependencies=[Depends(verify_service_api_key)])
logger = get_logger("ocr")


_QUALITY_ORDER = ["POOR", "FAIR", "GOOD", "EXCELLENT"]


@router.post("/extract", response_model=OcrResponse)
async def extract(
    file: UploadFile = File(..., alias="image"),
    back_file: Optional[UploadFile] = File(None, alias="backImage"),
    db: Session = Depends(get_db),
):
    """Front photo ("image", required) and optional back photo ("backImage") of the same pack.
    Each photo: perspective/orientation correction, several preprocessed variants, OCR on each
    variant, and field-level voting across variants (services/extraction.py)."""
    start = time.perf_counter()
    raw_bytes = await validate_upload(file)
    back_bytes = await validate_upload(back_file) if back_file is not None else None

    db_request = OcrRequest(
        image_name=file.filename,
        image_size=len(raw_bytes) + (len(back_bytes) if back_bytes else 0),
        image_type=file.content_type,
        processing_status="RUNNING",
    )
    db.add(db_request)
    db.commit()

    try:
        reading = read_photos(
            ocr_engine, raw_bytes, back_bytes,
            perspective=settings.OCR_PERSPECTIVE_CORRECTION,
            orient=settings.OCR_AUTO_ORIENT,
            variants=settings.OCR_TRY_VARIANTS,
            voting=settings.OCR_TRY_VARIANTS,
        )
    except ValueError:
        db_request.processing_status = "FAILED"
        db.commit()
        raise OcrServiceError(status.HTTP_422_UNPROCESSABLE_ENTITY, IMAGE_UNREADABLE)
    except Exception:
        logger.exception("OCR recognition failed for request_id=%s", db_request.request_id)
        db_request.processing_status = "FAILED"
        db.commit()
        raise OcrServiceError(status.HTTP_422_UNPROCESSABLE_ENTITY, OCR_FAILED)

    regions = reading.regions
    if not regions:
        db_request.processing_status = "FAILED"
        db.commit()
        raise OcrServiceError(status.HTTP_422_UNPROCESSABLE_ENTITY, OCR_FAILED)

    sides = [
        SideInfo(
            side=sr.side, quality=sr.quality.quality, warnings=sr.quality.warnings, variant=sr.variant,
            perspectiveCorrected=sr.perspective_corrected, rotatedDegrees=sr.rotated_degrees,
            rawText="\n".join(r.text for r in sr.regions) or None,
        )
        for sr in reading.sides
    ]
    # Overall quality = the worse of the two photos (one bad photo can hide a field).
    quality_label = min((s.quality for s in sides), key=_QUALITY_ORDER.index)
    fields = reading.fields

    # Barcode detection runs independently and, when present, can override
    # the regex-guessed barcode (§15 reconciliation rule).
    detected_barcode = None
    for data in (raw_bytes, back_bytes):
        if data is not None and detected_barcode is None:
            detected_barcode = detect_barcode(preprocessing.decode_image(data))
    fields["barcode"] = reconcile_barcode(fields["barcode"], detected_barcode)

    processing_time = round(time.perf_counter() - start, 2)
    avg_confidence = overall_confidence(fields)

    # Persist result + fields (Database_Integration.md §8, §14 transaction flow).
    db_result = OcrResult(
        request_id=db_request.request_id,
        quality=quality_label,
        average_confidence=avg_confidence,
        barcode=fields["barcode"].value,
        raw_text="\n".join(f"[{r.side}] {r.text}" for r in regions),
    )
    db.add(db_result)
    db.flush()
    for name, f in fields.items():
        db.add(OcrField(result_id=db_result.id, field_name=name, field_value=f.value, confidence=f.confidence))
    db_request.processing_status = "COMPLETED"
    db_request.processing_time_ms = int(processing_time * 1000)
    db.commit()

    return OcrResponse(
        success=True,
        processingTime=processing_time,
        quality=quality_label,
        fields=OcrFields(**{k: FieldValue(value=v.value, confidence=v.confidence) for k, v in fields.items()}),
        rawText="\n".join(r.text for r in regions),
        languages=detect_languages("\n".join(r.text for r in regions)),
        engine=ocr_engine.engine_name,
        sides=sides,
    )


@router.post("/barcode", response_model=BarcodeResponse)
async def barcode_only(file: UploadFile = File(..., alias="image")):
    raw_bytes = await validate_upload(file)
    try:
        img = preprocessing.decode_image(raw_bytes)
    except ValueError:
        raise OcrServiceError(status.HTTP_422_UNPROCESSABLE_ENTITY, IMAGE_UNREADABLE)

    result = detect_barcode(img)
    if not result:
        raise OcrServiceError(status.HTTP_422_UNPROCESSABLE_ENTITY, "No barcode detected in the uploaded image.")

    return BarcodeResponse(barcode=result.value, type=result.type, confidence=result.confidence)


@router.post("/preprocess")
async def preprocess_preview(file: UploadFile = File(..., alias="image")):
    """Debugging aid — returns the preprocessed image itself (PNG), not JSON.
    Useful for tuning the preprocessing pipeline against real label photos."""
    raw_bytes = await validate_upload(file)
    try:
        gray, _quality = preprocessing.preprocess(raw_bytes)
    except ValueError:
        raise OcrServiceError(status.HTTP_422_UNPROCESSABLE_ENTITY, IMAGE_UNREADABLE)

    ok, encoded = cv2.imencode(".png", gray)
    if not ok:
        raise OcrServiceError(status.HTTP_500_INTERNAL_SERVER_ERROR, "Failed to encode preview image.")
    return Response(content=encoded.tobytes(), media_type="image/png")


@router.post("/cover")
async def enhanced_cover(file: UploadFile = File(..., alias="image")):
    """Enhanced cover photo made from the seller's real front photo (not generative AI):
    perspective flatten, GrabCut background removal, white balance, white square canvas.
    Returns a JPEG. Header X-Cover-Method says whether the background was removed."""
    raw_bytes = await validate_upload(file)
    try:
        result = make_cover(raw_bytes)
    except ValueError:
        raise OcrServiceError(status.HTTP_422_UNPROCESSABLE_ENTITY, IMAGE_UNREADABLE)
    ok, encoded = cv2.imencode(".jpg", result.image, [cv2.IMWRITE_JPEG_QUALITY, 92])
    if not ok:
        raise OcrServiceError(status.HTTP_500_INTERNAL_SERVER_ERROR, "Failed to encode cover image.")
    return Response(
        content=encoded.tobytes(),
        media_type="image/jpeg",
        headers={
            "X-Cover-Method": result.method,
            "X-Perspective-Corrected": "true" if result.perspective_corrected else "false",
            "Access-Control-Expose-Headers": "X-Cover-Method, X-Perspective-Corrected",
        },
    )
