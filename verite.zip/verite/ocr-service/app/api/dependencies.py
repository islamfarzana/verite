from fastapi import UploadFile

from app.core.config import settings
from app.utils.errors import OcrServiceError, UNSUPPORTED_FORMAT, FILE_TOO_LARGE
from fastapi import status


async def validate_upload(file: UploadFile) -> bytes:
    if file.content_type not in settings.ALLOWED_CONTENT_TYPES:
        raise OcrServiceError(status.HTTP_400_BAD_REQUEST, UNSUPPORTED_FORMAT)

    raw = await file.read()
    if len(raw) == 0:
        raise OcrServiceError(status.HTTP_400_BAD_REQUEST, UNSUPPORTED_FORMAT)
    if len(raw) > settings.MAX_UPLOAD_SIZE:
        raise OcrServiceError(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, FILE_TOO_LARGE)
    return raw
