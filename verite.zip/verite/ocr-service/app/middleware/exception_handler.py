from fastapi import Request, status
from fastapi.responses import JSONResponse

from app.core.logging import get_logger
from app.utils.errors import OcrServiceError, INTERNAL_ERROR

logger = get_logger("exceptions")


async def ocr_exception_handler(request: Request, exc: OcrServiceError) -> JSONResponse:
    return JSONResponse(status_code=exc.status_code, content={"success": False, "message": exc.message})


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    # Full detail goes to the log (server-side only); the client only ever
    # sees a generic message — Security.md §20.
    logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"success": False, "message": INTERNAL_ERROR},
    )
