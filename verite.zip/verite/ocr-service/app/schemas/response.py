from typing import Optional

from pydantic import BaseModel


class FieldValue(BaseModel):
    value: Optional[str] = None
    confidence: float = 0.0


class OcrFields(BaseModel):
    productName: FieldValue
    productNameBn: FieldValue = FieldValue()
    brand: FieldValue
    manufacturer: FieldValue
    batchNumber: FieldValue
    manufacturingDate: FieldValue
    expiryDate: FieldValue
    barcode: FieldValue
    mrp: FieldValue
    weight: FieldValue
    countryOfOrigin: FieldValue
    licenceNumber: FieldValue


class SideInfo(BaseModel):
    side: str  # front | back
    quality: str
    warnings: list[str] = []
    variant: str  # which preprocessed version read best
    perspectiveCorrected: bool = False
    rotatedDegrees: int = 0
    rawText: Optional[str] = None


class OcrResponse(BaseModel):
    success: bool = True
    processingTime: float
    quality: str
    fields: OcrFields
    rawText: Optional[str] = None
    # v4: languages found in the text ("bn", "en"), engine used, and per-photo details.
    languages: list[str] = []
    engine: Optional[str] = None
    sides: list[SideInfo] = []


class BarcodeResponse(BaseModel):
    success: bool = True
    barcode: str
    type: str
    confidence: float


class ErrorResponse(BaseModel):
    success: bool = False
    message: str


class HealthResponse(BaseModel):
    status: str
    service: str = "OCR"
    version: str
    ocr: str
    database: str


class VersionResponse(BaseModel):
    service: str = "OCR"
    version: str
    environment: str
