from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    APP_NAME: str = "OCR Service"
    VERSION: str = "1.0.0"
    APP_ENV: str = "development"
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG: bool = False

    # Upload limits — mirrors FR-01 / Security.md §9
    MAX_UPLOAD_SIZE: int = 10 * 1024 * 1024  # 10 MB
    ALLOWED_CONTENT_TYPES: List[str] = ["image/jpeg", "image/png", "image/webp"]
    MIN_IMAGE_DIMENSION: int = 200  # px — below this we still try, but flag quality as POOR

    # OCR engine selection — see services/ocr_engine.py
    # hybrid    = PaddleOCR for English + Tesseract for Bangla+English (default; best coverage)
    # paddleocr = PaddleOCR only (English; PaddleOCR has no Bengali model)
    # tesseract = Tesseract only (Bangla+English with TESSERACT_LANG)
    OCR_ENGINE: str = "hybrid"
    OCR_LANGUAGE: str = "en"
    OCR_USE_GPU: bool = False
    # Tesseract languages; "ben" needs the tesseract-ocr-ben package (installed in the Dockerfile).
    TESSERACT_LANG: str = "ben+eng"
    # Page segmentation mode: 3 = automatic layout, 11 = sparse text (packaging); both are tried.
    TESSERACT_PSM_MODES: List[int] = [3, 11]
    # Try several preprocessed variants of each photo and keep the one that reads best.
    OCR_TRY_VARIANTS: bool = True
    # Flatten the packet using its detected outline (four-point perspective transform).
    OCR_PERSPECTIVE_CORRECTION: bool = True
    # Auto-rotate 90/180/270 degrees using Tesseract's orientation detection (OSD).
    OCR_AUTO_ORIENT: bool = True

    # Auth: the marketplace backend authenticates end users; this service
    # only needs to trust that the CALLER is the marketplace backend.
    API_KEY: str = ""  # empty disables the check (dev convenience) — set in production
    REQUIRE_API_KEY: bool = False

    # Database — intentionally separate from the marketplace's SQLite DB.
    DATABASE_URL: str = "postgresql+psycopg2://ocr:ocr@postgres:5432/ocr"

    CORS_ORIGINS: List[str] = ["http://localhost:3000"]

    LOG_LEVEL: str = "INFO"
    ENABLE_METRICS: bool = True

    # Rate limiting — see api/dependencies.py
    RATE_LIMIT_PER_MINUTE: int = 60


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
