from fastapi import Header, HTTPException, status

from app.core.config import settings


async def verify_service_api_key(x_api_key: str | None = Header(default=None)) -> None:
    """
    The OCR service does not authenticate end users (buyers/sellers/admins) —
    that remains entirely the marketplace's responsibility (Security.md §4,
    §19; PRD "Out of Scope"). This only verifies the CALLER is the trusted
    marketplace backend, via a shared service API key. Disabled by default
    for local development (REQUIRE_API_KEY=false); enable in production.
    """
    if not settings.REQUIRE_API_KEY:
        return
    if not settings.API_KEY or x_api_key != settings.API_KEY:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized request.")
