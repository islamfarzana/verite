# AI OCR Microservice for FMCG Marketplace

Standalone FastAPI service: upload a product label image, get back structured
product fields. Completely independent of the Next.js marketplace — no
knowledge of users, sessions, blockchain, or product publishing. The
marketplace's `/api/ocr/extract` route is a thin proxy in front of this.

## Architecture

```
Seller Dashboard (Next.js)
        │
Upload Product Label
        │
Next.js /api/ocr/extract  (proxy — see verite-app/app/api/ocr/extract/route.ts)
        │
POST /api/v1/ocr/extract  (this service)
        │
OpenCV preprocessing → PaddleOCR → Barcode detection → Regex parser → Confidence engine
        │
Structured JSON
        │
Next.js auto-fills the existing Add Product form
```

## Run locally (Docker — recommended)

```bash
cd ocr-service
cp .env.example .env
docker compose up --build
```

Health check: `curl http://localhost:8000/health`
Interactive docs: http://localhost:8000/docs

## Run locally (without Docker)

Requires Python 3.12, and system packages `libzbar0` (pyzbar), `tesseract-ocr`
and `tesseract-ocr-ben` (Bengali; needed to read Bangla labels) installed via your
OS package manager. On Windows, install Tesseract and tick "Bengali" in the
additional languages.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Point DATABASE_URL at a local Postgres, or use SQLite for quick dev:
#   DATABASE_URL=sqlite:///./ocr_dev.db
uvicorn app.main:app --reload
```

## Tests

```bash
pip install -r requirements.txt
pytest
```

`test_dates.py` and `test_parser.py` are pure-Python and always run.
`test_health.py` boots the full FastAPI app, which will attempt to load
PaddleOCR at startup — if PaddleOCR/PaddlePaddle aren't installed in your
environment, this specific test will fail at the `TestClient` context-enter
step; the app falls back to Tesseract automatically if PaddleOCR fails to
load (see `app/services/ocr_engine.py::_load_paddleocr`), so having
`tesseract-ocr` on PATH is enough to get a green run without PaddleOCR.

## API

See `/docs` (Swagger UI) once running, or `API_Reference.md` in the parent
project's spec documents — this implementation matches that contract:

- `GET /health`, `GET /version`
- `POST /api/v1/ocr/extract` — multipart field `image` (front) and optional
  `backImage` (back of the pack) → `OcrResponse` (+ `languages`, `engine`, `sides`)
- `POST /api/v1/ocr/cover` — multipart field `image` → JPEG "enhanced cover"
  made from the real photo (GrabCut background removal, perspective flatten,
  white square); header `X-Cover-Method: grabcut | crop-only`
- `POST /api/v1/ocr/barcode` — multipart field `image` → barcode only
- `POST /api/v1/ocr/preprocess` — multipart field `image` → returns the
  preprocessed PNG (debugging aid)
- `GET /metrics` — Prometheus metrics (if `ENABLE_METRICS=true`)

## v4: Bangla + English, robustness, evaluation (2026-10-28)

- `OCR_ENGINE=hybrid` (default): PaddleOCR for English + Tesseract `ben+eng`
  for Bangla (PaddleOCR has no Bengali model). `tesseract` = Tesseract only.
- Bangla keyword rules, Bengali digits and month names, OCR-confusion
  tolerance; product name in both scripts (`productName`, `productNameBn`).
- Perspective flattening, auto-rotation (OSD), upscaling of small photos,
  three preprocessed variants with field-level voting
  (`app/services/extraction.py`).
- `scripts/evaluate.py`: field-level precision/recall on labelled photos,
  with ablations (English-only vs Bangla+English, with/without preprocessing
  and voting). Use it on 50–100 real labels for the thesis evaluation.
- Tests: `tests/test_bangla_parser.py`, `tests/test_synthetic_ocr.py`
  (renders Bangla labels; needs `ben` data and a Bengali font, else skipped),
  `tests/test_cover.py`, `tests/test_api_v4.py` (FastAPI).

## What's implemented vs. staged for later

Implemented and real (not stubbed):
- Full OpenCV pipeline: decode, resize, denoise (bilateral filter), CLAHE
  contrast enhancement, deskew (minAreaRect-based), sharpening, and a
  brightness/blur quality scorer.
- PaddleOCR as the primary engine, loaded once at startup; automatic
  fallback to Tesseract if PaddleOCR fails to load in a given environment.
- pyzbar barcode detection (EAN-13/UPC/Code128/QR), cross-checked against
  the regex-detected barcode.
- Regex parser covering product name (heuristic — see code comment),
  brand, manufacturer, batch number, MFG/EXP dates (multi-format, normalized
  to ISO), MRP, weight, country of origin, licence number — every field is
  `null` unless actually found, no fabricated values.
- Real per-field confidence, derived from the OCR engine's own confidence
  for the text region a value was found in — never a random/fake number.
- SQLAlchemy models + Postgres persistence of every request/result/field.
- Structured JSON logging, request-ID + timing middleware, global exception
  handler that never leaks stack traces.
- Dockerfile + docker-compose (service + its own Postgres, internal network,
  healthchecks, non-root user).
- Optional real Prometheus `/metrics` via `prometheus-fastapi-instrumentator`.

Staged for a later iteration (flagged honestly rather than faked):
- Full four-point perspective correction from contour detection (current
  preprocessing corrects rotation/skew but not camera-angle perspective
  distortion) — a naive contour-based version is unreliable on curved/
  glossy FMCG packaging and needs a trained document-detector to be worth
  shipping.
- AI-based reflection/shadow removal (current pipeline handles general
  contrast/lighting via CLAHE, but not targeted glare removal).
- Alembic migrations (tables are created via `Base.metadata.create_all` on
  startup for now — fine for getting started, swap for real migrations
  before depending on schema changes in production).
- Grafana dashboards / Alertmanager wiring (Prometheus metrics are real and
  exposed; the dashboards/alert rules themselves aren't included here).
- Multi-language OCR, nutrition-table extraction, and the other
  "Future Enhancements" sections across the spec docs.
